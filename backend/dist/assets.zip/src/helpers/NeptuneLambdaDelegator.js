"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeNeptuneRequest = exports.NeptuneLambdaDelegator = void 0;
const LambdaLogger_1 = require("../common/LambdaLogger");
const NeptuneScriptClient_1 = require("../common/neptune/NeptuneScriptClient");
class NeptuneLambdaDelegator {
    static replacer(key, value) {
        const originalObject = this[key];
        if (originalObject instanceof Map) {
            return {
                dataType: 'Map',
                value: Array.from(originalObject.entries())
            };
        }
        return value;
    }
    static reviver(key, value) {
        if (typeof value === 'object' && value !== null) {
            if (value.dataType === 'Map') {
                return new Map(value.value);
            }
        }
        return value;
    }
}
exports.NeptuneLambdaDelegator = NeptuneLambdaDelegator;
const executeNeptuneRequest = async (event) => {
    const neptuneRequest = event.request;
    (new LambdaLogger_1.LambdaLogger()).debug('executing', neptuneRequest);
    const LOCALSTACK_HOSTNAME = process.env.LOCALSTACK_HOSTNAME;
    (new LambdaLogger_1.LambdaLogger()).debug('localstack hostname is: ', LOCALSTACK_HOSTNAME);
    const neptuneScriptClient = new NeptuneScriptClient_1.NeptuneScriptClient(`ws://${LOCALSTACK_HOSTNAME}:4510/gremlin`);
    try {
        const result = await neptuneScriptClient.executeScript(neptuneRequest);
        return JSON.stringify(result, NeptuneLambdaDelegator.replacer);
    }
    finally {
        await neptuneScriptClient.closeConnection();
    }
};
exports.executeNeptuneRequest = executeNeptuneRequest;
