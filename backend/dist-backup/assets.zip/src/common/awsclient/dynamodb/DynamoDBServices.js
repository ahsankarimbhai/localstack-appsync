"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBServices = void 0;
const _ = __importStar(require("lodash"));
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const node_http_handler_1 = require("@smithy/node-http-handler");
const LambdaLogger_1 = require("../../LambdaLogger");
class DynamoDBServices {
    constructor(requestTimeout = 20000) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!process.env.ENV_PREFIX) {
            throw new Error('ENV_PREFIX is not set');
        }
        requestTimeout = +(process.env.DYNAMODB_REQUEST_TIMEOUT_MILLISECONDS || requestTimeout);
        this.tablePrefix = process.env.ENV_PREFIX;
        this.dynamoDBClient = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({
            region: process.env.AWS_REGION,
            logger: this.logger,
            maxAttempts: 5,
            requestHandler: new node_http_handler_1.NodeHttpHandler({
                requestTimeout
            })
        }), {
            marshallOptions: {
                convertClassInstanceToMap: true,
                removeUndefinedValues: true
            }
        });
    }
    static getTableName(tableName) {
        return `${process.env.ENV_PREFIX}-${tableName}`;
    }
    getByKey(tableName, key, value) {
        const configKey = {};
        configKey[`${key}`] = value;
        return this.dynamoDBClient.send(new lib_dynamodb_1.GetCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Key: configKey
        })).then((data) => data.Item).catch((error) => {
            throw error;
        });
    }
    getByCompositeKey(tableName, compositeKey) {
        return this.dynamoDBClient.send(new lib_dynamodb_1.GetCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Key: compositeKey
        })).then((data) => data.Item).catch((error) => {
            throw error;
        });
    }
    deleteByCompositeKey(tableName, compositeKey) {
        return this.dynamoDBClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Key: compositeKey
        }));
    }
    async batchDelete(tableName, ids) {
        const results = [];
        if (!_.isEmpty(ids)) {
            const chunks = _.chunk(ids, DynamoDBServices.BATCH_CHUNK_MAX_SIZE);
            for (const chunk of chunks) {
                const delReqs = chunk.map(id => ({ DeleteRequest: { Key: id } }));
                results.push(await this.dynamoDBClient.send(new lib_dynamodb_1.BatchWriteCommand({
                    RequestItems: {
                        [DynamoDBServices.getTableName(tableName)]: delReqs
                    }
                })));
            }
        }
        return results;
    }
    async batchUpdate(tableName, toUpdate) {
        const results = [];
        if (!_.isEmpty(toUpdate)) {
            const chunks = _.chunk(toUpdate, DynamoDBServices.BATCH_CHUNK_MAX_SIZE);
            for (const chunk of chunks) {
                const updateRequest = chunk.map(item => ({ PutRequest: { Item: item } }));
                results.push(await this.dynamoDBClient.send(new lib_dynamodb_1.BatchWriteCommand({
                    RequestItems: {
                        [DynamoDBServices.getTableName(tableName)]: updateRequest
                    }
                })));
            }
        }
        return results;
    }
    async getByPartitionKey(tableName, pkName, pkValue, consistentRead = false, lastEvaluatedKey) {
        const expressionAttributeNames = {};
        expressionAttributeNames[`#${pkName}`] = pkName;
        const expressionAttributeValues = {};
        expressionAttributeValues[`:v_${pkName}`] = pkValue;
        let returnItems = [];
        const response = await this.dynamoDBClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Select: 'ALL_ATTRIBUTES',
            KeyConditionExpression: `#${pkName} = :v_${pkName}`,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ExclusiveStartKey: lastEvaluatedKey,
            ConsistentRead: consistentRead
        })).then((data) => ({ items: data.Items, lastEvaluatedKey: data.LastEvaluatedKey }));
        if (response.lastEvaluatedKey) {
            returnItems = await this.getByPartitionKey(tableName, pkName, pkValue, consistentRead, response.lastEvaluatedKey);
        }
        return _.concat(response.items, returnItems);
    }
    getCountByPartitionKeyAndAttribute(tableName, pkName, pkValue, attrName, attrValue) {
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        expressionAttributeNames[`#${pkName}`] = pkName;
        expressionAttributeNames[`#${attrName}`] = attrName;
        expressionAttributeValues[`:v_${pkName}`] = pkValue;
        expressionAttributeValues[`:v_${attrName}`] = attrValue;
        return this.dynamoDBClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Select: 'COUNT',
            KeyConditionExpression: `#${pkName} = :v_${pkName}`,
            FilterExpression: `#${attrName} = :v_${attrName}`,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues
        }));
    }
    save(tableName, item) {
        return this.dynamoDBClient.send(new lib_dynamodb_1.PutCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Item: item
        }));
    }
    async update(tableName, key, values) {
        const updates = _.reduce(values, (r, v, k) => {
            if (v !== undefined) {
                r[k] = {
                    Action: 'PUT',
                    Value: v
                };
            }
            return r;
        }, {});
        const command = new lib_dynamodb_1.UpdateCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Key: key,
            AttributeUpdates: updates,
            ReturnValues: 'ALL_NEW'
        });
        command.middlewareStack.addRelativeTo((next) => async (args) => {
            const attributeNames = Object.getOwnPropertyNames(args.input.AttributeUpdates);
            for (const attributeName of attributeNames) {
                const attribute = args.input.AttributeUpdates[attributeName];
                if (attribute.Value) {
                    if (Array.isArray(attribute.Value)) {
                        attribute.Value = { L: attribute.Value };
                    }
                    const valueNames = Object.getOwnPropertyNames(attribute.Value);
                    if (valueNames.length > 1) {
                        this.nestValuesWithinDynamoDBAttribute(attribute, valueNames);
                    }
                    else if (valueNames.length === 1) {
                        const valueName = valueNames[0];
                        switch (valueName) {
                            case 'S':
                            case 'N':
                            case 'BOOL':
                            case 'NULL':
                            case 'L':
                            case 'M':
                            case 'BS':
                            case 'NS':
                            case 'SS':
                            case 'B':
                                continue;
                            default:
                                this.nestValuesWithinDynamoDBAttribute(attribute, valueNames);
                        }
                    }
                }
            }
            return next(args);
        }, {
            relation: 'after',
            toMiddleware: 'DocumentMarshall'
        });
        return this.dynamoDBClient.send(command);
    }
    nestValuesWithinDynamoDBAttribute(attribute, valueNames) {
        const nestedObject = {};
        for (const valueName of valueNames) {
            nestedObject[valueName] = attribute.Value[valueName];
        }
        attribute.Value = { M: nestedObject };
    }
    async removeProperties(tableName, key, ...properties) {
        const updates = _.reduce(properties, (r, k) => {
            r[k] = {
                Action: 'DELETE'
            };
            return r;
        }, {});
        return this.dynamoDBClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Key: key,
            AttributeUpdates: updates,
            ReturnValues: 'ALL_NEW'
        }));
    }
    getItemCountBySecondaryIndex(tableName, indexName, key, value, nonKeyFilterExpression, nonKeyFilterExpressionAttributeNames, nonKeyFilterExpressionAttributeValues) {
        return this.dynamoDBClient.send(new lib_dynamodb_1.QueryCommand(DynamoDBServices.getSecondaryIndexQuery(tableName, indexName, key, value, 'COUNT', nonKeyFilterExpression, nonKeyFilterExpressionAttributeNames, nonKeyFilterExpressionAttributeValues)));
    }
    async getItemsBySecondaryIndex(tableName, indexName, key, value, nonKeyFilterExpression, nonKeyFilterExpressionAttributeNames, nonKeyFilterExpressionAttributeValues, lastEvaluatedKey) {
        let returnItems = [];
        const response = await this.dynamoDBClient.send(new lib_dynamodb_1.QueryCommand(DynamoDBServices.getSecondaryIndexQuery(tableName, indexName, key, value, 'ALL_ATTRIBUTES', nonKeyFilterExpression, nonKeyFilterExpressionAttributeNames, nonKeyFilterExpressionAttributeValues, lastEvaluatedKey))).then((data) => ({ items: data.Items, lastEvaluatedKey: data.LastEvaluatedKey }));
        if (response.lastEvaluatedKey) {
            returnItems = await this.getItemsBySecondaryIndex(tableName, indexName, key, value, nonKeyFilterExpression, nonKeyFilterExpressionAttributeNames, nonKeyFilterExpressionAttributeValues, response.lastEvaluatedKey);
        }
        return _.concat(response.items, returnItems);
    }
    async getItemsByLocalSecondaryIndex(tableName, secondaryIndexName, secondaryIndexSortKey, secondaryIndexSortValue, secondaryIndexPartitionKey, secondaryIndexPartitionValue, lastEvaluatedKey) {
        const params = DynamoDBServices.getSecondaryIndexQuery(tableName, secondaryIndexName, secondaryIndexSortKey, secondaryIndexSortValue, 'ALL_ATTRIBUTES', undefined, undefined, undefined, lastEvaluatedKey, secondaryIndexPartitionKey, secondaryIndexPartitionValue);
        let returnItems = [];
        const response = await this.dynamoDBClient.send(new lib_dynamodb_1.QueryCommand(params)).then((data) => ({ items: data.Items, lastEvaluatedKey: data.LastEvaluatedKey }));
        if (response.lastEvaluatedKey) {
            returnItems = await this.getItemsByLocalSecondaryIndex(tableName, secondaryIndexName, secondaryIndexSortKey, secondaryIndexSortValue, secondaryIndexPartitionKey, secondaryIndexPartitionValue, response.lastEvaluatedKey);
        }
        return _.concat(response.items, returnItems);
    }
    static getSecondaryIndexQuery(tableName, indexName, key, value, selectScope, nonKeyFilterExpression, nonKeyFilterExpressionAttributeNames, nonKeyFilterExpressionAttributeValues, lastEvaluatedKey, secondaryIndexPartitionKey, secondaryIndexPartitionValue) {
        const expressionAttributeNames = {};
        expressionAttributeNames[`#${key}`] = key;
        const expressionAttributeValues = {};
        expressionAttributeValues[`:v_${key}`] = value;
        let isSecondaryIndexPartitionKeyUsing = false;
        if (secondaryIndexPartitionKey && secondaryIndexPartitionValue) {
            isSecondaryIndexPartitionKeyUsing = true;
            expressionAttributeNames[`#${secondaryIndexPartitionKey}`] = secondaryIndexPartitionKey;
            expressionAttributeValues[`:v_${secondaryIndexPartitionKey}`] = secondaryIndexPartitionValue;
        }
        if (nonKeyFilterExpressionAttributeNames) {
            _.map(nonKeyFilterExpressionAttributeNames, (v, k) => { expressionAttributeNames[k] = v; });
        }
        if (nonKeyFilterExpressionAttributeValues) {
            _.map(nonKeyFilterExpressionAttributeValues, (v, k) => { expressionAttributeValues[k] = v; });
        }
        return {
            TableName: DynamoDBServices.getTableName(tableName),
            IndexName: indexName,
            Select: selectScope,
            KeyConditionExpression: isSecondaryIndexPartitionKeyUsing ? `#${key} = :v_${key} AND #${secondaryIndexPartitionKey} = :v_${secondaryIndexPartitionKey}` : `#${key} = :v_${key}`,
            FilterExpression: nonKeyFilterExpression,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ExclusiveStartKey: lastEvaluatedKey
        };
    }
    delete(tableName, key, value) {
        const configKey = {};
        configKey[`${key}`] = value;
        return this.dynamoDBClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            Key: configKey
        }));
    }
    async getAllTableEntries(tableName, lastEvaluatedKey) {
        let returnItems = [];
        const response = await this.dynamoDBClient.send(new lib_dynamodb_1.ScanCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            ExclusiveStartKey: lastEvaluatedKey
        })).then((data) => ({ items: data.Items, lastEvaluatedKey: data.LastEvaluatedKey }));
        if (response.lastEvaluatedKey) {
            returnItems = await this.getAllTableEntries(tableName, response.lastEvaluatedKey);
        }
        return _.concat(returnItems, response.items);
    }
    getFilteredTableEntries(tableName, filterExpression, expressionAttributeValues, lastEvaluatedKey) {
        return this.dynamoDBClient.send(new lib_dynamodb_1.ScanCommand({
            TableName: DynamoDBServices.getTableName(tableName),
            FilterExpression: filterExpression,
            ExpressionAttributeValues: expressionAttributeValues,
            ExclusiveStartKey: lastEvaluatedKey
        })).then((data) => ({ items: data.Items, lastEvaluatedKey: data.LastEvaluatedKey }));
    }
    async getAllFilteredTableEntries(tableName, filterExpression, expressionAttributeValues, lastEvaluatedKey) {
        let returnItems = [];
        const response = await this.getFilteredTableEntries(tableName, filterExpression, expressionAttributeValues, lastEvaluatedKey);
        if (response.lastEvaluatedKey) {
            returnItems = await this.getAllFilteredTableEntries(tableName, filterExpression, expressionAttributeValues, response.lastEvaluatedKey);
        }
        return _.concat(returnItems, response.items);
    }
}
exports.DynamoDBServices = DynamoDBServices;
DynamoDBServices.KEY_SEPARATOR = '__';
DynamoDBServices.NOT_SOFT_DELETED = 'attribute_not_exists(deletedAt)';
DynamoDBServices.SOFT_DELETED = 'attribute_exists(deletedAt)';
DynamoDBServices.BATCH_CHUNK_MAX_SIZE = 25;
