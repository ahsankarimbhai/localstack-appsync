"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CyberVisionDevicesCollection = void 0;
const CyberVisionCollection_1 = require("./CyberVisionCollection");
class CyberVisionDevicesCollection extends CyberVisionCollection_1.CyberVisionCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.CyberVisionDevicesCollection = CyberVisionDevicesCollection;
