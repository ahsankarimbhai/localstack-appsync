"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericSourceFetcher = void 0;
const _ = __importStar(require("lodash"));
const GenericSourceConfiguration_1 = require("../../common/generic/GenericSourceConfiguration");
const LambdaLogger_1 = require("../../common/LambdaLogger");
class GenericSourceFetcher {
    constructor(clientPicker, tenantUid, sourceType, sourceId, apiDetails, limit) {
        this.clientPicker = clientPicker;
        this.tenantUid = tenantUid;
        this.sourceType = sourceType;
        this.sourceId = sourceId;
        this.apiDetails = apiDetails;
        this.limit = limit;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.shouldAbortRetry = (err) => {
            var _a;
            const abortCodes = new Set([400, 401, 403, 404]);
            if (err.response && abortCodes.has(err.response.status)) {
                this.logger.error(`Generic Source Fetcher query cannot be resolved (aborting retry) for ${this.tenantUid}__${this.sourceType}__${this.sourceId} because status=${err.response.status}, statusText=${err.response.statusText}, url=${(_a = err.config) === null || _a === void 0 ? void 0 : _a.baseURL}, and data=${JSON.stringify(err.response.data)}`);
                return true;
            }
            return false;
        };
        this.savedData = new Map();
        this.apiDetailsMap = new Map();
        for (let i = 0; i < apiDetails.length; i += 1) {
            const apiDetail = apiDetails[i];
            let name = `${i}`;
            if (apiDetail.metaData) {
                name = apiDetail.metaData.referenceName;
            }
            this.apiDetailsMap.set(name, apiDetail);
            if (!this.apiDetailsNext) {
                this.apiDetailsNext = name;
            }
        }
        if (!this.apiDetailsNext) {
            throw new Error(`No apiDetails in GenericSourceFetcher for source ${sourceType}`);
        }
    }
    getInitialUrlWithParams(fetchData) {
        if (!fetchData) {
            fetchData = this.apiDetailsMap.get(this.apiDetailsNext).fetchData;
        }
        const params = (fetchData.urlParamNamesAndValues) ? new Map(Object.entries(fetchData.urlParamNamesAndValues)) : new Map();
        if (fetchData.pagingParamName) {
            params.set(fetchData.pagingParamName, this.limit);
        }
        let paramString = '';
        for (const [key, value] of params.entries()) {
            paramString += `${key}=${value}&`;
        }
        paramString = paramString.substring(0, paramString.length - 1);
        return (fetchData.relativeUrl.indexOf('?') === -1) ? `${fetchData.relativeUrl}?${paramString}` : `${fetchData.relativeUrl}&${paramString}`;
    }
    async fetchNextPage(uri, retryUtil) {
        const fetchData = this.apiDetailsMap.get(this.apiDetailsNext).fetchData;
        if (!this.client) {
            this.client = this.clientPicker(fetchData);
        }
        this.preQueryHandlerForLoopUntilEmptyResponse(fetchData);
        let headers = fetchData.headers;
        if (headers) {
            headers = JSON.parse(this.substituteSavedDataInString(JSON.stringify(fetchData.headers)));
        }
        let body = fetchData.body;
        if (body) {
            body = this.substituteSavedDataInString(JSON.stringify(fetchData.body));
        }
        const queryResult = await this.doQuery(uri, retryUtil, fetchData.httpMethod || 'GET', headers, body);
        this.extractedData = this.extractData(fetchData, queryResult);
        if (fetchData.extractData.saveDataArrayName) {
            this.savedData.set(fetchData.extractData.saveDataArrayName, this.extractedData);
        }
        if (fetchData.loopUntilEmptyResponse && this.loopIterator !== undefined) {
            this.postQueryHandlerForLoopUntilEmptyResponse(fetchData, queryResult, uri);
        }
        else {
            this.nextUri = this.extractNextLink(fetchData, queryResult, uri);
        }
        return this.extractedData;
    }
    provideNextUri() {
        return this.nextUri;
    }
    preQueryHandlerForLoopUntilEmptyResponse(fetchData) {
        if (fetchData.loopUntilEmptyResponse) {
            if (!this.loopIterator) {
                this.loopIterator = fetchData.loopUntilEmptyResponse.iteratorStart || 0;
            }
            if (fetchData.loopUntilEmptyResponse.iteratorValueName) {
                this.savedData.set(fetchData.loopUntilEmptyResponse.iteratorValueName, this.loopIterator);
            }
            if (fetchData.loopUntilEmptyResponse.iteratorIncrement && fetchData.loopUntilEmptyResponse.iteratorRangeName) {
                this.savedData.set(fetchData.loopUntilEmptyResponse.iteratorRangeName, this.loopIterator + fetchData.loopUntilEmptyResponse.iteratorIncrement);
            }
        }
    }
    postQueryHandlerForLoopUntilEmptyResponse(fetchData, res, uri) {
        if (fetchData.loopUntilEmptyResponse && this.loopIterator !== undefined) {
            if (Array.isArray(this.extractedData) && this.extractedData.length === 0) {
                this.loopIterator = undefined;
                this.client = undefined;
                this.nextUri = undefined;
                return true;
            }
            this.loopIterator = (fetchData.loopUntilEmptyResponse.iteratorIncrement) ? this.loopIterator + fetchData.loopUntilEmptyResponse.iteratorIncrement : this.loopIterator + this.limit;
            this.nextUri = this.extractNextLink(fetchData, res, uri);
        }
        return false;
    }
    substituteSavedDataInString(data) {
        for (const [key, value] of this.savedData) {
            let regex = `(\\$\{${key}})`;
            if (typeof value === 'number') {
                regex = `("\\$\{${key}}")`;
            }
            data = data.replace(new RegExp(regex, 'g'), value);
        }
        return data;
    }
    async doQuery(uri, retryUtil, httpMethod, headers, body) {
        return retryUtil.executeWithRetry(() => this.client.options(uri, httpMethod, body, { headers }), (err) => this.shouldAbortRetry(err), (err) => this.handleFailure(err, () => { throw err; })).then((result) => Promise.resolve(result));
    }
    handleFailure(err, reject) {
        this.logger.error(`Generic Source Fetcher query failed all retries for ${this.tenantUid}__${this.sourceType}__${this.sourceId} where error message=${err.message}`);
        if (err.lastError && err.lastError.response) {
            this.logger.error(`lastError status=${err.lastError.response.status}, statusText=${err.lastError.response.statusText}, url=${err.lastError.config.baseURL}, and data=${JSON.stringify(err.lastError.response.data)}`);
        }
        reject(err);
    }
    extractNextLink(fetchData, res, uri) {
        if (fetchData.extractNextLink) {
            if (fetchData.extractNextLink.source === GenericSourceConfiguration_1.ExtractNextLinkSource.RESPONSE) {
                const relevantFieldContent = _.get(res, fetchData.extractNextLink.path);
                if (relevantFieldContent !== undefined) {
                    if (fetchData.extractNextLink.regex) {
                        const regex = new RegExp(fetchData.extractNextLink.regex);
                        const match = relevantFieldContent.match(regex);
                        if (match) {
                            if (fetchData.extractNextLink.captureGroupName && match.groups[fetchData.extractNextLink.captureGroupName]) {
                                return _.get(match.groups, fetchData.extractNextLink.captureGroupName);
                            }
                            return match[0];
                        }
                    }
                    else {
                        return relevantFieldContent;
                    }
                }
            }
            else if (fetchData.extractNextLink.source === GenericSourceConfiguration_1.ExtractNextLinkSource.QUERY) {
                return uri;
            }
        }
        return undefined;
    }
    extractData(fetchData, res) {
        return _.get(res, fetchData.extractData.path);
    }
}
exports.GenericSourceFetcher = GenericSourceFetcher;
