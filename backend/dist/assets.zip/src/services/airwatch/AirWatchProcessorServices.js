"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AirWatchProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const AirWatchEndpointService_1 = require("../../collectors/services/AirWatchEndpointService");
class AirWatchProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(airWatchDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, airWatchDevice.DeviceReportedName, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        await this.verifyChange(currentTopology, airWatchDevice.UserEmailAddress, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
        await this.verifyChange(currentTopology, airWatchDevice.MacAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        await this.verifyChange(currentTopology, airWatchDevice.SerialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, airWatchDevice.Imei, CommonTypes_1.VertexType.IMEI, changes, unchanged);
        await this.verifyChange(currentTopology, airWatchDevice.PhoneNumber, CommonTypes_1.VertexType.PHONE_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, airWatchDevice.Udid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        await this.verifyChange(currentTopology, airWatchDevice.UserName, CommonTypes_1.VertexType.USER, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new AirWatchEndpointService_1.AirWatchEndpointService(tenantUid, sourceId);
    }
}
exports.AirWatchProcessorServices = AirWatchProcessorServices;
