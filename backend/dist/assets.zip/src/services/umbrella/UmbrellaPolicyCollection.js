"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UmbrellaPolicyCollection = void 0;
const UmbrellaCollection_1 = require("./UmbrellaCollection");
const UmbrellaRoamingComputersCollection_1 = require("./UmbrellaRoamingComputersCollection");
class UmbrellaPolicyCollection extends UmbrellaCollection_1.UmbrellaCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker, UmbrellaPolicyCollection.RETRY_CONFIG, () => undefined);
        this.functionState = functionState;
    }
}
exports.UmbrellaPolicyCollection = UmbrellaPolicyCollection;
UmbrellaPolicyCollection.RETRY_CONFIG = {
    retries: 5,
    delay: UmbrellaRoamingComputersCollection_1.UmbrellaRoamingComputersCollection.RETRY_CONFIG.delay,
    backoff: 'NEXT_RETRY_DELAY'
};
