"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SavedFilter = exports.SavedFilterServices = void 0;
const lodash_1 = __importDefault(require("lodash"));
const DynamoDBServices_1 = require("./awsclient/dynamodb/DynamoDBServices");
const LambdaLogger_1 = require("./LambdaLogger");
const DynamodbServiceFactory_1 = require("./awsclient/dynamodb/DynamodbServiceFactory");
class SavedFilterServices {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async add(tenantId, name, definition) {
        await this.verifyDistinctName(tenantId, name);
        return this.dynamoDBServices.save(SavedFilter.TABLE_NAME, new SavedFilter(tenantId, name, definition));
    }
    getByKey(tenantId, name) {
        const key = SavedFilter.createFilterKey(tenantId, name);
        return this.dynamoDBServices.getByKey(SavedFilter.TABLE_NAME, SavedFilter.FILTER_KEY, key);
    }
    deleteByKey(tenantId, name) {
        const key = SavedFilter.createFilterKey(tenantId, name);
        return this.dynamoDBServices.delete(SavedFilter.TABLE_NAME, SavedFilter.FILTER_KEY, key);
    }
    async getSavedFilters(tenantId, lastEvaluatedKey, filterExpression = `begins_with(${SavedFilter.FILTER_KEY}, :tenantId)`) {
        let returnItems = [];
        const response = await this.dynamoDBServices.getFilteredTableEntries(SavedFilter.TABLE_NAME, filterExpression, { ':tenantId': tenantId }, lastEvaluatedKey);
        if (response.lastEvaluatedKey) {
            returnItems = await this.getSavedFilters(tenantId, response.lastEvaluatedKey, filterExpression);
        }
        return lodash_1.default.concat(returnItems, response.items);
    }
    async deleteAllSavedFilters(tenantId) {
        this.logger.info(`All saved filters for the tenant ${tenantId} will be deleted`);
        const savedFilters = await this.getSavedFilters(tenantId);
        await this.dynamoDBServices.batchDelete(SavedFilter.TABLE_NAME, savedFilters.map(sf => ({ filterKey: sf.filterKey })));
    }
    async verifyDistinctName(tenantId, name) {
        const allSavedFilters = await this.getSavedFilters(tenantId);
        if (lodash_1.default.find(allSavedFilters, { name })) {
            throw new Error(`Filter with name [${name}] already exists`);
        }
    }
}
exports.SavedFilterServices = SavedFilterServices;
class SavedFilter {
    constructor(tenantId, name, definition) {
        this.tenantId = tenantId;
        this.name = name;
        this.definition = definition;
        this.filterKey = SavedFilter.createFilterKey(tenantId, name);
    }
    static createFilterKey(tenantId, name) {
        return lodash_1.default.join([tenantId, name], DynamoDBServices_1.DynamoDBServices.KEY_SEPARATOR);
    }
}
exports.SavedFilter = SavedFilter;
SavedFilter.TABLE_NAME = 'saved-filter';
SavedFilter.FILTER_KEY = 'filterKey';
