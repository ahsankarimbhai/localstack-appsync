"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdpKeyClient = void 0;
const LambdaLogger_1 = require("../LambdaLogger");
const Util_1 = require("../Util");
const _ = __importStar(require("lodash"));
const RetryUtil_1 = require("../RetryUtil");
const jwksClient = require('jwks-rsa');
class IdpKeyClient {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.idpClient = jwksClient({
            cache: true,
            cacheMaxAge: IdpKeyClient.CACHE_MAX_SIZE,
            strictSsl: true,
            timeout: +(process.env.JWKS_CLIENT_TIMEOUT_MILLISECONDS || 3000),
            jwksUri: this.getJwksUri()
        });
    }
    async getSigningKey(header) {
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, {
            retries: 2,
            backoff: 'FIXED',
            delay: 100,
            retryIf: (err) => { var _a; return ((_a = err.code) === null || _a === void 0 ? void 0 : _a.toUpperCase()) === 'ECONNRESET'; }
        });
        try {
            const signingKey = await retryUtil.executeWithRetry(async () => {
                const key = await this.idpClient.getSigningKey(header.kid);
                return key.publicKey || key.rsaPublicKey;
            });
            return signingKey;
        }
        catch (err) {
            this.logger.error(`Failed to get signing key ${header.kid}, err: ${err.message}`);
        }
        return undefined;
    }
    getUserId(decodedToken) {
        return {
            id: _.get(decodedToken, IdpKeyClient.SUB_CLAIM)
        };
    }
    verifyAudience(decodedToken, resource) {
    }
    isAdmin(decodedToken) {
        return _.isEqual(this.getRole(decodedToken), 'admin') || this.isAdminScope(decodedToken);
    }
    static valueIncluded(decodedToken, claim, ...values) {
        const claimValues = _.get(decodedToken, claim);
        return _.some(claimValues, value => _.indexOf(values, value) !== -1);
    }
}
exports.IdpKeyClient = IdpKeyClient;
IdpKeyClient.DEFAULT_ROLE = Util_1.ROLE_READONLY;
IdpKeyClient.CACHE_MAX_SIZE = 86400000;
IdpKeyClient.AUDIENCE_CLAIM = 'aud';
IdpKeyClient.SUB_CLAIM = 'sub';
