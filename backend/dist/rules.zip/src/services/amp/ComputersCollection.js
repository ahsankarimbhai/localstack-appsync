"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComputersCollection = void 0;
const AmpCollection_1 = require("./AmpCollection");
class ComputersCollection extends AmpCollection_1.AmpCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker, ComputersCollection.RETRY_CONFIG);
        this.functionState = functionState;
        this.updatedRecords = (record) => {
            const last = this.functionState.lastSuccessfulSequence;
            const timestamp = record.last_seen ? Date.parse(record.last_seen) : 0;
            return (!last || !timestamp || (timestamp >= last));
        };
    }
}
exports.ComputersCollection = ComputersCollection;
ComputersCollection.RETRY_CONFIG = {
    retries: 3,
    delay: 5000,
    timeout: 120000,
    backoff: 'NEXT_RETRY_DELAY'
};
