"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookResiliencyHandler = void 0;
const LambdaLogger_1 = require("../../../common/LambdaLogger");
const WebhookRegistrationRepo_1 = require("../../../common/dynamoDBRepo/WebhookRegistrationRepo");
const WebhookNotificationRepo_1 = require("../../../common/dynamoDBRepo/WebhookNotificationRepo");
class WebhookResiliencyHandler {
    constructor() {
        this.webhookRegistrationRepo = new WebhookRegistrationRepo_1.WebhookRegistrationRepo();
        this.webhookNotificationRepo = new WebhookNotificationRepo_1.WebhookNotificationRepo();
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.maxAllowedWebhookDispatchAttempts = +(process.env.MAX_ALLOWED_DS_WEBHOOK_DISPATCH_ATTEMPTS || 15);
    }
    async resetFailedAttempt(webhookId) {
        try {
            const webhookNotification = await this.webhookNotificationRepo.getByWebhookId(webhookId);
            if (!webhookNotification || (webhookNotification.failedAttempts || 0) <= 0) {
                return;
            }
            await this.webhookNotificationRepo.update(webhookId, 0);
        }
        catch (err) {
            this.logger.error(`failed to resetFailedAttempt for webhook ${webhookId}, err: ${err.message}`);
        }
    }
    async handleFailure(webhookId) {
        try {
            const webhookNotification = await this.webhookNotificationRepo.getByWebhookId(webhookId);
            const failedAttempts = (webhookNotification === null || webhookNotification === void 0 ? void 0 : webhookNotification.failedAttempts) || 0;
            if (failedAttempts >= this.maxAllowedWebhookDispatchAttempts) {
                this.logger.info(`failed to dispatch notifications continuously more than ${this.maxAllowedWebhookDispatchAttempts} times for webhook ${webhookId}, will suspend it`);
                await this.webhookRegistrationRepo.update(webhookId, undefined, undefined, undefined, undefined, undefined, WebhookRegistrationRepo_1.WebhookRegistrationStatus.SUSPEND);
                return;
            }
            await this.webhookNotificationRepo.upsert({
                webhookId,
                failedAttempts: failedAttempts + 1
            });
        }
        catch (err) {
            this.logger.error(`failed to handleFailure for webhook ${webhookId}, err: ${err.message}`);
        }
    }
}
exports.WebhookResiliencyHandler = WebhookResiliencyHandler;
