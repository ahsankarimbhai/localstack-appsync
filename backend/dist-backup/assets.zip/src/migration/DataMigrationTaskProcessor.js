"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalDataMigrationTaskProcessor = exports.DataMigrationTaskProcessor = exports.NeptuneDataMigrationTaskProcessor = void 0;
const NeptuneDBScheduledTaskProcessor_1 = require("../scheduled/NeptuneDBScheduledTaskProcessor");
const DataMigrationStatusHandler_1 = require("./DataMigrationStatusHandler");
const BasicScheduledTaskProcessor_1 = require("../scheduled/BasicScheduledTaskProcessor");
const BatchTaskServices_1 = require("../common/BatchTaskServices");
class NeptuneDataMigrationTaskProcessor extends NeptuneDBScheduledTaskProcessor_1.NeptuneDBScheduledTaskProcessor {
    getStatusHandler() {
        return new DataMigrationStatusHandler_1.DataMigrationStatusHandler(this.getTaskName(), this.tenantUid, this.producer);
    }
}
exports.NeptuneDataMigrationTaskProcessor = NeptuneDataMigrationTaskProcessor;
class DataMigrationTaskProcessor extends BasicScheduledTaskProcessor_1.BasicScheduledTaskProcessor {
    getStatusHandler() {
        return new DataMigrationStatusHandler_1.DataMigrationStatusHandler(this.getTaskName(), this.tenantUid, this.producer);
    }
}
exports.DataMigrationTaskProcessor = DataMigrationTaskProcessor;
class GlobalDataMigrationTaskProcessor extends DataMigrationTaskProcessor {
    constructor(taskParams) {
        super(BatchTaskServices_1.TaskScope.GLOBAL, undefined, taskParams);
    }
    getStatusHandler() {
        return new DataMigrationStatusHandler_1.DataMigrationStatusHandler(this.getTaskName(), this.tenantUid);
    }
}
exports.GlobalDataMigrationTaskProcessor = GlobalDataMigrationTaskProcessor;
