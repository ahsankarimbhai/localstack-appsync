"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnknownDuoHostnameMigration = void 0;
const elastic_builder_1 = __importDefault(require("elastic-builder"));
const Util_1 = require("../../common/Util");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
class UnknownDuoHostnameMigration extends DataMigrationTaskProcessor_1.DataMigrationTaskProcessor {
    async execute() {
        var _a;
        this.logger.debug('Starting delete unknown hostname endpoints', this.tenantUid);
        const boolQuery = elastic_builder_1.default.boolQuery();
        const queries = [];
        queries.push(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        queries.push(elastic_builder_1.default.queryStringQuery('producers.type:Duo AND producers.uid.keyword:*__undefined__duoEndpoint__Duo__*').allowLeadingWildcard(true));
        const elasticSearchClient = (0, ElasticsearchFactory_1.getElasticSearchClient)();
        const deleteByQueryResponse = await elasticSearchClient.deleteByQuery({
            wait_for_completion: false,
            conflicts: 'proceed',
            index: ElasticsearchServices_1.ElasticsearchServices.INDEX_NAME,
            body: elastic_builder_1.default.requestBodySearch()
                .query(boolQuery.must(queries))
        });
        if (!((_a = deleteByQueryResponse === null || deleteByQueryResponse === void 0 ? void 0 : deleteByQueryResponse.body) === null || _a === void 0 ? void 0 : _a.task)) {
            return Promise.reject(new Error(`Failed registering deleteByQuery execution, tenantId=${this.tenantUid}`));
        }
        this.logger.debug('deleteByQueryResponse', deleteByQueryResponse.body);
        const deleteByQueryTask = deleteByQueryResponse.body.task;
        let processing = true;
        while (processing) {
            await (0, Util_1.delay)(ElasticsearchServices_1.ElasticsearchServices.DELETE_TENANT_TASK_STATUS_WAIT_TIME);
            const result = await elasticSearchClient.tasks.get({
                task_id: deleteByQueryTask
            });
            if (!(result === null || result === void 0 ? void 0 : result.body)) {
                return Promise.reject(new Error(`Failed to check deleteByQuery task=${deleteByQueryTask} execution, tenantId=${this.tenantUid}`));
            }
            this.logger.debug('ES delete task result', result.body);
            processing = processing && !result.body.completed;
        }
        this.logger.debug('Finished delete unknown hostname endpoints', this.tenantUid);
        return Promise.resolve();
    }
    getTaskName() {
        return UnknownDuoHostnameMigration.TASK_NAME;
    }
}
exports.UnknownDuoHostnameMigration = UnknownDuoHostnameMigration;
UnknownDuoHostnameMigration.TASK_NAME = 'unknown-duo-hostname-migration';
