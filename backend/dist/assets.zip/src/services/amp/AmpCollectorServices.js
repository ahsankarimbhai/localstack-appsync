"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AmpCollectorServices = void 0;
const _ = __importStar(require("lodash"));
const Services_1 = require("../../common/Services");
const Util_1 = require("../../common/Util");
const ComputersCollection_1 = require("./ComputersCollection");
const TenantServices_1 = require("../../common/TenantServices");
const CommonTypes_1 = require("../../common/CommonTypes");
const JwtHelper_1 = require("../../common/tokenhelper/JwtHelper");
const GroupsCollection_1 = require("./GroupsCollection");
const VulnerabilitiesCollection_1 = require("./VulnerabilitiesCollection");
const AwsSecretsService_1 = require("../../common/AwsSecretsService");
const PoliciesCollection_1 = require("./PoliciesCollection");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const LIMIT = 500;
class AmpCollectorServices extends Services_1.BasePushCollectorService {
    constructor(secrets, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.functionName = functionName;
        this.sourceId = sourceId;
        this.webhookAuthToken = secrets === null || secrets === void 0 ? void 0 : secrets.webhookAuthToken;
        this.webhookSecret = secrets === null || secrets === void 0 ? void 0 : secrets.webhookSecret;
        this.webhookSource = `${CommonTypes_1.Source.AMP}${Util_1.SOURCE_SEPARATOR}${this.sourceId}`;
        this.cfgKey = `amp_webhook_id__${this.sourceId}`;
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.AMP, this.sourceId);
        }
    }
    async getGroups(timeBasedAsyncLambdaInvoker, nextUri) {
        const url = nextUri || `/v1/groups?limit=${LIMIT}`;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.AMP));
        if (!this.client) {
            await this.init();
        }
        return new GroupsCollection_1.GroupsCollection(this.client, url, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getPolicies(timeBasedAsyncLambdaInvoker, nextUri) {
        const url = nextUri || `/v1/policies?limit=${LIMIT}`;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.AMP));
        if (!this.client) {
            await this.init();
        }
        return new PoliciesCollection_1.PoliciesCollection(this.client, url, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getVulnerabilities(timeBasedAsyncLambdaInvoker, nextUri) {
        const url = nextUri || `/v1/vulnerabilities?limit=${LIMIT}`;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.AMP));
        if (!this.client) {
            await this.init();
        }
        return new VulnerabilitiesCollection_1.VulnerabilitiesCollection(this.client, url, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getVulnerabilityComputers(timeBasedAsyncLambdaInvoker, nextUri, sha256) {
        if (!nextUri && !sha256) {
            throw new Error('next URI or file checksum is required');
        }
        const url = nextUri || `/v1/vulnerabilities/${sha256}/computers?limit=${LIMIT}`;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.AMP));
        if (!this.client) {
            await this.init();
        }
        return new VulnerabilitiesCollection_1.VulnerabilityComputersCollection(this.client, url, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getComputers(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        const bulkLength = limit || LIMIT;
        const url = nextUri || `/v1/computers?limit=${bulkLength}`;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.AMP));
        if (!this.client) {
            await this.init();
        }
        return new ComputersCollection_1.ComputersCollection(this.client, url, timeBasedAsyncLambdaInvoker, functionState);
    }
    async registerWebhook(tenantWebhookReceiverUrl) {
        await this.initWebhookToken();
        const additionalHeaders = {};
        additionalHeaders[JwtHelper_1.AMP_TENANT_UID_HEADER_NAME] = [this.tenantUid, CommonTypes_1.Source.AMP, this.sourceId].join(Util_1.SOURCE_SEPARATOR);
        if (!this.client) {
            await this.init();
        }
        const res = await this.client.post('/v1/webhook_subscriptions', {
            name: `${this.tenantUid}-posaas-hook`,
            authentication: {
                type: 'token',
                value: this.webhookAuthToken
            },
            sha256_secret: this.webhookSecret,
            url: tenantWebhookReceiverUrl,
            actions: {
                computers: AmpCollectorServices.ACTIONS
            },
            additional_headers: additionalHeaders
        });
        const tenantConfiguration = new TenantServices_1.TenantConfiguration(this.tenantUid, this.cfgKey, res.data.data.id, 'AMP Webhook ID');
        const tenantServices = new TenantServices_1.TenantServices();
        await tenantServices.addTenantConfiguration(tenantConfiguration);
        return res;
    }
    async removeWebhook(webhookSubscriptionId) {
        await this.init();
        return this.client.delete(`/v1/webhook_subscriptions/${webhookSubscriptionId}`);
    }
    async initWebhookToken() {
        const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(this.tenantUid);
        await awsSecretsService.init();
        const secrets = awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, this.sourceId));
        if (!(secrets === null || secrets === void 0 ? void 0 : secrets.webhookSecret)) {
            this.logger.info(`generating webhook token and secret for tenant ${this.tenantUid} and AMP producer ${this.sourceId}`);
            this.webhookAuthToken = (0, Util_1.generateSecret)(32);
            this.webhookSecret = (0, Util_1.generateSecret)(32);
            await awsSecretsService.setSecretValue((0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, this.sourceId), { ...secrets || {}, webhookSecret: this.webhookSecret, webhookAuthToken: this.webhookAuthToken }, true);
        }
        else {
            this.webhookAuthToken = secrets === null || secrets === void 0 ? void 0 : secrets.webhookAuthToken;
            this.webhookSecret = secrets === null || secrets === void 0 ? void 0 : secrets.webhookSecret;
        }
    }
    async removeWebhookSecrets(sourceString, secrets) {
        if ((secrets === null || secrets === void 0 ? void 0 : secrets.webhookAuthToken) || (secrets === null || secrets === void 0 ? void 0 : secrets.webhookSecret)) {
            await super.removeWebhookSecrets(sourceString, secrets);
            if (secrets.ampApiKey) {
                const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(this.tenantUid);
                await awsSecretsService.setSecretValue((0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, this.sourceId), { ampApiKey: secrets.ampApiKey }, true);
            }
        }
        this.webhookAuthToken = undefined;
        this.webhookSecret = undefined;
    }
    async registerWebhooks() {
        if (!process.env.GW_API_PRODUCER_NOTIFICATION_URL) {
            throw new Error('GW_API_PRODUCER_NOTIFICATION_URL is not set');
        }
        await this.registerWebhook(process.env.GW_API_PRODUCER_NOTIFICATION_URL);
    }
    async getRegisteredWebhook() {
        const tenantServices = new TenantServices_1.TenantServices();
        const existingWebhooksConfig = await tenantServices.getTenantConfiguration(this.tenantUid, this.cfgKey);
        if (existingWebhooksConfig) {
            return existingWebhooksConfig.value;
        }
        return Promise.resolve();
    }
    async removeWebhooks() {
        const webhookId = await this.getRegisteredWebhook();
        if (webhookId) {
            await this.removeWebhook(webhookId);
        }
        const tenantServices = new TenantServices_1.TenantServices();
        await tenantServices.deleteTenantConfiguration(this.tenantUid, this.cfgKey);
    }
    async removeFailingWebhooks(failingSourceId, whatIf = true) {
        await this.init();
        const tenantServices = new TenantServices_1.TenantServices();
        const webhookType = this.cfgKey.split(Util_1.SOURCE_SEPARATOR)[0];
        const failingWebhookKey = (0, Util_1.toSourceString)(webhookType, failingSourceId);
        const failingWebhook = await tenantServices.getTenantConfiguration(this.tenantUid, failingWebhookKey);
        if (!failingWebhook) {
            this.logger.error(`No webhook found where tenantUid=${this.tenantUid}, source=${webhookType}, sourceId=${failingSourceId}`);
            throw new Error('No webhook found');
        }
        const failingWebhookId = failingWebhook.value;
        if (!failingWebhookId) {
            this.logger.error(`No webhook ID found when removing AMP webhook where tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.AMP}, activeSourceId=${this.sourceId}, failingSourceId=${failingSourceId}`);
            throw new Error('No webhook ID found');
        }
        try {
            if (!whatIf) {
                await this.removeWebhook(failingWebhookId);
                this.logger.debug(`Deleted AMP webhook ID ${failingWebhookId} where tenantUid=${this.tenantUid}, sourceId=${failingSourceId}`);
                await tenantServices.deleteTenantConfiguration(this.tenantUid, failingWebhookKey);
            }
            else {
                this.logger.debug(`(whatif) will attempt to remove AMP webhook where id=${failingWebhookId}, tenantUid=${this.tenantUid}, source=${webhookType}, failingSourceId=${failingSourceId} using the credentials from activeSourceId=${this.sourceId}`);
            }
        }
        catch (ex) {
            this.logger.error(`Error occurred removing AMP webhook where error=${ex.message}, tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.AMP}, activeSourceId=${this.sourceId}, failingSourceId=${failingSourceId}, webhookId=${failingWebhookId}`);
            return Promise.reject(ex);
        }
        return Promise.resolve(true);
    }
    hasRegisteredWebhooks() {
        return this.getRegisteredWebhook();
    }
    async getWebhookStatus() {
        var _a, _b, _c, _d;
        const webhookId = await this.getRegisteredWebhook();
        if (!webhookId) {
            return this.errorStatus(this.webhookSource, 'No webhook registered', 'AMP webhook is not registered', false);
        }
        if (!this.client) {
            await this.init();
        }
        let webhookDetails;
        try {
            webhookDetails = await this.client.get(`/v1/webhook_subscriptions/${webhookId}`);
        }
        catch (e) {
            return this.errorStatus(this.webhookSource, 'Error fetching webhook status', `get webhook ${webhookId} returned error ${e.message}`, true, `response error: ${(_b = (_a = e.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error}, response error description: ${(_d = (_c = e.response) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.error_description}`);
        }
        if (_.get(webhookDetails.data, 'data.status') !== 'active') {
            return this.errorStatus(this.webhookSource, 'Webhook is not active', `expected webhook ${webhookId} to be active`);
        }
        const actions = _.get(webhookDetails.data, 'data.actions.computers');
        if (_.size(actions) !== 3) {
            return this.errorStatus(this.webhookSource, 'Number of registered actions is incorrect', `mismatch in actions. actual: ${actions} expected: ${AmpCollectorServices.ACTIONS}`);
        }
        for (const action of AmpCollectorServices.ACTIONS) {
            if (!_.includes(actions, action)) {
                return this.errorStatus(this.webhookSource, 'Incorrect webhook actions are registered', `mismatch in actions. actual: ${actions} expected: ${AmpCollectorServices.ACTIONS}`);
            }
        }
        return new Services_1.WebhookStatus(this.webhookSource, 'success');
    }
}
exports.AmpCollectorServices = AmpCollectorServices;
AmpCollectorServices.ACTIONS = ['created', 'updated', 'deleted'];
