"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohModulesSyncScheduleTimeMigration = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const ScheduleServices_1 = require("../../common/ScheduleServices");
const DynamodbServiceFactory_1 = require("../../common/awsclient/dynamodb/DynamodbServiceFactory");
class IrohModulesSyncScheduleTimeMigration extends DataMigrationTaskProcessor_1.DataMigrationTaskProcessor {
    async execute() {
        this.logger.debug('Starting iroh sync scheduled time migration', this.tenantUid);
        const key = {};
        key[ScheduleServices_1.ScheduledTask.TASK_KEY] = ScheduleServices_1.ScheduledTask.getKey('iroh-sync-producers', this.tenantUid, undefined);
        const update = {
            schedule: '*/10 * * * *'
        };
        await (0, DynamodbServiceFactory_1.getDynamoDBService)().update(ScheduleServices_1.ScheduledTask.TABLE_NAME, key, update);
        this.logger.debug('Finished iroh sync scheduled time endpoints', this.tenantUid);
        return Promise.resolve();
    }
    getTaskName() {
        return IrohModulesSyncScheduleTimeMigration.TASK_NAME;
    }
}
exports.IrohModulesSyncScheduleTimeMigration = IrohModulesSyncScheduleTimeMigration;
IrohModulesSyncScheduleTimeMigration.TASK_NAME = 'iroh-sync-scheduling-migration';
