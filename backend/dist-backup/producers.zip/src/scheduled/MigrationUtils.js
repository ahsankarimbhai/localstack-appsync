"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.moveSecretToConfigHelper = exports.moveSecretToConfig = void 0;
const lodash_1 = __importDefault(require("lodash"));
const TenantServices_1 = require("../common/TenantServices");
const AwsSecretsService_1 = require("../common/AwsSecretsService");
const Util_1 = require("../common/Util");
const LambdaLogger_1 = require("../common/LambdaLogger");
const logger = new LambdaLogger_1.LambdaLogger();
async function moveSecretToConfig(tenantUid, source, secretName, propertyName) {
    const secretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await secretsService.init();
    return moveSecretToConfigHelper(secretsService, { source, properties: [{ secretName, propertyName }] });
}
exports.moveSecretToConfig = moveSecretToConfig;
async function moveSecretToConfigHelper(secretsService, sourceProperties) {
    const tenantServices = new TenantServices_1.TenantServices();
    const producerConfigurations = await tenantServices.getProducerConfigurations(secretsService.scope);
    for (const producerConfiguration of lodash_1.default.filter(producerConfigurations, { producerType: sourceProperties.source })) {
        const cfgKey = (0, Util_1.toSourceString)(producerConfiguration.producerType, producerConfiguration.producerId);
        let secrets;
        try {
            secrets = secretsService.getSecret(cfgKey);
        }
        catch (err) {
            continue;
        }
        const value = lodash_1.default.merge({
            sourceId: producerConfiguration.producerId,
            source: producerConfiguration.producerType,
            schedule: producerConfiguration.cronSchedule
        }, (0, Util_1.toObject)(producerConfiguration.properties));
        let shouldUpdate = false;
        lodash_1.default.forEach(sourceProperties.properties, sProp => {
            const secretValue = lodash_1.default.get(secrets, sProp.secretName);
            if (!lodash_1.default.isEqual(value[sProp.propertyName], secretValue)) {
                value[sProp.propertyName] = lodash_1.default.get(secrets, sProp.secretName);
                shouldUpdate = true;
            }
        });
        if (shouldUpdate) {
            const cfgVal = JSON.stringify(value);
            logger.info(`updating value for ${cfgKey} on tenant ${secretsService.scope} to ${cfgVal}`);
            await tenantServices.updateProducerConfiguration(secretsService.scope, cfgKey, producerConfiguration.description, producerConfiguration.name, cfgVal);
        }
    }
    return Promise.resolve();
}
exports.moveSecretToConfigHelper = moveSecretToConfigHelper;
