"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DataMigrationTaskServices = exports.DataMigrationTaskMetadataServices = exports.GlobalDataMigrationTask = exports.DataMigrationTask = exports.DataMigrationTaskMetadata = void 0;
const BatchTaskServices_1 = require("./BatchTaskServices");
const DateUtils_1 = require("./DateUtils");
class DataMigrationTaskMetadata extends BatchTaskServices_1.BatchTaskMetadata {
    constructor(name, scope, producerTypeList, order = 0, idempotent = false, timeoutInterval = DataMigrationTask.TIMEOUT_INTERVAL, taskParams, allowParallel) {
        super(name, scope, producerTypeList, taskParams, allowParallel);
        this.name = name;
        this.scope = scope;
        this.order = order;
        this.idempotent = idempotent;
        this.timeoutInterval = timeoutInterval;
        if (order < 0) {
            throw new Error(`order cannot be negative: ${order}`);
        }
    }
}
exports.DataMigrationTaskMetadata = DataMigrationTaskMetadata;
DataMigrationTaskMetadata.TABLE_NAME = `data-migration-${BatchTaskServices_1.BatchTaskMetadata.TABLE_NAME_SUFFIX}`;
class DataMigrationTask extends BatchTaskServices_1.BatchTask {
    constructor(name, tenantUid, timeoutInterval, producer, taskParams, allowParallel, priorityWeight) {
        super(name, tenantUid, producer, taskParams);
        this.name = name;
        this.tenantUid = tenantUid;
        this.timeoutInterval = timeoutInterval;
        this.producer = producer;
        this.taskParams = taskParams;
        this.allowParallel = allowParallel;
        this.priorityWeight = priorityWeight;
        this.timeToExpire = Math.floor(Date.now() / 1000) + DataMigrationTask.TTL_SECONDS;
    }
}
exports.DataMigrationTask = DataMigrationTask;
DataMigrationTask.TABLE_NAME = `data-migration-${BatchTaskServices_1.BatchTask.TABLE_NAME_SUFFIX}`;
DataMigrationTask.TIMEOUT_INTERVAL = DateUtils_1.DAY_MILLIS;
DataMigrationTask.TTL_SECONDS = 30 * DateUtils_1.DAY_SECONDS;
class GlobalDataMigrationTask extends DataMigrationTask {
    constructor(name, timeoutInterval, taskParams, allowParallel, priorityWeight) {
        super(name, BatchTaskServices_1.TaskScope.GLOBAL, timeoutInterval !== null && timeoutInterval !== void 0 ? timeoutInterval : DataMigrationTask.TIMEOUT_INTERVAL, undefined, taskParams, allowParallel, priorityWeight);
        this.taskParams = taskParams;
    }
}
exports.GlobalDataMigrationTask = GlobalDataMigrationTask;
class DataMigrationTaskMetadataServices extends BatchTaskServices_1.BatchTaskMetadataServices {
    getTableName() {
        return DataMigrationTaskMetadata.TABLE_NAME;
    }
}
exports.DataMigrationTaskMetadataServices = DataMigrationTaskMetadataServices;
class DataMigrationTaskServices extends BatchTaskServices_1.BatchTaskServices {
    getTableName() {
        return DataMigrationTask.TABLE_NAME;
    }
    async updateTaskStartTime(name, tenantUid, producer) {
        const task = await this.getTask(name, tenantUid, producer);
        if (task.started) {
            throw new Error(`task with name ${name} for tenant ${tenantUid}${producer ? ` and ${producer}` : ''} has been already started`);
        }
        task.started = Date.now();
        return this.save(task);
    }
    async updateTaskEndTime(name, tenantUid, producer, errors) {
        const task = await this.getStartedTask(name, tenantUid, producer);
        task.ended = Date.now();
        task.withErrors = errors;
        return this.save(task);
    }
    async updateTaskTimeout(name, tenantUid, producer) {
        const task = await this.getStartedTask(name, tenantUid, producer);
        const runningTime = Date.now() - task.started;
        const timeoutInterval = task.timeoutInterval || DataMigrationTask.TIMEOUT_INTERVAL;
        if (runningTime > timeoutInterval) {
            task.ended = Date.now();
            const err = new Error(`task ${task.taskKey} timed out after ${Math.floor(runningTime / 1000)} seconds`);
            this.logger.error(err);
            err.loggedMessage = err.message;
            task.withErrors = [err];
            return this.save(task);
        }
        return Promise.resolve(task);
    }
    getNotStartedTasks() {
        return this.dynamoDBServices.getAllFilteredTableEntries(this.getTableName(), 'attribute_not_exists(started)', undefined);
    }
    async getRunningTasks() {
        const response = await this.dynamoDBServices.getAllFilteredTableEntries(this.getTableName(), 'attribute_exists(started) and attribute_not_exists(ended)');
        return response;
    }
    async getStartedTask(name, tenantUid, producer) {
        const task = await this.getTask(name, tenantUid, producer);
        if (!task.started) {
            throw new Error(`task with name ${name} for tenant ${tenantUid}${producer ? ` and ${producer}` : ''} has not been started`);
        }
        return task;
    }
    async getTask(name, tenantUid, producer) {
        const task = await this.getByKey(name, tenantUid, producer);
        if (!task) {
            throw new Error(`task with name ${name} for tenant ${tenantUid}${producer ? ` and ${producer}` : ''} does not exist`);
        }
        return task;
    }
}
exports.DataMigrationTaskServices = DataMigrationTaskServices;
