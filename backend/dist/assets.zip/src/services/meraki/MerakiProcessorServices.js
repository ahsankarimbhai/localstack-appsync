"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MerakiProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const MerakiEndpointService_1 = require("../../collectors/services/MerakiEndpointService");
class MerakiProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(merakiDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, merakiDevice.uuid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        await this.verifyChange(currentTopology, merakiDevice.wifiMac, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        await this.verifyChange(currentTopology, merakiDevice.serialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, merakiDevice.publicIp, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
        await this.verifyChange(currentTopology, merakiDevice.imei, CommonTypes_1.VertexType.IMEI, changes, unchanged);
        await this.verifyChange(currentTopology, merakiDevice.phoneNumber, CommonTypes_1.VertexType.PHONE_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, vertexState.getPropertyValue(CommonTypes_1.VertexBasicProperty.NAME), CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        if (!(0, CommonTypes_1.empty)(merakiDevice.lastUser)) {
            const nonEmptyValue = merakiDevice.lastUser;
            if (nonEmptyValue.indexOf('\\') === 0) {
                await this.verifyChange(currentTopology, merakiDevice.lastUser, CommonTypes_1.VertexType.USER, changes, unchanged);
            }
            else if (nonEmptyValue.indexOf('@') > 0) {
                await this.verifyChange(currentTopology, merakiDevice.lastUser, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
            }
            else {
                await this.verifyChange(currentTopology, merakiDevice.lastUser, CommonTypes_1.VertexType.APP_USER, changes, unchanged);
            }
        }
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new MerakiEndpointService_1.MerakiEndpointService(tenantUid, sourceId);
    }
}
exports.MerakiProcessorServices = MerakiProcessorServices;
