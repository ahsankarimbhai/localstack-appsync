"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listPostureDevices = void 0;
const listPostureDevices = async (event) => {
    console.log('in listPostureDevices');
    console.log("EVENT\n" + JSON.stringify(event, null, 2));
};
exports.listPostureDevices = listPostureDevices;
