"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuoUserStateModelService = exports.DuoUserStateModel = exports.DuoUserModelService = exports.DuoUserModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
class DuoUserModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.DUO_USER;
    }
    async initProperties(duoUser) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, duoUser.user_id);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.DuoUserModel = DuoUserModel;
class DuoUserModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new DuoUserModel(this.partitionKey);
    }
}
exports.DuoUserModelService = DuoUserModelService;
class DuoUserStateModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.DUO_USER_STATE;
    }
    async initProperties(duoUser) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(duoUser));
        if (duoUser.last_login) {
            this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, duoUser.last_login * 1000);
        }
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, duoUser.username);
        this.setProperty(DuoUserStateModel.CREATED_KEY, duoUser.created);
        this.setProperty(DuoUserStateModel.FIRST_NAME_KEY, duoUser.firstname);
        this.setProperty(DuoUserStateModel.LAST_NAME_KEY, duoUser.lastname);
        this.setProperty(DuoUserStateModel.REAL_NAME_KEY, duoUser.realname);
        this.setProperty(DuoUserStateModel.EMAIL_KEY, duoUser.email);
        this.setProperty(DuoUserStateModel.USER_ID_KEY, duoUser.user_id);
        this.setProperty(DuoUserStateModel.USERNAME_KEY, duoUser.username);
        this.setProperty(DuoUserStateModel.GROUPS_KEY, duoUser.groups);
        this.setProperty(DuoUserStateModel.PHONES_KEY, duoUser.phones);
        this.setProperty(DuoUserStateModel.LAST_LOGIN_KEY, duoUser.last_login);
        this.setProperty(DuoUserStateModel.LAST_DIRSYNC_KEY, duoUser.last_directory_sync);
        this.setProperty(DuoUserStateModel.STATUS_KEY, duoUser.status);
        this.setProperty(DuoUserStateModel.IS_ENROLLED, duoUser.is_enrolled);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.DuoUserStateModel = DuoUserStateModel;
DuoUserStateModel.CREATED_KEY = 'created';
DuoUserStateModel.FIRST_NAME_KEY = 'firstname';
DuoUserStateModel.LAST_NAME_KEY = 'lastname';
DuoUserStateModel.EMAIL_KEY = 'email';
DuoUserStateModel.USERNAME_KEY = 'username';
DuoUserStateModel.REAL_NAME_KEY = 'realname';
DuoUserStateModel.USER_ID_KEY = 'user_id';
DuoUserStateModel.GROUPS_KEY = 'groups';
DuoUserStateModel.PHONES_KEY = 'phones';
DuoUserStateModel.LAST_LOGIN_KEY = 'last_login';
DuoUserStateModel.LAST_DIRSYNC_KEY = 'last_directory_sync';
DuoUserStateModel.STATUS_KEY = 'status';
DuoUserStateModel.IS_ENROLLED = 'is_enrolled';
class DuoUserStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new DuoUserStateModel(this.partitionKey);
    }
}
exports.DuoUserStateModelService = DuoUserStateModelService;
