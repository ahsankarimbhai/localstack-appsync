"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomEndpointStateModelService = exports.CustomEndpointStateModel = exports.CustomEndpointModelService = exports.CustomEndpointModel = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const Util_1 = require("../common/Util");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class CustomEndpointModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.CUSTOM_ENDPOINT;
    }
    async initProperties(ep) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, ep.extId);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.CustomEndpointModel = CustomEndpointModel;
class CustomEndpointModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new CustomEndpointModel(this.partitionKey);
    }
}
exports.CustomEndpointModelService = CustomEndpointModelService;
class CustomEndpointStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.CUSTOM_ENDPOINT_STATE;
    }
    async initProperties(ep) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(ep, [CommonTypes_1.VertexBasicProperty.LAST_UPDATED])));
        _.forEach(_.toPairs(ep), (pair) => {
            if (!CustomEndpointStateModel.IDENTITY_PROPERTIES.includes(pair[0])) {
                if (pair[0] === CommonTypes_1.VertexBasicProperty.EXT_ID) {
                    return;
                }
                if (pair[0] === CommonTypes_1.VertexBasicProperty.LAST_UPDATED) {
                    if (!(0, Util_1.isValidDateTime)(pair[1])) {
                        return;
                    }
                }
                if (pair[0] === 'internalIps') {
                    this.setInternalIpAddresses(pair[1]);
                    return;
                }
                if (pair[0] === CommonTypes_1.VertexBasicProperty.OS_TYPE) {
                    this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(pair[1]));
                    return;
                }
                this.setProperty(_.camelCase(pair[0]), pair[1]);
            }
        });
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(ep.osType ? ep.osType : '', ep.osVersion ? ep.osVersion : '', ep.osBuild));
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, ep.osType, ep.osVersion);
        this.setPropertyIfNotSet(CommonTypes_1.VertexBasicProperty.OS_TYPE, CommonTypes_1.OS.UNKNOWN);
        this.setPropertyIfNotSet(CommonTypes_1.VertexBasicProperty.OS_VERSION, CommonTypes_1.NA);
        this.setPropertyIfNotSet(CommonTypes_1.VertexBasicProperty.OS_BUILD, CommonTypes_1.NA);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.CustomEndpointStateModel = CustomEndpointStateModel;
CustomEndpointStateModel.IDENTITY_PROPERTIES = [
    'hardwareId',
    'macAddresses',
    'externalIps',
    'serialNumber',
    'imei',
    'users',
    'appUsers',
    'emails',
    'phones'
];
class CustomEndpointStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new CustomEndpointStateModel(this.partitionKey);
    }
}
exports.CustomEndpointStateModelService = CustomEndpointStateModelService;
