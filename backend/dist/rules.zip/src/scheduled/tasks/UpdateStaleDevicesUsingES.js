"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateStaleDevicesUsingES = void 0;
const _ = __importStar(require("lodash"));
const NeptuneServicesFactory_1 = require("../../common/neptune/NeptuneServicesFactory");
const CommonTypes_1 = require("../../common/CommonTypes");
const gremlin_1 = require("gremlin");
const PostureEndpointService_1 = require("../../model/PostureEndpointService");
const bluebird_1 = require("bluebird");
const BasicScheduledTaskProcessor_1 = require("../BasicScheduledTaskProcessor");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const ResourcesManager_1 = require("../../common/ResourcesManager");
const TimestreamWriteServices_1 = require("../../common/TimestreamWriteServices");
const elastic_builder_1 = __importDefault(require("elastic-builder"));
const P = gremlin_1.process.P;
const t = gremlin_1.process.t;
class UpdateStaleDevicesUsingES extends BasicScheduledTaskProcessor_1.BasicScheduledTaskProcessor {
    constructor(timeBasedLambdaHandler, tenantUid, retentionPolicy, scrollId, cumulativeTotal) {
        super(tenantUid);
        this.timeBasedLambdaHandler = timeBasedLambdaHandler;
        this.tenantUid = tenantUid;
        this.scrollId = scrollId;
        this.cumulativeTotal = cumulativeTotal;
        this.totalCount = 0;
        this.esServices = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        this.neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
        if (!process.env.ENV_PREFIX) {
            throw new Error('ENV_PREFIX is not set');
        }
        this.now = Date.now();
        this.millisAgo = this.now - retentionPolicy;
    }
    async processTask() {
        if (!this.scrollId) {
            this.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.WORKFLOW_STARTED)]);
        }
        if (!this.cumulativeTotal) {
            this.cumulativeTotal = 0;
        }
        const startTime = Date.now();
        this.totalCount = 0;
        let shouldClearScroll = false;
        let result;
        try {
            shouldClearScroll = true;
            for (const timestamp of UpdateStaleDevicesUsingES.TIMESTAMPS_TO_VALIDATE) {
                result = await this.processTimestamp(timestamp);
                if (!result.isEnded) {
                    break;
                }
                if (this.scrollId) {
                    await this.esServices.clearSearchScroll(this.scrollId);
                    this.scrollId = undefined;
                }
            }
            if (result === null || result === void 0 ? void 0 : result.isEnded) {
                await this.handleSuccess();
            }
        }
        catch (err) {
            this.logger.debug(`${this.getLogPrefix()} ${this.getTaskName()} failed, ${JSON.stringify(err)}`);
            shouldClearScroll = true;
            await this.handleFailure(err);
        }
        finally {
            if (shouldClearScroll && this.scrollId) {
                await this.esServices.clearSearchScroll(this.scrollId);
            }
            await (0, ResourcesManager_1.closeConnections)();
            this.logger.debug(`${this.getLogPrefix()} completed, records affected: ${this.totalCount}, cumulative total: ${this.cumulativeTotal}, runtime: ${Date.now() - startTime} ms`);
            this.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, this.totalCount)]);
            await this.timestreamUtil.sendRequestsToStream(this.timestreamRequestBuilder.createRequestsAndReset());
        }
        if (!result) {
            result = {
                scrollId: this.scrollId,
                cumulativeTotal: this.cumulativeTotal,
                tenantUid: this.tenantUid,
                producer: this.producer,
                taskParams: this.taskParams,
                isEnded: true
            };
        }
        return result;
    }
    getTaskName() {
        return UpdateStaleDevicesUsingES.TASK_NAME;
    }
    execute() {
        throw new Error('Unsupported. Invoke process instead');
    }
    async processBatch(candidateIdsES) {
        if (candidateIdsES.length === 0) {
            return;
        }
        this.logger.debug(`ES stale devices candidates: ${candidateIdsES}`);
        const neptuneStartTime = Date.now();
        const dupCandidateIdsNeptune = await this.neptuneServices.executeTenantQuery((g) => this.buildQueryGetStaleSEs(g, candidateIdsES)
            .property(CommonTypes_1.EdgeBasicProperty.UNTIL, this.now)
            .select('pe')
            .by(t.id)
            .toList());
        this.logger.debug(`Candidates after Neptune verification and update: ${dupCandidateIdsNeptune}`);
        const validatedCandidateIdsNeptune = new Set(dupCandidateIdsNeptune);
        if (candidateIdsES.length !== validatedCandidateIdsNeptune.size) {
            this.logger.debug(`The number of stale devices in ES: ${candidateIdsES.length} doesn't match the number in Neptune: ${validatedCandidateIdsNeptune.size}`);
        }
        const svc = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        for (const peId of validatedCandidateIdsNeptune) {
            await svc.updateSearchableVertex(peId, true);
        }
        this.totalCount += validatedCandidateIdsNeptune.size;
        this.cumulativeTotal += validatedCandidateIdsNeptune.size;
        this.logger.debug(`${this.getLogPrefix()} elements updated in this batch: [${validatedCandidateIdsNeptune.size}] out of [${this.totalCount}] in current function execution and [${this.cumulativeTotal}] cumulatively`);
        const neptuneElapsedTime = Date.now() - neptuneStartTime;
        this.logger.debug(`${this.getLogPrefix()} elapsed time to call Neptune and update ES: ${neptuneElapsedTime} ms`);
    }
    buildQueryGetStaleSEs(g, peIds) {
        return g.V(peIds).has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid)
            .as('pe')
            .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .as('se')
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
            .inV()
            .has(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, P.lt(this.millisAgo))
            .select('se');
    }
    buildQueryWithTimestampFilter(timestampKeyword, timestampAgeMillis) {
        const searchQuery = elastic_builder_1.default.boolQuery();
        const mustQueries = [];
        mustQueries.push(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        mustQueries.push(elastic_builder_1.default.existsQuery(timestampKeyword));
        mustQueries.push(elastic_builder_1.default.rangeQuery(timestampKeyword).lt(timestampAgeMillis));
        const mustNotQueries = [];
        mustNotQueries.push(elastic_builder_1.default.termQuery(timestampKeyword, ''));
        return searchQuery
            .must(mustQueries)
            .mustNot(mustNotQueries);
    }
    async processTimestamp(timestamp) {
        let deviceIds;
        do {
            deviceIds = [];
            this.logger.debug(`${this.getLogPrefix()} remaining time in millis: ${this.timeBasedLambdaHandler.getRemainingTimeInMillis()}, threshold: ${this.timeBasedLambdaHandler.timeoutThreshold}`);
            if (this.timeBasedLambdaHandler.isItTimeToStop()) {
                const event = {
                    scrollId: this.scrollId,
                    cumulativeTotal: this.cumulativeTotal,
                    tenantUid: this.tenantUid,
                    producer: this.producer,
                    taskParams: this.taskParams,
                    isEnded: false
                };
                await this.timeBasedLambdaHandler.handle(event);
                return event;
            }
            const esStartTime = Date.now();
            const res = await this.esServices.getSpecificFieldsWithScrollWithBody(elastic_builder_1.default.requestBodySearch().query(this.buildQueryWithTimestampFilter(timestamp, this.millisAgo)).toJSON(), ['postureEndpointId'], this.scrollId, UpdateStaleDevicesUsingES.DEFAULT_MAX_BATCH_SIZE);
            const esElapsedTime = Date.now() - esStartTime;
            this.logger.debug(`${this.getLogPrefix()} elapsed time to call ES: ${esElapsedTime} ms`);
            if (_.isEmpty(res.hits)) {
                break;
            }
            else {
                deviceIds.push(...res.hits.map((hit) => hit._id));
            }
            this.scrollId = res.scrollId;
            await this.processBatch(deviceIds);
            await (0, bluebird_1.delay)(UpdateStaleDevicesUsingES.DEFAULT_DELAY_MILLIS);
        } while (!_.isEmpty(deviceIds));
        return {
            cumulativeTotal: this.cumulativeTotal,
            tenantUid: this.tenantUid,
            producer: this.producer,
            taskParams: this.taskParams,
            isEnded: true
        };
    }
}
exports.UpdateStaleDevicesUsingES = UpdateStaleDevicesUsingES;
UpdateStaleDevicesUsingES.DEFAULT_MAX_BATCH_SIZE = 100;
UpdateStaleDevicesUsingES.TASK_NAME = 'update-stale-devices-using-es';
UpdateStaleDevicesUsingES.TIMESTAMPS_TO_VALIDATE = ['providersLastUpdated.keyword', 'producers.lastUpdated.keyword'];
UpdateStaleDevicesUsingES.DEFAULT_DELAY_MILLIS = 1000;
