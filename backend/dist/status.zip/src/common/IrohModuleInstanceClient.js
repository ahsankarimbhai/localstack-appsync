"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohModuleInstanceClient = exports.postureModuleTypeData = exports.IROH_AUTH = exports.DEVICE_INSIGHTS_VISIBILITY = exports.DEVICE_INSIGHTS = void 0;
const axios_1 = __importDefault(require("axios"));
const LambdaLogger_1 = require("./LambdaLogger");
const IrohClient_1 = require("./IrohClient");
const TenantServices_1 = require("./TenantServices");
const lodash_1 = __importDefault(require("lodash"));
const Util_1 = require("./Util");
const RetryUtil_1 = require("./RetryUtil");
exports.DEVICE_INSIGHTS = 'Device Insights';
exports.DEVICE_INSIGHTS_VISIBILITY = 'org';
exports.IROH_AUTH = 'iroh-auth';
exports.postureModuleTypeData = {
    description: exports.DEVICE_INSIGHTS,
    short_description: exports.DEVICE_INSIGHTS,
    title: exports.DEVICE_INSIGHTS,
    default_name: exports.DEVICE_INSIGHTS,
    enabled: true,
    max_nb_instances: 1
};
class IrohModuleInstanceClient {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.emptyResponseError = 'API returns empty array';
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!process.env.IROH_URI) {
            throw new Error('IROH_URI is not set');
        }
        this.irohUri = process.env.IROH_URI;
        this.axios = axios_1.default.create();
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'IrohModuleInstanceClient');
    }
    async getModuleInstances(moduleTypeId, enabled = true) {
        let url = `${IrohModuleInstanceClient.IROH_MODULE_INSTANCE_URI}?enabled=${enabled}`;
        if (!lodash_1.default.isEmpty(moduleTypeId)) {
            url = `${url}&module_type_id=${moduleTypeId}`;
        }
        const req = await this.getOptions(url);
        return this.requestWithRetry(req, async (resp) => {
            if (!resp.data || resp.data.length === 0) {
                throw new Error(`${this.emptyResponseError} for getModuleInstances`);
            }
            return resp.data;
        });
    }
    async getModuleTypes(record, query, enabled = true) {
        const data = {
            enabled
        };
        if (record) {
            data.record = record;
        }
        if (query) {
            data.query = query;
        }
        const req = await this.getOptions(IrohModuleInstanceClient.IROH_MODULE_TYPE_URI, data);
        return this.requestWithRetry(req, async (resp) => {
            if (!resp.data || resp.data.length === 0) {
                throw new Error(`${this.emptyResponseError} for getModuleTypes`);
            }
            return resp.data;
        });
    }
    async getDIModuleTypes(record, query, enabled = true) {
        const data = {
            enabled
        };
        if (record) {
            data.record = record;
        }
        if (query) {
            data.query = query;
        }
        const req = await this.getOptions(IrohModuleInstanceClient.IROH_MODULE_TYPE_URI, data);
        return this.requestWithRetry(req, (resp) => {
            const diTypes = lodash_1.default.filter(resp.data || [], moduleType => lodash_1.default.find(moduleType.external_references, { class: IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS }));
            if (!diTypes || diTypes.length === 0) {
                throw new Error(`${this.emptyResponseError} for getDIModuleTypes`);
            }
            return diTypes;
        });
    }
    async requestWithRetry(req, responseCallback, retries = 1) {
        var _a;
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, {
            retries,
            backoff: 'FIXED',
            delay: 300
        });
        let result;
        try {
            result = await retryUtil.executeWithRetry(async () => {
                const resp = await this.axios.request(req);
                return responseCallback(resp);
            });
        }
        catch (err) {
            this.logger.error(`Failed to send api request to ${req.url}: ${err.message}`);
            if (!((_a = err.message) === null || _a === void 0 ? void 0 : _a.includes(this.emptyResponseError))) {
                throw err;
            }
        }
        return result;
    }
    async registerSxModuleTypeInstance(module_type_id) {
        try {
            this.logger.debug(`Going to enable Device Insights Module instance for ${this.tenantUid}`);
            const response = await this.axios.request(await this.getOptions(IrohModuleInstanceClient.IROH_MODULE_INSTANCE_URI, {
                name: exports.DEVICE_INSIGHTS,
                module_type_id,
                settings: {},
                enabled: true,
                visibility: exports.DEVICE_INSIGHTS_VISIBILITY
            }, 'post'));
            this.logger.debug(`Enabled Device Insights Module instance for ${this.tenantUid}`);
            return response.data;
        }
        catch (err) {
            this.logger.error(`Failed to enable posture module instance: ${err.message}`);
            throw err;
        }
    }
    async enablePostureModule() {
        const diModuleType = await IrohModuleInstanceClient.getSXDeviceInsightsTypeId();
        const moduleInstances = await this.getModuleInstances(diModuleType);
        if (!moduleInstances || lodash_1.default.isEmpty(moduleInstances)) {
            return this.registerSxModuleTypeInstance(diModuleType);
        }
        this.logger.debug(`Device Insights Module instance is already enabled for ${this.tenantUid}`);
        return Promise.resolve();
    }
    async addPostureModuleType() {
        const host = process.env.POSTURE_URL;
        if (!host) {
            throw new Error('POSTURE_URL is not set');
        }
        try {
            exports.postureModuleTypeData.properties = {
                host,
                authentication: exports.IROH_AUTH
            };
            const response = await this.axios.request(await this.getOptions(IrohModuleInstanceClient.IROH_MODULE_TYPE_URI, exports.postureModuleTypeData, 'post'));
            return response.data;
        }
        catch (err) {
            this.logger.error(`Failed to add posture module type: ${err.message}`);
            throw err;
        }
    }
    async getOptions(url, data, method = 'get') {
        const token = await (0, IrohClient_1.getAccessToken)(this.tenantUid);
        return {
            method,
            baseURL: this.irohUri,
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${token}`
            },
            url,
            data
        };
    }
    static async getSXDeviceInsightsTypeId() {
        const tenantServices = new TenantServices_1.TenantServices();
        const tenantConfiguration = await tenantServices.getTenantConfiguration(TenantServices_1.TenantServices.GLOBAL, IrohModuleInstanceClient.IROH_MODULE_TYPE_URI_KEY);
        if (!tenantConfiguration) {
            throw new Error('Device Insights Module Type is not registered');
        }
        return tenantConfiguration.value;
    }
}
exports.IrohModuleInstanceClient = IrohModuleInstanceClient;
IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS = 'securex:di:asset_source';
IrohModuleInstanceClient.CSC_SUBSCRIPTION_URL_CLASS = 'securex:csc:subscription_endpoint';
IrohModuleInstanceClient.CSC_ADMIN_URL_CLASS = 'securex:csc:admin_endpoint';
IrohModuleInstanceClient.IROH_INT_URI = '/iroh/iroh-int';
IrohModuleInstanceClient.IROH_MODULE_INSTANCE_URI = `${IrohModuleInstanceClient.IROH_INT_URI}/module-instance`;
IrohModuleInstanceClient.IROH_MODULE_TYPE_URI = `${IrohModuleInstanceClient.IROH_INT_URI}/module-type`;
IrohModuleInstanceClient.IROH_MODULE_TYPE_URI_KEY = 'iroh_module_type_id';
