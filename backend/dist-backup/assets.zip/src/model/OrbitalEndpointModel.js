"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrbitalEndpointStateModelService = exports.OrbitalEndpointStateModel = exports.OrbitalQueries = exports.OrbitalEndpointModelService = exports.OrbitalEndpointModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const _ = __importStar(require("lodash"));
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class OrbitalEndpointModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.ORBITAL_ENDPOINT;
    }
    async initProperties(orbitalEndpoint) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, orbitalEndpoint.nodeinfo.ampuuid);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.OrbitalEndpointModel = OrbitalEndpointModel;
OrbitalEndpointModel.ADMIN_USERS = ['Administrator', 'DefaultAccount', 'Guest', 'WDAGUtilityAccount', 'Admin', 'Owner', 'admin'];
class OrbitalEndpointModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new OrbitalEndpointModel(this.partitionKey);
    }
}
exports.OrbitalEndpointModelService = OrbitalEndpointModelService;
var OrbitalQueries;
(function (OrbitalQueries) {
    OrbitalQueries["LOCAL_USERS"] = "local_users";
    OrbitalQueries["LOGGED_IN_USERS"] = "logged_in_users";
    OrbitalQueries["CERTIFICATES"] = "certificates";
    OrbitalQueries["DISK_ENCRYPTION"] = "disk_encryption";
    OrbitalQueries["DRIVES"] = "connected_drives";
    OrbitalQueries["OS_VERSION"] = "os_version";
    OrbitalQueries["SYSTEM_INFO"] = "system_info";
    OrbitalQueries["WIN_SECURITY_CENTER"] = "windows_security_center";
    OrbitalQueries["WIN_SECURITY_PRODUCTS"] = "windows_security_products";
    OrbitalQueries["MACHINE_SID_REGISTER"] = "machine_sid_register";
    OrbitalQueries["MACHINE_GUID"] = "machine_guid";
    OrbitalQueries["PROGRAMS"] = "programs";
    OrbitalQueries["PATCHES"] = "patches";
    OrbitalQueries["KERNEL_INFO"] = "kernel_info";
    OrbitalQueries["RPM_PACKAGES"] = "rpm_packages";
    OrbitalQueries["DEB_PACKAGES"] = "deb_packages";
})(OrbitalQueries = exports.OrbitalQueries || (exports.OrbitalQueries = {}));
class OrbitalEndpointStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.ORBITAL_ENDPOINT_STATE;
    }
    async initProperties(orbitalEndpoint) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(orbitalEndpoint, [OrbitalEndpointStateModel.REPORTED, 'hostinfo.updated'])));
        this.setProperty(OrbitalEndpointStateModel.CREATOR, orbitalEndpoint.creator);
        this.setProperty(OrbitalEndpointStateModel.ORGANISATION, orbitalEndpoint.organization);
        this.setProperty(OrbitalEndpointStateModel.ERROR, orbitalEndpoint.error);
        this.setProperty(OrbitalEndpointStateModel.QUERY, orbitalEndpoint.query);
        this.setProperty(OrbitalEndpointStateModel.CONTEXT, orbitalEndpoint.context);
        this.setProperty(OrbitalEndpointStateModel.NODE_ID, orbitalEndpoint.nodeinfo.id);
        this.setProperty(OrbitalEndpointStateModel.AMPUUID, orbitalEndpoint.nodeinfo.ampuuid);
        this.setProperty(OrbitalEndpointStateModel.NODE_OS, orbitalEndpoint.nodeinfo.os);
        this.setProperty(OrbitalEndpointStateModel.VERSION, orbitalEndpoint.hostinfo.version);
        this.setProperty(OrbitalEndpointStateModel.OS_RELEASE, orbitalEndpoint.hostinfo.osinfo.release);
        this.setProperty(OrbitalEndpointStateModel.FQDN, orbitalEndpoint.hostinfo.fqdn);
        this.setProperty(OrbitalEndpointStateModel.INTERFACES, orbitalEndpoint.hostinfo.interfaces);
        this.setProperty(OrbitalEndpointStateModel.UPDATED, Date.parse(orbitalEndpoint.hostinfo.updated));
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, orbitalEndpoint.hostinfo.hostname);
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(orbitalEndpoint.reported));
        this.setProperty(OrbitalEndpointStateModel.REPORTED, Date.parse(orbitalEndpoint.reported));
        const internalIpAddresses = [];
        _.forOwn(orbitalEndpoint.hostinfo.interfaces, (deviceInterface) => {
            if (deviceInterface.ipv4 && !deviceInterface.ipv4.startsWith('169.254')) {
                internalIpAddresses.push(_.split(deviceInterface.ipv4, '/')[0]);
            }
        });
        this.setInternalIpAddresses(internalIpAddresses);
        let osQueryResults = orbitalEndpoint.osQuery;
        if (orbitalEndpoint.osQueryResult) {
            osQueryResults = orbitalEndpoint.osQueryResult;
        }
        for (const osQueryResult of osQueryResults || []) {
            const label = osQueryResult.label;
            if (_.includes(OrbitalEndpointStateModel.allowlist, label) && osQueryResult.columns && osQueryResult.columns.length > 0) {
                const resultColumnsLength = osQueryResult.columns.length;
                if (osQueryResult.values) {
                    const valuesLength = osQueryResult.values.length;
                    const processedResult = [];
                    for (let j = 0; j < valuesLength / resultColumnsLength; j += 1) {
                        const result = {};
                        for (let i = 0; i < resultColumnsLength; i += 1) {
                            const currentKey = osQueryResult.columns[i];
                            result[currentKey] = osQueryResult.values[j * resultColumnsLength + i];
                        }
                        processedResult.push(result);
                    }
                    const propertyKey = label === OrbitalQueries.OS_VERSION ? OrbitalEndpointStateModel.OS_VERSION_DETAILS : label;
                    if (_.includes(OrbitalEndpointStateModel.compressedProperties, label)) {
                        await this.setPropertyWithCompressedValue(propertyKey, JSON.stringify(processedResult));
                    }
                    else {
                        this.setProperty(propertyKey, processedResult);
                    }
                }
            }
        }
        const machineSidRegistry = this.getProperty(OrbitalQueries.MACHINE_SID_REGISTER);
        if ((machineSidRegistry === null || machineSidRegistry === void 0 ? void 0 : machineSidRegistry.value.length) > 0) {
            this.setProperty(OrbitalEndpointStateModel.COMPUTER_SID, this.decodeRegKeyToComputerSid(machineSidRegistry.value[0].sid));
        }
        const osVersionDetails = _.get(this.getProperty(OrbitalEndpointStateModel.OS_VERSION_DETAILS), 'value[0]');
        if (osVersionDetails) {
            this.setProperty(OrbitalEndpointStateModel.OS_ARCH, osVersionDetails.arch);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(osVersionDetails.name));
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, osVersionDetails.version);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(osVersionDetails.name, osVersionDetails.version));
            (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, osVersionDetails.name);
        }
        else {
            this.setProperty(OrbitalEndpointStateModel.OS_ARCH, orbitalEndpoint.hostinfo.osinfo.arch);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(orbitalEndpoint.hostinfo.osinfo.os));
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, _.join([orbitalEndpoint.hostinfo.osinfo.osname, orbitalEndpoint.hostinfo.osinfo.version], ' '));
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(orbitalEndpoint.hostinfo.osinfo.osname, orbitalEndpoint.hostinfo.osinfo.version));
            (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, [
                orbitalEndpoint.hostinfo.osinfo.osname.includes(orbitalEndpoint.hostinfo.osinfo.os)
                    ? orbitalEndpoint.hostinfo.osinfo.osname
                    : orbitalEndpoint.hostinfo.osinfo.version.includes(orbitalEndpoint.hostinfo.osinfo.os)
                        ? orbitalEndpoint.hostinfo.osinfo.version
                        : orbitalEndpoint.hostinfo.osinfo.os,
                orbitalEndpoint.hostinfo.osinfo.arch
            ].filter(item => item).join(' '), orbitalEndpoint.hostinfo.osinfo.release);
        }
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
    decodeRegKeyToComputerSid(regSid) {
        const decimal = _
            .chain([regSid.substring(0, 8), regSid.substring(8, 16), regSid.substring(16, 24)])
            .map(v => `${v.substring(6, 8)}${v.substring(4, 6)}${v.substring(2, 4)}${v.substring(0, 2)}`)
            .map(v => parseInt(v, 16))
            .value()
            .join('-');
        return `S-1-5-21-${decimal}`;
    }
}
exports.OrbitalEndpointStateModel = OrbitalEndpointStateModel;
OrbitalEndpointStateModel.CREATOR = 'creator';
OrbitalEndpointStateModel.ORGANISATION = 'organization';
OrbitalEndpointStateModel.REPORTED = 'reported';
OrbitalEndpointStateModel.ERROR = 'error';
OrbitalEndpointStateModel.QUERY = 'query';
OrbitalEndpointStateModel.CONTEXT = 'context';
OrbitalEndpointStateModel.NODE_ID = 'nodeId';
OrbitalEndpointStateModel.AMPUUID = 'ampuuid';
OrbitalEndpointStateModel.NODE_OS = 'nodeOs';
OrbitalEndpointStateModel.UPDATED = 'updated';
OrbitalEndpointStateModel.VERSION = 'version';
OrbitalEndpointStateModel.OS_RELEASE = 'release';
OrbitalEndpointStateModel.OS_ARCH = 'arch';
OrbitalEndpointStateModel.OS_VERSION_DETAILS = 'os_version_details';
OrbitalEndpointStateModel.FQDN = 'fqdn';
OrbitalEndpointStateModel.INTERFACES = 'interfaces';
OrbitalEndpointStateModel.USERNAME_KEY = 'username';
OrbitalEndpointStateModel.COMPUTER_SID = 'computerSid';
OrbitalEndpointStateModel.MACHINE_GUID = 'machine_guid';
OrbitalEndpointStateModel.ANYCONNECT_UUID = 'anyconnect_uuid';
OrbitalEndpointStateModel.allowlist = [
    OrbitalQueries.SYSTEM_INFO, OrbitalQueries.OS_VERSION, OrbitalQueries.LOCAL_USERS, OrbitalQueries.LOGGED_IN_USERS,
    OrbitalQueries.WIN_SECURITY_PRODUCTS, OrbitalQueries.WIN_SECURITY_CENTER, OrbitalQueries.MACHINE_SID_REGISTER,
    OrbitalQueries.DISK_ENCRYPTION, OrbitalQueries.PATCHES, OrbitalQueries.KERNEL_INFO, OrbitalQueries.PROGRAMS,
    OrbitalQueries.RPM_PACKAGES, OrbitalQueries.DEB_PACKAGES
];
OrbitalEndpointStateModel.compressedProperties = [
    OrbitalQueries.PATCHES, OrbitalQueries.KERNEL_INFO, OrbitalQueries.PROGRAMS, OrbitalQueries.RPM_PACKAGES, OrbitalQueries.DEB_PACKAGES
];
class OrbitalEndpointStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new OrbitalEndpointStateModel(this.partitionKey);
    }
}
exports.OrbitalEndpointStateModelService = OrbitalEndpointStateModelService;
