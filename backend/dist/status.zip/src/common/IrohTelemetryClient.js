"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohTelemetryClient = void 0;
const Util_1 = require("./Util");
const IrohServiceBase_1 = require("./IrohServiceBase");
class IrohTelemetryClient extends IrohServiceBase_1.IrohServiceBase {
    constructor(tenantUid) {
        super(tenantUid);
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'IrohTelemetryClient');
    }
    async publishMetrics(metrics) {
        try {
            await this.axios.request(await this.getOptions(IrohTelemetryClient.IROH_TELEMETRY_PUBLISH_URI, metrics, 'post'));
        }
        catch (err) {
            let errDetail = err.message;
            if (err.response) {
                errDetail = errDetail.concat(` [status: ${err.response.status}, data: ${JSON.stringify(err.response.data)}]`);
            }
            this.logger.error(`Failed to publish metrics: ${errDetail}`);
            throw err;
        }
    }
}
exports.IrohTelemetryClient = IrohTelemetryClient;
IrohTelemetryClient.IROH_TELEMETRY_PUBLISH_URI = '/iroh/telemetry/publish';
