"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SentinelOneDevicesCollection = void 0;
const SentinelOneCollection_1 = require("./SentinelOneCollection");
class SentinelOneDevicesCollection extends SentinelOneCollection_1.SentinelOneCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.SentinelOneDevicesCollection = SentinelOneDevicesCollection;
