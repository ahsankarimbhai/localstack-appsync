"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureUserService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
class AzureUserService extends Services_1.BasePersonService {
    getPvType() {
        return CommonTypes_1.VertexType.AZURE_USER;
    }
    getPsType() {
        return CommonTypes_1.VertexType.AZURE_USER_STATE;
    }
}
exports.AzureUserService = AzureUserService;
