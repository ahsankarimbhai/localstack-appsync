"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchAndNotifyDevices = exports.removeLabelsProcessing = exports.deleteAllPersonsInESForTenant = exports.deleteAllDevicesInESForTenant = exports.updateWebhookForAllTenantsByShards = exports.updateWebhookForAllTenants = exports.cleanupSchedulingTimes = exports.syncProducerWithIrohModuleInstance = exports.addIrohModuleInstanceAsProducer = exports.setSXModuleInstanceId = exports.removeTenantFeatureFlags = exports.disableFeatureFlagForAllTenants = exports.enableFeatureFlagForAllTenants = exports.addTenantFeatureFlags = exports.listTenantFeatureFlags = exports.deleteFailingWebhooks = exports.deleteWebhooks = exports.registerWebhooks = exports.updateOrbitalSecretsForAllTenants = exports.rescheduleExpiringOrbitalQueries = exports.updateOrbitalQueryForAllTenants = exports.removeAllProducersForTenant = exports.clearSetupStatusForAllTenants = exports.removeProducerFromAllTenants = exports.removeCurrentStateForFunctionAndProducer = exports.getTenantByExtId = exports.listTenants = exports.removeProducerConfigurationHelper = exports.removeProducerConfiguration = exports.deleteTenant = exports.createTenant = void 0;
const lodash_1 = __importDefault(require("lodash"));
const uuid_1 = require("uuid");
const TenantServices_1 = require("./common/TenantServices");
const AwsSecretsService_1 = require("./common/AwsSecretsService");
const Util_1 = require("./common/Util");
const LambdaLogger_1 = require("./common/LambdaLogger");
const CommonTypes_1 = require("./common/CommonTypes");
const ScheduleServices_1 = require("./common/ScheduleServices");
const ScheduledTaskRunner_1 = require("./scheduled/ScheduledTaskRunner");
const CloseProducerCurrentStates_1 = require("./scheduled/tasks/CloseProducerCurrentStates");
const WebhooksRegistrar_1 = require("./helpers/WebhooksRegistrar");
const FunctionStateServices_1 = require("./common/FunctionStateServices");
const GroupServices_1 = require("./services/common/GroupServices");
const ProducerUtil_1 = require("./services/common/ProducerUtil");
const handlers_1 = require("./graphql-api/handlers");
const IrohModuleInstanceClient_1 = require("./common/IrohModuleInstanceClient");
const SourceUtils_1 = require("./common/SourceUtils");
const ElasticsearchServices_1 = require("./common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("./common/ElasticsearchFactory");
const OrbitalCollectorServices_1 = require("./services/orbital/OrbitalCollectorServices");
const DynamoDBServices_1 = require("./common/awsclient/dynamodb/DynamoDBServices");
const AmpCollectorServices_1 = require("./services/amp/AmpCollectorServices");
const JamfCollectorServices_1 = require("./services/jamf/JamfCollectorServices");
const UnifiedConnectorCollectorServices_1 = require("./services/unifiedconnector/UnifiedConnectorCollectorServices");
const LambdaServices_1 = require("./common/LambdaServices");
const ShardingServices_1 = require("./common/neptune/ShardingServices");
const LabelDeviceService_1 = require("./services/common/LabelDeviceService");
const RuleService_1 = require("./services/common/RuleService");
const SystemRuleService_1 = require("./services/common/SystemRuleService");
const IncidentService_1 = require("./services/common/IncidentService");
const LabelService_1 = require("./services/common/LabelService");
const TimeBasedAsyncLambdaInvoker_1 = require("./common/TimeBasedAsyncLambdaInvoker");
const cron_time_generator_1 = require("cron-time-generator");
const PolicyServices_1 = require("./services/common/PolicyServices");
const SavedFilterServices_1 = require("./common/SavedFilterServices");
const WebhookNotificationService_1 = require("./services/common/data-sharing/WebhookNotificationService");
const WebhookHelper_1 = require("./services/common/data-sharing/WebhookHelper");
const GenericSourceConfiguration_1 = require("./common/generic/GenericSourceConfiguration");
const GenericSourceUtils_1 = require("./common/generic/GenericSourceUtils");
const DynamodbServiceFactory_1 = require("./common/awsclient/dynamodb/DynamodbServiceFactory");
const logger = new LambdaLogger_1.LambdaLogger();
const UMBRELLA_V2_API_KEY = 'v2-api-key';
const createTenant = async (event) => {
    const { tenantExtId, description, tenantConfiguration } = event;
    if (!tenantExtId) {
        throw new Error('tenantExtId is mandatory for createTenant');
    }
    const tenantUid = (0, uuid_1.v4)();
    const tenant = new TenantServices_1.Tenant(tenantUid, tenantExtId, description);
    await new ShardingServices_1.ShardingServices().allocateNeptuneCluster(tenantUid);
    await new TenantServices_1.TenantServices().addTenant(tenant);
    const secretService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await secretService.setSecretValue('tenantCreated', true);
    await Promise.all(lodash_1.default.map(tenantConfiguration, (item) => {
        const sourceId = TenantServices_1.TenantConfiguration.generateSourceId();
        const itemValue = JSON.stringify({
            ...item.value,
            sourceId,
            source: item.key
        });
        return (0, handlers_1.addTenantProducerConfiguration)(new TenantServices_1.TenantConfiguration(tenantUid, `${item.key}__${sourceId}`, itemValue, item.description, item.name));
    }));
    const scheduledTasksService = new ScheduleServices_1.ScheduledTaskServices();
    await scheduledTasksService.scheduleTenantTasks(tenantUid);
    new LambdaLogger_1.LambdaLogger().info(`Successfully created tenant ${tenant.toString()}`);
    return { tenantUid };
};
exports.createTenant = createTenant;
const deleteTenant = async (event, context) => {
    const tenantUid = event.tenantUid;
    const tenantServices = new TenantServices_1.TenantServices();
    const scheduledTasksService = new ScheduleServices_1.ScheduledTaskServices();
    const functionStateServices = new FunctionStateServices_1.FunctionStateServices();
    const groupServices = new GroupServices_1.GroupServices(tenantUid);
    const ruleService = new RuleService_1.RuleService(tenantUid);
    const labelService = new LabelService_1.LabelService(tenantUid);
    const incidentService = new IncidentService_1.IncidentService(tenantUid);
    const tenantConfigurations = await tenantServices.getTenantConfigurations(tenantUid);
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    const policyService = new PolicyServices_1.PolicyServices(tenantUid);
    const savedFilterService = new SavedFilterServices_1.SavedFilterServices();
    const esService = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    if (lodash_1.default.size(tenantConfigurations) > 0) {
        await awsSecretsService.init();
    }
    for (const tenantConfiguration of tenantConfigurations) {
        const producer = tenantServices.mapToProducerConfigurations([tenantConfiguration])[0];
        if ((0, CommonTypes_1.sourceSupportsWebhooks)(lodash_1.default.get(producer, 'producerType'))) {
            const secrets = awsSecretsService.getSecret((0, Util_1.toSourceString)(producer.producerType, producer.producerId));
            const svc = ProducerUtil_1.ProducerUtil.getPushCollectorService(tenantConfiguration, secrets, tenantUid, context, producer.producerId, producer.producerType);
            logger.info(`deleting webhook for producer ${producer.producerType} ${producer.producerId}`);
            await svc.removeWebhooks();
        }
    }
    await Promise.all(lodash_1.default.concat(lodash_1.default.map(tenantConfigurations, item => tenantServices.deleteTenantConfigurationByKey(item.tenantKey)), [tenantServices.deleteTenant(tenantUid), awsSecretsService.deleteSecret(true)]));
    await Promise.all([scheduledTasksService.removeTenantTasks(tenantUid),
        functionStateServices.removeTenantFunctionStates(tenantUid),
        groupServices.removeAllGroups(),
        labelService.deleteAllLabels(),
        ruleService.hardDeleteAllRules(),
        incidentService.deleteAllMappings(),
        policyService.removeAllPolicies(),
        savedFilterService.deleteAllSavedFilters(tenantUid),
        esService.deleteTenantEndpointData(),
        esService.deleteTenantPersonData()])
        .catch(e => logger.error(`Failed to complete tenant deletion, eroor: ${e.message}`));
    logger.info(`Successfully deleted tenant ${tenantUid}`);
    return 'success';
};
exports.deleteTenant = deleteTenant;
const removeProducerConfiguration = async (event, context) => {
    const { tenantUid, role, userId } = (0, Util_1.getFromHeaders)(event);
    (0, Util_1.verifyAuthorization)(role, userId, tenantUid);
    const { producerType, producerId } = event.args;
    const tenantServices = new TenantServices_1.TenantServices();
    const tenantConfiguration = await tenantServices.getTenantConfigurationOrFail(tenantUid, producerType, producerId);
    return (0, exports.removeProducerConfigurationHelper)(tenantUid, tenantConfiguration, context);
};
exports.removeProducerConfiguration = removeProducerConfiguration;
const removeProducerConfigurationHelper = async (tenantUid, tenantConfiguration, context) => {
    const value = JSON.parse(tenantConfiguration.value);
    const producerType = value.source;
    const producerId = value.sourceId;
    const cfgKey = (0, Util_1.toSourceString)(producerType, producerId);
    const tenantServices = new TenantServices_1.TenantServices();
    logger.debug(`marking producer ${producerId}/${producerType} of tenant ${tenantUid} as delete`);
    await tenantServices.markDeletedProducerConfiguration(tenantUid, cfgKey);
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    logger.debug(`Getting the secret for ${producerId}/${producerType} of tenant ${tenantUid}`);
    const secrets = awsSecretsService.getSecretByKey((0, Util_1.toSourceString)(producerType, producerId));
    if (secrets) {
        if ((0, CommonTypes_1.sourceSupportsWebhooks)(producerType)) {
            try {
                logger.debug(`Source ${producerId}/${producerType} of tenant ${tenantUid} supports webhooks, will be removing its webhooks`);
                const svc = ProducerUtil_1.ProducerUtil.getPushCollectorService(tenantConfiguration, secrets, tenantUid, context, producerId, producerType);
                await svc.removeWebhooks();
                logger.debug(`Removed webhook for source ${producerId}/${producerType} of tenant ${tenantUid}`);
            }
            catch (e) {
                logger.error(`Failed to remove webhooks for source ${producerId}/${producerType} of tenant ${tenantUid}. Error: ${e.message}`);
            }
        }
        logger.debug(`Removing the secrets for ${producerId}/${producerType} of tenant ${tenantUid}`);
        await awsSecretsService.removeSecretValue((0, Util_1.toSourceString)(producerType, producerId));
    }
    logger.debug(`Removing the scheduled tasks for ${producerId}/${producerType} of tenant ${tenantUid}`);
    const scheduledTasksService = new ScheduleServices_1.ScheduledTaskServices();
    await scheduledTasksService.removeProducerTasks(tenantUid, cfgKey);
    logger.debug(`Triggering close producer current state task for ${producerId}/${producerType} of tenant ${tenantUid}`);
    await new ScheduledTaskRunner_1.ScheduledTaskRunner().triggerTask(new ScheduleServices_1.ScheduledTask(CloseProducerCurrentStates_1.CloseProducerCurrentStates.TASK_NAME, tenantUid, ScheduleServices_1.ScheduleType.NOW, cfgKey));
    logger.debug(`Removing elasticsearch data for ${producerId}/${producerType} of tenant ${tenantUid}`);
    const esServices = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    await esServices.deleteProducer(producerId);
    await new RuleService_1.RuleService(tenantUid).deleteProducerFromRules(producerType, producerId);
    logger.debug(`Finished deleting producer ${producerId}/${producerType} of tenant ${tenantUid}`);
    return true;
};
exports.removeProducerConfigurationHelper = removeProducerConfigurationHelper;
const listTenants = async (event) => {
    const { role, userId } = (0, Util_1.getFromHeaders)(event);
    (0, Util_1.verifySystemAdminAuthorization)(role, userId);
    const tenantServices = new TenantServices_1.TenantServices();
    const tenants = await tenantServices.getAllTenants();
    const out = [];
    for (const tenant of tenants) {
        const featureFlags = await tenantServices.getFeatureFlags(tenant.id);
        out.push({ ...tenant, featureFlags });
    }
    return out;
};
exports.listTenants = listTenants;
const getTenantByExtId = async (event) => {
    const { tenantExtId } = event;
    if (!tenantExtId) {
        throw new Error('tenantExtId is mandatory for getTenantByExtId');
    }
    const ts = new TenantServices_1.TenantServices();
    const tenant = await ts.getTenantByExtId(tenantExtId);
    if (tenant) {
        const featureFlags = await ts.getFeatureFlags(tenant.id);
        return { tenant, featureFlags };
    }
    return tenant;
};
exports.getTenantByExtId = getTenantByExtId;
const removeCurrentStateForFunctionAndProducer = async (event) => {
    const { functionName, producerType } = event;
    if (!functionName || !producerType) {
        throw new Error('tenantId, sourceId, functionName are mandatory');
    }
    logger.debug(`Will be attempting to remove current state for all instances of source ${producerType} created by function ${functionName} for all tenants`);
    const functionStateServices = new FunctionStateServices_1.FunctionStateServices();
    const ts = new TenantServices_1.TenantServices();
    const tenants = await ts.getAllTenants();
    for (const tenant of tenants) {
        logger.debug(`Will be attempting to remove current state for all instances of source ${producerType} created by function ${functionName} for tenant ${tenant.id}`);
        const tenantProducers = await ts.getProducerConfigurations(tenant.id);
        const filterProducers = lodash_1.default.filter(tenantProducers, producer => producer.producerType === producerType);
        if (filterProducers.length === 0) {
            logger.debug(`No need to remove current state for ${filterProducers.length} instances of source ${producerType} created by function ${functionName} for tenant ${tenant.id}. No such sources`);
            continue;
        }
        logger.debug(`Will be attempting to remove current state for ${filterProducers.length} instances of source ${producerType} created by function ${functionName} for tenant ${tenant.id}`);
        for (const producer of filterProducers) {
            const sourceKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
            try {
                logger.debug(`Will be attempting to remove current state of source ${sourceKey} for tenant ${tenant.id} created by function ${functionName}`);
                await functionStateServices.deleteByKey(`${tenant.id}__${functionName}__${sourceKey}`);
                logger.debug(`Finished removing current state of source ${sourceKey} for tenant ${tenant.id} created by function ${functionName}`);
            }
            catch (e) {
                logger.error(`Failed to remove current state of source ${sourceKey} for tenant ${tenant.id} created by function ${functionName}`);
            }
        }
        logger.debug(`Finished removing current state for all instances of source ${producerType} created by function ${functionName} for tenant ${tenant.id}`);
    }
    logger.debug(`Finished removing current state for all instances of source ${producerType} created by function ${functionName} for all tenants`);
};
exports.removeCurrentStateForFunctionAndProducer = removeCurrentStateForFunctionAndProducer;
const removeProducerFromAllTenants = async (event) => {
    const { producerType } = event;
    if (!producerType) {
        throw new Error('producerType is mandatory');
    }
    logger.debug(`Will be attempting to remove producer of type ${producerType} from all tenants`);
    const ts = new TenantServices_1.TenantServices();
    const tenants = await ts.getAllTenants();
    for (const tenant of tenants) {
        logger.debug(`Will be attempting to remove all instances of source ${producerType} for tenant ${tenant.id}`);
        const tenantProducers = await ts.getProducerConfigurations(tenant.id);
        const filterProducers = lodash_1.default.filter(tenantProducers, producer => producer.producerType === producerType);
        if (filterProducers.length === 0) {
            logger.debug(`No need to remove instanced of producer ${producerType} for tenant ${tenant.id}. No such sources`);
            continue;
        }
        logger.debug(`Will be attempting to remove ${filterProducers.length} instances of source ${producerType} for tenant ${tenant.id}`);
        for (const producer of filterProducers) {
            try {
                logger.debug(`Will be attempting to get the configuration of source ${producer.producerId} for tenant ${tenant.id}`);
                const tenantConfiguration = await ts.getTenantConfigurationOrFail(tenant.id, producerType, producer.producerId);
                logger.debug(`Will be attempting to delete source ${producer.producerId} for tenant ${tenant.id}`);
                await (0, exports.removeProducerConfigurationHelper)(tenant.id, tenantConfiguration, { functionName: 'removeProducerFromAllTenants' });
                logger.debug(`Finished deleting source ${producer.producerId} for tenant ${tenant.id}`);
            }
            catch (e) {
                logger.error(`Failed deleting source ${producer.producerId} for tenant ${tenant.id}`);
            }
        }
        logger.debug(`Finished removing all instances of source ${producerType} for tenant ${tenant.id}`);
    }
    logger.debug(`Finished removing producer of type ${producerType} from all tenants`);
};
exports.removeProducerFromAllTenants = removeProducerFromAllTenants;
const clearSetupStatusForAllTenants = async () => {
    logger.debug('Will be attempting to clear setup status from all tenants');
    const ts = new TenantServices_1.TenantServices();
    const tenants = await ts.getAllTenants();
    for (const tenant of tenants) {
        logger.debug(`Will be updating tenant setup status of tenant ${tenant.id} to ${TenantServices_1.TenantSetupStatus.NOT_SETUP}`);
        await ts.setTenantSetupStatus(tenant.id, TenantServices_1.TenantSetupStatus.NOT_SETUP);
        logger.debug(`Finished updating tenant setup status of tenant ${tenant.id} to ${TenantServices_1.TenantSetupStatus.NOT_SETUP}`);
    }
    logger.debug(`Finished updating tenant setup status for all tenants to ${TenantServices_1.TenantSetupStatus.NOT_SETUP}`);
};
exports.clearSetupStatusForAllTenants = clearSetupStatusForAllTenants;
const removeAllProducersForTenant = async (event, context) => {
    const { tenantExtId } = event;
    if (!tenantExtId) {
        throw new Error('tenantExtId is mandatory');
    }
    logger.debug(`Will be attempting to remove all producers for tenant with SecureX id: ${tenantExtId}`);
    const ts = new TenantServices_1.TenantServices();
    const tenant = await ts.getTenantByExtId(tenantExtId);
    if (!tenant) {
        const message = `unable to find tenant that matches given SecureX id: ${tenantExtId}, will not be deleting any producers`;
        logger.debug(message);
        throw new Error(message);
    }
    const producerConfig = await ts.getProducerConfigurations(tenant.id);
    for (const producer of producerConfig) {
        logger.debug(`Removing producer ${JSON.stringify(producer)} of tenant ${tenant.toString()}`);
        const cfgKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
        const tenantConfiguration = await ts.getTenantConfiguration(tenant.id, cfgKey);
        if (tenantConfiguration) {
            await (0, exports.removeProducerConfigurationHelper)(tenant.id, tenantConfiguration, context);
        }
    }
    logger.debug(`Deleting tenant from ES: ${tenant.toString()}`);
    const esServices = new ElasticsearchServices_1.ElasticsearchServices(tenant.id, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    await esServices.deleteTenant();
    logger.debug(`Finished removing all producers for tenant with SecureX id: ${tenant.toString()}`);
};
exports.removeAllProducersForTenant = removeAllProducersForTenant;
const updateOrbitalQueryForAllTenants = async () => {
    await updateOrbitalQueryForAllTenantsImpl(true);
};
exports.updateOrbitalQueryForAllTenants = updateOrbitalQueryForAllTenants;
const rescheduleExpiringOrbitalQueries = async () => {
    await updateOrbitalQueryForAllTenantsImpl(false);
};
exports.rescheduleExpiringOrbitalQueries = rescheduleExpiringOrbitalQueries;
const updateOrbitalSecretsForAllTenants = async (event) => {
    const { tenantUid } = event;
    await updateOrbitalQueryForAllTenantsImpl(false, true, tenantUid);
};
exports.updateOrbitalSecretsForAllTenants = updateOrbitalSecretsForAllTenants;
async function updateOrbitalQueryForAllTenantsImpl(reconfigureRegisteredWebhooks, refreshWebhookSecrets = false, tenantUid) {
    var _a;
    logger.debug('Will be attempting to update orbital queries for all tenants (re-registering webhooks)');
    const ts = new TenantServices_1.TenantServices();
    const tenants = (tenantUid) ? [await ts.getTenantById(tenantUid)].filter(x => x !== undefined) : await ts.getAllTenants();
    if (tenants.length === 0) {
        if (tenantUid) {
            logger.error(`Could not find tenant by ID ${tenantUid}`);
        }
        else {
            logger.error('Could not find any tenants');
        }
        return;
    }
    for (const tenant of tenants) {
        const producerConfig = await ts.getProducerConfigurations(tenant.id);
        const orbitalProducers = lodash_1.default.filter(producerConfig, x => x.producerType === CommonTypes_1.Source.ORBITAL);
        if (orbitalProducers.length > 0) {
            const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenant.id);
            await awsSecretsService.init();
            for (const producer of orbitalProducers) {
                try {
                    logger.debug(`Will be re-registering webhook for producer ${JSON.stringify(producer)} of tenant ${tenant.toString()}`);
                    const sourceString = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
                    const secrets = awsSecretsService.getSecret(sourceString);
                    const baseUrl = (_a = lodash_1.default.find(producer.properties, p => p.key === 'baseURL')) === null || _a === void 0 ? void 0 : _a.value;
                    const orbitalService = new OrbitalCollectorServices_1.OrbitalCollectorServices(secrets, tenant.id, producer.producerId, baseUrl);
                    if (await orbitalService.hasRegisteredWebhooks()) {
                        if (refreshWebhookSecrets) {
                            logger.info(`refreshing webhook secrets for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}, baseUrl: ${baseUrl}`);
                            await orbitalService.refreshWebhookSecrets();
                        }
                        if (reconfigureRegisteredWebhooks) {
                            logger.info(`deleting webhook for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}, baseUrl: ${baseUrl}`);
                            await orbitalService.removeWebhooks();
                            logger.info(`registering webhook for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}, baseUrl: ${baseUrl}`);
                            await orbitalService.registerWebhooks();
                            logger.info(`Finished updating query for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}, baseUrl: ${baseUrl}`);
                        }
                        else {
                            logger.info(`Skipping reconfigure of webhook for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}, baseUrl: ${baseUrl}`);
                        }
                    }
                    else {
                        logger.info(`There is no webhook registered for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}, baseUrl: ${baseUrl}`);
                    }
                }
                catch (e) {
                    logger.error(`Failed updating query for tenant ${tenant.id}, producer ${(0, Util_1.toSourceString)(producer.producerType, producer.producerId)}`);
                }
            }
        }
        logger.debug('Finished updating orbital queries for all tenants (re-registering webhooks)');
    }
}
const registerWebhooks = async (event, context) => {
    const { tenantUid, role, userId } = (0, Util_1.getFromHeaders)(event);
    const { producerType, producerId } = event.args;
    logger.info(`user ${userId} about to register webhooks for tenant ${tenantUid} for producer ${producerType} ${producerId}`);
    (0, Util_1.verifyAuthorization)(role, userId, tenantUid);
    const webhooksRegistrar = new WebhooksRegistrar_1.WebhooksRegistrar(tenantUid, producerType, producerId);
    const hasRegisteredWebhooks = await webhooksRegistrar.hasRegisteredWebhooks(context);
    if (hasRegisteredWebhooks) {
        logger.info('there are registered webhooks for the producer, not registering new ones');
        return false;
    }
    await webhooksRegistrar.registerWebhooks(context);
    return true;
};
exports.registerWebhooks = registerWebhooks;
const deleteWebhooks = async (event, context) => {
    const { tenantUid, role, userId } = (0, Util_1.getFromHeaders)(event);
    const { producerType, producerId } = event.args;
    logger.info(`user ${userId} removing webhooks for tenant ${tenantUid} for producer ${producerType} ${producerId}`);
    (0, Util_1.verifyAuthorization)(role, userId, tenantUid);
    try {
        await new WebhooksRegistrar_1.WebhooksRegistrar(tenantUid, producerType, producerId).deleteWebhooks(context);
        return true;
    }
    catch (e) {
        logger.error(`Failed deleting webhook for tenant ${tenantUid} for producer ${producerType} ${producerId}`, e);
    }
    return false;
};
exports.deleteWebhooks = deleteWebhooks;
const deleteFailingWebhooks = async (event) => {
    let tenantUid;
    let sourceType;
    let failingSourceId;
    const { tenantKey } = event.args;
    if (tenantKey) {
        const tenantKeyElements = lodash_1.default.split(tenantKey, Util_1.SOURCE_SEPARATOR);
        if (tenantKeyElements.length < 3) {
            throw new Error(`tenantKey is not formatted like tenantUid__producerType__producerId where tenantKey=${tenantKey}`);
        }
        tenantUid = tenantKeyElements[0];
        sourceType = tenantKeyElements[1];
        failingSourceId = tenantKeyElements[2];
    }
    else {
        ({ tenantUid } = (0, Util_1.getFromHeaders)(event));
        const { producerType, producerId } = event.args;
        sourceType = producerType;
        failingSourceId = producerId;
    }
    if (!tenantUid) {
        throw new Error('tenantUid (or tenantKey) is a required parameter to identify the failing webhook to delete');
    }
    if (!sourceType) {
        throw new Error('producerType (or tenantKey) is a required parameter to identify the failing webhook to delete');
    }
    if (!failingSourceId) {
        throw new Error('producerId (or tenantKey) is a required parameter to identify the failing webhook to delete');
    }
    const { whatif } = event.args;
    const safeWhatIf = (whatif !== undefined) ? whatif : true;
    const dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    return removeActiveTenantFailingWebhook(dynamoDBServices, tenantUid, sourceType, failingSourceId, safeWhatIf);
};
exports.deleteFailingWebhooks = deleteFailingWebhooks;
const removeActiveTenantFailingWebhook = async (dynamoDBServices, tenantUid, sourceType, failingSourceId, safeWhatIf = true) => {
    const tenantPrefix = `${tenantUid}__${sourceType}`;
    const activeTenants = await dynamoDBServices.getItemsBySecondaryIndex(TenantServices_1.TenantConfiguration.TABLE_NAME, TenantServices_1.TenantConfiguration.getDynamoDBTenantUidIndex(), TenantServices_1.TenantConfiguration.TENANT_UID, tenantUid, 'begins_with(tenantKey, :prefix) and attribute_not_exists(deletedAt) and not contains(tenantKey, :failingSourceId)', undefined, { ':prefix': tenantPrefix, ':failingSourceId': failingSourceId });
    if (activeTenants.length === 0) {
        throw new Error(`No non-deleted tenants found where tenantKey begins with '${tenantPrefix}'`);
    }
    const activeTenant = activeTenants[0];
    const activeTenantKeyElements = lodash_1.default.split(activeTenant.tenantKey, DynamoDBServices_1.DynamoDBServices.KEY_SEPARATOR);
    if (activeTenantKeyElements.length < 3) {
        throw new Error(`Queried tenantKey is not formatted like tenantUid__sourceType__sourceId where tenantKey=${activeTenant.tenantKey}`);
    }
    const activeSourceId = activeTenantKeyElements[2];
    const activeTenantValue = JSON.parse(activeTenant.value || '{}');
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    let service;
    switch (sourceType) {
        case CommonTypes_1.Source.AMP:
            service = new AmpCollectorServices_1.AmpCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, activeSourceId)), tenantUid, '', activeSourceId);
            break;
        case CommonTypes_1.Source.JAMF:
            service = new JamfCollectorServices_1.JamfCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.JAMF, activeSourceId)), tenantUid, '', activeSourceId);
            break;
        case CommonTypes_1.Source.ORBITAL:
            service = new OrbitalCollectorServices_1.OrbitalCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, activeSourceId)), tenantUid, activeSourceId, activeTenantValue.baseURL);
            break;
        case CommonTypes_1.Source.UNIFIED_CONNECTOR:
            service = new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, activeSourceId)), activeTenantValue.baseUrl, activeTenantValue.adminBaseUrl, tenantUid, activeSourceId);
            break;
        default:
            throw new Error(`Source type '${sourceType}' has not been implemented`);
    }
    return service.removeFailingWebhooks(failingSourceId, safeWhatIf);
};
const listTenantFeatureFlags = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for listTenantFeatureFlags');
    }
    logger.info(`List featureFlags of tenantUid ${tenantUid}`);
    try {
        const tenantServices = new TenantServices_1.TenantServices();
        return tenantServices.getFeatureFlags(tenantUid);
    }
    catch (e) {
        logger.error(`Failed to list feature flags of tenantUid ${tenantUid}`, e);
        throw e;
    }
};
exports.listTenantFeatureFlags = listTenantFeatureFlags;
const addTenantFeatureFlags = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for addTenantFeatureFlags');
    }
    const { featureFlags } = event.args;
    logger.info(`Adding featureFlags ${featureFlags} to tenantUid ${tenantUid}`);
    try {
        const tenantServices = new TenantServices_1.TenantServices();
        return tenantServices.addFeatureFlags(tenantUid, JSON.parse(featureFlags) || {});
    }
    catch (e) {
        logger.error(`Failed adding featureFlags ${featureFlags} to tenantUid ${tenantUid}`, e);
        throw e;
    }
};
exports.addTenantFeatureFlags = addTenantFeatureFlags;
const enableFeatureFlagForAllTenants = async (event) => {
    const { featureFlag } = event.args;
    logger.info(`Enable featureFlag ${featureFlag} for all tenants`);
    try {
        const tenantServices = new TenantServices_1.TenantServices();
        return tenantServices.enableFeatureFlagForAllTenants(featureFlag);
    }
    catch (e) {
        logger.error(`Failed to enable featureFlag ${featureFlag} for all tenants`, e);
        throw e;
    }
};
exports.enableFeatureFlagForAllTenants = enableFeatureFlagForAllTenants;
const disableFeatureFlagForAllTenants = async (event) => {
    const { featureFlag } = event.args;
    logger.info(`Disable featureFlag ${featureFlag} for all tenants`);
    try {
        const tenantServices = new TenantServices_1.TenantServices();
        return tenantServices.disableFeatureFlagForAllTenants(featureFlag);
    }
    catch (e) {
        logger.error(`Failed to disable featureFlag ${featureFlag} for all tenants`, e);
        throw e;
    }
};
exports.disableFeatureFlagForAllTenants = disableFeatureFlagForAllTenants;
const removeTenantFeatureFlags = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for removeTenantFeatureFlags');
    }
    const { featureFlags } = event.args;
    logger.info(`Removing featureFlags ${featureFlags} for tenantUid ${tenantUid}`);
    try {
        const tenantServices = new TenantServices_1.TenantServices();
        return tenantServices.removeFeatureFlags(tenantUid, JSON.parse(featureFlags) || {});
    }
    catch (e) {
        logger.error(`Failed to remove featureFlags ${featureFlags} for tenantUid ${tenantUid}`, e);
        throw e;
    }
};
exports.removeTenantFeatureFlags = removeTenantFeatureFlags;
const setSXModuleInstanceId = async (event) => {
    const { tenantUid, producerName, source, moduleInstanceId } = event;
    if (!tenantUid || !producerName || !source || !moduleInstanceId) {
        throw new Error('missing [tenantUid, producerName, source, moduleInstanceId] values, which are mandatory for setSXModuleInstanceId');
    }
    const tenantServices = new TenantServices_1.TenantServices();
    const allTenantConfigs = await tenantServices.getTenantConfigurations(tenantUid);
    const producers = lodash_1.default.filter(allTenantConfigs, { name: producerName });
    if (!producers || lodash_1.default.isEmpty(producers)) {
        throw new Error(`Producer with name ${producerName} does not exist at tenant [${tenantUid}]`);
    }
    const producer = lodash_1.default.find(producers, currentProducer => {
        const producerConfigValue = JSON.parse(currentProducer.value);
        return producerConfigValue.source === source;
    });
    if (!producer) {
        throw new Error(`Producer with name ${producerName} and type ${source} does not exist at tenant [${tenantUid}]`);
    }
    const producerConfigValue = JSON.parse(producer.value);
    const cfgKey = (0, Util_1.toSourceString)(producerConfigValue.source, producerConfigValue.sourceId);
    logger.info(`Updating ${cfgKey} on tenant ${tenantUid}, moduleInstanceId: ${moduleInstanceId}`);
    return tenantServices.updateProducerConfiguration(tenantUid, cfgKey, undefined, undefined, producer.value, moduleInstanceId);
};
exports.setSXModuleInstanceId = setSXModuleInstanceId;
const addIrohModuleInstanceAsProducer = async (tenantUid, moduleInstance, moduleType, context) => {
    const sourceId = (0, uuid_1.v4)();
    const tenantServices = new TenantServices_1.TenantServices();
    const featureFlags = await tenantServices.getFeatureFlags(tenantUid);
    const isGenericFeatureFlagEnabled = featureFlags.includes(TenantServices_1.FeatureFlag.GENERIC_SOURCE);
    let isGeneric = false;
    let producerType = SourceUtils_1.SourceUtils.getSourceByModuleType(moduleType);
    let itemValue;
    if (isGenericFeatureFlagEnabled && (!producerType || GenericSourceUtils_1.GenericSourceUtils.isSourceConfiguration(producerType))) {
        itemValue = getGenericSourceModuleAttributes(moduleInstance, moduleType, sourceId, featureFlags);
        if (itemValue) {
            producerType = itemValue.source;
            isGeneric = true;
        }
    }
    if (!producerType) {
        return undefined;
    }
    if (!itemValue) {
        itemValue = getDefinedModuleAttributes(moduleInstance, moduleType, producerType, sourceId, featureFlags);
    }
    const cfgKey = (0, Util_1.toSourceString)(producerType, sourceId);
    logger.info(`Creating ${cfgKey} producer on tenant ${tenantUid}`);
    const producerConfig = new TenantServices_1.TenantConfiguration(tenantUid, cfgKey, JSON.stringify(itemValue), undefined, moduleInstance.name, moduleInstance.id, isGeneric);
    const currentProducer = tenantServices.addTenantConfiguration(producerConfig);
    await new SystemRuleService_1.SystemRuleService(tenantUid).createSystemRulesForProducer(producerType, sourceId, moduleInstance.name, true);
    logger.debug(`Scheduling task for producer ${JSON.stringify(currentProducer)}`);
    const scheduledTasksService = new ScheduleServices_1.ScheduledTaskServices();
    await scheduledTasksService.scheduleProducerTasks(tenantUid, cfgKey);
    if ((0, CommonTypes_1.sourceSupportsWebhooks)(producerType)) {
        logger.debug(`Registering webhook for producer ${JSON.stringify(currentProducer)}`);
        const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
        await awsSecretsService.init();
        const secrets = awsSecretsService.getSecret((0, Util_1.toSourceString)(producerType, sourceId));
        const svc = ProducerUtil_1.ProducerUtil.getPushCollectorService(producerConfig, secrets, tenantUid, context, sourceId, producerType);
        try {
            await svc.registerWebhooks();
        }
        catch (e) {
            logger.error(`Failed to register webhook ${JSON.stringify(e)}, ${e.message}`);
        }
    }
    return { producerType, producerId: sourceId };
};
exports.addIrohModuleInstanceAsProducer = addIrohModuleInstanceAsProducer;
function getDefinedModuleAttributes(moduleInstance, moduleType, producerType, sourceId, featureFlags) {
    var _a;
    const baseURL = SourceUtils_1.SourceUtils.extractModuleInstanceBaseUrl(producerType, moduleInstance, moduleType);
    const reducedSchedulingFeatureFlag = featureFlags.includes(TenantServices_1.FeatureFlag.REDUCE_SCHEDULING);
    const onceAWeek = reducedSchedulingFeatureFlag && (0, CommonTypes_1.sourceWithLessSync)(producerType);
    const itemValue = {
        sourceId,
        baseURL,
        schedule: onceAWeek ? (0, Util_1.generateCronOnceAWeek)() : (0, Util_1.generateCronOnceADay)(),
        source: producerType
    };
    if (producerType === CommonTypes_1.Source.MERAKI) {
        itemValue.merakiNetworkId = lodash_1.default.get(moduleInstance.settings, 'custom_network-instance-id');
    }
    if (producerType === CommonTypes_1.Source.UMBRELLA) {
        itemValue.organizationId = lodash_1.default.get(moduleInstance.settings, 'organization-id');
        itemValue.umbrellaV2Support = isUmbrellaV2Support(moduleInstance);
    }
    if (producerType === CommonTypes_1.Source.UNIFIED_CONNECTOR) {
        itemValue.adminBaseUrl = (_a = lodash_1.default.find(moduleType.external_references, { class: IrohModuleInstanceClient_1.IrohModuleInstanceClient.CSC_ADMIN_URL_CLASS })) === null || _a === void 0 ? void 0 : _a.link;
    }
    if (producerType === CommonTypes_1.Source.SERVICENOW) {
        itemValue.baseURL = lodash_1.default.replace(itemValue.baseURL, /service-now.com\/(.+)/g, 'service-now.com');
    }
    return itemValue;
}
function getGenericSourceModuleAttributes(moduleInstance, moduleType, sourceId, featureFlags) {
    const sourceConfiguration = GenericSourceUtils_1.GenericSourceUtils.getSourceConfigurationByModuleType(moduleType);
    if (!sourceConfiguration) {
        throw new Error(`No source configuration defined for moduleType ${JSON.stringify(moduleType)}`);
    }
    const producerType = sourceConfiguration.sourceName;
    if (sourceConfiguration.requiredFeatureFlag && !featureFlags.includes(sourceConfiguration.requiredFeatureFlag)) {
        logger.info(`Cannot create new module for source ${producerType} because feature is not enabled: ${sourceConfiguration.requiredFeatureFlag}`);
        return undefined;
    }
    if (!sourceConfiguration.integrationModule) {
        throw new Error(`No integrationModule in the source configuration for source ${producerType}`);
    }
    const moduleAttributes = {};
    for (const attribute of sourceConfiguration.integrationModule.attributesToMap) {
        if (moduleAttributes[attribute.name] && !attribute.overwrite) {
            continue;
        }
        if (attribute.path) {
            if (attribute.source === GenericSourceConfiguration_1.ModuleAttributeSource.INSTANCE) {
                moduleAttributes[attribute.name] = lodash_1.default.get(moduleInstance, attribute.path);
            }
            else if (attribute.source === GenericSourceConfiguration_1.ModuleAttributeSource.TYPE) {
                moduleAttributes[attribute.name] = lodash_1.default.get(moduleType, attribute.path);
            }
        }
        if (moduleAttributes[attribute.name] && attribute.regex) {
            const regex = new RegExp(attribute.regex);
            const match = moduleAttributes[attribute.name].match(regex);
            if (match) {
                if (attribute.captureGroupName && match.groups[attribute.captureGroupName]) {
                    moduleAttributes[attribute.name] = lodash_1.default.get(match.groups, attribute.captureGroupName);
                }
                else {
                    moduleAttributes[attribute.name] = match[0];
                }
            }
        }
        if (attribute.literal) {
            moduleAttributes[attribute.name] = substituteVariablesInString(attribute.literal, Object.entries(moduleAttributes));
        }
    }
    const baseURL = moduleAttributes.baseURL;
    if (!baseURL) {
        throw new Error(`baseURL is not defined in the source configuration for source ${producerType}`);
    }
    const reducedSchedulingFeatureFlag = featureFlags.includes(TenantServices_1.FeatureFlag.REDUCE_SCHEDULING);
    const onceAWeek = reducedSchedulingFeatureFlag && (0, CommonTypes_1.sourceWithLessSync)(producerType);
    const itemValue = {
        sourceId,
        baseURL,
        schedule: onceAWeek ? (0, Util_1.generateCronOnceAWeek)() : (0, Util_1.generateCronOnceADay)(),
        source: producerType
    };
    const attrNames = Object.getOwnPropertyNames(moduleAttributes);
    for (const attrName of attrNames) {
        if (!itemValue[attrName]) {
            itemValue[attrName] = moduleAttributes[attrName];
        }
    }
    return itemValue;
}
function substituteVariablesInString(input, replacement) {
    if (input) {
        for (const [key, value] of replacement) {
            input = input.replace(new RegExp(`(\\$\{${key}})`, 'g'), value);
        }
    }
    return input;
}
function isUmbrellaV2Support(moduleInstance) {
    const v2Key = lodash_1.default.get(moduleInstance.settings, UMBRELLA_V2_API_KEY);
    return !lodash_1.default.isUndefined(v2Key) && !lodash_1.default.isEmpty(v2Key);
}
async function updateProducerProperties(dataToUpdate, producer, cfgKey, tenantUid, tenantServices, moduleInstance) {
    const cfgValue = JSON.stringify(lodash_1.default.merge((0, Util_1.toObject)(producer.properties), dataToUpdate, { source: producer.producerType, sourceId: producer.producerId, schedule: producer.cronSchedule }));
    logger.info(`Updating ${cfgKey} producer on tenant ${tenantUid}, value: ${cfgValue}`);
    await tenantServices.updateProducerConfiguration(tenantUid, cfgKey, undefined, moduleInstance.name, cfgValue, moduleInstance.id);
}
const syncProducerWithIrohModuleInstance = async (tenantUid, moduleInstance, moduleType, producer) => {
    var _a;
    const tenantServices = new TenantServices_1.TenantServices();
    const functionStateServices = new FunctionStateServices_1.FunctionStateServices();
    const cfgKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
    const baseURL = SourceUtils_1.SourceUtils.extractModuleInstanceBaseUrl(producer.producerType, moduleInstance, moduleType);
    const producerBaseURL = lodash_1.default.find(producer.properties, { key: 'baseURL' });
    const updates = {};
    if (baseURL !== (producerBaseURL === null || producerBaseURL === void 0 ? void 0 : producerBaseURL.value)) {
        updates.baseURL = baseURL;
    }
    const nameHasChanged = moduleInstance.name !== producer.name;
    if (producer.producerType === CommonTypes_1.Source.MERAKI) {
        const sxMerakiNetworkId = lodash_1.default.get(moduleInstance.settings, 'custom_network-instance-id');
        const merakiNetworkId = lodash_1.default.find(producer.properties, { key: 'merakiNetworkId' });
        if (sxMerakiNetworkId !== (merakiNetworkId === null || merakiNetworkId === void 0 ? void 0 : merakiNetworkId.value)) {
            updates.merakiNetworkId = sxMerakiNetworkId;
        }
    }
    if (producer.producerType === CommonTypes_1.Source.UMBRELLA) {
        logger.debug(`Umbrella producer sync. Current: ${JSON.stringify(producer)}, mt: ${JSON.stringify(moduleType)}, mi: ${JSON.stringify(moduleInstance)}`);
        const sxOrgId = lodash_1.default.get(moduleInstance.settings, 'organization-id');
        const orgId = lodash_1.default.find(producer.properties, { key: 'organizationId' });
        if (sxOrgId !== (orgId === null || orgId === void 0 ? void 0 : orgId.value)) {
            updates.organizationId = sxOrgId;
        }
        const umbrellaV2Support = isUmbrellaV2Support(moduleInstance);
        if (producer.properties.umbrellaV2Support !== umbrellaV2Support) {
            updates.umbrellaV2Support = umbrellaV2Support;
            const sourceKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
            await functionStateServices.deleteByKey(`${tenantUid}__${process.env.ENV_PREFIX}-${(0, CommonTypes_1.sourceToFetchFunctionName)(CommonTypes_1.Source.UMBRELLA)}__${sourceKey}`);
        }
    }
    if (producer.producerType === CommonTypes_1.Source.UNIFIED_CONNECTOR) {
        const sxAdminBaseUrl = (_a = lodash_1.default.find(moduleType.external_references, { class: IrohModuleInstanceClient_1.IrohModuleInstanceClient.CSC_ADMIN_URL_CLASS })) === null || _a === void 0 ? void 0 : _a.link;
        const cscAdminBaseUrl = lodash_1.default.find(producer.properties, { key: 'adminBaseUrl' });
        if (sxAdminBaseUrl !== (cscAdminBaseUrl === null || cscAdminBaseUrl === void 0 ? void 0 : cscAdminBaseUrl.value)) {
            updates.adminBaseUrl = sxAdminBaseUrl;
        }
    }
    if (producer.producerType === CommonTypes_1.Source.SERVICENOW) {
        updates.baseURL = lodash_1.default.replace(baseURL, /service-now.com\/(.+)/g, 'service-now.com');
    }
    if (!lodash_1.default.isEmpty(updates) || nameHasChanged) {
        logger.debug(`Will be updating the following fields ${JSON.stringify(updates)} for ${producer.producerType}/${moduleInstance.id} on tenant ${tenantUid}`);
        await updateProducerProperties(updates, producer, cfgKey, tenantUid, tenantServices, moduleInstance);
    }
    else {
        logger.debug(`No updates needed for ${producer.producerType}/${moduleInstance.id} on tenant ${tenantUid}.`);
    }
    logger.debug(`Finished syncing ${producer.producerType}/${moduleInstance.id} `);
};
exports.syncProducerWithIrohModuleInstance = syncProducerWithIrohModuleInstance;
const cleanupSchedulingTimes = async () => {
    logger.debug('Will be attempting to cleanup scheduling of all tenants');
    const ts = new TenantServices_1.TenantServices();
    const tenants = await ts.getAllTenants();
    for (const tenant of tenants) {
        logger.debug(`Will be attempting to cleanup scheduling for tenant ${tenant.id}`);
        const tenantProducers = await ts.getProducerConfigurations(tenant.id);
        const filterProducers = lodash_1.default.filter(tenantProducers, producer => !(0, CommonTypes_1.sourceNotSupportingPull)(producer.producerType));
        if (filterProducers.length === 0) {
            logger.debug(`No need to cleanup scheduling for tenant ${tenant.id}. No relevant sources`);
            continue;
        }
        logger.debug(`Will be attempting to cleanup scheduling of ${filterProducers.length} sources for tenant ${tenant.id}`);
        for (const producer of filterProducers) {
            try {
                if (lodash_1.default.isEmpty(producer.cronSchedule) || (0, Util_1.isScheduledMultipleTimesADay)(producer.cronSchedule)) {
                    const updatedSchedule = cron_time_generator_1.CronTime.everyDayAt(ScheduleServices_1.ScheduledTask.getRandomHour(), 0);
                    const cfgKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
                    logger.info(`producer ${cfgKey} on tenant ${tenant.id} is scheduled multiple times a day: ${producer.cronSchedule}`);
                    const existingProducerConfig = await ts.getTenantConfiguration(tenant.id, cfgKey);
                    const value = lodash_1.default.merge(JSON.parse((existingProducerConfig === null || existingProducerConfig === void 0 ? void 0 : existingProducerConfig.value) || '{}'), { schedule: updatedSchedule });
                    const cfgVal = JSON.stringify(value);
                    logger.info(`updating value config of ${cfgKey} on tenant ${tenant.id} to value: ${cfgVal}`);
                    await ts.updateProducerConfiguration(tenant.id, cfgKey, undefined, undefined, cfgVal);
                    logger.info(`Finished updating value config of ${cfgKey} on tenant ${tenant.id} to value: ${cfgVal}`);
                }
            }
            catch (e) {
                logger.error(`Failed updating schedule ${producer.cronSchedule} for ${producer.producerId} for tenant ${tenant.id}`);
            }
        }
        logger.debug(`Finished cleanup scheduling for tenant ${tenant.id}`);
    }
    logger.debug('Finished cleanup scheduling for all tenants');
};
exports.cleanupSchedulingTimes = cleanupSchedulingTimes;
const updateWebhookForAllTenants = async (event) => {
    const { source, tenantUid, numOfShards = -1, currentShard = -1 } = event;
    const { registerAll, forceRefreshWebhooks, refreshSecrets } = event || false;
    logger.debug(`Will be attempting to update queries for all tenants (re-registering webhooks) for provider ${source}. numOfShards: ${numOfShards}, current shard: ${currentShard}, register all: ${registerAll}, force refresh webhooks: ${forceRefreshWebhooks}, refresh secrets: ${refreshSecrets}, event: ${JSON.stringify(event)}`);
    const ts = new TenantServices_1.TenantServices();
    let tenants = (tenantUid) ? [await ts.getTenantById(tenantUid)].filter(x => x !== undefined) : await ts.getAllTenants();
    if (tenants.length === 0) {
        if (tenantUid) {
            logger.error(`Could not find tenant by ID ${tenantUid}`);
        }
        else {
            logger.error('Could not find any tenants');
        }
        return;
    }
    const dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    if (!tenantUid && numOfShards >= 0 && currentShard >= 0) {
        const totalTenants = tenants.length;
        tenants = lodash_1.default.filter(tenants, tenant => !lodash_1.default.isEmpty(tenant.id) && tenant.id.charCodeAt(0) % numOfShards === currentShard);
        logger.debug(`Running shard ${currentShard} / ${numOfShards} for ${tenants.length} out of ${totalTenants} total tenants`);
    }
    for (const tenant of tenants) {
        try {
            const producerConfig = await ts.getProducerConfigurations(tenant.id);
            const sourceProducers = lodash_1.default.filter(producerConfig, x => x.producerType === source);
            if (!sourceProducers || sourceProducers.length === 0) {
                logger.debug(`No producers for tenant ${tenant.id} with type ${source}`);
                continue;
            }
            const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenant.id);
            await awsSecretsService.init();
            await reregisterWHForProducers(sourceProducers, tenant, awsSecretsService);
        }
        catch (e) {
            logger.error(`Failed update webhook for tenant ${tenant.id}, ${JSON.stringify(e.message)}`);
        }
    }
    if (tenantUid) {
        logger.debug(`Finished updating queries for tenant ${tenantUid} (re-registering webhooks where registerAll=${registerAll}, forceRefreshWebhooks=${forceRefreshWebhooks}, refreshSecrets=${refreshSecrets})`);
    }
    else {
        logger.debug(`Finished updating queries for all tenants (re-registering webhooks where registerAll=${registerAll}, forceRefreshWebhooks=${forceRefreshWebhooks}, refreshSecrets=${refreshSecrets})`);
    }
    async function reregisterWHForProducers(sourceProducers, tenant, awsSecretsService) {
        for (const producer of sourceProducers) {
            try {
                logger.debug(`Will be re-registering webhook for producer ${JSON.stringify(producer)} of tenant ${tenant.toString()}`);
                const sourceString = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
                const secrets = awsSecretsService.getSecret(sourceString);
                const tenantConfiguration = await (new TenantServices_1.TenantServices()).getTenantConfigurationOrFail(tenant.id, producer.producerType, producer.producerId);
                const collectorService = ProducerUtil_1.ProducerUtil.getPushCollectorService(tenantConfiguration, secrets, tenant.id, { functionName: 'reregisterWHForProducers' }, producer.producerId, producer.producerType);
                const hasRegisteredWebhooks = await collectorService.hasRegisteredWebhooks();
                if (hasRegisteredWebhooks) {
                    if (!forceRefreshWebhooks) {
                        const status = await collectorService.getWebhookStatus();
                        if (status.isSuccess()) {
                            continue;
                        }
                        if (status.isApiAuthError()) {
                            logger.info(`skip processing for tenant: ${tenant.id}, producer: ${producer.producerType} ${producer.producerId}, ${status.exceptionDetail}`);
                            continue;
                        }
                        if (status.isErrorUnknownAPIkey()) {
                            await removeActiveTenantFailingWebhook(dynamoDBServices, tenant.id, producer.producerType, producer.producerId, false);
                            continue;
                        }
                    }
                    logger.info(`Deleting webhook for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}`);
                    await collectorService.removeWebhooks();
                }
                if (refreshSecrets && source !== CommonTypes_1.Source.ORBITAL) {
                    if (!hasRegisteredWebhooks || !await collectorService.hasRegisteredWebhooks()) {
                        await collectorService.removeWebhookSecrets(sourceString, secrets);
                    }
                    else {
                        logger.error(`Error: Webhook could not be removed and is still registered for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}`);
                    }
                }
                if (hasRegisteredWebhooks || registerAll) {
                    logger.info(`Registering webhook for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}`);
                    await collectorService.registerWebhooks();
                    logger.info(`Finished updating webhook for tenant ${tenant.id}, producer ${producer.producerType} ${producer.producerId}`);
                }
            }
            catch (e) {
                logger.error(`Failed to update webhook for tenant: ${tenant.id}, producer: ${producer.producerType} ${producer.producerId}, ${JSON.stringify(e.message)}`);
            }
        }
    }
};
exports.updateWebhookForAllTenants = updateWebhookForAllTenants;
const updateWebhookForAllTenantsByShards = async (event) => {
    const { source, numOfShards, whatif } = event;
    const { registerAll, forceRefreshWebhooks } = event || false;
    logger.debug(`Will be attempting to update queries for all tenants (re-registering webhooks) for provider ${source}, using ${numOfShards} shards`);
    const shards = lodash_1.default.range(numOfShards);
    const lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
    const functionName = `${process.env.ENV_PREFIX}-update-query-for-all`;
    for (const currentShard of shards) {
        const invokeParams = { source, registerAll, numOfShards, currentShard, forceRefreshWebhooks, whatif };
        await lambdaServices.asyncInvoke(functionName, JSON.stringify(invokeParams));
    }
};
exports.updateWebhookForAllTenantsByShards = updateWebhookForAllTenantsByShards;
const deleteAllDevicesInESForTenant = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    logger.debug(`Deleting all devices for tenant from ES: ${tenantUid}`);
    const esServices = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    await esServices.deleteTenantEndpointData();
    logger.debug(`Finished deleting all devices for tenant from ES: ${tenantUid}`);
};
exports.deleteAllDevicesInESForTenant = deleteAllDevicesInESForTenant;
const deleteAllPersonsInESForTenant = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    logger.debug(`Deleting all persons for tenant from ES: ${tenantUid}`);
    const esServices = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    await esServices.deleteTenantPersonData();
    logger.debug(`Finished deleting all persons for tenant from ES: ${tenantUid}`);
};
exports.deleteAllPersonsInESForTenant = deleteAllPersonsInESForTenant;
const removeLabelsProcessing = async (event, context) => {
    logger.info(`Start label deletion processing, ${JSON.stringify(event)}`);
    const { tenantUid, labelIds, processingMetadata } = event;
    if (lodash_1.default.isUndefined(tenantUid) || lodash_1.default.isEmpty(labelIds)) {
        throw new Error(`Input data is invalid ${JSON.stringify(event)}`);
    }
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context, 240000);
    const esService = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    const scrollId = await publishQueriedDeviceIds(tenantUid, esService, timeBasedAsyncLambdaInvoker, esService.includeLabelsSearchQuery(labelIds), processingMetadata === null || processingMetadata === void 0 ? void 0 : processingMetadata.scrollId);
    if (lodash_1.default.isUndefined(scrollId)) {
        const labelDeviceService = new LabelDeviceService_1.LabelDeviceService(tenantUid);
        const ruleService = new RuleService_1.RuleService(tenantUid);
        const labelsMapBeforeDeletion = await new LabelService_1.LabelService(tenantUid).getLabelsMetadataMap();
        await Promise.all([labelDeviceService.removeLabelsFromAllDevices(labelIds), ruleService.deleteLabelsFromRules(labelIds, labelsMapBeforeDeletion)]);
        logger.info('Finished external label deletion processing');
    }
    else {
        logger.info('Execution was stopped by time, function will be restarted');
        await timeBasedAsyncLambdaInvoker.invokeLambda({ tenantUid, labelIds, processingMetadata: { scrollId } });
    }
};
exports.removeLabelsProcessing = removeLabelsProcessing;
const fetchAndNotifyDevices = async (event, context) => {
    logger.debug(`Start fetchAndNotifyDevices, ${JSON.stringify(event)}`);
    const { tenantUid, filter, exclusionList, processingMetadata } = event;
    if (lodash_1.default.isUndefined(tenantUid) || lodash_1.default.isUndefined(filter)) {
        throw new Error('tenantUid and filter must be provided');
    }
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context, 240000);
    const esService = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    const scrollId = await publishQueriedDeviceIds(tenantUid, esService, timeBasedAsyncLambdaInvoker, esService.buildQueryWithExcludedDeviceIds(filter, exclusionList || []), processingMetadata === null || processingMetadata === void 0 ? void 0 : processingMetadata.scrollId);
    if (scrollId) {
        logger.debug('Execution was stopped by time, function will be restarted');
        await timeBasedAsyncLambdaInvoker.invokeLambda({ tenantUid, filter, processingMetadata: { scrollId } });
    }
};
exports.fetchAndNotifyDevices = fetchAndNotifyDevices;
const publishQueriedDeviceIds = async (tenantUid, esService, timeBasedAsyncLambdaInvoker, query, scrollId) => {
    const incidentService = new IncidentService_1.IncidentService(tenantUid);
    const webhookNotificationService = new WebhookNotificationService_1.WebhookNotificationService();
    const incidentsEvtBusArn = await incidentService.getBusArnIfTenantIsSupportedIncidents();
    const shouldSendDsWebhookNotification = (await webhookNotificationService.getWebhooks(tenantUid)).length > 0;
    let deviceIds = [];
    if (incidentsEvtBusArn || shouldSendDsWebhookNotification) {
        const res = await esService.getPostureEndpointIdsWithTimeControl(query, timeBasedAsyncLambdaInvoker, scrollId);
        scrollId = res.scrollId;
        deviceIds = res.deviceIds;
        if (deviceIds.length > 0 && incidentsEvtBusArn) {
            await incidentService.publishEvents({ deviceIds, tenantId: tenantUid }, incidentsEvtBusArn);
        }
        if (deviceIds.length > 0 && shouldSendDsWebhookNotification) {
            await webhookNotificationService.sendDeviceEvent(tenantUid, WebhookHelper_1.WebhookEventType.DEVICE_UPDATE, deviceIds);
        }
    }
    return scrollId;
};
