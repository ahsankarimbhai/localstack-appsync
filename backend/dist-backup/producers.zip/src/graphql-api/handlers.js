"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteDevicesFinancialRiskFactor = exports.setDevicesAssetValue = exports.setDevicesFinancialRiskFactor = exports.removeLabelsForAFilter = exports.addLabelsForAFilter = exports.removeLabelsForDevices = exports.addLabelsForDevices = exports.deleteLabels = exports.updateLabels = exports.createLabel = exports.getLabels = exports.moveDevicesToDeployment = exports.getModuleTypeId = exports.getTenantTags = exports.getTenantGroups = exports.getTenantUCDeployments = exports.getTenantPolicies = exports.getCollectionErrors = exports.collectionMetrics = exports.dashboardPersonCounts = exports.dashboardCounts = exports.getTenantMetadata = exports.enableSXOrganization = exports.getTenantSetupStatus = exports.isSXOrganizationEnabled = exports.deleteFilter = exports.addFilter = exports.updateProducerConfiguration = exports.addTenantProducerConfiguration = exports.getJsonSchemas = exports.getProducerConfigurations = exports.addProducerConfiguration = exports.listPosturePersonsHistoricalState = exports.listPostureEndpointsHistoricalState = exports.exportPosturePersonsScroll = exports.exportPostureDevicesScroll = exports.listPosturePersons = exports.listPostureDevices = exports.getPosturePersonsFilterChoices = exports.countPosturePersons = exports.countPostureDevices = exports.getPostureEndpointMergingLogic = exports.getPosturePerson = exports.getPostureDevice = exports.addInformationToEndpoint = exports.augmentWithPolicyDetails = exports.augmentWithGroupDetails = exports.getUserEndpoints = exports.getWebhooksStatus = exports.logger = void 0;
exports.deleteRule = exports.updateRule = exports.createRule = exports.getRules = exports.removeDevicesAssetValueWithFilter = exports.removeDevicesFinancialRiskFactorWithFilter = exports.setDevicesAssetValueWithFilter = exports.setDevicesFinancialRiskFactorWithFilter = exports.deleteDevicesAssetValue = void 0;
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../common/CommonTypes");
const PosturePersonService_1 = require("../model/PosturePersonService");
const PostureEndpointService_1 = require("../model/PostureEndpointService");
const TenantServices_1 = require("../common/TenantServices");
const Util_1 = require("../common/Util");
const LambdaLogger_1 = require("../common/LambdaLogger");
const GroupServices_1 = require("../services/common/GroupServices");
const VulnerabilityUtil_1 = require("../services/common/VulnerabilityUtil");
const WebhooksRegistrar_1 = require("../helpers/WebhooksRegistrar");
const ResourcesManager_1 = require("../common/ResourcesManager");
const PolicyServices_1 = require("../services/common/PolicyServices");
const ProcessingUtil_1 = require("../common/ProcessingUtil");
const SavedFilterServices_1 = require("../common/SavedFilterServices");
const TimestreamQueryServices_1 = require("../common/TimestreamQueryServices");
const AwsSecretsService_1 = require("../common/AwsSecretsService");
const IrohClient_1 = require("../common/IrohClient");
const index_1 = require("../index");
const UnifiedConnectorDeploymentServices_1 = require("../services/unifiedconnector/UnifiedConnectorDeploymentServices");
const UnifiedConnectorCollectorServices_1 = require("../services/unifiedconnector/UnifiedConnectorCollectorServices");
const DateUtils_1 = require("../common/DateUtils");
const UnifiedConnectorCollectorServicesUtility_1 = require("../services/unifiedconnector/UnifiedConnectorCollectorServicesUtility");
const AutoRefreshingBEIrohToken_1 = require("../common/AutoRefreshingBEIrohToken");
const LabelService_1 = require("../services/common/LabelService");
const LabelDeviceService_1 = require("../services/common/LabelDeviceService");
const NeptuneClientManager_1 = require("../common/neptune/NeptuneClientManager");
const RuleService_1 = require("../services/common/RuleService");
const IncidentService_1 = require("../services/common/IncidentService");
const LambdaServices_1 = require("../common/LambdaServices");
const SourceUtils_1 = require("../common/SourceUtils");
const WebhookNotificationService_1 = require("../services/common/data-sharing/WebhookNotificationService");
const WebhookHelper_1 = require("../services/common/data-sharing/WebhookHelper");
const GenericSourceUtils_1 = require("../common/generic/GenericSourceUtils");
exports.logger = new LambdaLogger_1.LambdaLogger();
const DEFAULT_METRICS_DAYS = 7;
const neptuneClientManager = NeptuneClientManager_1.NeptuneClientManager.getInstance();
const getWebhooksStatus = async (event, context) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { producerType, producerId } = event.args;
    exports.logger.info(`trigger getWebhooksStatus for tenant ${tenantUid} from producer ${producerType}, producerId ${producerId}`);
    return await new WebhooksRegistrar_1.WebhooksRegistrar(tenantUid, producerType, producerId).getWebhookStatus(context);
};
exports.getWebhooksStatus = getWebhooksStatus;
const handleFeatureFlagsReplacements = async (tenantUid, inputArray, tenantService, ipadOsFFStatus, preReleaseFFStatus) => {
    tenantService = tenantService || new TenantServices_1.TenantServices();
    ipadOsFFStatus = (ipadOsFFStatus === undefined) ? await tenantService.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.IPADOS_ENABLED) : ipadOsFFStatus;
    preReleaseFFStatus = (preReleaseFFStatus === undefined) ? await tenantService.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.PRE_RELEASE_ENABLED) : preReleaseFFStatus;
    let outArray = inputArray;
    if (!ipadOsFFStatus) {
        outArray = outArray === null || outArray === void 0 ? void 0 : outArray.map((element) => { if (element.osType === CommonTypes_1.OS.IPAD_OS) {
            element.osType = CommonTypes_1.OS.IOS;
        } return element; });
    }
    if (!preReleaseFFStatus) {
        outArray = outArray === null || outArray === void 0 ? void 0 : outArray.map((element) => { if (element.osSupport === CommonTypes_1.OsSupport.preRelease) {
            element.osSupport = undefined;
        } return element; });
    }
    return outArray;
};
const getUserEndpoints = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { type, value } = event.args;
    exports.logger.info(`get endpoints for user ${value} of type ${type} for tenant ${tenantUid}`);
    try {
        const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
        const endpoints = await service.getUserEndpoints(type, value);
        return { endpoints: await handleFeatureFlagsReplacements(tenantUid, endpoints) };
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.getUserEndpoints = getUserEndpoints;
async function augmentWithGroupDetails(postureEndpoint, tenantUid) {
    const groupServices = new GroupServices_1.GroupServices(tenantUid);
    const addProducerGroupDetails = async (src, findFn) => {
        const producers = _.filter(postureEndpoint.producers, { type: src });
        for (const producer of producers) {
            const groupValue = findFn(producer);
            if (groupValue) {
                const groupObjects = [];
                const groupIds = Array.isArray(groupValue) ? groupValue : [groupValue];
                for (const groupId of groupIds) {
                    if (groupId) {
                        const group = await groupServices.getGroup({
                            id: groupId,
                            source: src,
                            sourceId: producer.producerId
                        });
                        if (group) {
                            groupObjects.push({ name: group.name, description: group.description });
                        }
                    }
                }
                producer.properties.push({ key: 'groups', value: JSON.stringify(groupObjects) });
                if (groupObjects.length > 0) {
                    producer.properties.push({ key: 'groupName', value: groupObjects[0].name });
                }
            }
        }
    };
    await addProducerGroupDetails(CommonTypes_1.Source.AMP, (producer) => _.get(_.find(producer.properties, { key: 'groupGuid' }), 'value'));
    await addProducerGroupDetails(CommonTypes_1.Source.CROWDSTRIKE, (producer) => {
        const groupsString = _.get(_.find(producer.properties, { key: 'groupIds' }), 'value');
        return (groupsString) ? JSON.parse(groupsString) : undefined;
    });
}
exports.augmentWithGroupDetails = augmentWithGroupDetails;
async function augmentWithPolicyDetails(postureEndpoint, tenantUid) {
    const policyServices = new PolicyServices_1.PolicyServices(tenantUid);
    const addProducerPolicyDetails = async (src, findFn) => {
        const producers = _.filter(postureEndpoint.producers, { type: src });
        for (const producer of producers) {
            const policyValue = findFn(producer);
            if (policyValue) {
                const policyObjects = [];
                const policyIds = Array.isArray(policyValue) ? policyValue : [policyValue];
                for (const policyId of policyIds) {
                    const policy = await policyServices.getPolicy({
                        id: policyId,
                        source: src,
                        sourceId: producer.producerId
                    });
                    if (policy) {
                        policyObjects.push({ name: policy.name, description: policy.description, type: policy.type, isDefault: _.toString(policy.isDefault), priority: _.toString(policy.priority) });
                    }
                }
                producer.properties.push({ key: 'policies', value: JSON.stringify(policyObjects) });
            }
        }
    };
    await addProducerPolicyDetails(CommonTypes_1.Source.AMP, producer => {
        const policy = _.find(producer.properties, { key: 'policy' });
        return (policy) ? JSON.parse(policy.value).guid : undefined;
    });
    await addProducerPolicyDetails(CommonTypes_1.Source.CROWDSTRIKE, producer => {
        const policiesString = _.get(_.find(producer.properties, { key: 'policyIds' }), 'value');
        return (policiesString) ? JSON.parse(policiesString) : undefined;
    });
    await addProducerPolicyDetails(CommonTypes_1.Source.UMBRELLA, producer => _.get(_.find(producer.properties, { key: 'appliedBundle' }), 'value'));
}
exports.augmentWithPolicyDetails = augmentWithPolicyDetails;
async function addInformationToEndpoint(postureEndpointUid, tenantUid) {
    const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
    const postureEndpoint = await service.getPostureEndpoint(postureEndpointUid);
    if (postureEndpoint) {
        if (PostureEndpointService_1.PostureEndpointService.hasProducer(postureEndpoint, CommonTypes_1.Source.AMP)) {
            const vulnerabilityUtil = new VulnerabilityUtil_1.VulnerabilityUtil();
            await vulnerabilityUtil.augmentWithVulnerabilities(postureEndpoint, tenantUid);
        }
        await Promise.all([service.addDeploymentsToMergedEP(postureEndpoint), service.addDataFromESToMergedEP(postureEndpoint)]);
        await augmentWithGroupDetails(postureEndpoint, tenantUid);
        await augmentWithPolicyDetails(postureEndpoint, tenantUid);
        postureEndpoint.producers = _.sortBy(postureEndpoint.producers, producer => producer.uid);
    }
    return postureEndpoint;
}
exports.addInformationToEndpoint = addInformationToEndpoint;
const getPostureDevice = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const postureEndpointUid = event.args.id;
    exports.logger.info(`get posture endpoint ${postureEndpointUid} for tenant ${tenantUid}`);
    try {
        const returnedEndpoint = await addInformationToEndpoint(postureEndpointUid, tenantUid);
        if ((returnedEndpoint === null || returnedEndpoint === void 0 ? void 0 : returnedEndpoint.osType) === CommonTypes_1.OS.IPAD_OS) {
            if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.IPADOS_ENABLED)) {
                returnedEndpoint.osType = CommonTypes_1.OS.IOS;
            }
        }
        if ((returnedEndpoint === null || returnedEndpoint === void 0 ? void 0 : returnedEndpoint.osSupport) === CommonTypes_1.OsSupport.preRelease) {
            if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.PRE_RELEASE_ENABLED)) {
                returnedEndpoint.osSupport = undefined;
            }
        }
        return returnedEndpoint;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.getPostureDevice = getPostureDevice;
const getPosturePerson = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const posturePersonUid = event.args.id;
    exports.logger.info(`get posture person ${posturePersonUid} for tenant ${tenantUid}`);
    try {
        const service = new PosturePersonService_1.PosturePersonService(tenantUid);
        const person = await service.getPosturePerson(posturePersonUid);
        if (person) {
            if (PosturePersonService_1.PosturePersonService.hasProducer(person, CommonTypes_1.Source.AZURE_USERS)) {
                person.usedDevices = await service.getUsedDevices(person);
            }
        }
        return person;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.getPosturePerson = getPosturePerson;
const getPostureEndpointMergingLogic = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const postureEndpointUid = event.args.id;
    exports.logger.info(`get posture endpoint merging logic ${postureEndpointUid} for tenant ${tenantUid}`);
    try {
        const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
        return service.getPostureEndpointMergingLogic(postureEndpointUid);
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.getPostureEndpointMergingLogic = getPostureEndpointMergingLogic;
const countPostureDevices = async (event) => {
    var _a, _b;
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const filter = event.args.filter;
    exports.logger.info(`count posture devices for tenant ${tenantUid} with filter ${JSON.stringify(filter)}`);
    try {
        const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
        const labelService = new LabelService_1.LabelService(tenantUid);
        const tenantService = new TenantServices_1.TenantServices();
        const [labelsMap, ipadOsFFStatus] = await Promise.all([labelService.getLabelsMetadataMap(), tenantService.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.IPADOS_ENABLED)]);
        if (!ipadOsFFStatus && ((_b = (_a = filter === null || filter === void 0 ? void 0 : filter.osTypes) === null || _a === void 0 ? void 0 : _a.includes) === null || _b === void 0 ? void 0 : _b.call(_a, CommonTypes_1.OS.IOS))) {
            filter.osTypes.push(CommonTypes_1.OS.IPAD_OS);
        }
        const countPostureEndpointsResult = await service.countPostureEndpoints(filter, labelsMap);
        if (ipadOsFFStatus) {
            return countPostureEndpointsResult;
        }
        countPostureEndpointsResult.osType = aggregateIpadosToIosCount(countPostureEndpointsResult.osType);
        return countPostureEndpointsResult;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.countPostureDevices = countPostureDevices;
const countPosturePersons = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const filter = event.args.filter;
    exports.logger.info(`count posture persons for tenant ${tenantUid} with filter ${JSON.stringify(filter)}`);
    try {
        const service = new PosturePersonService_1.PosturePersonService(tenantUid);
        const labelService = new LabelService_1.LabelService(tenantUid);
        const labelsMap = await labelService.getLabelsMetadataMap();
        const countPosturePersonsResult = await service.countPosturePersons(filter, labelsMap);
        return countPosturePersonsResult;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.countPosturePersons = countPosturePersons;
const getPosturePersonsFilterChoices = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { filter, properties, limit } = event.args;
    exports.logger.info(`get posture persons filter choices for tenant ${tenantUid} with filter ${JSON.stringify(filter)}, properties ${JSON.stringify(properties)} and limit ${limit}`);
    try {
        const service = new PosturePersonService_1.PosturePersonService(tenantUid);
        const result = await service.getPosturePersonsFilterChoices(filter, properties, limit);
        return result;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.getPosturePersonsFilterChoices = getPosturePersonsFilterChoices;
const aggregateIpadosToIosCount = (arr) => {
    const iosIpadosCount = arr === null || arr === void 0 ? void 0 : arr.reduce((accumulator, currentValue) => ((currentValue.value === CommonTypes_1.OS.IPAD_OS || currentValue.value === CommonTypes_1.OS.IOS) ? accumulator + currentValue.count : accumulator), 0);
    const retArr = arr === null || arr === void 0 ? void 0 : arr.filter((item) => item.value !== CommonTypes_1.OS.IPAD_OS && item.value !== CommonTypes_1.OS.IOS);
    if (iosIpadosCount && Array.isArray(retArr)) {
        retArr.push({ value: CommonTypes_1.OS.IOS, count: iosIpadosCount });
    }
    return retArr;
};
const listPostureDevices = async (event) => {
    var _a, _b;
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const filter = event.args.filter;
    exports.logger.info(`list posture devices for tenant ${tenantUid} with filter ${JSON.stringify(filter)}`);
    try {
        const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
        const tenantService = new TenantServices_1.TenantServices();
        const ipadOsFFStatus = await tenantService.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.IPADOS_ENABLED);
        if (!ipadOsFFStatus && ((_b = (_a = filter === null || filter === void 0 ? void 0 : filter.osTypes) === null || _a === void 0 ? void 0 : _a.includes) === null || _b === void 0 ? void 0 : _b.call(_a, CommonTypes_1.OS.IOS))) {
            filter.osTypes.push(CommonTypes_1.OS.IPAD_OS);
        }
        const devices = await service.listPostureEndpoints(filter);
        return await handleFeatureFlagsReplacements(tenantUid, devices, tenantService, ipadOsFFStatus);
    }
    catch (err) {
        exports.logger.debug(`failed to process request, err: ${err.message}`);
        throw err;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.listPostureDevices = listPostureDevices;
const listPosturePersons = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const filter = event.args.filter;
    exports.logger.info(`list posture persons for tenant ${tenantUid} with filter ${JSON.stringify(filter)}`);
    try {
        const service = new PosturePersonService_1.PosturePersonService(tenantUid);
        const labelService = new LabelService_1.LabelService(tenantUid);
        const labelMap = await labelService.getLabelsMetadataMap();
        const persons = await service.listPosturePersons(filter, labelMap);
        return persons;
    }
    catch (err) {
        exports.logger.debug(`failed to process request, err: ${err.message}`);
        throw err;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.listPosturePersons = listPosturePersons;
const exportPostureDevicesScroll = async (event) => {
    var _a, _b;
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { filter, scrollId } = event.args;
    exports.logger.info(`export posture devices for tenant ${tenantUid} with filter ${JSON.stringify(filter)} and scrollId ${scrollId}`);
    try {
        const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
        const tenantService = new TenantServices_1.TenantServices();
        const ipadOsFFStatus = await tenantService.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.IPADOS_ENABLED);
        if (!ipadOsFFStatus && ((_b = (_a = filter === null || filter === void 0 ? void 0 : filter.osTypes) === null || _a === void 0 ? void 0 : _a.includes) === null || _b === void 0 ? void 0 : _b.call(_a, CommonTypes_1.OS.IOS))) {
            filter.osTypes.push(CommonTypes_1.OS.IPAD_OS);
        }
        const scrollRet = await service.exportPostureEndpointsScroll(filter, scrollId);
        if (!scrollRet) {
            return scrollRet;
        }
        scrollRet.mergedEndpoints = await handleFeatureFlagsReplacements(tenantUid, scrollRet.mergedEndpoints, tenantService, ipadOsFFStatus);
        return scrollRet;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.exportPostureDevicesScroll = exportPostureDevicesScroll;
const exportPosturePersonsScroll = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { filter, scrollId } = event.args;
    exports.logger.info(`export posture persons for tenant ${tenantUid} with filter ${JSON.stringify(filter)} and scrollId ${scrollId}`);
    try {
        const service = new PosturePersonService_1.PosturePersonService(tenantUid);
        const labelService = new LabelService_1.LabelService(tenantUid);
        const labelMap = await labelService.getLabelsMetadataMap();
        const scrollRet = await service.exportPosturePersonsScroll(filter, labelMap, scrollId);
        return scrollRet;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.exportPosturePersonsScroll = exportPosturePersonsScroll;
const listPostureEndpointsHistoricalState = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const filter = event.args.filter;
    exports.logger.info(`list posture devices historical state for tenant ${tenantUid} with filter ${JSON.stringify(filter)}`);
    try {
        const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
        return await service.listPostureEndpointsHistoricalState({
            ...filter,
            since: filter.since * 1000,
            until: filter.until * 1000
        });
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.listPostureEndpointsHistoricalState = listPostureEndpointsHistoricalState;
const listPosturePersonsHistoricalState = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const filter = event.args.filter;
    exports.logger.info(`list posture persons historical state for tenant ${tenantUid} with filter ${JSON.stringify(filter)}`);
    try {
        const service = new PosturePersonService_1.PosturePersonService(tenantUid);
        return await service.listPosturePersonsHistoricalState({
            ...filter,
            since: filter.since * 1000,
            until: filter.until * 1000
        });
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.listPosturePersonsHistoricalState = listPosturePersonsHistoricalState;
const addProducerConfiguration = async (event) => {
    const { tenantUid, role, userId } = (0, Util_1.getFromHeaders)(event);
    (0, Util_1.verifyAuthorization)(role, userId, tenantUid);
    const { producerType, name, description } = event.args.input;
    if (producerType !== CommonTypes_1.Source.CUSTOM) {
        throw new Error('producerType must be a Custom source');
    }
    validateCustomSourceFields(name, description);
    const sourceId = TenantServices_1.TenantConfiguration.generateSourceId();
    const cfgKey = (0, Util_1.toSourceString)(producerType, sourceId);
    const value = {
        sourceId,
        source: producerType
    };
    const cfgVal = JSON.stringify(value);
    const cfg = new TenantServices_1.TenantConfiguration(tenantUid, cfgKey, cfgVal, description, name);
    exports.logger.info(`adding producer configuration by ${userId} for ${cfgKey} on tenant ${tenantUid} to name: ${name}, description: ${description}, value: ${cfgVal}`);
    await addTenantProducerConfiguration(cfg);
    return {
        ...event.args.input,
        producerId: sourceId
    };
};
exports.addProducerConfiguration = addProducerConfiguration;
const getProducerConfigurations = (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    return new TenantServices_1.TenantServices().getProducerConfigurations(tenantUid);
};
exports.getProducerConfigurations = getProducerConfigurations;
const getJsonSchemas = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const tenantServices = new TenantServices_1.TenantServices();
    const featureFlags = await tenantServices.getFeatureFlags(tenantUid);
    if (!featureFlags.includes(TenantServices_1.FeatureFlag.GENERIC_SOURCE)) {
        throw new Error('Feature is not enabled for this tenant');
    }
    const producers = await tenantServices.getProducerConfigurations(tenantUid);
    const producerSet = new Set();
    _.forEach(producers, (producer) => producerSet.add(producer.producerType));
    const configurations = [];
    Array.from(producerSet).sort().forEach((producerType) => {
        const configurationsEntry = {
            producerType
        };
        try {
            const config = GenericSourceUtils_1.GenericSourceUtils.getSourceConfiguration(producerType, featureFlags);
            if (!config) {
                return;
            }
            const schema = {
                sourceName: config.sourceName,
                requiredFeatureFlag: config.requiredFeatureFlag,
                uiMapping: config.uiMapping
            };
            configurationsEntry.schema = JSON.stringify(schema);
            configurations.push(configurationsEntry);
        }
        catch (ex) {
            if (ex.message.indexOf('No configuration defined') === -1) {
                configurationsEntry.error = ex.message;
                configurations.push(configurationsEntry);
            }
        }
    });
    return configurations;
};
exports.getJsonSchemas = getJsonSchemas;
function shouldContainCronExpression(producerType, cronSchedule) {
    return !(0, CommonTypes_1.sourceNotSupportingPull)(producerType) && !cronSchedule;
}
function validateCustomSourceFields(name, description) {
    const nameValue = _.trim(name);
    if (!nameValue) {
        throw new Error('Name cannot be left blank');
    }
    if (nameValue.length > 50) {
        throw new Error('Name can not exceed 50 characters');
    }
    const descriptionValue = _.trim(description);
    if (descriptionValue.length > 300) {
        throw new Error('Description can not exceed 300 characters');
    }
}
function limitCronSchedule(cronSchedule) {
    if (!cronSchedule) {
        return cronSchedule;
    }
    const tokens = cronSchedule.split(' ');
    if (tokens.length < 5) {
        throw new Error('Schedule contains too few tokens (should be like 0 0 * * *)');
    }
    if (tokens.length > 5) {
        throw new Error('Schedule contains too many tokens (should be like 0 0 * * *)');
    }
    const min = '0';
    tokens.shift();
    const hour = tokens.shift();
    if (hour.indexOf('*') > -1 || hour.indexOf(',') > -1 || hour.indexOf('-') > -1 || hour.indexOf('/') > -1) {
        throw new Error('Schedule may not run more than once per day');
    }
    return `${min} ${hour} ${tokens.join(' ')}`;
}
async function addTenantProducerConfiguration(cfg) {
    const tenantServices = new TenantServices_1.TenantServices();
    if (cfg.name) {
        await tenantServices.verifyDistinctName(cfg.tenantUid, cfg.name);
    }
    return tenantServices.addTenantConfiguration(cfg);
}
exports.addTenantProducerConfiguration = addTenantProducerConfiguration;
const updateProducerConfiguration = async (event) => {
    const { tenantUid, role, userId } = (0, Util_1.getFromHeaders)(event);
    (0, Util_1.verifyAuthorization)(role, userId, tenantUid);
    const { producerType, producerId, cronSchedule } = event.args.input;
    let { name, description } = event.args.input;
    if (producerType !== CommonTypes_1.Source.CUSTOM) {
        name = undefined;
        description = undefined;
    }
    else {
        validateCustomSourceFields(name, description);
    }
    if (shouldContainCronExpression(producerType, cronSchedule)) {
        throw new Error('Schedule is mandatory and must be defined');
    }
    const limitedCronSchedule = limitCronSchedule(cronSchedule);
    const cfgKey = (0, Util_1.toSourceString)(producerType, producerId);
    const tenantServices = new TenantServices_1.TenantServices();
    const existingProducerConfig = await tenantServices.getTenantConfiguration(tenantUid, cfgKey);
    if (!existingProducerConfig) {
        exports.logger.error(`No matching producer exists on tenant ${tenantUid} for ${cfgKey}`);
        throw new Error('No matching producer exists on this tenant');
    }
    const isReduceSchedulingOn = await tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.REDUCE_SCHEDULING);
    if (isReduceSchedulingOn && (0, CommonTypes_1.sourceWithLessSync)(producerType)) {
        if (!(0, Util_1.validateCronIsLessOftenThanExpected)(limitedCronSchedule, DateUtils_1.WEEK_MILLIS)) {
            throw new Error('Cron expression runs more often than expected');
        }
    }
    if (name !== existingProducerConfig.name) {
        await tenantServices.verifyDistinctName(tenantUid, name);
    }
    const value = _.merge(JSON.parse(existingProducerConfig.value || '{}'), { schedule: limitedCronSchedule });
    const cfgVal = JSON.stringify(value);
    exports.logger.info(`updating producer configuration schedule by ${userId} for ${cfgKey} on tenant ${tenantUid} to name: ${name}, description: ${description}, value: ${cfgVal}`);
    try {
        const data = await tenantServices.updateProducerConfiguration(tenantUid, cfgKey, description, name, cfgVal);
        return parseUpdateProducerConfigurationResponse(data);
    }
    catch (error) {
        throw new Error(`updating producer configuration schedule by ${userId} for ${cfgKey} on tenant ${tenantUid} to name: ${name}, description: ${description}, value: ${cfgVal} failed: ${error}`);
    }
};
exports.updateProducerConfiguration = updateProducerConfiguration;
function parseUpdateProducerConfigurationResponse(data) {
    var _a, _b, _c;
    if (data === undefined)
        return data;
    const parsedResponse = JSON.parse((_a = data.Attributes) === null || _a === void 0 ? void 0 : _a.value);
    let responseProperties = { ...parsedResponse };
    delete responseProperties.sourceId;
    delete responseProperties.schedule;
    responseProperties = Object.keys(responseProperties).map(e => ({ key: e, value: responseProperties[e] }));
    return {
        producerType: parsedResponse.source,
        producerId: parsedResponse.sourceId,
        name: (_b = data.Attributes) === null || _b === void 0 ? void 0 : _b.name,
        description: (_c = data.Attributes) === null || _c === void 0 ? void 0 : _c.description,
        cronSchedule: parsedResponse.schedule,
        properties: responseProperties
    };
}
const addFilter = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { filter } = event.args;
    if (!filter) {
        throw new Error('Filter does not exist in event args');
    }
    await new SavedFilterServices_1.SavedFilterServices().add(tenantUid, filter.name, filter.definition);
    return filter;
};
exports.addFilter = addFilter;
const deleteFilter = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { name } = event.args;
    if (!name) {
        throw new Error('Filter name does not exist in event args');
    }
    await new SavedFilterServices_1.SavedFilterServices().deleteByKey(tenantUid, name);
    return true;
};
exports.deleteFilter = deleteFilter;
const isSXOrganizationEnabled = async (event) => {
    const orgExtId = event.args.organizationId;
    const tenantServices = new TenantServices_1.TenantServices();
    const tenant = await tenantServices.getTenantByExtId(orgExtId);
    return !!tenant;
};
exports.isSXOrganizationEnabled = isSXOrganizationEnabled;
const getTenantSetupStatus = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    if (!tenantUid) {
        return TenantServices_1.TenantSetupStatus.NOT_SETUP;
    }
    exports.logger.debug(`Getting the tenant setup status for tenant ${tenantUid}`);
    const tenantServices = new TenantServices_1.TenantServices();
    const { setupStatus } = await tenantServices.getTenantSetupStatus(tenantUid);
    let returnedSetupStatus = setupStatus !== null && setupStatus !== void 0 ? setupStatus : TenantServices_1.TenantSetupStatus.NOT_SETUP;
    exports.logger.debug(`Got the tenant setup status ${setupStatus} for tenant ${tenantUid}. Returned status will be ${returnedSetupStatus}`);
    const autoRefreshingToken = new AutoRefreshingBEIrohToken_1.AutoRefreshingBEIrohToken(tenantUid);
    try {
        await autoRefreshingToken.getFunctioningToken();
        exports.logger.debug(`Was able to fetch BE access token for the tenant. Returned status will be ${returnedSetupStatus}`);
    }
    catch (e) {
        if (e.isAxiosError && e.response) {
            const errorData = e.response.data;
            const userTokenNoLongerValid = (errorData === null || errorData === void 0 ? void 0 : errorData.error) === 'oauth2_validation_exception';
            if (userTokenNoLongerValid) {
                returnedSetupStatus = TenantServices_1.TenantSetupStatus.NOT_SETUP;
                await tenantServices.setTenantSetupStatus(tenantUid, returnedSetupStatus);
                exports.logger.debug(`The BE token for the user is no longer valid since user no longer part of the org. Returned status will be ${returnedSetupStatus}`);
            }
        }
        else {
            exports.logger.error(`Failed to fetch the status of the tenant ${tenantUid} BE token. Unknown error so will not be referring to it: ${JSON.stringify(e.message)}. Returned status will be ${returnedSetupStatus}`);
        }
    }
    return returnedSetupStatus;
};
exports.getTenantSetupStatus = getTenantSetupStatus;
const enableSXOrganization = async (event) => {
    const { role, userId, token, tenantExtId } = (0, Util_1.getFromHeaders)(event);
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can enable tenant');
    }
    const tenantServices = new TenantServices_1.TenantServices();
    if (token) {
        exports.logger.debug(`Enabling tenant for organization ${tenantExtId} by userId ${userId}`);
        const globalSecretsService = new AwsSecretsService_1.GlobalAwsSecretsService();
        await globalSecretsService.init();
        const irohClient = new IrohClient_1.IrohExternalClient(globalSecretsService);
        await irohClient.setupTenant(token, true);
    }
    const tenant = await tenantServices.getTenantByExtId(tenantExtId);
    if (!tenant) {
        throw new Error(`Failed to enable tenant organization ${tenantExtId}`);
    }
    try {
        await (0, index_1.syncIrohModuleInstances)({ tenant: { tenantUid: tenant.id } }, { functionName: exports.enableSXOrganization.name });
    }
    catch (e) {
        exports.logger.error(`failed to perform a sync of IROH module instances. not failing the activation flow on that. Error: ${JSON.stringify(e.message)}`);
    }
    return tenant.id;
};
exports.enableSXOrganization = enableSXOrganization;
const getTenantMetadata = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    if (!tenantUid) {
        throw new Error('Tenant uid does not exist in request headers');
    }
    const tenantServices = new TenantServices_1.TenantServices();
    const tenant = await tenantServices.getTenantById(tenantUid);
    if (!tenant) {
        throw new Error(`Tenant with [${tenantUid}] does not exist`);
    }
    const featureFlags = await tenantServices.getFeatureFlags(tenantUid);
    const savedFilters = await new SavedFilterServices_1.SavedFilterServices().getSavedFilters(tenantUid);
    return {
        id: tenantUid,
        featureFlags,
        filters: _.map(savedFilters, filter => ({ name: filter.name, definition: filter.definition }))
    };
};
exports.getTenantMetadata = getTenantMetadata;
const dashboardCounts = async (event) => {
    try {
        const { tenantUid } = (0, Util_1.getFromHeaders)(event);
        exports.logger.info(`dashboardCounts for tenant ${tenantUid}`);
        const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
        const dashboardCountsResult = await service.dashboardCounts();
        if (await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.IPADOS_ENABLED)) {
            return dashboardCountsResult;
        }
        dashboardCountsResult.osTypes = aggregateIpadosToIosCount(dashboardCountsResult.osTypes);
        return dashboardCountsResult;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.dashboardCounts = dashboardCounts;
const dashboardPersonCounts = async (event) => {
    try {
        const { tenantUid } = (0, Util_1.getFromHeaders)(event);
        exports.logger.info(`dashboardPersonCounts for tenant ${tenantUid}`);
        const service = new PosturePersonService_1.PosturePersonService(tenantUid);
        const dashboardPersonCountsResult = await service.dashboardCounts();
        return dashboardPersonCountsResult;
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.dashboardPersonCounts = dashboardPersonCounts;
const collectionMetrics = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const daysAgo = _.get(event, 'args.daysAgo', DEFAULT_METRICS_DAYS);
    if (daysAgo <= 0) {
        throw new Error(`Number of days must be positive: ${daysAgo}`);
    }
    const tenantServices = new TenantServices_1.TenantServices();
    const producerInputs = _.map(_.get(event, 'args.producers'), (producer) => (0, Util_1.toSourceString)(producer.producerType, producer.producerId));
    const producers = _.filter(await Promise.all(producerInputs.map(async (producer) => ((await tenantServices.getTenantConfiguration(tenantUid, producer)) ? producer : undefined))), (producer) => producer);
    if (producers.length === 0 && producerInputs.length > 0) {
        return [];
    }
    const workflows = _.get(event, 'args.workflows', [CommonTypes_1.WorkFlow.COLLECTION, CommonTypes_1.WorkFlow.NOTIFICATION_PROCESSING]);
    exports.logger.info(`get ${workflows} metrics for ${daysAgo} days for tenant ${tenantUid} and producers: ${producers}`);
    const service = new TimestreamQueryServices_1.TimestreamReportServices(tenantUid);
    return service.getCollectionMetricsHistory(daysAgo, producers, workflows);
};
exports.collectionMetrics = collectionMetrics;
const getCollectionErrors = (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    return new ProcessingUtil_1.ProcessingUtil().getCollectionErrors(tenantUid);
};
exports.getCollectionErrors = getCollectionErrors;
const getTenantPolicies = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { filter } = event.args;
    exports.logger.info(`getTenantPolicies for tenant ${tenantUid} and filter ${filter}`);
    const service = new PolicyServices_1.PolicyServices(tenantUid);
    return service.getPolicies(filter);
};
exports.getTenantPolicies = getTenantPolicies;
const getTenantUCDeployments = async (event) => {
    var _a, _b;
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const producerIds = ((_a = event.args) === null || _a === void 0 ? void 0 : _a.producerIds) || [];
    const bulk = (_b = event.args) === null || _b === void 0 ? void 0 : _b.bulk;
    const results = [];
    const deploymentServices = new UnifiedConnectorDeploymentServices_1.UnifiedConnectorDeploymentServices(tenantUid);
    const sourceDetails = await deploymentServices.getSourceDetails(producerIds);
    while (producerIds.length > 0 || sourceDetails.length > 0) {
        const producerId = (producerIds.length > 0) ? producerIds.shift() : undefined;
        if (sourceDetails.length > 0 && (producerId === undefined || sourceDetails[0].producerId === producerId)) {
            const detail = sourceDetails.shift();
            const service = new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(detail.secrets, detail.baseURL, detail.adminBaseUrl, tenantUid, detail.producerId);
            let deployments;
            try {
                if (!bulk) {
                    deployments = await service.getDeploymentsSummary();
                }
                else {
                    deployments = await service.getDeploymentsBulk();
                }
            }
            catch (ex) {
                results.push({ producerId: detail.producerId, deployments: undefined });
                continue;
            }
            results.push({ producerId: detail.producerId, deployments });
        }
        else if (producerId) {
            results.push({ producerId, deployments: undefined });
        }
    }
    return results;
};
exports.getTenantUCDeployments = getTenantUCDeployments;
const getTenantGroups = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { filter } = event.args;
    exports.logger.info(`getTenantGroups for tenant ${tenantUid} and filter ${filter}`);
    const service = new GroupServices_1.GroupServices(tenantUid);
    return service.getGroups(filter);
};
exports.getTenantGroups = getTenantGroups;
const getTenantTags = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    exports.logger.info(`getTenantTags for tenant ${tenantUid}`);
    const postureEndpointService = new PostureEndpointService_1.PostureEndpointService(tenantUid);
    const tags = await postureEndpointService.getTenantTags();
    exports.logger.info(`getTenantTags results count = ${tags.length}`);
    return _.map(tags, (tag) => ({ name: tag.value, sources: [] }));
};
exports.getTenantTags = getTenantTags;
const getModuleTypeId = async (event) => {
    const { source } = event.args;
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const result = await SourceUtils_1.SourceUtils.getModuleTypeIdBySource(tenantUid, source);
    return result;
};
exports.getModuleTypeId = getModuleTypeId;
const moveDevicesToDeployment = async (event) => {
    const { role, tenantUid } = (0, Util_1.getFromHeaders)(event);
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can move device between CSC deployments');
    }
    const { devices, deploymentId } = event.args;
    exports.logger.info(`move devices to deployment for tenant ${tenantUid} with devices=${JSON.stringify(devices)}, deploymentId${deploymentId}`);
    if (!Array.isArray(devices) || devices.length === 0) {
        throw new Error('devices must be an array and is a required parameter to move devices to deployment');
    }
    const maxDevices = +(process.env.MAX_DEVICE_DEPLOYMENT_MOVEMENT || 15);
    if (devices.length > maxDevices) {
        throw new Error(`Can only move up to ${maxDevices} devices at a time`);
    }
    if (!devices[0].uid || !devices[0].ucId || !devices[0].producerId) {
        throw new Error('devices must be an array of objects containing an uid, an ucId, and a producerId to move devices to deployment');
    }
    if (!deploymentId) {
        throw new Error('deploymentId is a required parameter to move devices to deployment');
    }
    const map = new Map();
    for (const device of devices) {
        let array = map.get(device.producerId);
        if (!array) {
            array = [];
            map.set(device.producerId, array);
        }
        array.push(device);
    }
    const successArray = [];
    const failureArray = [];
    for (const producers of map) {
        const producerId = producers[0];
        const producerDevices = producers[1];
        try {
            const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
            await awsSecretsService.init();
            const tenantServices = new TenantServices_1.TenantServices();
            const source = (0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, producerId);
            const tenantConfiguration = await tenantServices.getTenantConfiguration(tenantUid, source);
            const tenantConfigurationValue = JSON.parse((tenantConfiguration === null || tenantConfiguration === void 0 ? void 0 : tenantConfiguration.value) || '{}');
            const ucCollector = new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, producerId)), tenantConfigurationValue.baseURL, tenantConfigurationValue.adminBaseUrl, tenantUid, producerId);
            const ucUtility = new UnifiedConnectorCollectorServicesUtility_1.UnifiedConnectorCollectorServicesUtility(ucCollector);
            await ucUtility.moveDevicesToDeployment(producerDevices, deploymentId);
            successArray.push(..._.map(producerDevices, (device) => ({ device })));
        }
        catch (error) {
            exports.logger.error(`Error occurred in Unified Connector while moving device deployment where error=${JSON.stringify(error)}`);
            if (Array.isArray(error)) {
                const errorsArray = error;
                failureArray.push(...errorsArray);
                const successfulDevices = _.differenceWith(producerDevices, errorsArray, (left, right) => left.ucId === right.device.ucId);
                successArray.push(..._.map(successfulDevices, (device) => ({ device })));
            }
            else {
                for (const device of producerDevices) {
                    failureArray.push({ device, error: error.message });
                }
            }
        }
    }
    await (0, ResourcesManager_1.closeConnections)();
    return Promise.resolve({
        success: successArray,
        failure: failureArray
    });
};
exports.moveDevicesToDeployment = moveDevicesToDeployment;
const getLabels = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Labels and financialRiskFactor attributes not supported');
        throw new Error('Labels not supported');
    }
    exports.logger.debug(`Get all labels for tenant ${tenantUid}`);
    const labelService = new LabelService_1.LabelService(tenantUid);
    const rulesService = new RuleService_1.RuleService(tenantUid);
    const [labelsMeta, labelsLinkedToRules] = await Promise.all([labelService.getLabelsMetadata(), rulesService.getLabelsLinkedToRules()]);
    return labelsMeta.map(labelMeta => {
        const linkedRules = labelsLinkedToRules.has(labelMeta.labelId) ? labelsLinkedToRules.get(labelMeta.labelId) : [];
        return _.merge(labelMeta, { linkedRules });
    });
};
exports.getLabels = getLabels;
const createLabel = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Labels and financialRiskFactor attributes not supported');
        throw new Error('Labels not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can create labels');
    }
    const { label } = event.args;
    exports.logger.debug(`Create label ${JSON.stringify(label)} for tenant ${tenantUid}`);
    const labelService = new LabelService_1.LabelService(tenantUid);
    return labelService.createLabel(label);
};
exports.createLabel = createLabel;
const updateLabels = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Labels and financialRiskFactor attributes not supported');
        throw new Error('Labels not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can update labels');
    }
    const { labels } = event.args;
    exports.logger.debug(`Update for tenant ${tenantUid} labels ${JSON.stringify(labels)}`);
    const labelService = new LabelService_1.LabelService(tenantUid);
    return labelService.updateLabels(labels);
};
exports.updateLabels = updateLabels;
const deleteLabels = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Labels and financialRiskFactor attributes not supported');
        throw new Error('Labels not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can delete labels');
    }
    const { labelIds } = event.args;
    exports.logger.debug(`Delete for tenant ${tenantUid} labels ${JSON.stringify(labelIds)}`);
    const labelService = new LabelService_1.LabelService(tenantUid);
    const deleteLabelsResponse = await labelService.deleteLabels(labelIds);
    const lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
    const functionName = `${process.env.ENV_PREFIX}-processing-for-labels-deletion`;
    await lambdaServices.asyncInvoke(functionName, JSON.stringify({ tenantUid, labelIds }));
    return deleteLabelsResponse;
};
exports.deleteLabels = deleteLabels;
const addLabelsForDevices = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Labels and financialRiskFactor attributes not supported');
        throw new Error('Labels not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can add labels for devices');
    }
    const { labelIds, deviceIds } = event.args;
    const labelDeviceService = new LabelDeviceService_1.LabelDeviceService(tenantUid);
    exports.logger.debug(`For tenant ${tenantUid} to devices ${JSON.stringify(deviceIds)} assign labels ${labelIds}`);
    const result = await labelDeviceService.addLabelsForDevices(labelIds, deviceIds);
    await sendNotificationForUpdatedDeviceIds(tenantUid, deviceIds, result, labelIds);
    return result;
};
exports.addLabelsForDevices = addLabelsForDevices;
const removeLabelsForDevices = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Labels and financialRiskFactor attributes not supported');
        throw new Error('Labels not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can remove labels from devices');
    }
    const { labelIds, deviceIds } = event.args;
    const labelDeviceService = new LabelDeviceService_1.LabelDeviceService(tenantUid);
    exports.logger.debug(`For tenant ${tenantUid} from devices ${JSON.stringify(deviceIds)} remove labels ${labelIds}`);
    const result = await labelDeviceService.removeLabelsFromDevices(labelIds, deviceIds);
    await sendNotificationForUpdatedDeviceIds(tenantUid, deviceIds, result, labelIds);
    return _.merge({ failure: [] }, result);
};
exports.removeLabelsForDevices = removeLabelsForDevices;
const addLabelsForAFilter = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Labels and financialRiskFactor attributes not supported');
        throw new Error('Labels not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can add labels for devices');
    }
    const { labelIds, filter, exclusionList } = event.args;
    exports.logger.debug(`For tenant ${tenantUid} for devices that matches ${JSON.stringify(filter)} and excludes
  ${JSON.stringify(exclusionList)} add labels ${JSON.stringify(labelIds)}`);
    const labelDeviceService = new LabelDeviceService_1.LabelDeviceService(tenantUid);
    await fetchAndNotifyDeviceChange(tenantUid, filter, exclusionList);
    return labelDeviceService.addLabelsForDevicesMatchingFilter(labelIds, filter, exclusionList);
};
exports.addLabelsForAFilter = addLabelsForAFilter;
const removeLabelsForAFilter = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Labels and financialRiskFactor attributes not supported');
        throw new Error('Labels not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can remove labels from devices');
    }
    const { labelIds, filter, exclusionList } = event.args;
    exports.logger.debug(`For tenant ${tenantUid} from devices that matches ${JSON.stringify(filter)} and excludes
  ${JSON.stringify(exclusionList)} remove labels ${JSON.stringify(labelIds)}`);
    const labelDeviceService = new LabelDeviceService_1.LabelDeviceService(tenantUid);
    await fetchAndNotifyDeviceChange(tenantUid, filter, exclusionList);
    return labelDeviceService.removeLabelsFromDevicesMatchingFilter(labelIds, filter, exclusionList);
};
exports.removeLabelsForAFilter = removeLabelsForAFilter;
const setDevicesFinancialRiskFactor = async (event) => {
    event.args.assetValue = event.args.financialRiskFactor;
    return (0, exports.setDevicesAssetValue)(event);
};
exports.setDevicesFinancialRiskFactor = setDevicesFinancialRiskFactor;
const setDevicesAssetValue = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Asset values attributes not supported');
        throw new Error('Asset Value not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can set asset value to devices');
    }
    const { assetValue, deviceIds } = event.args;
    const postureEndpointService = new PostureEndpointService_1.PostureEndpointService(tenantUid);
    const result = await postureEndpointService.setDevicesAssetValue(assetValue, deviceIds);
    await sendNotificationForUpdatedDeviceIds(tenantUid, deviceIds, result);
    return result;
};
exports.setDevicesAssetValue = setDevicesAssetValue;
const deleteDevicesFinancialRiskFactor = async (event) => (0, exports.deleteDevicesAssetValue)(event);
exports.deleteDevicesFinancialRiskFactor = deleteDevicesFinancialRiskFactor;
const deleteDevicesAssetValue = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Asset values attributes not supported');
        throw new Error('Asset Value not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can delete asset value from devices');
    }
    const { deviceIds } = event.args;
    const postureEndpointService = new PostureEndpointService_1.PostureEndpointService(tenantUid);
    const result = await postureEndpointService.deleteDevicesAssetValue(deviceIds);
    await sendNotificationForUpdatedDeviceIds(tenantUid, deviceIds, result);
    return result;
};
exports.deleteDevicesAssetValue = deleteDevicesAssetValue;
const setDevicesFinancialRiskFactorWithFilter = async (event) => {
    event.args.assetValue = event.args.financialRiskFactor;
    return (0, exports.setDevicesAssetValueWithFilter)(event);
};
exports.setDevicesFinancialRiskFactorWithFilter = setDevicesFinancialRiskFactorWithFilter;
const setDevicesAssetValueWithFilter = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Asset values attributes not supported');
        throw new Error('Asset Value not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can set asset value to devices');
    }
    const { assetValue, filter, exclusionList } = event.args;
    exports.logger.debug(`For tenant ${tenantUid} for devices that match ${JSON.stringify(filter)} and excludes
  ${JSON.stringify(exclusionList)} set asset value ${JSON.stringify(assetValue)}`);
    const postureEndpointService = new PostureEndpointService_1.PostureEndpointService(tenantUid);
    const result = await postureEndpointService.updateDevicesAssetValueMatchingFilter(assetValue, filter, exclusionList);
    await fetchAndNotifyDeviceChange(tenantUid, filter, exclusionList);
    return result;
};
exports.setDevicesAssetValueWithFilter = setDevicesAssetValueWithFilter;
const removeDevicesFinancialRiskFactorWithFilter = async (event) => (0, exports.removeDevicesAssetValueWithFilter)(event);
exports.removeDevicesFinancialRiskFactorWithFilter = removeDevicesFinancialRiskFactorWithFilter;
const removeDevicesAssetValueWithFilter = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    if (!await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE)) {
        exports.logger.error('Asset values attributes not supported');
        throw new Error('Asset Value not supported');
    }
    if (role !== Util_1.ROLE_ADMIN) {
        throw new Error('Only user with admin permissions can delete asset value from devices');
    }
    const { filter, exclusionList } = event.args;
    exports.logger.debug(`For tenant ${tenantUid} for devices that match ${JSON.stringify(filter)} and excludes
  ${JSON.stringify(exclusionList)} delete asset value`);
    const postureEndpointService = new PostureEndpointService_1.PostureEndpointService(tenantUid);
    const result = await postureEndpointService.updateDevicesAssetValueMatchingFilter(undefined, filter, exclusionList);
    await fetchAndNotifyDeviceChange(tenantUid, filter, exclusionList);
    return result;
};
exports.removeDevicesAssetValueWithFilter = removeDevicesAssetValueWithFilter;
const getRules = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    exports.logger.debug(`Get all rules for tenant ${tenantUid}, user role: ${role}`);
    const ruleService = new RuleService_1.RuleService(tenantUid);
    let rules = await ruleService.getAllRulesWithCount();
    rules = _.filter(rules, (ruleAndCount) => (!ruleAndCount.rule.hidden));
    return rules;
};
exports.getRules = getRules;
const createRule = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    const { rule } = event.args;
    exports.logger.debug(`Create rule ${JSON.stringify(rule)} for tenant ${tenantUid}, user role: ${role}`);
    if (role !== Util_1.ROLE_ADMIN) {
        exports.logger.error('Only user with admin permissions can use rules');
        throw new Error('Rules not supported');
    }
    try {
        const ruleService = new RuleService_1.RuleService(tenantUid);
        const ruleResponse = await ruleService.createRule(rule);
        return { rule: ruleResponse };
    }
    catch (e) {
        return { error: e.message };
    }
};
exports.createRule = createRule;
const updateRule = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    const { rule } = event.args;
    exports.logger.debug(`Update for tenant ${tenantUid} rule: ${JSON.stringify(rule)}, user role: ${role}`);
    if (role !== Util_1.ROLE_ADMIN) {
        exports.logger.error('Only user with admin permissions can use rules');
        throw new Error('Rules not supported');
    }
    try {
        const ruleService = new RuleService_1.RuleService(tenantUid);
        const result = await ruleService.updateRule(rule);
        return { rule: result };
    }
    catch (e) {
        return { error: e.message };
    }
};
exports.updateRule = updateRule;
const deleteRule = async (event) => {
    const { tenantUid, role } = (0, Util_1.getFromHeaders)(event);
    const { ruleId } = event.args;
    exports.logger.debug(`Delete for tenant ${tenantUid} rule: ${JSON.stringify(ruleId)}, user role: ${role}`);
    if (role !== Util_1.ROLE_ADMIN) {
        exports.logger.error('Only user with admin permissions can use rules');
        throw new Error('Rules not supported');
    }
    const ruleService = new RuleService_1.RuleService(tenantUid);
    const rule = await ruleService.getRule(ruleId);
    if (rule.origin === RuleService_1.RuleOrigin.SYSTEM) {
        exports.logger.error('Cannot delete a system rule');
        throw new Error('Cannot delete a system rule');
    }
    await ruleService.softDeleteRule(ruleId);
    return true;
};
exports.deleteRule = deleteRule;
const sendNotificationForUpdatedDeviceIds = async (tenantUid, deviceIds, result, labelIds) => {
    const updated = [];
    if (_.isEmpty(result.failure) && _.isEmpty(result.failuresWithDetails)) {
        deviceIds.forEach(id => updated.push(id));
    }
    else if (!_.isEmpty(result.failure)) {
    }
    else if (_.isUndefined(labelIds) && !_.isEmpty(result.failuresWithDetails)) {
        deviceIds
            .filter(deviceId => { var _a; return !((_a = result.failuresWithDetails) === null || _a === void 0 ? void 0 : _a.some(detail => detail.deviceId === deviceId)); })
            .forEach(deviceId => updated.push(deviceId));
    }
    else if (!_.isUndefined(labelIds) && !_.isEmpty(result.failuresWithDetails)) {
        labelIds.sort();
        deviceIds.forEach(id => {
            var _a;
            if (!((_a = result.failuresWithDetails) === null || _a === void 0 ? void 0 : _a.some(error => { var _a; return error.deviceId === id && _.isEqual((_a = error.labelIds) === null || _a === void 0 ? void 0 : _a.sort(), labelIds); }))) {
                updated.push(id);
            }
        });
    }
    if (updated.length > 0) {
        const incidentService = new IncidentService_1.IncidentService(tenantUid);
        const incidentsEvtBusArn = await incidentService.getBusArnIfTenantIsSupportedIncidents();
        if (incidentsEvtBusArn) {
            await incidentService.publishEvents({ deviceIds: updated, tenantId: tenantUid }, incidentsEvtBusArn);
        }
        const webhookNotificationService = new WebhookNotificationService_1.WebhookNotificationService();
        const shouldSendDsWebhookNotification = (await webhookNotificationService.getWebhooks(tenantUid)).length > 0;
        if (shouldSendDsWebhookNotification) {
            await webhookNotificationService.sendDeviceEvent(tenantUid, WebhookHelper_1.WebhookEventType.DEVICE_UPDATE, updated);
        }
    }
};
const fetchAndNotifyDeviceChange = async (tenantUid, filter, exclusionList) => {
    const lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
    await lambdaServices.asyncInvoke(`${process.env.ENV_PREFIX}-fetch-and-notify-devices`, JSON.stringify({ tenantUid, filter, exclusionList }));
};
