"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomProcessorServices = void 0;
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const CustomEndpointService_1 = require("../../collectors/services/CustomEndpointService");
class CustomProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(endpoint, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, vertexState.getPropertyValue(CommonTypes_1.VertexBasicProperty.NAME), CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        await this.verifyChange(currentTopology, endpoint.hardwareId, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        await this.verifyChange(currentTopology, endpoint.serialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, endpoint.imei, CommonTypes_1.VertexType.IMEI, changes, unchanged);
        await this.verifyMultipleChanges(endpoint, 'externalIps', CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, currentTopology, changes, unchanged);
        await this.verifyMultipleChanges(endpoint, 'macAddresses', CommonTypes_1.VertexType.MAC_ADDRESS, currentTopology, changes, unchanged);
        await this.verifyMultipleChanges(endpoint, 'users', CommonTypes_1.VertexType.USER, currentTopology, changes, unchanged);
        await this.verifyMultipleChanges(endpoint, 'appUsers', CommonTypes_1.VertexType.APP_USER, currentTopology, changes, unchanged);
        await this.verifyMultipleChanges(endpoint, 'emails', CommonTypes_1.VertexType.EMAIL, currentTopology, changes, unchanged);
        await this.verifyMultipleChanges(endpoint, 'phones', CommonTypes_1.VertexType.PHONE_NUMBER, currentTopology, changes, unchanged);
    }
    async verifyMultipleChanges(endpoint, propertyName, vertexType, currentTopology, changes, unchanged) {
        for (const identifier of _.get(endpoint, propertyName, [])) {
            await this.verifyChange(currentTopology, identifier, vertexType, changes, unchanged);
        }
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new CustomEndpointService_1.CustomEndpointService(tenantUid, sourceId);
    }
}
exports.CustomProcessorServices = CustomProcessorServices;
