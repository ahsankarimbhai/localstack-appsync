"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AirWatchDeviceCollection = void 0;
const lodash_1 = __importDefault(require("lodash"));
const Collection_1 = require("../../common/Collection");
const url_1 = require("url");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const query_string_1 = __importDefault(require("query-string"));
function extractNextLink(res) {
    var _a;
    if (!((_a = res.config) === null || _a === void 0 ? void 0 : _a.baseURL)) {
        return undefined;
    }
    let requestUrl = new url_1.URL(lodash_1.default.get(res, 'config.url', ''), res.config.baseURL);
    if (res.config.baseURL.indexOf(ProxyClientFactory_1.ProxyClientFactory.IROH_PREF) > 0) {
        const apiAddressIndex = res.config.baseURL.indexOf('/mdm/devices/search');
        const baseUrl = res.config.baseURL.substring(0, apiAddressIndex);
        const apiUrl = res.config.baseURL.substring(apiAddressIndex);
        requestUrl = new url_1.URL(apiUrl, baseUrl);
    }
    if (!requestUrl) {
        return undefined;
    }
    const searchParams = requestUrl.searchParams;
    const pageSize = lodash_1.default.toNumber(searchParams.get('pagesize'));
    const page = lodash_1.default.toNumber(searchParams.get('page'));
    const totalCount = lodash_1.default.get(res, 'data.Total', 0);
    if (totalCount <= ((page + 1) * pageSize)) {
        return undefined;
    }
    const params = query_string_1.default.parse(requestUrl.search);
    params.page = page + 1;
    return `${requestUrl.pathname}?${query_string_1.default.stringify(params)}`;
}
function extractData(res) {
    if (lodash_1.default.isArray(res.data.Devices)) {
        return res.data.Devices;
    }
    throw new Error('No devices found. Please verify the Airwatch module configuration');
}
class AirWatchDeviceCollection extends Collection_1.Collection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, nextLinkFn) {
        super(client, uri, nextLinkFn || extractNextLink, extractData, timeBasedAsyncLambdaInvoker);
    }
}
exports.AirWatchDeviceCollection = AirWatchDeviceCollection;
