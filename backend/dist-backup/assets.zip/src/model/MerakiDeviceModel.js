"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MerakiDeviceStateModelService = exports.MerakiDeviceStateModel = exports.MerakiDeviceModelService = exports.MerakiDeviceModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const _ = __importStar(require("lodash"));
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class MerakiDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.MERAKI_SM_DEVICE;
    }
    async initProperties(merakiDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, merakiDevice.id);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.MerakiDeviceModel = MerakiDeviceModel;
class MerakiDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new MerakiDeviceModel(this.partitionKey);
    }
}
exports.MerakiDeviceModelService = MerakiDeviceModelService;
class MerakiDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.MERAKI_SM_DEVICE_STATE;
    }
    async initProperties(merakiDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(merakiDevice, ['lastConnected'])));
        _.forEach(_.toPairs(merakiDevice), (pair) => {
            if (!MerakiDeviceStateModel.EXTERNAL_PROPERTIES.includes(pair[0])) {
                if (pair[0] === 'id') {
                    return;
                }
                switch (pair[0]) {
                    case 'name':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, pair[1]);
                        break;
                    case 'osName':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(pair[1]));
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, (0, CommonTypes_1.getOsVersion)(pair[1]));
                        break;
                    case 'osBuild':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, pair[1]);
                        break;
                    case 'isManaged':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.IS_MANAGED, pair[1]);
                        break;
                    case 'lastConnected':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, pair[1] * 1000);
                        break;
                    case 'ip':
                        this.setInternalIpAddresses(pair[1]);
                        break;
                    default:
                        this.setProperty(_.camelCase(pair[0]), pair[1]);
                }
            }
        });
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(merakiDevice.osName, '', merakiDevice.osBuild));
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, [merakiDevice.osName, merakiDevice.systemModel].filter(item => item).join(' '));
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.MerakiDeviceStateModel = MerakiDeviceStateModel;
MerakiDeviceStateModel.EXTERNAL_PROPERTIES = [
    'uuid',
    'serialNumber',
    'wifiMac',
    'publicIp',
    'lastUser'
];
MerakiDeviceStateModel.TAGS_KEY = 'tags';
MerakiDeviceStateModel.AUTO_TAGS_KEY = 'autoTags';
MerakiDeviceStateModel.SYSTEM_MODEL_KEY = 'systemModel';
MerakiDeviceStateModel.HAS_CHROME_MDM_KEY = 'hasChromeMdm';
MerakiDeviceStateModel.IS_SUPERVISED_KEY = 'isSupervised';
MerakiDeviceStateModel.ANDROID_SECURITY_PATCH_LEVEL_KEY = 'androidSecurityPatchVersion';
class MerakiDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new MerakiDeviceStateModel(this.partitionKey);
    }
}
exports.MerakiDeviceStateModelService = MerakiDeviceStateModelService;
