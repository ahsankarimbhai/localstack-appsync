"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ThrottleTenantForMigrationRunner = void 0;
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const RebalanceNeptuneClustersBase_1 = require("./RebalanceNeptuneClustersBase");
const bluebird_1 = require("bluebird");
class ThrottleTenantForMigrationRunner extends RebalanceNeptuneClustersBase_1.RebalanceNeptuneClustersBase {
    constructor() {
        super();
        this.maxTenantsInMigration = +(process.env.MAX_TENANTS_IN_MIGRATION || 30);
        this.maxExportVerticesInMigration = +(process.env.MAX_EXPORT_VERTICES_IN_MIGRATION || 1000000);
    }
    async run() {
        this.logger.info('Start ThrottleTenantForMigrationRunner');
        let logsNotStarted = await this.neptuneShardMigrationLogRepo.getLogsByStatus([NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.CREATE]);
        if (process.env.ENABLE_AUTO_THROTTLER !== 'true') {
            logsNotStarted = logsNotStarted.filter(l => l.manualKickOff === true);
        }
        if (logsNotStarted.length === 0) {
            this.logger.info('End ThrottleTenantForMigrationRunner, no tenant needs migration');
            return;
        }
        const tenantsToMigrate = [];
        let exportedVertices = 0;
        while (logsNotStarted.length > 0) {
            const migrationLog = logsNotStarted.pop();
            if (!migrationLog) {
                continue;
            }
            const { verticesCount } = await this.countNeptuneEntries(migrationLog.tenantUid, migrationLog.migrateFromShardId);
            exportedVertices += verticesCount;
            tenantsToMigrate.push(migrationLog.tenantUid);
            if (exportedVertices >= this.maxExportVerticesInMigration || tenantsToMigrate.length >= this.maxTenantsInMigration) {
                break;
            }
        }
        await bluebird_1.Promise.map(tenantsToMigrate, async (tenantUid) => {
            try {
                this.logger.info(`throttle and start migration for tenant ${tenantUid}`);
                await this.neptuneShardRepo.updateNeptuneShard(tenantUid, undefined, true);
                await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.START, Date.now());
            }
            catch (err) {
                this.logger.error(`failed to throttle and start migration for tenant ${tenantUid}, error: ${err.message}`);
                await this.neptuneShardRepo.updateNeptuneShard(tenantUid, undefined, false);
            }
        });
        this.logger.info('End ThrottleTenantForMigrationRunner');
    }
}
exports.ThrottleTenantForMigrationRunner = ThrottleTenantForMigrationRunner;
