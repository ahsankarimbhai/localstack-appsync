"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SentinelOneCollectorServices = void 0;
const SentinelOneDevicesCollection_1 = require("./SentinelOneDevicesCollection");
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
class SentinelOneCollectorServices extends Services_1.BaseCollectorService {
    constructor(tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.functionName = functionName;
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.SENTINEL_ONE, this.sourceId);
        }
    }
    async getDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.SENTINEL_ONE));
        const bulkLength = limit || SentinelOneCollectorServices.LIMIT;
        return new SentinelOneDevicesCollection_1.SentinelOneDevicesCollection(this.client, nextUri || `/web/api/v2.1/agents?limit=${bulkLength}`, timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.SentinelOneCollectorServices = SentinelOneCollectorServices;
SentinelOneCollectorServices.LIMIT = 100;
