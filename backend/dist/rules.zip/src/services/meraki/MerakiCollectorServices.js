"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MerakiCollectorServices = void 0;
const DevicesCollection_1 = require("./DevicesCollection");
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
class MerakiCollectorServices extends Services_1.BaseCollectorService {
    constructor(networkId, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.networkId = networkId;
        this.functionName = functionName;
    }
    async getSmDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.MERAKI, this.sourceId);
        }
        const bulkLength = limit || MerakiCollectorServices.LIMIT;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.MERAKI));
        return new DevicesCollection_1.DevicesCollection(this.client, nextUri || `/api/v1/networks/${this.networkId}/sm/devices?perPage=${bulkLength}&fields[]=${MerakiCollectorServices.FIELDS}`, timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.MerakiCollectorServices = MerakiCollectorServices;
MerakiCollectorServices.LIMIT = 500;
MerakiCollectorServices.FIELDS = 'tags,autoTags,ip,systemType,lastConnected,userSuppliedAddress,location,lastUser,ownerEmail,ownerUsername,osBuild,publicIp,phoneNumber,isManaged,hadMdm,isSupervised,meid,imei,iccid,simCarrierNetwork,createdAt,quarantined,avName,avRunning,asName,fwName,isRooted,loginRequired,screenLockEnabled,screenLockDelay,autoLoginDisabled,hasMdm,hasDesktopAgent,diskEncryptionEnabled,hardwareEncryptionCaps,passCodeLock,usesHardwareKeystore,androidSecurityPatchVersion';
