"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrowdStrikeEndpointService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
class CrowdStrikeEndpointService extends Services_1.BaseEndpointService {
    getPvType() {
        return CommonTypes_1.VertexType.CROWD_STRIKE_DEVICE;
    }
    getPsType() {
        return CommonTypes_1.VertexType.CROWD_STRIKE_DEVICE_STATE;
    }
}
exports.CrowdStrikeEndpointService = CrowdStrikeEndpointService;
