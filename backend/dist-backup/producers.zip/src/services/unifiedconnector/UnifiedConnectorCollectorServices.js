"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedConnectorAxiosWrapper = exports.UnifiedConnectorCollectorServices = void 0;
const _ = __importStar(require("lodash"));
const axios_1 = __importDefault(require("axios"));
const Util_1 = require("../../common/Util");
const CommonTypes_1 = require("../../common/CommonTypes");
const Services_1 = require("../../common/Services");
const TenantServices_1 = require("../../common/TenantServices");
const UnifiedConnectorComputerCollection_1 = require("./UnifiedConnectorComputerCollection");
const query_string_1 = __importDefault(require("query-string"));
const AutoRefreshingBEIrohToken_1 = require("../../common/AutoRefreshingBEIrohToken");
const AwsSecretsService_1 = require("../../common/AwsSecretsService");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const UnifiedConnectorDeviceModel_1 = require("../../model/UnifiedConnectorDeviceModel");
const RetryUtil_1 = require("../../common/RetryUtil");
class UnifiedConnectorCollectorServices extends Services_1.BasePushCollectorService {
    constructor(secrets, baseUrl, adminBaseUrl, tenantUid, sourceId) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.autorefreshingBEIrohToken = undefined;
        this.initialized = false;
        this.cfgKey = `unifiedConnector_webhook_id__${this.sourceId}`;
        this.webhookSource = (0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, this.sourceId);
        this.subscriptionAxios = new UnifiedConnectorAxiosWrapper(baseUrl, this);
        this.adminAxios = new UnifiedConnectorAxiosWrapper(adminBaseUrl, this);
    }
    async init() {
        if (!this.businessGuid) {
            const tenantService = new TenantServices_1.TenantServices();
            const tenant = await tenantService.getTenantById(this.tenantUid);
            if (!(tenant === null || tenant === void 0 ? void 0 : tenant.extId)) {
                throw new Error(`Unable to get the business guid needed for the fetching of information (extId) for tenant ${this.tenantUid}`);
            }
            this.businessGuid = tenant.extId;
        }
    }
    async getAuthorizationHeader() {
        if (!this.initialized) {
            this.autorefreshingBEIrohToken = new AutoRefreshingBEIrohToken_1.AutoRefreshingBEIrohToken(this.tenantUid);
            this.initialized = true;
        }
        const accessToken = await this.autorefreshingBEIrohToken.getFunctioningToken();
        return `Bearer ${accessToken}`;
    }
    async getComputersBulk(timeBasedAsyncLambdaInvoker, functionName, nextUri, limit) {
        await this.init();
        const bulkLength = limit || UnifiedConnectorCollectorServices.LIMIT;
        const functionState = await this.getInitialState(functionName, this.getProducer(CommonTypes_1.Source.UNIFIED_CONNECTOR));
        const params = {
            limit: bulkLength
        };
        return new UnifiedConnectorComputerCollection_1.UnifiedConnectorComputerCollection(this.adminAxios, nextUri || `/business/${this.businessGuid}/computers/bulk?${query_string_1.default.stringify(params)}`, timeBasedAsyncLambdaInvoker, functionState);
    }
    async initWebhookToken() {
        if (!this.webhookSecret) {
            const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(this.tenantUid);
            await awsSecretsService.init();
            const secrets = awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, this.sourceId));
            this.webhookSecret = await this.initWebhookTokenImpl(secrets, CommonTypes_1.Source.UNIFIED_CONNECTOR);
        }
    }
    async getWebhookStatus() {
        var _a, _b, _c, _d;
        await this.init();
        const webhookId = await this.getRegisteredWebhook();
        if (!webhookId) {
            return this.errorStatus(this.webhookSource, 'No webhook registered', 'UnifiedConnector webhook is not registered', false);
        }
        let webhookDetails;
        try {
            webhookDetails = await this.subscriptionAxios.get(`/business/${this.businessGuid}/subscription/${webhookId}`);
        }
        catch (e) {
            return this.errorStatus(this.webhookSource, 'Error fetching webhook status', `get webhook ${webhookId} returned message '${e.message}'`, true, `response error: ${(_b = (_a = e.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error}, response error description: ${(_d = (_c = e.response) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.error_description}`);
        }
        if (_.get(webhookDetails.data, 'disabled')) {
            return this.errorStatus(this.webhookSource, 'Webhook is not active', `expected webhook ${webhookId} to be active`);
        }
        const attributes = _.keys(_.get(webhookDetails.data, 'attributes'));
        if (_.size(attributes) !== UnifiedConnectorCollectorServices.UNIFIED_CONNECTOR_ATTRIBUTES.length) {
            return this.errorStatus(this.webhookSource, 'Number of registered attributes is incorrect', `mismatch in actions. actual: ${attributes} expected: ${UnifiedConnectorCollectorServices.UNIFIED_CONNECTOR_ATTRIBUTES}`);
        }
        for (const attribute of UnifiedConnectorCollectorServices.UNIFIED_CONNECTOR_ATTRIBUTES) {
            if (!_.includes(attributes, attribute)) {
                return this.errorStatus(this.webhookSource, 'Incorrect webhook attributes are registered', `mismatch in actions. actual: ${attributes} expected: ${UnifiedConnectorCollectorServices.UNIFIED_CONNECTOR_ATTRIBUTES}`);
            }
        }
        return new Services_1.WebhookStatus(this.webhookSource, 'success');
    }
    async registerWebhooks() {
        if (!process.env.GW_API_PRODUCER_NOTIFICATION_URL) {
            throw new Error('GW_API_PRODUCER_NOTIFICATION_URL is not set');
        }
        await this.init();
        await this.initWebhookToken();
        if (!this.webhookSecret) {
            throw new Error('missing webhook secret');
        }
        this.logger.info(`registering CSC webhook for tenant ${this.tenantUid}`);
        try {
            const res = await this.subscriptionAxios.post(`/business/${this.businessGuid}/subscriptions`, {
                authentication: {
                    type: 'basic',
                    value: (0, Util_1.basicAuthenticationEncode)([this.tenantUid, CommonTypes_1.Source.UNIFIED_CONNECTOR, this.sourceId].join(Util_1.SOURCE_SEPARATOR), this.webhookSecret)
                },
                name: `${this.tenantUid}${Util_1.SOURCE_SEPARATOR}${this.sourceId}`,
                disabled: false,
                URL: process.env.GW_API_PRODUCER_NOTIFICATION_URL,
                attributes: UnifiedConnectorCollectorServices.UNIFIED_CONNECTOR_ATTRIBUTES
            });
            this.logger.info(`while registering CSC webhook for tenant ${this.tenantUid}, got the response from CSC: ${JSON.stringify(res.data)}. Will be saving it`);
            const tenantConfiguration = new TenantServices_1.TenantConfiguration(this.tenantUid, this.cfgKey, res.data.id, 'UnifiedConnector Webhook ID');
            const tenantServices = new TenantServices_1.TenantServices();
            await tenantServices.addTenantConfiguration(tenantConfiguration);
            this.logger.info(`Finished registering CSC webhook for tenant ${this.tenantUid}`);
        }
        catch (e) {
            this.logger.error(`failed to register CSC webhook for tenant ${this.tenantUid}. Reason: ${e}`);
            throw e;
        }
    }
    async removeWebhooks() {
        var _a, _b;
        await this.init();
        const webhookId = await this.getRegisteredWebhook();
        if (webhookId) {
            try {
                await this.subscriptionAxios.delete(`/business/${this.businessGuid}/subscription/${webhookId}`);
            }
            catch (err) {
                if (((_b = (_a = err.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.code) !== 15) {
                    throw err;
                }
            }
        }
        const tenantServices = new TenantServices_1.TenantServices();
        await tenantServices.deleteTenantConfiguration(this.tenantUid, this.cfgKey);
    }
    async removeFailingWebhooks(failingSourceId, whatIf = true) {
        await this.init();
        const tenantServices = new TenantServices_1.TenantServices();
        const webhookType = this.cfgKey.split(Util_1.SOURCE_SEPARATOR)[0];
        const failingWebhookKey = (0, Util_1.toSourceString)(webhookType, failingSourceId);
        const failingWebhook = await tenantServices.getTenantConfiguration(this.tenantUid, failingWebhookKey);
        if (!failingWebhook) {
            throw new Error(`No webhook found where tenantUid=${this.tenantUid}, source=${webhookType}, sourceId=${failingSourceId}`);
        }
        const failingWebhookId = failingWebhook.value;
        if (!failingWebhookId) {
            this.logger.error(`No webhook ID found when removing Unified Connector webhook where tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.UNIFIED_CONNECTOR}, activeSourceId=${this.sourceId}, failingSourceId=${failingSourceId}`);
            throw new Error('No webhook ID found');
        }
        try {
            if (!whatIf) {
                await this.subscriptionAxios.delete(`/business/${this.businessGuid}/subscription/${failingWebhookId}`);
                this.logger.debug(`Deleted UnifiedConnector webhook ID ${failingWebhookId} where tenantUid=${this.tenantUid}, sourceId=${failingSourceId}`);
                await tenantServices.deleteTenantConfiguration(this.tenantUid, failingWebhookKey);
            }
            else {
                this.logger.debug(`(whatif) will attempt to remove Unified Connector webhook where id=${failingWebhookId}, tenantUid=${this.tenantUid}, source=${webhookType}, failingSourceId=${failingSourceId} using the credentials from activeSourceId=${this.sourceId}`);
            }
        }
        catch (ex) {
            this.logger.error(`Error occurred removing Unified Connector webhook where error=${ex.message}, tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.AMP}, activeSourceId=${this.sourceId}, failingSourceId=${failingSourceId}, webhookId=${failingWebhookId}`);
            return Promise.reject(ex);
        }
        return Promise.resolve(true);
    }
    async getRegisteredWebhook() {
        const tenantServices = new TenantServices_1.TenantServices();
        const existingWebhookConfig = await tenantServices.getTenantConfiguration(this.tenantUid, this.cfgKey);
        if (existingWebhookConfig) {
            return existingWebhookConfig.value;
        }
        return Promise.resolve(undefined);
    }
    async hasRegisteredWebhooks() {
        return this.getRegisteredWebhook();
    }
    async removeWebhookSecrets(sourceString, secrets) {
        if (secrets === null || secrets === void 0 ? void 0 : secrets.webhookSecret) {
            await super.removeWebhookSecrets(sourceString, secrets);
        }
        this.webhookSecret = undefined;
    }
    async getDeploymentsBulk() {
        var _a, _b;
        await this.init();
        const uri = `/business/${this.businessGuid}/deployments/bulk`;
        try {
            const deploymentsResponse = await this.adminAxios.get(uri);
            return (_b = (_a = deploymentsResponse === null || deploymentsResponse === void 0 ? void 0 : deploymentsResponse.data) === null || _a === void 0 ? void 0 : _a.deployments) !== null && _b !== void 0 ? _b : [];
        }
        catch (e) {
            this.logger.error(`Failed to fetch deployments from ${uri}. Cause: ${JSON.stringify(e)}`);
            return [];
        }
    }
    async getDeploymentsSummary() {
        var _a;
        await this.init();
        const uri = `/business/${this.businessGuid}/deployments`;
        try {
            const deploymentsResponse = await this.adminAxios.get(uri);
            return (_a = deploymentsResponse === null || deploymentsResponse === void 0 ? void 0 : deploymentsResponse.data) === null || _a === void 0 ? void 0 : _a.deployments;
        }
        catch (e) {
            this.logger.error(`Failed to fetch deployments from ${uri}. Cause: ${JSON.stringify(e)}`);
            return [];
        }
    }
    async getDeployment(deploymentId) {
        var _a;
        await this.init();
        const uri = `/business/${this.businessGuid}/deployment/${deploymentId}`;
        try {
            const deploymentResponse = await this.adminAxios.get(uri);
            return (_a = deploymentResponse === null || deploymentResponse === void 0 ? void 0 : deploymentResponse.data) === null || _a === void 0 ? void 0 : _a.deployment;
        }
        catch (e) {
            this.logger.error(`Failed to fetch deployment from ${uri}. Cause: ${JSON.stringify(e)}`);
            throw e;
        }
    }
    async queryCscDevice(ucId) {
        var _a, _b;
        await this.init();
        try {
            const response = await this.adminAxios.get(`/business/${this.businessGuid}/computer/${ucId}`);
            return Promise.resolve(response === null || response === void 0 ? void 0 : response.data);
        }
        catch (ex) {
            this.logger.error(`Failed to query CSC device where error='${ex}', error status=${ex.status}, error statusText=${ex.statusText}, error data=${JSON.stringify(ex.data)}, tenantExtId=${this.businessGuid}, device ucId=${ucId}`);
            if ((_b = (_a = ex.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.msg) {
                ex.message = `Error querying device: ${ex.response.data.msg}`;
            }
            return Promise.reject(ex);
        }
    }
    async updateCscDevice(ucId, deviceUpdate) {
        var _a, _b;
        await this.init();
        try {
            const response = await this.adminAxios.patch(`/business/${this.businessGuid}/computer/${ucId}`, deviceUpdate);
            return Promise.resolve(response);
        }
        catch (ex) {
            this.logger.error(`Failed to update CSC device where error='${ex}', error status=${ex.status}, error statusText=${ex.statusText}, error data=${JSON.stringify(ex.data)}, tenantExtId=${this.businessGuid}, device ucId=${ucId}, device update=${JSON.stringify(deviceUpdate)}`);
            if ((_b = (_a = ex.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.msg) {
                ex.message = `Error updating device: ${ex.response.data.msg}`;
            }
            return Promise.reject(ex);
        }
    }
    static parseCscOsVersion(input) {
        let osName = '';
        let major = '';
        let minor = '';
        let patch = '';
        if (input) {
            const splitOsAndVersion = _.split(input, ' - ');
            if (_.startsWith(splitOsAndVersion[0], 'name ')) {
                osName = splitOsAndVersion[0].substring(5);
            }
            if (splitOsAndVersion.length > 0) {
                const versions = _.split(splitOsAndVersion[1], '/');
                const versionMajorSplit = _.split(versions[0], ' ');
                if (versionMajorSplit.length > 0 && versionMajorSplit[1]) {
                    major = versionMajorSplit[1];
                }
                if (versions.length > 1) {
                    const versionMinorSplit = _.split(versions[1], ' ');
                    if (versionMinorSplit.length > 0 && versionMinorSplit[1]) {
                        minor = versionMinorSplit[1];
                    }
                }
                if (versions.length > 2) {
                    const versionPatchSplit = _.split(versions[2], ' ');
                    if (versionPatchSplit.length > 0 && versionPatchSplit[1]) {
                        patch = versionPatchSplit[1];
                    }
                }
            }
        }
        const osVersion = major ? `${major}${minor ? `.${minor}${patch ? `.${patch}` : ''}` : ''}` : '';
        return { osName, osVersion, major, minor, patch };
    }
    static transformCscDeviceToMergedUnifiedConnectorDevice(inputDevice) {
        const { osName, osVersion } = this.parseCscOsVersion(inputDevice.last_os);
        const outputDevice = {
            timestamp: new Date(inputDevice.updated).getTime(),
            serial: inputDevice.serial,
            deploymentId: inputDevice.last_deployment_id,
            hostname: inputDevice.last_hostname,
            mac: [],
            ips: [],
            software: [],
            cloudMgmtVersion: undefined,
            seVersion: undefined,
            cscVersion: undefined,
            osType: (0, CommonTypes_1.getOsType)(osName),
            osVersion,
            wantedDeploymentId: (inputDevice.wanted_deployment_id === UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.DEFAULT_DEPLOYMENT_ID) ? inputDevice.last_deployment_id : inputDevice.wanted_deployment_id
        };
        if (inputDevice.adapters) {
            for (const adapter of inputDevice.adapters) {
                outputDevice.mac.push(adapter.mac);
                if (Array.isArray(adapter.ipv4)) {
                    for (const ip of adapter.ipv4) {
                        outputDevice.ips.push(ip);
                    }
                }
                if (Array.isArray(adapter.ipv6)) {
                    for (const ip of adapter.ipv6) {
                        outputDevice.ips.push(ip);
                    }
                }
            }
        }
        if (inputDevice.installations) {
            for (const installation of inputDevice.installations) {
                outputDevice.software.push(`${installation.package.product}/${installation.package.version}`);
                if (installation.package.product === 'cm-enterprise') {
                    outputDevice.cloudMgmtVersion = installation.package.version;
                }
                else if (installation.package.product === 'AMP') {
                    outputDevice.seVersion = installation.package.version;
                }
                else if (_.startsWith(installation.package.product, 'ac-')) {
                    outputDevice.cscVersion = installation.package.version;
                }
            }
        }
        return outputDevice;
    }
    static transformCscDeviceToUnifiedConnectorRestComputer(inputDevice) {
        const { osName, major, minor, patch } = this.parseCscOsVersion(inputDevice.last_os);
        return {
            subscription: '',
            deployment_id: inputDevice.last_deployment_id,
            wanted_deployment_id: inputDevice.wanted_deployment_id,
            ucid: inputDevice.ucid,
            created: inputDevice.created,
            updated: inputDevice.updated,
            attributes: {
                hardware: {
                    serial_number: inputDevice.serial,
                    uuid: inputDevice.bios_uuid,
                    disk_list: []
                },
                os: {
                    hostname: inputDevice.last_hostname,
                    domainname: inputDevice.domainname,
                    name: osName,
                    major,
                    minor,
                    patch_version: patch,
                    adapters: inputDevice.adapters
                }
            },
            installations: inputDevice.installations
        };
    }
}
exports.UnifiedConnectorCollectorServices = UnifiedConnectorCollectorServices;
UnifiedConnectorCollectorServices.LIMIT = 500;
UnifiedConnectorCollectorServices.UNIFIED_CONNECTOR_ATTRIBUTES = [
    'ipv4', 'ipv6', 'hostname', 'hwid', 'mac', 'name', 'major', 'minor', 'build', 'serial', 'software', 'deployment'
];
class UnifiedConnectorAxiosWrapper {
    constructor(baseUrl, service) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.baseUrl = baseUrl;
        this.service = service;
    }
    init() {
        this.axios = axios_1.default.create({
            baseURL: this.baseUrl,
            responseType: 'json'
        });
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'UnifiedConnectorAxiosWrapper');
        return this.axios;
    }
    parseErrors(err, method) {
        var _a, _b, _c;
        if (err.isAxiosError && err.response) {
            if ((_a = err.response.data) === null || _a === void 0 ? void 0 : _a.code) {
                if (typeof ((_b = err.response.data) === null || _b === void 0 ? void 0 : _b.details) === 'string') {
                    err.message = `${err.response.data.details} (Secure Client code: ${err.response.data.code}).`;
                }
                else if (typeof ((_c = err.response.data) === null || _c === void 0 ? void 0 : _c.msg) === 'string') {
                    err.message = `${err.response.data.msg} (Secure Client code: ${err.response.data.code}).`;
                }
            }
            else {
                err.message = `${err.response.statusText} (${err.response.status}).`;
            }
            this.logger.error(`AxiosError occurred in UnifiedConnectorAxiosWrapper where method=${method}, message='${err.message}', status=${err.response.status}, statusText='${err.response.statusText}', data=${JSON.stringify(err.response.data)}`, err);
            throw err;
        }
        else {
            const unknownError = err;
            this.logger.error(`Unhandled Error occurred in UnifiedConnectorAxiosWrapper where method=${method}, message='${unknownError.message}', name=${unknownError.name}`, unknownError);
            throw err;
        }
    }
    async options(url, method, data, configs) {
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, {
            retries: 2,
            backoff: 'FIXED',
            delay: 300,
            retryIf: (err) => { var _a; return (_a = err.message) === null || _a === void 0 ? void 0 : _a.toUpperCase().includes('ECONNRESET'); }
        });
        try {
            const res = await retryUtil.executeWithRetry(async () => {
                if (!this.axios) {
                    await this.init();
                }
                this.authHeader = await this.service.getAuthorizationHeader();
                const headers = configs ? configs.headers : {};
                return this.axios.request({
                    url,
                    method,
                    data,
                    baseURL: this.baseUrl,
                    responseType: 'json',
                    headers: _.merge(headers, {
                        Authorization: this.authHeader
                    })
                })
                    .catch((err) => this.parseErrors(err, method));
            });
            return res;
        }
        catch (err) {
            return this.parseErrors(err, method);
        }
    }
    get(url) {
        return this.options(url, 'get');
    }
    post(url, data, configs) {
        return this.options(url, 'post', data, configs);
    }
    patch(url, data, configs) {
        return this.options(url, 'patch', data, configs);
    }
    delete(url) {
        return this.options(url, 'delete');
    }
}
exports.UnifiedConnectorAxiosWrapper = UnifiedConnectorAxiosWrapper;
