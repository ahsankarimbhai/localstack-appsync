"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegisterTenantAsDIModuleMigration = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const IrohModuleInstanceClient_1 = require("../../common/IrohModuleInstanceClient");
const TenantServices_1 = require("../../common/TenantServices");
class RegisterTenantAsDIModuleMigration extends DataMigrationTaskProcessor_1.DataMigrationTaskProcessor {
    async execute() {
        this.logger.debug(`Start registering DI module for ${this.tenantUid}`);
        const tenantServices = new TenantServices_1.TenantServices();
        const { setupStatus } = await tenantServices.getTenantSetupStatus(this.tenantUid);
        if (setupStatus !== TenantServices_1.TenantSetupStatus.SET_UP) {
            this.logger.debug(`Will not be registering DI module for ${this.tenantUid}, the tenant isn't set up`);
            return Promise.resolve();
        }
        const irohModuleInstanceClient = new IrohModuleInstanceClient_1.IrohModuleInstanceClient(this.tenantUid);
        await irohModuleInstanceClient.enablePostureModule();
        this.logger.debug(`Finished registering DI module for ${this.tenantUid}`);
        return Promise.resolve();
    }
    getTaskName() {
        return RegisterTenantAsDIModuleMigration.TASK_NAME;
    }
}
exports.RegisterTenantAsDIModuleMigration = RegisterTenantAsDIModuleMigration;
RegisterTenantAsDIModuleMigration.TASK_NAME = 'register-di-module-instance';
