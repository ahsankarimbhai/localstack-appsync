"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toServiceError = exports.NotFoundError = exports.UnauthorizedError = exports.BadRequestError = exports.ServiceError = void 0;
class ServiceError extends Error {
    constructor(errorCode, message) {
        super(message);
        this.errorCode = errorCode || '500';
        this.errorSummary = message;
    }
}
exports.ServiceError = ServiceError;
class BadRequestError extends ServiceError {
    constructor(message) {
        super('400', message || 'Bad Request');
    }
}
exports.BadRequestError = BadRequestError;
class UnauthorizedError extends ServiceError {
    constructor() {
        super('401', 'Unauthorized');
    }
}
exports.UnauthorizedError = UnauthorizedError;
class NotFoundError extends ServiceError {
    constructor() {
        super('404', 'Not Found');
    }
}
exports.NotFoundError = NotFoundError;
const toServiceError = (err) => {
    if (err.errorCode) {
        return err;
    }
    return new ServiceError(err.code, err.message);
};
exports.toServiceError = toServiceError;
