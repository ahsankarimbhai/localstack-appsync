"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrendVisionOneCollection = void 0;
const Collection_1 = require("../../common/Collection");
function extractNextLink(res) {
    return res.data.nextLink;
}
function extractData(res) {
    return res.data.items;
}
class TrendVisionOneCollection extends Collection_1.Collection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker) {
        super(client, uri, extractNextLink, extractData, timeBasedAsyncLambdaInvoker);
    }
}
exports.TrendVisionOneCollection = TrendVisionOneCollection;
