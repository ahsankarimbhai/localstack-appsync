"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MerakiEndpointService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
class MerakiEndpointService extends Services_1.BaseEndpointService {
    getPvType() {
        return CommonTypes_1.VertexType.MERAKI_SM_DEVICE;
    }
    getPsType() {
        return CommonTypes_1.VertexType.MERAKI_SM_DEVICE_STATE;
    }
}
exports.MerakiEndpointService = MerakiEndpointService;
