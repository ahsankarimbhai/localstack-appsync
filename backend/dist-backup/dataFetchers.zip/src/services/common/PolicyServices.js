"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PolicyServices = void 0;
const _ = __importStar(require("lodash"));
const DynamoDBServices_1 = require("../../common/awsclient/dynamodb/DynamoDBServices");
const TenantServices_1 = require("../../common/TenantServices");
const DateUtils_1 = require("../../common/DateUtils");
const Util_1 = require("../../common/Util");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const DynamodbServiceFactory_1 = require("../../common/awsclient/dynamodb/DynamodbServiceFactory");
class PolicyServices {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    upsertPolicy(policy) {
        return this.dynamoDBServices.save(PolicyServices.TABLE_NAME, {
            ...policy,
            lowercaseName: _.toLower(policy.name),
            tenantKey: this.getPolicyKey(policy),
            tenantUid: this.tenantUid,
            timeToExpire: Math.floor(Date.now() / 1000) + PolicyServices.TTL_SECONDS
        });
    }
    getPolicyKey(policy) {
        return TenantServices_1.TenantServices.getTenantConfigKey(this.tenantUid, [policy.id, policy.source, policy.sourceId].join(Util_1.SOURCE_SEPARATOR));
    }
    getPolicy(policy) {
        return this.dynamoDBServices.getByKey(PolicyServices.TABLE_NAME, PolicyServices.TENANT_KEY, this.getPolicyKey(policy));
    }
    async getPolicies(filter, lastEvaluatedKey) {
        let expression;
        let expressionAttributeValues;
        if (filter) {
            expression = 'contains(lowercaseName, :filter)';
            expressionAttributeValues = { ':filter': _.toLower(filter) };
        }
        return this.dynamoDBServices.getItemsBySecondaryIndex(PolicyServices.TABLE_NAME, PolicyServices.getDynamoDBTenantUidIndex(), PolicyServices.TENANT_UID, this.tenantUid, expression, undefined, expressionAttributeValues, lastEvaluatedKey);
    }
    async removeAllPolicies() {
        this.logger.info(`All policies for the tenant ${this.tenantUid} will be deleted`);
        return this.deletePolicies(await this.getPolicies());
    }
    deletePolicies(groups) {
        return Promise.all(_.map(groups, (group) => this.deleteByKey(_.get(group, PolicyServices.TENANT_KEY))));
    }
    deleteByKey(tenantKey) {
        return this.dynamoDBServices.delete(PolicyServices.TABLE_NAME, PolicyServices.TENANT_KEY, tenantKey);
    }
    static getDynamoDBTenantUidIndex() {
        return DynamoDBServices_1.DynamoDBServices.getTableName(PolicyServices.TENANT_UID_INDEX);
    }
}
exports.PolicyServices = PolicyServices;
PolicyServices.TABLE_NAME = 'policy';
PolicyServices.TENANT_KEY = 'tenantKey';
PolicyServices.TENANT_UID = 'tenantUid';
PolicyServices.TENANT_UID_INDEX = 'policy-tenant-uid-idx';
PolicyServices.TTL_SECONDS = 30 * DateUtils_1.DAY_SECONDS;
