"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohEntitlementSummaryClient = void 0;
const Util_1 = require("./Util");
const IrohServiceBase_1 = require("./IrohServiceBase");
const DateUtils_1 = require("./DateUtils");
const lodash_1 = __importDefault(require("lodash"));
class IrohEntitlementSummaryClient extends IrohServiceBase_1.IrohServiceBase {
    constructor(tenantUid) {
        super(tenantUid);
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'IrohRetentionPolicyClient');
    }
    async getEntitlementSummary() {
        try {
            const response = await this.axios.request(await this.getOptions(IrohEntitlementSummaryClient.IROH_ENTITLEMENT_SUMMARY_URI));
            this.logger.debug(`EntitlementSummary for tenant: ${this.tenantUid}, summary: ${JSON.stringify(response.data)}`);
            return response.data;
        }
        catch (err) {
            this.logger.debug(`Failed to get EntitlementSummary: ${err.message}`);
            return undefined;
        }
    }
    async getRetentionPolicy() {
        const summary = await this.getEntitlementSummary();
        const retentionPolicyDays = lodash_1.default.get(summary === null || summary === void 0 ? void 0 : summary.techvals, 'data-retention-in-days');
        if (lodash_1.default.isUndefined(retentionPolicyDays)) {
            return IrohEntitlementSummaryClient.DEFAULT_RETENTION_POLICY_MILLIS;
        }
        if (retentionPolicyDays <= 0) {
            this.logger.error(`Retention policy incorrect value ${retentionPolicyDays} for tenant ${this.tenantUid}`);
            return IrohEntitlementSummaryClient.ON_ERROR_INCOME_DATA_RETENTION_POLICY_MILLIS;
        }
        return retentionPolicyDays * DateUtils_1.DAY_MILLIS;
    }
}
exports.IrohEntitlementSummaryClient = IrohEntitlementSummaryClient;
IrohEntitlementSummaryClient.IROH_ENTITLEMENT_SUMMARY_URI = 'iroh/profile/entitlement-summary';
IrohEntitlementSummaryClient.ON_ERROR_INCOME_DATA_RETENTION_POLICY_MILLIS = 365 * DateUtils_1.DAY_MILLIS;
IrohEntitlementSummaryClient.DEFAULT_RETENTION_POLICY_MILLIS = 90 * DateUtils_1.DAY_MILLIS;
IrohEntitlementSummaryClient.RETENTION_POLICY_CACHE_PREFIX = 'retention_policy';
