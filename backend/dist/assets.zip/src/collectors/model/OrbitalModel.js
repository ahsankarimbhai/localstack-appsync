"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrbitalConfig = void 0;
class OrbitalConfig {
    constructor() {
        this.createdAt = Date.now();
    }
}
exports.OrbitalConfig = OrbitalConfig;
