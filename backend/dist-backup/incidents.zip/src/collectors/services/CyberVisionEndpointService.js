"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CyberVisionEndpointService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
class CyberVisionEndpointService extends Services_1.BaseEndpointService {
    getPvType() {
        return CommonTypes_1.VertexType.CYBER_VISION_DEVICE;
    }
    getPsType() {
        return CommonTypes_1.VertexType.CYBER_VISION_DEVICE_STATE;
    }
}
exports.CyberVisionEndpointService = CyberVisionEndpointService;
