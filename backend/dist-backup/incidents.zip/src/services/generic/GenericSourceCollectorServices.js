"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericSourceCollectorServices = void 0;
const Services_1 = require("../../common/Services");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const TenantServices_1 = require("../../common/TenantServices");
const GenericSourceCollection_1 = require("./GenericSourceCollection");
const Util_1 = require("../../common/Util");
const GenericSourceFetcher_1 = require("./GenericSourceFetcher");
class GenericSourceCollectorServices extends Services_1.BaseCollectorService {
    constructor(tenantUid, sourceType, sourceId, apiDetails, functionName) {
        super(tenantUid, sourceId);
        this.sourceType = sourceType;
        this.apiDetails = apiDetails;
        this.functionName = functionName;
    }
    async init() {
        if (!this.clientPicker) {
            const tenantService = new TenantServices_1.TenantServices();
            const producerConfig = await tenantService.getTenantConfigurationOrFail(this.tenantUid, this.sourceType, this.sourceId);
            if (!producerConfig.value) {
                throw new Error(`Tenant Configuration is missing "value" for generic ${this.sourceType}__${this.sourceId} producer`);
            }
            const cfgValue = JSON.parse(producerConfig.value);
            if (!cfgValue.baseURL) {
                throw new Error(`Tenant Configuration Value is missing "baseURL" for generic ${this.sourceType}__${this.sourceId} producer`);
            }
            this.clientPicker = (fetchData) => new ProxyClientFactory_1.GenericSourceIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, this.tenantUid, (0, Util_1.toSourceString)(this.sourceType, this.sourceId), fetchData);
        }
    }
    async getDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const functionState = await this.getInitialState(this.functionName, this.getProducer(this.sourceType));
        const customPageFetcher = new GenericSourceFetcher_1.GenericSourceFetcher(this.clientPicker, this.tenantUid, this.sourceType, this.sourceId, this.apiDetails, limit || GenericSourceCollectorServices.LIMIT);
        return new GenericSourceCollection_1.GenericSourceCollection(customPageFetcher, nextUri || customPageFetcher.getInitialUrlWithParams(), timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.GenericSourceCollectorServices = GenericSourceCollectorServices;
GenericSourceCollectorServices.LIMIT = 100;
