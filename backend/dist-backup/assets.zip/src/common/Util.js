"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.stringToGzip = exports.epochToISOString = exports.streamToString = exports.getProducerExtId = exports.hasDuplicatesInArray = exports.changeCronFromDailyToWeekly = exports.generateCronOnceAWeek = exports.generateCronOnceADay = exports.validateCronIsLessOftenThanExpected = exports.fixAndParseJson = exports.toObject = exports.parseSimpleLabel = exports.parseJSONString = exports.scrubAxiosAuthHeader = exports.processHostNameToNotBeFqdn = exports.lambdaProxyResponse = exports.getLambdaResponseHeaders = exports.validateCronExpression = exports.isValidDateTime = exports.isScheduledMultipleTimesADay = exports.isScheduledForNextWindow = exports.getAllSubsets = exports.base64Encode = exports.base64Decode = exports.encodeTenantName = exports.decodeTenantName = exports.getFromHeaders = exports.parseTaskParamsFromEvt = exports.getAppDataFromEvent = exports.parseEvent = exports.toSourceString = exports.verifySystemAdminAuthorization = exports.verifyAuthorization = exports.delay = exports.generateSecret = exports.logError = exports.basicAuthenticationEncode = exports.SOURCE_TAG_DYNAMIC = exports.SOURCE_SEPARATOR = exports.TOKEN_SEPARATOR = exports.UNAUTHORIZED = exports.SYSTEM_ADMIN = exports.ROLE_ADMIN = exports.ROLE_READONLY = exports.AUTHORIZER_IROH_TOKEN_HEADER_NAME = exports.AUTHORIZER_TENANT_USER_ID_HEADER_NAME = exports.AUTHORIZER_TENANT_ROLE_HEADER_NAME = exports.AUTHORIZER_TENANT_NAME_HEADER_NAME = exports.AUTHORIZER_TENANT_EXT_ID_HEADER_NAME = exports.AUTHORIZER_TENANT_UID_HEADER_NAME = void 0;
exports.gunzipToString = void 0;
const _ = __importStar(require("lodash"));
const crypto_1 = require("crypto");
const LambdaLogger_1 = require("./LambdaLogger");
const CronParser = __importStar(require("cron-parser"));
const zlib_1 = require("zlib");
exports.AUTHORIZER_TENANT_UID_HEADER_NAME = 'tenantuid';
exports.AUTHORIZER_TENANT_EXT_ID_HEADER_NAME = 'tenantextid';
exports.AUTHORIZER_TENANT_NAME_HEADER_NAME = 'tenantname';
exports.AUTHORIZER_TENANT_ROLE_HEADER_NAME = 'role';
exports.AUTHORIZER_TENANT_USER_ID_HEADER_NAME = 'id';
exports.AUTHORIZER_IROH_TOKEN_HEADER_NAME = 'irohtoken';
exports.ROLE_READONLY = 'readonly';
exports.ROLE_ADMIN = 'admin';
exports.SYSTEM_ADMIN = 'systemAdmin';
exports.UNAUTHORIZED = new Error('Unauthorized');
exports.TOKEN_SEPARATOR = '::';
exports.SOURCE_SEPARATOR = '__';
exports.SOURCE_TAG_DYNAMIC = '#DYNAMIC';
function basicAuthenticationEncode(username, password) {
    return (0, exports.base64Encode)(`${username}:${password}`);
}
exports.basicAuthenticationEncode = basicAuthenticationEncode;
function logError(error) {
    var _a;
    const logger = new LambdaLogger_1.LambdaLogger();
    const response = error.response || ((_a = error.lastError) === null || _a === void 0 ? void 0 : _a.response);
    if (response) {
        logger.error(_.omit(response.data, 'lastError.config.data'));
        logger.error(response.status);
        logger.error(response.headers);
    }
    throw error;
}
exports.logError = logError;
function generateSecret(size) {
    return (0, crypto_1.randomBytes)(size).toString('hex');
}
exports.generateSecret = generateSecret;
exports.delay = ((ms) => new Promise(resolve => setTimeout(resolve, ms)));
const verifyAuthorization = (role, userId, tenantUid) => {
    if (role !== exports.ROLE_ADMIN) {
        const logger = new LambdaLogger_1.LambdaLogger();
        logger.error(`User ${userId} with role ${role} is not authorized to execute function for tenant ${tenantUid}`);
        throw exports.UNAUTHORIZED;
    }
};
exports.verifyAuthorization = verifyAuthorization;
const verifySystemAdminAuthorization = (role, userId, tenantUid) => {
    if (role !== exports.ROLE_ADMIN || userId !== exports.SYSTEM_ADMIN) {
        const logger = new LambdaLogger_1.LambdaLogger();
        logger.error(`User ${userId} with role ${role} is not authorized to execute function for tenant ${tenantUid}`);
        throw exports.UNAUTHORIZED;
    }
};
exports.verifySystemAdminAuthorization = verifySystemAdminAuthorization;
const toSourceString = (source, sourceId) => ((sourceId) ? `${source}${exports.SOURCE_SEPARATOR}${sourceId}` : source);
exports.toSourceString = toSourceString;
const parseEvent = (event) => {
    if (_.get(event, 'Records[0].Sns.Message')) {
        return JSON.parse(event.Records[0].Sns.Message);
    }
    if (_.get(event, 'detail.eventBridgeData')) {
        return event.detail.eventBridgeData;
    }
    return event;
};
exports.parseEvent = parseEvent;
const getAppDataFromEvent = (event) => {
    const message = (0, exports.parseEvent)(event);
    return {
        tenant: message.tenant || { tenantUid: message.tenantUid, producer: message.producer },
        nextUri: message.nextUri,
        sha256: message.sha256,
        currentSequenceStart: message.currentSequenceStart
    };
};
exports.getAppDataFromEvent = getAppDataFromEvent;
const parseTaskParamsFromEvt = (event) => {
    const message = (0, exports.parseEvent)(event);
    if (!message.taskParams) {
        return undefined;
    }
    return JSON.parse(message.taskParams);
};
exports.parseTaskParamsFromEvt = parseTaskParamsFromEvt;
const getFromHeaders = (event) => {
    const tenantUid = event.request.headers[exports.AUTHORIZER_TENANT_UID_HEADER_NAME];
    const tenantExtId = event.request.headers[exports.AUTHORIZER_TENANT_EXT_ID_HEADER_NAME];
    const tenantName = (0, exports.decodeTenantName)(event.request.headers[exports.AUTHORIZER_TENANT_NAME_HEADER_NAME]);
    const role = event.request.headers[exports.AUTHORIZER_TENANT_ROLE_HEADER_NAME];
    const userId = event.request.headers[exports.AUTHORIZER_TENANT_USER_ID_HEADER_NAME];
    const token = event.request.headers[exports.AUTHORIZER_IROH_TOKEN_HEADER_NAME];
    new LambdaLogger_1.LambdaLogger().debug(`request for tenantUid: ${tenantUid}, tenantName: ${tenantName}, userId: ${userId}, role: ${role}`);
    return { tenantUid, tenantName, role, userId, token, tenantExtId };
};
exports.getFromHeaders = getFromHeaders;
const decodeTenantName = (str) => (0, exports.base64Decode)(str || '');
exports.decodeTenantName = decodeTenantName;
const encodeTenantName = (str) => (str ? (0, exports.base64Encode)(str) : str);
exports.encodeTenantName = encodeTenantName;
const base64Decode = (str) => Buffer.from(str, 'base64').toString();
exports.base64Decode = base64Decode;
const base64Encode = (str) => (Buffer.from(str).toString('base64'));
exports.base64Encode = base64Encode;
const getAllSubsets = (theArray) => _.tail(theArray.reduce((subsets, value) => subsets.concat(subsets.map((set) => [value, ...set])), [[]]));
exports.getAllSubsets = getAllSubsets;
const isScheduledForNextWindow = (schedule, scheduleWindow) => {
    if (!schedule) {
        return false;
    }
    const currentDate = new Date();
    const endScheduleWindowDate = new Date(currentDate.getTime() + scheduleWindow);
    let interval;
    try {
        interval = CronParser.parseExpression(schedule, {
            currentDate,
            endDate: endScheduleWindowDate
        });
    }
    catch (e) {
        throw new Error(`The schedule: [${schedule}] is invalid`);
    }
    return interval.hasNext();
};
exports.isScheduledForNextWindow = isScheduledForNextWindow;
const isScheduledMultipleTimesADay = (cronSchedule) => {
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    const options = {
        currentDate: new Date(),
        endDate: nextWeek,
        iterator: true
    };
    const parsedCron = CronParser.parseExpression(cronSchedule, options);
    let count = 0;
    while (parsedCron.hasNext() && count <= 7) {
        parsedCron.next();
        count += 1;
    }
    return count > 7;
};
exports.isScheduledMultipleTimesADay = isScheduledMultipleTimesADay;
const isValidDateTime = (value) => _.isNumber(value) && value > 946684800000;
exports.isValidDateTime = isValidDateTime;
const validateCronExpression = (schedule) => {
    try {
        CronParser.parseExpression(schedule);
    }
    catch (e) {
        throw new Error(`The schedule: [${schedule}] is invalid`);
    }
};
exports.validateCronExpression = validateCronExpression;
const getLambdaResponseHeaders = (method) => ({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-User-Agent,posaas-tenant-uid',
    'Access-Control-Allow-Methods': `${method},OPTIONS`
});
exports.getLambdaResponseHeaders = getLambdaResponseHeaders;
const lambdaProxyResponse = (method, body, statusCode = 200) => {
    const response = {
        statusCode,
        headers: (0, exports.getLambdaResponseHeaders)(method)
    };
    if (body) {
        response.body = body;
    }
    return response;
};
exports.lambdaProxyResponse = lambdaProxyResponse;
const processHostNameToNotBeFqdn = (hostName) => {
    if (_.invoke(hostName, 'match', '.*[a-zA-Z]+.*')) {
        return _.first(_.split(hostName, '.', 1));
    }
    return hostName;
};
exports.processHostNameToNotBeFqdn = processHostNameToNotBeFqdn;
const scrubAxiosAuthHeader = (axios, logger, prefix) => {
    axios.interceptors.response.use(_.identity, (error) => {
        var _a, _b, _c;
        if (error.config) {
            if ((_a = error.config.auth) === null || _a === void 0 ? void 0 : _a.password) {
                error.config.auth.password = '*****';
            }
            if (error.config.data) {
                const searchString = 'refresh_token=';
                const startIndex = error.config.data.indexOf(searchString) + searchString.length;
                const startString = error.config.data.substring(0, startIndex);
                const endIndex = error.config.data.indexOf('&', startIndex);
                const endString = (endIndex > -1) ? error.config.data.substring(endIndex) : '';
                error.config.data = `${startString}*****${endString}`;
            }
            if ((_b = error.config.headers) === null || _b === void 0 ? void 0 : _b.Authorization) {
                error.config.headers.Authorization = '*****';
                delete error.request._header;
            }
        }
        if (logger) {
            const message = `Failed axios call, response data: ${JSON.stringify((_c = error.response) === null || _c === void 0 ? void 0 : _c.data)}`;
            if (prefix) {
                logger.error(`${prefix} - ${message}`);
            }
            else {
                logger.error(message);
            }
        }
        return Promise.reject(error);
    });
};
exports.scrubAxiosAuthHeader = scrubAxiosAuthHeader;
const parseJSONString = (jsonString) => {
    let parsedJson = {};
    try {
        if (jsonString) {
            parsedJson = JSON.parse(jsonString);
        }
    }
    catch (err) {
        const logger = new LambdaLogger_1.LambdaLogger();
        logger.warn('failed to parse json', jsonString);
    }
    return parsedJson;
};
exports.parseJSONString = parseJSONString;
const parseSimpleLabel = (vertexLabel) => {
    const labels = _.split(vertexLabel, '::');
    const sourceLabel = _.split(labels[0], exports.SOURCE_SEPARATOR).length > 0 ? _.split(labels[0], exports.SOURCE_SEPARATOR)[0] : vertexLabel;
    return sourceLabel;
};
exports.parseSimpleLabel = parseSimpleLabel;
const toObject = (properties) => {
    const out = {};
    _.each(properties, (prop) => {
        out[prop.key] = prop.value;
    });
    return out;
};
exports.toObject = toObject;
const fixAndParseJson = (jsonStr) => {
    let returnStr = jsonStr;
    const rExp = /}[ \n]*{/g;
    if (rExp.test(jsonStr)) {
        returnStr = `[${jsonStr.replace(rExp, '}, {')}]`;
    }
    const regexComments = / \/\/.*?(\n|$)/g;
    if (regexComments.test(returnStr)) {
        returnStr = jsonStr.replace(regexComments, '\n');
    }
    return JSON.parse(returnStr);
};
exports.fixAndParseJson = fixAndParseJson;
const validateCronIsLessOftenThanExpected = (cronSchedule, expected) => {
    try {
        const parsedCron = CronParser.parseExpression(cronSchedule);
        const diff = parsedCron.next().toDate().valueOf() - parsedCron.prev().toDate().valueOf();
        return diff >= expected;
    }
    catch (e) {
        throw new Error('Cron expression is invalid');
    }
};
exports.validateCronIsLessOftenThanExpected = validateCronIsLessOftenThanExpected;
const generateCronOnceADay = () => `0 ${_.random(0, 23)} * * *`;
exports.generateCronOnceADay = generateCronOnceADay;
const generateCronOnceAWeek = () => `0 ${_.random(0, 23)} * * ${_.random(1, 7)}`;
exports.generateCronOnceAWeek = generateCronOnceAWeek;
const changeCronFromDailyToWeekly = (cron) => cron.slice(0, -1) + _.random(1, 7);
exports.changeCronFromDailyToWeekly = changeCronFromDailyToWeekly;
const hasDuplicatesInArray = (arr) => new Set(arr).size !== arr.length;
exports.hasDuplicatesInArray = hasDuplicatesInArray;
const getProducerExtId = (uid) => _.first(_.split(uid, exports.SOURCE_SEPARATOR));
exports.getProducerExtId = getProducerExtId;
const streamToString = (stream) => new Promise((resolve, reject) => {
    const chunks = [];
    stream.on('data', (chunk) => chunks.push(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
});
exports.streamToString = streamToString;
const epochToISOString = (epoch) => (epoch ? new Date(epoch).toISOString() : undefined);
exports.epochToISOString = epochToISOString;
const stringToGzip = (str) => new Promise(((resolve, reject) => {
    (0, zlib_1.gzip)(str, (err, res) => {
        if (err)
            return reject(err);
        return resolve(res.toString('base64'));
    });
}));
exports.stringToGzip = stringToGzip;
const gunzipToString = (gzipStr) => new Promise(((resolve, reject) => {
    (0, zlib_1.gunzip)(Buffer.from(gzipStr, 'base64'), (err, res) => {
        if (err)
            return reject(err);
        return resolve(res.toString('utf8'));
    });
}));
exports.gunzipToString = gunzipToString;
