"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RefreshExportStatusRunner = void 0;
const RebalanceNeptuneClustersBase_1 = require("./RebalanceNeptuneClustersBase");
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const bluebird_1 = require("bluebird");
class RefreshExportStatusRunner extends RebalanceNeptuneClustersBase_1.RebalanceNeptuneClustersBase {
    async run(logsInExporting) {
        this.logger.info('Start RefreshExportStatusRunner');
        const succeedTenants = [];
        if (logsInExporting.length === 0) {
            this.logger.info('End RefreshExportStatusRunner, no tenant has status EXPORTING');
            return succeedTenants;
        }
        await bluebird_1.Promise.map(logsInExporting, async (migrationLog) => {
            const tenantUid = migrationLog.tenantUid;
            this.logger.info(`refresh export status for tenant ${tenantUid}`);
            try {
                const logDetails = await this.neptuneShardMigrationLogDetailRepo.getTenantMigrationLogDetails(tenantUid);
                if (logDetails.length === 0) {
                    throw new Error('logDetails is not found');
                }
                const updatedLogDetails = [];
                for (const item of logDetails) {
                    if (item.exportStatus === 'succeeded' || item.exportStatus === 'failed') {
                        continue;
                    }
                    const res = await this.getNeptuneExportServiceStatus(tenantUid, item.exportId);
                    item.exportStatus = res.status;
                    item.outputS3Uri = res.outputS3Uri;
                    updatedLogDetails.push(item);
                }
                const allFinished = logDetails.every(item => item.exportStatus === 'succeeded' || item.exportStatus === 'failed');
                const hasFailure = logDetails.some(item => item.exportStatus === 'failed');
                if (allFinished && !hasFailure) {
                    succeedTenants.push(tenantUid);
                }
                await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, allFinished && hasFailure ? NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORT_FAILED : NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORTING);
                await bluebird_1.Promise.map(updatedLogDetails, async (logDetail) => {
                    await this.neptuneShardMigrationLogDetailRepo.update(logDetail.exportId, logDetail.exportStatus, logDetail.outputS3Uri);
                }, { concurrency: 500 });
            }
            catch (err) {
                this.logger.error(`failed to refresh export status for tenant ${tenantUid}, error: ${err.message}`);
            }
        }, {
            concurrency: 5
        });
        this.logger.info('End RefreshExportStatusRunner');
        return succeedTenants;
    }
    async getNeptuneExportServiceStatus(tenantUid, jobId) {
        const resp = await this.lambdaServices.syncInvoke(process.env.NEPTUNE_EXPORT_STATUS_SERVICE_LAMBDA_NAME, JSON.stringify({ jobId }));
        this.logger.info(`Get neptune export status for tenant ${tenantUid}: ${resp.Payload}`);
        const payload = JSON.parse(resp.Payload);
        const exportResult = JSON.parse((payload === null || payload === void 0 ? void 0 : payload.body) || '{}');
        return exportResult;
    }
}
exports.RefreshExportStatusRunner = RefreshExportStatusRunner;
