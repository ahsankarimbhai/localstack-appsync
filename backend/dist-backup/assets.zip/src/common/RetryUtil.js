"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RetryUtil = void 0;
const ts_retry_promise_1 = require("ts-retry-promise");
const LambdaLogger_1 = require("./LambdaLogger");
const bluebird_1 = require("bluebird");
class RetryUtil {
    constructor(timeBasedAsyncLambdaInvoker, retryUtilConfig) {
        var _a;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.getRemainingTimeInMillis = ((_a = timeBasedAsyncLambdaInvoker === null || timeBasedAsyncLambdaInvoker === void 0 ? void 0 : timeBasedAsyncLambdaInvoker.context) === null || _a === void 0 ? void 0 : _a.getRemainingTimeInMillis) ? timeBasedAsyncLambdaInvoker.context.getRemainingTimeInMillis : timeBasedAsyncLambdaInvoker === null || timeBasedAsyncLambdaInvoker === void 0 ? void 0 : timeBasedAsyncLambdaInvoker.getRemainingTimeInMillis;
        this.nextRetryDelay = this.nextRetryDelay.bind(this);
        this.nextDelay = null;
        this.abortRetry = false;
        this.retryConfig = this.convertRetryUtilConfigToRetryConfig(retryUtilConfig);
    }
    convertRetryUtilConfigToRetryConfig(retryUtilConfig) {
        if (!retryUtilConfig) {
            return RetryUtil.DEFAULT_RETRY_CONFIG;
        }
        const retryConfig = { ...retryUtilConfig };
        if (retryUtilConfig.backoff === 'NEXT_RETRY_DELAY') {
            if (!this.getRemainingTimeInMillis) {
                throw new Error('Missing timeBasedAsyncLambdaInvoker.getRemainingTimeInMillis() in RetryUtil where backoff = NEXT_RETRY_DELAY');
            }
            retryConfig.backoff = this.nextRetryDelay;
        }
        return retryConfig;
    }
    getRetryConfig() {
        return this.retryConfig;
    }
    async executeWithRetry(operation, shouldAbortRetry, reject, attemptTimeout) {
        let retryCount = 0;
        let lastError = null;
        return (0, ts_retry_promise_1.retry)(() => {
            const action = bluebird_1.Promise.try(() => {
                if (this.nextDelay === 0) {
                    this.logger.info(`Timeout occurred performing retry. Retry count = ${retryCount}`);
                    if (lastError) {
                        throw lastError;
                    }
                    throw new Error('Timeout occurred performing request');
                }
                if (this.abortRetry && lastError) {
                    throw lastError;
                }
                if (retryCount > 0) {
                    this.logger.info(`Execution attempt failed. Retry count = ${retryCount} of ${this.retryConfig.retries}`);
                }
                retryCount += 1;
                return operation().catch((err) => {
                    lastError = err;
                    if (shouldAbortRetry && shouldAbortRetry(err)) {
                        this.logger.info(`Aborting retry. Retry count = ${retryCount}`);
                        this.abortRetry = true;
                    }
                    throw err;
                });
            });
            return attemptTimeout ? action.timeout(attemptTimeout, new Error(`attempt timeout after ${attemptTimeout}ms`)) : action;
        }, this.retryConfig)
            .catch((reason) => {
            var _a;
            if ((_a = reason.lastError) === null || _a === void 0 ? void 0 : _a.message) {
                reason.message = reason.lastError.message;
            }
            if (reject) {
                reject(reason);
            }
            else {
                throw reason;
            }
        });
    }
    nextRetryDelay(attempt, delay) {
        let nextDelay = 0;
        if (!this.abortRetry) {
            const remained = this.getRemainingTimeInMillis();
            nextDelay = (delay * 2) < remained + 10000 ? (delay * 2) : 0;
        }
        this.logger.info(`Attempt ${attempt}, next retry delay: ${nextDelay} milliseconds`);
        this.nextDelay = nextDelay;
        return nextDelay;
    }
}
exports.RetryUtil = RetryUtil;
RetryUtil.DEFAULT_RETRY_CONFIG = {
    retries: 3,
    delay: 500,
    backoff: 'FIXED'
};
