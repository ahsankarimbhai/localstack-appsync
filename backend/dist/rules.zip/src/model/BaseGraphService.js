"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addCurrentStateTraversal = exports.addEdgeTraversal = exports.buildEdge = exports.BaseEdgeService = exports.BaseVertexService = exports.BaseGraphService = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphElement_1 = require("./BaseGraphElement");
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const CommonTypes_1 = require("../common/CommonTypes");
const LambdaLogger_1 = require("../common/LambdaLogger");
class BaseGraphService {
    constructor(partitionKey) {
        this.partitionKey = partitionKey;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    getNeptuneServices() {
        if (!this.neptuneServices) {
            this.neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.partitionKey);
        }
        return this.neptuneServices;
    }
}
exports.BaseGraphService = BaseGraphService;
class BaseVertexService extends BaseGraphService {
    getInputKeyProperties() {
        return ['id'];
    }
    async get(id) {
        const result = await this.getNeptuneServices().fetchVertexById(id);
        const foundVertex = _.get(result, '[0]');
        return foundVertex ? this.toVertexModelObject(foundVertex.properties, foundVertex.id, foundVertex.label) : undefined;
    }
    async upsert(object) {
        const vertexFilter = {
            id: object.getId(),
            label: object.getLabel(),
            properties: this.getFilterProperties(object.properties)
        };
        const result = await this.getNeptuneServices().upsertVertex(vertexFilter, object.properties, object.secondaryLabels);
        switch (_.size(result)) {
            case 1:
                return Promise.resolve(this.toVertexModelObject(result[0].properties, result[0].id, result[0].label));
            default:
                this.logger.error(`failed to upsert ${JSON.stringify(object)}`);
                return Promise.reject(new Error('got multiple or empty results, where expected a single one'));
        }
    }
    addUpsertTraversal(graphTraversal, object, withFold = false) {
        const vertexFilter = {
            id: object.getId(),
            label: object.getLabel(),
            properties: this.getFilterProperties(object.properties)
        };
        return withFold ? this.getNeptuneServices().addUpsertVertexTraversalStepsWithFold(graphTraversal, vertexFilter, object.properties, object.secondaryLabels)
            : this.getNeptuneServices().addUpsertVertexTraversalSteps(graphTraversal, vertexFilter, object.properties, object.secondaryLabels);
    }
    getByKey(keyProperties) {
        if (this.validateKeyProperties(keyProperties)) {
            return this.getByKeyProperties(keyProperties);
        }
        return Promise.reject(new Error('invalid keyProperties'));
    }
    validateKeyProperties(keyProperties) {
        const keyPropertyNames = _.map(keyProperties, prop => prop.key);
        return this.notNull(keyProperties) && _.isEqual(this.createInstance().getKeyProperties().sort(), keyPropertyNames.sort());
    }
    getFilterProperties(properties) {
        const filterProperties = _.filter(properties, p => (p.isKey === true || p.key === CommonTypes_1.BasicProperty.PARTITION_KEY));
        if (this.notNull(filterProperties)) {
            return filterProperties;
        }
        throw new Error('filter property values cannot be null');
    }
    notNull(properties) {
        return _.every(properties, prop => !_.isNull(prop.value));
    }
    async getCurrentState(model) {
        const extId = model.getPropertyValueOrThrow(CommonTypes_1.VertexBasicProperty.EXT_ID);
        const partitionKey = model.getPropertyValueOrThrow(CommonTypes_1.BasicProperty.PARTITION_KEY);
        const currentState = await this.getNeptuneServices().getCurrentState((0, NeptuneServicesFactory_1.getVertexId)(extId, model.type, partitionKey));
        return currentState ? this.toVertexModelObject(currentState.properties, currentState.id, currentState.label) : currentState;
    }
    toVertexModelObject(result, vertexId = undefined, label) {
        const modelObject = this.createInstance();
        const keyProperties = modelObject.getKeyProperties();
        modelObject.properties = _.map(result, (prop) => ({ key: prop.key, value: prop.value, isKey: _.includes(keyProperties, prop.key) }));
        modelObject.setLabel(label && label !== CommonTypes_1.VertexType.UNDEFINED ? label : modelObject.type);
        modelObject.updateId(vertexId);
        return modelObject;
    }
    async getByKeyProperties(keyProperties) {
        const filter = {
            label: this.createInstance().type,
            properties: keyProperties
        };
        const result = await this.getNeptuneServices().getSingleVertex(filter);
        if (result) {
            return this.toVertexModelObject(result.properties, result.id, result.label);
        }
        return undefined;
    }
    skipUpdate(object) {
        return false;
    }
}
exports.BaseVertexService = BaseVertexService;
class BaseEdgeService extends BaseGraphService {
    upsert(object) {
        const edge = {
            label: object.type,
            from: object.sourceId,
            to: object.targetId,
            properties: object.properties
        };
        return this.getNeptuneServices().upsertEdge(edge);
    }
    addUpsertTraversalSteps(graphTraversal, object) {
        const edge = {
            label: object.type,
            from: object.sourceId,
            to: object.targetId,
            properties: object.properties
        };
        return this.getNeptuneServices().addUpsertEdgeTraversalSteps(graphTraversal, edge);
    }
    async getByEnds(sourceId, targetId) {
        const edgeResult = await this.getNeptuneServices().getEdgeBySourceAndTarget({ id: sourceId }, { id: targetId });
        return (_.size(edgeResult) === 0) ? Promise.resolve() : Promise.resolve(this.toEdgeModelObject(edgeResult[0]));
    }
    toEdgeModelObject(edgeResult) {
        const partitionKey = _.get(_.find(edgeResult.properties, CommonTypes_1.BasicProperty.PARTITION_KEY), CommonTypes_1.BasicProperty.PARTITION_KEY);
        return new BaseGraphElement_1.BaseGraphEdge(edgeResult.from, edgeResult.to, partitionKey, edgeResult.label);
    }
    get(id) {
        throw new Error('Get edge by id is not supported');
    }
    addCurrentStateTraversal(graphTraversal, object) {
        const edge = {
            label: object.type,
            from: object.sourceId,
            to: object.targetId,
            properties: object.properties
        };
        return this.getNeptuneServices().addCurrentStateTraversal(graphTraversal, edge);
    }
}
exports.BaseEdgeService = BaseEdgeService;
function buildEdge(from, to, type, edgeProperties) {
    const partitionKey = from.getPropertyValueOrThrow(CommonTypes_1.BasicProperty.PARTITION_KEY);
    const edge = new BaseGraphElement_1.BaseGraphEdge(from.getId(), to.getId(), partitionKey, type, edgeProperties);
    const edgeService = new BaseEdgeService(partitionKey);
    return edgeService.upsert(edge);
}
exports.buildEdge = buildEdge;
function addEdgeTraversal(graphTraversal, from, to, type, edgeProperties) {
    const partitionKey = from.getPropertyValueOrThrow(CommonTypes_1.BasicProperty.PARTITION_KEY);
    const edge = new BaseGraphElement_1.BaseGraphEdge(from.getId(), to.getId(), partitionKey, type, edgeProperties);
    const edgeService = new BaseEdgeService(partitionKey);
    return edgeService.addUpsertTraversalSteps(graphTraversal, edge);
}
exports.addEdgeTraversal = addEdgeTraversal;
function addCurrentStateTraversal(graphTraversal, from, to) {
    const partitionKey = from.getPropertyValueOrThrow(CommonTypes_1.BasicProperty.PARTITION_KEY);
    const edge = new BaseGraphElement_1.BaseGraphEdge(from.getId(), to.getId(), partitionKey, CommonTypes_1.EdgeType.HAS_STATE);
    const edgeService = new BaseEdgeService(partitionKey);
    return edgeService.addCurrentStateTraversal(graphTraversal, edge);
}
exports.addCurrentStateTraversal = addCurrentStateTraversal;
