"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const HandlerCreator_1 = require("./common/lambdahandler/HandlerCreator");
const MetricsTelemetryMiddleware_1 = require("./common/lambdahandler/MetricsTelemetryMiddleware");
const mappings = require("./graphql-api/handlers");
exports.handler = (0, HandlerCreator_1.createHandler)(mappings, MetricsTelemetryMiddleware_1.IntegrationType.AppSync);
