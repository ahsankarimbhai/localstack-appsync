"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTokenClientId = exports.getTokenExp = exports.getAccessToken = exports.IrohInternalClient = exports.IrohExternalClient = void 0;
const lodash_1 = __importDefault(require("lodash"));
const query_string_1 = __importDefault(require("query-string"));
const url_1 = require("url");
const axios_1 = __importDefault(require("axios"));
const AwsSecretsService_1 = require("./AwsSecretsService");
const LambdaLogger_1 = require("./LambdaLogger");
const jsonwebtoken_1 = require("jsonwebtoken");
const TenantServices_1 = require("./TenantServices");
const uuid_1 = require("uuid");
const ScheduleServices_1 = require("./ScheduleServices");
const Util_1 = require("./Util");
const IrohWebhookClient_1 = require("./IrohWebhookClient");
const DateUtils_1 = require("./DateUtils");
const IrohModuleInstanceClient_1 = require("./IrohModuleInstanceClient");
const MemoryCache_1 = require("./cache/MemoryCache");
const ShardingServices_1 = require("./neptune/ShardingServices");
const IROH_OAUTH2_URI = '/iroh/oauth2';
const IROH_TOKEN_URI = `${IROH_OAUTH2_URI}/token`;
const IROH_CSRF_URI = `${IROH_OAUTH2_URI}/csrf-token`;
const IROH_AUTHORIZE_URI = `${IROH_OAUTH2_URI}/authorize`;
const SCOPES = 'vault/posture:read profile openid integration orbital webhook admin/csc:write admin/integration/module-instance:write';
const SCOPES_AS_ARRAY = lodash_1.default.split(SCOPES, ' ');
const IROH_ACCESS_TOKEN_CACHE_KEY = 'IROH_ACCESS_TOKEN_';
class IrohClient {
    constructor(globalSecretsService) {
        this.globalSecretsService = globalSecretsService;
        this.logger = new LambdaLogger_1.LambdaLogger();
        const { clientId, clientSecret } = this.globalSecretsService.getSecretByKey(IrohClient.IROH_AUTH_KEY) || {};
        if (!clientId || !clientSecret) {
            throw new Error('clientId and/or clientSecret is not set');
        }
        this.irohTokenService = new IrohTokenService(clientId, clientSecret);
    }
    static isAdmin(token) {
        const decodedToken = (0, jsonwebtoken_1.decode)(token);
        const role = lodash_1.default.get(decodedToken, IrohClient.ROLE_CLAIM);
        return lodash_1.default.isEqual(role, IrohClient.ADMIN_ROLE);
    }
    static getTenantExtId(token) {
        const decodedToken = (0, jsonwebtoken_1.decode)(token);
        return lodash_1.default.get(decodedToken, IrohClient.ORG_ID_CLAIM, '');
    }
    static getTokenScopes(token) {
        const decodedToken = (0, jsonwebtoken_1.decode)(token);
        return lodash_1.default.get(decodedToken, IrohClient.IROH_SCOPES_CLAIM, []);
    }
    getTenant(token, jit = true) {
        const extId = IrohClient.getTenantExtId(token);
        return this.createTenantIfNeeded(extId, jit);
    }
    async storeRefreshToken(irohTokenResponse, jit = false, tenant) {
        const refreshToken = irohTokenResponse.data.refresh_token;
        if (!tenant) {
            tenant = await this.getTenant(refreshToken, jit);
        }
        const tenantSecretsService = new AwsSecretsService_1.AwsSecretsService(lodash_1.default.get(tenant, 'id'));
        const value = this.getRefreshTokenSecretValue(refreshToken);
        await tenantSecretsService.setSecretValue(IrohClient.IROH_AUTH_KEY, value);
        return tenant;
    }
    getRefreshToken(tenantSecretsService, isAdmin) {
        const { refreshToken, refreshTokenReadOnly } = tenantSecretsService.getSecretByKey(IrohInternalClient.IROH_AUTH_KEY) || {};
        return isAdmin ? refreshToken : refreshTokenReadOnly;
    }
    getRefreshTokenSecretValue(refreshToken) {
        return IrohClient.isAdmin(refreshToken) ? { refreshToken } : { refreshTokenReadOnly: refreshToken };
    }
    async createTenantIfNeeded(extId, jit = true) {
        const tenantServices = new TenantServices_1.TenantServices();
        let tenant = await tenantServices.getTenantByExtId(extId);
        if (!tenant) {
            if (!jit) {
                throw new Error(`Tenant with extId ${extId} does not exist`);
            }
            this.logger.info(`Enable Device Insights for tenant, extId: ${extId}`);
            tenant = new TenantServices_1.Tenant((0, uuid_1.v4)(), extId, new Date().toISOString());
            await new ShardingServices_1.ShardingServices().allocateNeptuneCluster(tenant.id);
            await tenantServices.addTenant(tenant);
            const scheduledTasksService = new ScheduleServices_1.ScheduledTaskServices();
            await scheduledTasksService.scheduleTenantTasks(tenant.id);
        }
        return tenant;
    }
}
IrohClient.IROH_AUTH_KEY = 'irohAuth';
IrohClient.ORG_ID_CLAIM = 'https://schemas.cisco.com/iroh/identity/claims/org/id';
IrohClient.ROLE_CLAIM = 'https://schemas.cisco.com/iroh/identity/claims/user/role';
IrohClient.IROH_SCOPES_CLAIM = 'https://schemas.cisco.com/iroh/identity/claims/scopes';
IrohClient.ADMIN_ROLE = 'admin';
class IrohExternalClient extends IrohClient {
    async getAccessToken(code) {
        try {
            const irohTokenResponse = await this.irohTokenService.getAccessToken(code);
            await this.storeRefreshToken(irohTokenResponse);
            return irohTokenResponse.data.access_token;
        }
        catch (err) {
            this.logger.warn(`Failed to get access token: ${err.message}`);
            throw err;
        }
    }
    async setupTenant(token, jit = false) {
        if (!IrohClient.isAdmin(token)) {
            throw new Error('This operation is restricted for admin users only');
        }
        this.logger.info('Performing tenant setup');
        try {
            const code = await this.irohTokenService.getAuthorizationCodeFromCsrf(token);
            const irohToken = await this.irohTokenService.getAccessToken(code);
            const tenant = await this.getTenant(irohToken.data.refresh_token, jit);
            const tenantServices = new TenantServices_1.TenantServices();
            const { setupStatus } = await tenantServices.getTenantSetupStatus(tenant.id);
            const shouldSetup = setupStatus !== TenantServices_1.TenantSetupStatus.SET_UP;
            if (shouldSetup) {
                await tenantServices.setTenantSetupStatus(tenant.id, TenantServices_1.TenantSetupStatus.SETTING_UP);
            }
            const tenantId = lodash_1.default.get(tenant, 'id');
            const tenantSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantId);
            try {
                await tenantSecretsService.init();
            }
            catch (e) {
                if (e.name === 'ResourceNotFoundException' && shouldSetup) {
                    this.logger.debug(`there is no secret yet for tenant ${tenantId} and it is in setup state. Continuing with generating a secret for tenant`);
                }
                else {
                    throw e;
                }
            }
            const refreshToken = await this.getRefreshToken(tenantSecretsService, true);
            if (!refreshToken || shouldSetup || jit || this.needToUpdateScopes(refreshToken)) {
                this.logger.info(`Going to update token for tenant SecureX id: ${tenant.extId} / DI id: ${tenant.id}`);
                await this.storeRefreshToken(irohToken, jit, tenant);
            }
            const irohModuleInstanceClient = new IrohModuleInstanceClient_1.IrohModuleInstanceClient(tenant.id);
            await irohModuleInstanceClient.enablePostureModule();
            await this.setupSxModulesWebhookIfNeeded(tenant);
            if (shouldSetup) {
                await tenantServices.setTenantSetupStatus(tenant.id, TenantServices_1.TenantSetupStatus.SET_UP);
            }
        }
        catch (e) {
            this.logger.error(`Tenant setup failed, error: ${JSON.stringify(e.message)}`);
            throw e;
        }
    }
    needToUpdateScopes(token) {
        const tokenScopes = IrohClient.getTokenScopes(token !== null && token !== void 0 ? token : '');
        const differentScopes = lodash_1.default.difference(tokenScopes, SCOPES_AS_ARRAY);
        return !lodash_1.default.isEmpty(differentScopes);
    }
    async setupSxModulesWebhookIfNeeded(tenant) {
        const webhookClient = new IrohWebhookClient_1.IrohWebhookClient(tenant.id);
        const diRegistered = await webhookClient.isDIWebhookRegistered();
        if (!diRegistered) {
            await webhookClient.registerWebhook();
        }
    }
    async refreshAccessToken(token) {
        try {
            const tenant = await this.getTenant(token, false);
            const tenantSecretsService = new AwsSecretsService_1.AwsSecretsService(lodash_1.default.get(tenant, 'id'));
            await tenantSecretsService.init();
            return new IrohInternalClient(tenantSecretsService, this.globalSecretsService).refreshAccessToken(IrohClient.isAdmin(token));
        }
        catch (err) {
            this.logger.warn(`Failed to refresh access token: ${err.message}`);
            throw err;
        }
    }
}
exports.IrohExternalClient = IrohExternalClient;
class IrohInternalClient extends IrohClient {
    constructor(tenantSecretsService, globalSecretsService) {
        super(globalSecretsService);
        this.tenantSecretsService = tenantSecretsService;
    }
    async refreshAccessToken(isAdmin = true) {
        const refreshToken = await this.getRefreshToken(this.tenantSecretsService, isAdmin);
        if (!refreshToken) {
            throw new Error(`refreshToken does not exist for ${isAdmin ? 'admin' : 'read-only'} user`);
        }
        try {
            const irohToken = await this.irohTokenService.refreshAccessToken(refreshToken);
            const currentTokenExp = getTokenExp(refreshToken);
            const isCurrentRefreshTokenExpiringSoon = (!currentTokenExp) || currentTokenExp * 1000 < new Date().getTime() + 90 * DateUtils_1.DAY_MILLIS;
            if (isCurrentRefreshTokenExpiringSoon && !lodash_1.default.isNil(irohToken.data.refresh_token)) {
                const value = this.getRefreshTokenSecretValue(irohToken.data.refresh_token);
                await this.tenantSecretsService.setSecretValue(IrohClient.IROH_AUTH_KEY, value);
            }
            return irohToken.data.access_token;
        }
        catch (err) {
            this.logger.error(`Failed to refresh access token: ${err.message}`);
            throw err;
        }
    }
}
exports.IrohInternalClient = IrohInternalClient;
class IrohTokenService {
    constructor(clientId, clientSecret) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!process.env.IROH_URI) {
            throw new Error('IROH_URI is not set');
        }
        this.irohUri = process.env.IROH_URI;
        if (!process.env.IROH_REDIRECT_URI) {
            throw new Error('IROH_REDIRECT_URI is not set');
        }
        this.redirectUri = process.env.IROH_REDIRECT_URI;
        this.axios = axios_1.default.create();
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'IrohTokenService');
    }
    getAccessToken(code) {
        const params = {
            code,
            grant_type: 'authorization_code',
            redirect_uri: this.redirectUri
        };
        return this.axios.request(this.getOptions(params));
    }
    async getAuthorizationCodeFromCsrf(token) {
        const csrf = await this.getCsrfToken(token);
        return this.getAuthorizationCode(token, csrf);
    }
    async getCsrfToken(token) {
        const params = {
            client_id: this.clientId,
            scope: SCOPES
        };
        const url = IROH_CSRF_URI;
        const method = 'post';
        const options = {
            baseURL: this.irohUri,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Accept: 'application/json',
                Authorization: `Bearer ${token}`
            },
            url,
            method,
            data: query_string_1.default.stringify(params)
        };
        const response = await this.axios.request(options);
        return response.data.csrf;
    }
    async getAuthorizationCode(token, csrf) {
        const params = {
            csrf,
            client_id: this.clientId,
            scope: SCOPES,
            redirect_uri: this.redirectUri,
            response_type: 'code',
            state: (0, Util_1.generateSecret)(32)
        };
        const url = IROH_AUTHORIZE_URI;
        const method = 'post';
        const options = {
            baseURL: this.irohUri,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Accept: 'application/json',
                Authorization: `Bearer ${token}`
            },
            url,
            method,
            data: query_string_1.default.stringify(params)
        };
        const response = await this.axios.request(options);
        const code = new url_1.URL(response.data.url).searchParams.get('code');
        if (!code) {
            throw new Error('Failed to parse authorization code from redirect uri');
        }
        return code;
    }
    refreshAccessToken(refreshToken) {
        const params = {
            grant_type: 'refresh_token',
            refresh_token: refreshToken
        };
        return this.axios.request(this.getOptions(params));
    }
    getOptions(params) {
        const auth = {
            username: this.clientId,
            password: this.clientSecret
        };
        const url = IROH_TOKEN_URI;
        const method = 'post';
        return {
            baseURL: this.irohUri,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            auth,
            url,
            method,
            data: query_string_1.default.stringify(params)
        };
    }
}
async function getAccessToken(tenantUid) {
    const cacheMgr = MemoryCache_1.MemoryCacheManager.getInstance();
    const cacheKey = IROH_ACCESS_TOKEN_CACHE_KEY.concat(tenantUid);
    let token = cacheMgr.get(cacheKey);
    if (token) {
        const tokenExp = getTokenExp(token);
        if (tokenExp * 1000 - Date.now() > 5000) {
            return token;
        }
    }
    token = await generateToken(tenantUid);
    cacheMgr.put(cacheKey, token);
    return token;
}
exports.getAccessToken = getAccessToken;
async function generateToken(tenantUid) {
    const tenantSecrets = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await tenantSecrets.init();
    const globalSecrets = new AwsSecretsService_1.GlobalAwsSecretsService();
    await globalSecrets.init();
    const irohClient = new IrohInternalClient(tenantSecrets, globalSecrets);
    return irohClient.refreshAccessToken();
}
function getTokenExp(token) {
    const decodedToken = (0, jsonwebtoken_1.decode)(token);
    return decodedToken.exp;
}
exports.getTokenExp = getTokenExp;
function getTokenClientId(token) {
    const clientIdClaim = 'https://schemas.cisco.com/iroh/identity/claims/oauth/client/id';
    const decodedToken = (0, jsonwebtoken_1.decode)(token, { complete: true });
    const tokenPayload = lodash_1.default.get(decodedToken, 'payload', {});
    return lodash_1.default.get(tokenPayload, clientIdClaim, 'unknown');
}
exports.getTokenClientId = getTokenClientId;
