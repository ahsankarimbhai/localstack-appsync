"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoRefreshingBEIrohToken = void 0;
const LambdaLogger_1 = require("./LambdaLogger");
const IrohClient_1 = require("./IrohClient");
class AutoRefreshingBEIrohToken {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async getFunctioningToken() {
        if (!this.accessToken || (this.expires && this.expires < Date.now())) {
            const { token, expiry } = await this.getAccessToken();
            this.accessToken = token;
            this.expires = Date.parse(expiry);
        }
        return this.accessToken;
    }
    async getAccessToken() {
        var _a;
        try {
            const token = await (0, IrohClient_1.getAccessToken)(this.tenantUid);
            this.logger.debug('Refreshed an access token from stored BE token, will be using that for authentication');
            const tokenExp = (0, IrohClient_1.getTokenExp)(token);
            return { token, expiry: new Date(tokenExp).toString() };
        }
        catch (e) {
            if (e.config) {
                if ((_a = e.config.headers) === null || _a === void 0 ? void 0 : _a.Authorization) {
                    e.config.headers.Authorization = '*****';
                }
                if (e.config.auth) {
                    e.config.auth = '*****';
                }
                if (e.config.data) {
                    e.config.data = '*****';
                }
            }
            if (e.request) {
                delete e.request._header;
            }
            this.logger.error('Failed to fetch an active BE access token', e);
            throw e;
        }
    }
}
exports.AutoRefreshingBEIrohToken = AutoRefreshingBEIrohToken;
