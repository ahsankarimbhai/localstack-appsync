"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuoVersionServices = void 0;
const _ = __importStar(require("lodash"));
const axios_1 = __importDefault(require("axios"));
const crypto_1 = __importDefault(require("crypto"));
const url_1 = require("url");
const Util_1 = require("../../common/Util");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const CommonTypes_1 = require("../../common/CommonTypes");
var ProductStatus;
(function (ProductStatus) {
    ProductStatus["PRE_RELEASE"] = "Pre-release";
    ProductStatus["CURRENT"] = "Current";
    ProductStatus["SUPPORTED"] = "Supported";
    ProductStatus["END_OF_LIFE"] = "End-of-life";
})(ProductStatus || (ProductStatus = {}));
var VersionStatus;
(function (VersionStatus) {
    VersionStatus["FUTURE"] = "Future";
    VersionStatus["OPTIONAL"] = "Optional";
    VersionStatus["CURRENT"] = "Current";
    VersionStatus["OUT_OF_DATE"] = "Out-of-date";
})(VersionStatus || (VersionStatus = {}));
class DuoVersionServices {
    constructor(secrets) {
        this.secrets = secrets;
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!secrets.ikey) {
            throw new Error('duoIkey is not defined');
        }
        if (!secrets.skey) {
            throw new Error('duoSkey is not defined');
        }
        if (!secrets.baseURL) {
            throw new Error('baseURL is not defined');
        }
        this.axios = axios_1.default.create({
            baseURL: this.secrets.baseURL,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'DuoVersionServices');
    }
    signRequest(date, request) {
        const canon = this.getCanon(date, request);
        const sig = crypto_1.default
            .createHmac('sha512', this.secrets.skey)
            .update(canon)
            .digest('hex');
        return Buffer.from(`${this.secrets.ikey}:${sig}`).toString('base64');
    }
    getCanon(date, request) {
        return _.join([date, _.toUpper(request.method), _.toLower(new url_1.URL(this.secrets.baseURL).hostname), request.path, ''], '\n');
    }
    req(path) {
        this.logger.info(`executing duo versions request ${path}`);
        const date = new Date(Date.now()).toUTCString();
        const signature = this.signRequest(date, { path, method: 'GET' });
        return this.axios
            .get(path, {
            headers: {
                Date: date,
                Authorization: `Basic ${signature}`
            }
        })
            .then((res) => {
            if (res.data.stat !== 'OK') {
                throw new Error(`Failed fetching ${path} from Duo ${JSON.stringify(res.data)}`);
            }
            return res.data.response;
        })
            .catch(Util_1.logError);
    }
    async getProducts() {
        const res = await this.req('/v1/products');
        return res.data;
    }
    getVersions() {
        return this.req('/v1/versions');
    }
    getVersionsFor(products, versions, osFamily) {
        const osProducts = _.filter(products, { family: osFamily });
        return _.map(osProducts, prod => {
            switch (prod.status) {
                case ProductStatus.END_OF_LIFE: {
                    return { baseVersion: prod.base_version, eol: true };
                }
                case ProductStatus.PRE_RELEASE: {
                    return { baseVersion: prod.base_version, preRelease: true };
                }
                case ProductStatus.CURRENT:
                case ProductStatus.SUPPORTED:
                default: {
                    const osVersions = _.filter(versions, { product_id: prod.id });
                    const current = _.find(osVersions, { status: VersionStatus.CURRENT });
                    return {
                        baseVersion: prod.base_version,
                        current: _.toNumber(current.version.substring(prod.base_version.length + 1))
                    };
                }
            }
        });
    }
    async getOsVersions() {
        const products = await this.getProducts();
        const versions = await this.getVersions();
        return Object.values(CommonTypes_1.OperatingSystemFamily).reduce((obj, item) => ({ ...obj, [item]: this.getVersionsFor(products, versions, item) }), {});
    }
}
exports.DuoVersionServices = DuoVersionServices;
