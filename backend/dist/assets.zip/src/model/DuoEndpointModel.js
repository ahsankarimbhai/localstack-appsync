"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuoEndpointStateModelService = exports.DuoEndpointStateModel = exports.DuoEndpointModelService = exports.DuoEndpointModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const Util_1 = require("../common/Util");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class DuoEndpointModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.DUO_ENDPOINT;
    }
    async initProperties(ep) {
        const hwid = ep.hardware_uuid || ep.cpu_id || ep.device_id || ep.device_udid || ep.computer_sid;
        const hostname = ep.device_name || ep.hostname;
        const extId = hwid ? `${hwid}${Util_1.SOURCE_SEPARATOR}${hostname}` : ep.epkey;
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, extId);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.DuoEndpointModel = DuoEndpointModel;
class DuoEndpointModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new DuoEndpointModel(this.partitionKey);
    }
    getInputKeyProperties() {
        return ['hardwareId', 'hostname'];
    }
}
exports.DuoEndpointModelService = DuoEndpointModelService;
class DuoEndpointStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.DUO_ENDPOINT_STATE;
    }
    async initProperties(ep) {
        const duoEndpointStateId = {
            disk_encryption_status: ep.disk_encryption_status,
            firewall_status: ep.firewall_status,
            model: ep.model,
            os_build: ep.os_build,
            os_family: ep.os_family,
            os_version: ep.os_version,
            password_status: ep.password_status,
            security_agents: ep.security_agents,
            trusted_endpoint: ep.trusted_endpoint,
            type: ep.type,
            computer_sid: ep.computer_sid,
            cpu_id: ep.cpu_id,
            device_id: ep.device_id,
            device_udid: ep.device_udid,
            domain_sid: ep.domain_sid,
            hardware_uuid: ep.hardware_uuid,
            machine_guid: ep.machine_guid,
            hostname: ep.device_name || ep.hostname
        };
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(duoEndpointStateId));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(ep.os_family));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, ep.os_version);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, this.extractOsVersionForDuo(ep.os_version, ep.os_build));
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, ep.os_family, [ep.os_version, ep.os_build].filter(item => item).join('.'));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, ep.os_build);
        this.setProperty(DuoEndpointStateModel.DEVICE_USERNAME_TYPE_KEY, ep.device_username_type);
        this.setProperty(DuoEndpointStateModel.PASSWORD_STATUS_KEY, ep.password_status);
        this.setProperty(DuoEndpointStateModel.DISK_ENCRYPTION_KEY, ep.disk_encryption_status);
        this.setProperty(DuoEndpointStateModel.FIREWALL_STATUS_KEY, ep.firewall_status);
        this.setProperty(DuoEndpointStateModel.TRUSTED_ENDPOINT_KEY, ep.trusted_endpoint);
        this.setProperty(DuoEndpointStateModel.MODEL_KEY, ep.model);
        this.setProperty(DuoEndpointStateModel.TYPE_KEY, ep.type);
        this.setProperty(DuoEndpointStateModel.SECURITY_AGENTS_KEY, ep.security_agents);
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, ep.last_updated ? ep.last_updated * 1000 : ep.last_updated);
        const duoEndpoint = ep;
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, duoEndpoint.device_name || duoEndpoint.hostname);
        this.setProperty(DuoEndpointStateModel.DEVICE_IDENTIFIER_KEY, duoEndpoint.device_identifier);
        this.setProperty(DuoEndpointStateModel.DEVICE_IDENTIFIER_TYPE_KEY, duoEndpoint.device_identifier_type);
        this.setProperty(DuoEndpointStateModel.HEALTH_APP_CLIENT_VERSION_KEY, duoEndpoint.health_app_client_version);
        this.setProperty(DuoEndpointStateModel.HEALTH_DATA_LAST_COLLECTED_KEY, duoEndpoint.health_data_last_collected);
        this.setProperty(DuoEndpointStateModel.MACHINE_GUID, duoEndpoint.machine_guid);
        this.setProperty(DuoEndpointStateModel.COMPUTER_SID, duoEndpoint.computer_sid);
        this.setProperty(DuoEndpointStateModel.DOMAIN_SID, duoEndpoint.domain_sid);
        this.setProperty(DuoEndpointStateModel.DEVICE_ID, duoEndpoint.device_id);
        this.setProperty(DuoEndpointStateModel.DEVICE_UDID, duoEndpoint.device_udid);
        this.setProperty(DuoEndpointStateModel.CPU_ID_KEY, duoEndpoint.cpu_id);
        this.setProperty(DuoEndpointStateModel.HARDWARE_UUID, duoEndpoint.hardware_uuid);
        this.setProperty(DuoEndpointStateModel.FQDN_KEY, duoEndpoint.fqdn);
        this.setProperty(DuoEndpointStateModel.MANUFACTURER_KEY, duoEndpoint.manufacturer);
        this.setProperty(DuoEndpointStateModel.TAMPERED_KEY, duoEndpoint.tampered);
        this.setProperty(DuoEndpointStateModel.BIOMETRIC_KEY, duoEndpoint.biometric);
    }
    extractOsVersionForDuo(osVersion, osBuild) {
        if (osVersion === undefined || osBuild === undefined) {
            return 'na';
        }
        osVersion = osVersion.replace(/\s+/g, '');
        const versionParts = [osVersion];
        if (osBuild && osBuild.trim() !== '') {
            versionParts[0] = osVersion.replace(/\s*\(\s*/g, '(').replace(/\s*\)\s*/g, ')');
            versionParts.push(osBuild.trim());
        }
        return versionParts.join('.') || 'na';
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.DuoEndpointStateModel = DuoEndpointStateModel;
DuoEndpointStateModel.DEVICE_USERNAME_KEY = 'deviceUsername';
DuoEndpointStateModel.DEVICE_USERNAME_TYPE_KEY = 'deviceUsernameType';
DuoEndpointStateModel.EMAIL_KEY = 'email';
DuoEndpointStateModel.USERNAME_KEY = 'username';
DuoEndpointStateModel.PASSWORD_STATUS_KEY = 'passwordStatus';
DuoEndpointStateModel.DISK_ENCRYPTION_KEY = 'diskEncryptionStatus';
DuoEndpointStateModel.FIREWALL_STATUS_KEY = 'firewallStatus';
DuoEndpointStateModel.TRUSTED_ENDPOINT_KEY = 'trustedEndpoint';
DuoEndpointStateModel.MODEL_KEY = 'model';
DuoEndpointStateModel.TYPE_KEY = 'type';
DuoEndpointStateModel.SECURITY_AGENTS_KEY = 'securityAgents';
DuoEndpointStateModel.CPU_ID_KEY = 'cpuId';
DuoEndpointStateModel.FQDN_KEY = 'fqdn';
DuoEndpointStateModel.MANUFACTURER_KEY = 'manufacturer';
DuoEndpointStateModel.TAMPERED_KEY = 'tampered';
DuoEndpointStateModel.BIOMETRIC_KEY = 'biometric';
DuoEndpointStateModel.DEVICE_IDENTIFIER_KEY = 'deviceIdentifier';
DuoEndpointStateModel.DEVICE_IDENTIFIER_TYPE_KEY = 'deviceIdentifierType';
DuoEndpointStateModel.HEALTH_APP_CLIENT_VERSION_KEY = 'healthAppClientVersion';
DuoEndpointStateModel.HEALTH_DATA_LAST_COLLECTED_KEY = 'healthDataLastCollected';
DuoEndpointStateModel.MACHINE_GUID = 'machineGuid';
DuoEndpointStateModel.COMPUTER_SID = 'computerSid';
DuoEndpointStateModel.DOMAIN_SID = 'domainSid';
DuoEndpointStateModel.DEVICE_ID = 'deviceId';
DuoEndpointStateModel.DEVICE_UDID = 'deviceUdid';
DuoEndpointStateModel.HARDWARE_UUID = 'hardwareUuid';
class DuoEndpointStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new DuoEndpointStateModel(this.partitionKey);
    }
}
exports.DuoEndpointStateModelService = DuoEndpointStateModelService;
