"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimestreamRequestBuilder = exports.MetricsToDimensions = void 0;
const _ = __importStar(require("lodash"));
const TimestreamWriteServices_1 = require("./TimestreamWriteServices");
const now = require('nano-time');
class MetricsToDimensions {
    constructor(metrics, dimensions, evaluateAndRaiseAlert) {
        this.dimensions = dimensions;
        this.metrics = [];
        this.addMetrics(metrics, evaluateAndRaiseAlert);
    }
    addMetrics(metrics, evaluateAndRaiseAlert) {
        _.forEach(metrics, metric => this.addMetric(metric, evaluateAndRaiseAlert));
    }
    addMetric(metric, evaluateAndRaiseAlert) {
        const entry = _.find(this.metrics, { name: metric.name });
        if (entry) {
            entry.value += metric.value;
        }
        else {
            this.metrics.push(_.clone(metric));
        }
        if (evaluateAndRaiseAlert) {
            evaluateAndRaiseAlert(metric.name, (entry === null || entry === void 0 ? void 0 : entry.value) || metric.value, this.dimensions);
        }
    }
}
exports.MetricsToDimensions = MetricsToDimensions;
class TimestreamRequestBuilder {
    constructor() {
        this.metricsToDimensionsArray = [];
    }
    add(metrics, dimensions, evaluateAndRaiseAlert) {
        const positiveMetrics = TimestreamRequestBuilder.getPositiveMetrics(metrics);
        if (_.isEmpty(positiveMetrics)) {
            return;
        }
        const metricsToDimension = _.find(this.metricsToDimensionsArray, entry => _.isEqual(_.sortBy(entry.dimensions), _.sortBy(dimensions)));
        if (metricsToDimension) {
            metricsToDimension.addMetrics(positiveMetrics, evaluateAndRaiseAlert);
        }
        else {
            this.metricsToDimensionsArray.push(new MetricsToDimensions(positiveMetrics, dimensions, evaluateAndRaiseAlert));
        }
    }
    createRequestsAndReset() {
        const requests = _.map(this.metricsToDimensionsArray, (entry) => {
            const commonAttributes = {
                Dimensions: TimestreamRequestBuilder.getDimensions(...entry.dimensions),
                MeasureValueType: 'BIGINT',
                Time: now(),
                TimeUnit: 'NANOSECONDS'
            };
            const records = _.map(entry.metrics, metric => ({
                MeasureName: metric.name,
                MeasureValue: metric.value.toString()
            }));
            return {
                DatabaseName: TimestreamWriteServices_1.TimestreamWriteServices.getDatabaseName(),
                TableName: TimestreamWriteServices_1.TimestreamWriteServices.TABLE_NAME,
                Records: records,
                CommonAttributes: commonAttributes
            };
        });
        this.metricsToDimensionsArray = [];
        return requests;
    }
    static basicDimensions(tenantUid, producer, workflow) {
        const dimensions = [new TimestreamWriteServices_1.Dimension(TimestreamWriteServices_1.DimensionName.TENANT, tenantUid)];
        if (producer) {
            dimensions.push(new TimestreamWriteServices_1.Dimension(TimestreamWriteServices_1.DimensionName.PRODUCER, producer));
        }
        if (workflow) {
            dimensions.push(new TimestreamWriteServices_1.Dimension(TimestreamWriteServices_1.DimensionName.WORKFLOW, workflow));
        }
        return dimensions;
    }
    static batchJobDimensions(tenantUid, batchJobName, producer) {
        const dimensions = [new TimestreamWriteServices_1.Dimension(TimestreamWriteServices_1.DimensionName.TENANT, tenantUid)];
        if (producer) {
            dimensions.push(new TimestreamWriteServices_1.Dimension(TimestreamWriteServices_1.DimensionName.PRODUCER, producer));
        }
        if (batchJobName) {
            dimensions.push(new TimestreamWriteServices_1.Dimension(TimestreamWriteServices_1.DimensionName.WORKFLOW, batchJobName));
        }
        return dimensions;
    }
    static getDimensions(...dimensions) {
        return _.map(dimensions, dimension => ({ Name: dimension.name, Value: dimension.value }));
    }
    static getPositiveMetrics(state) {
        return _.filter(state, (metric) => metric.value > 0);
    }
}
exports.TimestreamRequestBuilder = TimestreamRequestBuilder;
