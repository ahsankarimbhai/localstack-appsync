"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedConnectorCollectorServicesUtility = void 0;
const ProducerUtil_1 = require("../common/ProducerUtil");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const TimestreamWriteServices_1 = require("../../common/TimestreamWriteServices");
const UnifiedConnectorCollectorServices_1 = require("./UnifiedConnectorCollectorServices");
const bluebird_1 = require("bluebird");
class UnifiedConnectorCollectorServicesUtility {
    constructor(service) {
        this.service = service;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async moveDevicesToDeployment(devices, deploymentId) {
        await this.service.init();
        const failureArray = [];
        const deviceUpdate = {
            wanted_deployment_id: deploymentId
        };
        await bluebird_1.Promise.map(devices, async (device) => {
            let deviceData = null;
            try {
                await this.service.updateCscDevice(device.ucId, deviceUpdate);
                deviceData = await this.service.queryCscDevice(device.ucId);
                if (deploymentId !== deviceData.wanted_deployment_id && deploymentId !== deviceData.last_deployment_id) {
                    failureArray.push({
                        device,
                        error: `CSC device query shows a different wanted_deployment_id and last_deployment_id than the desired deploymentId ${deploymentId} where response=${JSON.stringify(deviceData)}`
                    });
                    return;
                }
                const restComputer = UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices.transformCscDeviceToUnifiedConnectorRestComputer(deviceData);
                await this.processCustomChanges(restComputer);
                this.logger.info(`Processed move to new deployment ${deploymentId} for CSC device ${JSON.stringify(device)} where response=${JSON.stringify(deviceData)} and new device=${JSON.stringify(restComputer)}`);
            }
            catch (error) {
                const errorMessage = error.message;
                this.logger.error(`Error occurred while moving device deployment where error='${errorMessage}', tenantExtId=${this.service.businessGuid}, desired deploymentId=${deploymentId}, device=${JSON.stringify(device)}, response=${JSON.stringify(deviceData)}`);
                failureArray.push({ device, error: errorMessage });
            }
        }, { concurrency: +(process.env.MOVE_DEVICES_CONCURRENCY || 15) });
        if (failureArray.length > 0) {
            return bluebird_1.Promise.reject(failureArray);
        }
        return bluebird_1.Promise.resolve(true);
    }
    async processCustomChanges(data) {
        const records = [];
        const producerUtil = new ProducerUtil_1.ProducerUtil();
        const preProcessMetrics = await producerUtil.preProcessData(this.service.webhookSource, this.service.tenantUid, data, records);
        if (Array.isArray(preProcessMetrics) && preProcessMetrics.length > 0) {
            for (const metric of preProcessMetrics) {
                if (metric.name === TimestreamWriteServices_1.MetricName.RECORDS_FAILED && metric.value > 0) {
                    return bluebird_1.Promise.reject(new Error(`Failed on pre-processing where ucId=${data.ucid}. See logs for details`));
                }
            }
        }
        const inRecords = [];
        try {
            for (const record of records) {
                const recordData = {
                    retryCount: 0,
                    producer: this.service.webhookSource,
                    tenantUid: this.service.tenantUid,
                    data: JSON.parse(record.Data).data
                };
                const inRecord = {
                    kinesis: {
                        partitionKey: 'CustomEntry:0:0',
                        sequenceNumber: '0',
                        data: Buffer.from(JSON.stringify(recordData), 'ascii').toString('base64')
                    },
                    eventID: 'shard-0:0'
                };
                inRecords.push(inRecord);
            }
        }
        catch (ex) {
            this.logger.error(`Error occurred while processing custom changes where error='${ex}', data=${JSON.stringify(data)}, records=${JSON.stringify(records)}`);
            return bluebird_1.Promise.reject(ex);
        }
        const allProcessMetrics = await producerUtil.processEventRecords(inRecords);
        if (Array.isArray(allProcessMetrics) && allProcessMetrics.length > 0) {
            for (const processMetrics of allProcessMetrics) {
                for (const metric of processMetrics) {
                    if (metric.name === TimestreamWriteServices_1.MetricName.RECORDS_FAILED && metric.value > 0) {
                        return bluebird_1.Promise.reject(new Error(`Failed on processing where ucId=${data.ucid}. See logs for details`));
                    }
                }
            }
        }
        return bluebird_1.Promise.resolve();
    }
}
exports.UnifiedConnectorCollectorServicesUtility = UnifiedConnectorCollectorServicesUtility;
