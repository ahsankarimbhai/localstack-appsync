"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefenderCollectorServices = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const DefenderCollection_1 = require("./DefenderCollection");
const query_string_1 = __importDefault(require("query-string"));
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
class DefenderCollectorServices extends Services_1.BaseCollectorService {
    constructor(baseUrl, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.baseUrl = baseUrl;
        this.functionName = functionName;
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.DEFENDER, this.sourceId);
        }
    }
    async getDevices(timeBasedAsyncLambdaInvoker, nextUri, limit, sort) {
        await this.init();
        const params = {
            $top: limit || DefenderCollection_1.DefenderCollection.LIMIT,
            $orderby: sort || 'computerDnsName'
        };
        if (nextUri && nextUri.indexOf('$top') === -1) {
            nextUri = `${nextUri}${(nextUri.indexOf('?') === -1) ? '?' : '&'}${query_string_1.default.stringify(params)}`;
        }
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.DEFENDER));
        return new DefenderCollection_1.DefenderCollection(this.client, nextUri || `machines?${decodeURIComponent(query_string_1.default.stringify(params))}`, timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.DefenderCollectorServices = DefenderCollectorServices;
