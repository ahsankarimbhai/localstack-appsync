"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UmbrellaRoamingComputersCollection = void 0;
const UmbrellaCollection_1 = require("./UmbrellaCollection");
class UmbrellaRoamingComputersCollection extends UmbrellaCollection_1.UmbrellaCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker, UmbrellaRoamingComputersCollection.RETRY_CONFIG);
        this.functionState = functionState;
    }
}
exports.UmbrellaRoamingComputersCollection = UmbrellaRoamingComputersCollection;
UmbrellaRoamingComputersCollection.RETRY_CONFIG = {
    retries: 10,
    delay: 20000,
    timeout: 600000,
    backoff: 'NEXT_RETRY_DELAY'
};
