"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceNowProcessorServices = void 0;
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const CommonTypes_1 = require("../../common/CommonTypes");
const ServiceNowEndpointService_1 = require("../../collectors/services/ServiceNowEndpointService");
class ServiceNowProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(serviceNowDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, serviceNowDevice.name, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        await this.verifyChange(currentTopology, serviceNowDevice.serial_number, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, serviceNowDevice.mac_address, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        await this.verifyChange(currentTopology, serviceNowDevice.ip_address, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new ServiceNowEndpointService_1.ServiceNowEndpointService(tenantUid, sourceId);
    }
}
exports.ServiceNowProcessorServices = ServiceNowProcessorServices;
