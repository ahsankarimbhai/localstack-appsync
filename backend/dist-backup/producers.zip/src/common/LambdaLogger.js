"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LambdaLogger = void 0;
const LOGGER = require('logplease');
class LambdaLogger {
    constructor() {
        var _a, _b;
        this.logger = LOGGER.create('PosaaS', { useColors: false, showTimestamp: false });
        if (process.env.LOG_LEVEL) {
            LOGGER.setLogLevel(process.env.LOG_LEVEL);
        }
        else if ((_a = process.env.ENV) === null || _a === void 0 ? void 0 : _a.startsWith('prod')) {
            LOGGER.setLogLevel(LOGGER.LogLevels.INFO);
        }
        else if ((_b = process.env.ENV) === null || _b === void 0 ? void 0 : _b.startsWith('ci')) {
            LOGGER.setLogLevel(LOGGER.LogLevels.ERROR);
        }
    }
    log(...messages) {
        this.logger.debug(messages);
    }
    debug(message, ...optionalParams) {
        if (typeof message === 'string' && message.indexOf('endpoints') === 0) {
            return;
        }
        this.logger.debug(message, optionalParams);
    }
    info(message, ...optionalParams) {
        if (message.commandName && (!process.env.DEBUG_AWS || process.env.DEBUG_AWS === 'false')) {
            return;
        }
        this.logger.info(message, optionalParams);
    }
    warn(message, ...optionalParams) {
        this.logger.warn(message, optionalParams);
    }
    error(message, ...optionalParams) {
        this.logger.error(message, optionalParams);
    }
}
exports.LambdaLogger = LambdaLogger;
