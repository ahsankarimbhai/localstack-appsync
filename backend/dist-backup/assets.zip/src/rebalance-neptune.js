"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bulkLoadNeptuneData = exports.exportNeptuneData = exports.neptuneMigrationStateTracker = void 0;
const NeptuneMigrationStateTracker_1 = require("./rebalance-neptune/NeptuneMigrationStateTracker");
const ExportNeptuneDataRunner_1 = require("./rebalance-neptune/runners/ExportNeptuneDataRunner");
const BulkLoadNeptuneDataRunner_1 = require("./rebalance-neptune/runners/BulkLoadNeptuneDataRunner");
const Util_1 = require("./common/Util");
const neptuneMigrationStateTracker = async () => {
    const task = new NeptuneMigrationStateTracker_1.NeptuneMigrationStateTracker();
    await task.processTask();
};
exports.neptuneMigrationStateTracker = neptuneMigrationStateTracker;
const exportNeptuneData = async (event) => {
    const { tenants } = (0, Util_1.parseEvent)(event);
    const task = new ExportNeptuneDataRunner_1.ExportNeptuneDataRunner();
    await task.run(tenants || []);
};
exports.exportNeptuneData = exportNeptuneData;
const bulkLoadNeptuneData = async (event) => {
    const { tenants } = (0, Util_1.parseEvent)(event);
    const task = new BulkLoadNeptuneDataRunner_1.BulkLoadNeptuneDataRunner();
    await task.run(tenants || []);
};
exports.bulkLoadNeptuneData = bulkLoadNeptuneData;
