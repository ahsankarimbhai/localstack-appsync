"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SNSServices = void 0;
const client_sns_1 = require("@aws-sdk/client-sns");
const LambdaLogger_1 = require("./LambdaLogger");
class SNSServices {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.sns = new client_sns_1.SNSClient({ logger: this.logger });
    }
    publish(topicARN, message, messageAttributes) {
        return this.sns.send(new client_sns_1.PublishCommand({
            TopicArn: topicARN,
            Message: message,
            MessageAttributes: messageAttributes
        }));
    }
}
exports.SNSServices = SNSServices;
