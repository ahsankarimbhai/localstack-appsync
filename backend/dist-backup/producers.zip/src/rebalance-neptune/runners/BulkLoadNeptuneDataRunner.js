"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BulkLoadNeptuneDataRunner = void 0;
const RebalanceNeptuneClustersBase_1 = require("./RebalanceNeptuneClustersBase");
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const bluebird_1 = require("bluebird");
const _ = __importStar(require("lodash"));
class BulkLoadNeptuneDataRunner extends RebalanceNeptuneClustersBase_1.RebalanceNeptuneClustersBase {
    constructor() {
        super();
        this.maxBulkLoadJobsCount = +(process.env.MAX_BULK_LOAD_JOBS_COUNT || 20);
    }
    async run(tenants) {
        this.logger.info('Start BulkLoadNeptuneDataRunner');
        if (tenants.length === 0) {
            this.logger.info('End BulkLoadNeptuneDataRunner, no tenant needs to be bulk loaded');
            return;
        }
        await bluebird_1.Promise.map(tenants, async (tenantUid) => {
            const migrationLog = await this.neptuneShardMigrationLogRepo.getTenantMigrationLog(tenantUid);
            if (!migrationLog) {
                return;
            }
            try {
                if (await this.terminateNotThrottledTenant(tenantUid)) {
                    return;
                }
                const logDetails = await this.neptuneShardMigrationLogDetailRepo.getTenantMigrationLogDetails(tenantUid);
                if (logDetails.length === 0 || logDetails.some(l => l.exportStatus !== 'succeeded')) {
                    throw new Error('exporting is not completed');
                }
                await this.processLog(migrationLog, logDetails);
            }
            catch (err) {
                this.logger.error(`failed to load data for tenant ${tenantUid}, error: ${err.message}`);
                await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOAD_FAILED);
            }
        });
        this.logger.info('End BulkLoadNeptuneDataRunner');
    }
    async processLog(migrationLog, logDetails) {
        var _a;
        const tenantUid = migrationLog.tenantUid;
        const logDetailsInLoading = logDetails.filter(l => l.loadId && (!l.loadStatus || this.LOADER_IN_PROGRESS_CODES.includes(l.loadStatus)));
        let loadingAvailabilities = this.maxBulkLoadJobsCount - logDetailsInLoading.length;
        if (loadingAvailabilities <= 0) {
            this.logger.info(`won't trigger bulk load for tenantUid ${tenantUid}, it has ${logDetailsInLoading.length} loading tasks in progress and the maximum availability is ${this.maxBulkLoadJobsCount}`);
            return;
        }
        let logDetailsToLoad = logDetails.filter(l => !l.loadId);
        if (logDetailsToLoad.length === 0) {
            this.logger.info(`tenantUid ${tenantUid} has no log detail to be loaded`);
            return;
        }
        this.logger.info(`start bulk loading for tenant ${tenantUid}`);
        const neptuneWriterEndpoint = this.getClusterEndpoint(migrationLog.migrateToShardId);
        const neptuneUri = `https://${neptuneWriterEndpoint.rawImportEndpoint}:${neptuneWriterEndpoint.port}`;
        const updatedLogDetails = [];
        const dependedLoadIds = [];
        const failedLoadIdForNode = (_a = logDetails.find(l => l.type === RebalanceNeptuneClustersBase_1.ExportDataType.NODES && l.loadStatus && l.loadStatus !== this.LOADER_COMPLETED_CODE
            && !this.LOADER_IN_PROGRESS_CODES.includes(l.loadStatus))) === null || _a === void 0 ? void 0 : _a.loadId;
        if (failedLoadIdForNode) {
            dependedLoadIds.push(failedLoadIdForNode);
        }
        logDetailsToLoad = _.orderBy(logDetailsToLoad, l => l.type, 'desc');
        for (const logDetail of logDetailsToLoad) {
            if (loadingAvailabilities <= 0) {
                break;
            }
            loadingAvailabilities -= 1;
            const s3path = `${logDetail.outputS3Uri}/${logDetail.type}/`;
            const requestPayload = {
                source: s3path,
                format: 'csv',
                iamRoleArn: this.loaderS3AccessRoleArn,
                region: process.env.AWS_REGION,
                parallelism: 'OVERSUBSCRIBE',
                queueRequest: 'TRUE'
            };
            if (logDetail.type === RebalanceNeptuneClustersBase_1.ExportDataType.EDGES && dependedLoadIds.length > 0) {
                requestPayload.dependencies = dependedLoadIds;
            }
            const loadId = await this.triggerNeptuneBulkLoadWithPayload(tenantUid, requestPayload, neptuneUri);
            if (logDetail.type === RebalanceNeptuneClustersBase_1.ExportDataType.NODES) {
                dependedLoadIds.push(loadId);
            }
            logDetail.loadId = loadId;
            logDetail.loadRequestPayload = JSON.stringify(requestPayload);
            updatedLogDetails.push(logDetail);
        }
        await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOADING);
        await bluebird_1.Promise.map(updatedLogDetails, async (logDetail) => {
            await this.neptuneShardMigrationLogDetailRepo.update(logDetail.exportId, undefined, undefined, undefined, logDetail.loadId, logDetail.loadStatus, logDetail.loadRequestPayload);
        }, { concurrency: 500 });
    }
    async triggerNeptuneBulkLoadWithPayload(tenantUid, requestPayload, neptuneUri) {
        var _a;
        const res = await this.neptuneHttpClient.request({
            method: 'post',
            baseURL: neptuneUri,
            headers: {
                Accept: 'application/json'
            },
            url: '/loader',
            data: requestPayload
        });
        if (!res.data || res.data.status !== '200 OK' || !res.data.payload || !res.data.payload.loadId) {
            throw new Error(`Failed to trigger Neptune Bulk Load for tenant ${tenantUid} with request - ${JSON.stringify(requestPayload)}, response payload: ${JSON.stringify(((_a = res.data) === null || _a === void 0 ? void 0 : _a.payload) || {})}`);
        }
        const loadId = res.data.payload.loadId;
        this.logger.info(`Neptune Bulk Load loadId ${loadId} is triggered for tenant ${tenantUid} with request - ${JSON.stringify(requestPayload)}`);
        return loadId;
    }
}
exports.BulkLoadNeptuneDataRunner = BulkLoadNeptuneDataRunner;
