"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PopulateTenantUidTask = void 0;
const Util_1 = require("../../common/Util");
const bluebird_1 = require("bluebird");
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const DynamodbServiceFactory_1 = require("../../common/awsclient/dynamodb/DynamodbServiceFactory");
class PopulateTenantUidTask extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor() {
        super(...arguments);
        this.TENANT_KEY = 'tenantKey';
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    }
    async execute() {
        const taskParamsObj = this.getTaskParamsObj();
        if (!taskParamsObj || !taskParamsObj.tableNames) {
            throw new Error('tableNames must be provided.');
        }
        for (const tableName of taskParamsObj.tableNames) {
            await this.populateTenantUid(tableName);
        }
        return bluebird_1.Promise.resolve();
    }
    getTaskParamsObj() {
        try {
            return JSON.parse(this.taskParams);
        }
        catch {
            return undefined;
        }
    }
    async populateTenantUid(tableName) {
        const items = await this.dynamoDBServices.getAllFilteredTableEntries(tableName, 'attribute_not_exists(tenantUid)');
        this.logger.info(`retrieved total ${items.length} items for table ${tableName}`);
        let hasErr = false;
        await bluebird_1.Promise.map(items, async (item) => {
            try {
                const tenantUid = this.extractTenantUid(item.tenantKey || '');
                if (!tenantUid) {
                    return;
                }
                const key = {};
                key[this.TENANT_KEY] = item.tenantKey;
                await this.dynamoDBServices.update(tableName, key, { tenantUid });
            }
            catch (err) {
                hasErr = true;
                this.logger.error(`failed to update item ${item.tenantKey}, error: ${err}`);
            }
        }, { concurrency: 500 });
        if (hasErr) {
            throw new Error(`Error occurred when updating table ${tableName}`);
        }
    }
    extractTenantUid(tenantKey) {
        const indexOfSeparator = tenantKey.indexOf(Util_1.SOURCE_SEPARATOR);
        if (indexOfSeparator <= 0) {
            return undefined;
        }
        return tenantKey.substring(0, indexOfSeparator);
    }
    getTaskName() {
        return PopulateTenantUidTask.TASK_NAME;
    }
}
exports.PopulateTenantUidTask = PopulateTenantUidTask;
PopulateTenantUidTask.TASK_NAME = 'populate-tenantuid-task';
