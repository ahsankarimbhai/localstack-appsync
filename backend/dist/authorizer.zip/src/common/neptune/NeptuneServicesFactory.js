"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.closeNeptuneClient = exports.getVertexId = exports.getNeptuneServices = exports.VERTEX_ID_SEPARATOR = void 0;
const NeptuneServices_1 = require("./NeptuneServices");
const NeptuneClientManager_1 = require("./NeptuneClientManager");
exports.VERTEX_ID_SEPARATOR = '__';
function getNeptuneServices(partitionKey, strongConsistentReadDelay = 100) {
    return new NeptuneServices_1.NeptuneServices(partitionKey, strongConsistentReadDelay);
}
exports.getNeptuneServices = getNeptuneServices;
function getVertexId(vertexId, vertexType, tenantUid) {
    return `${vertexId}${exports.VERTEX_ID_SEPARATOR}${vertexType}${exports.VERTEX_ID_SEPARATOR}${tenantUid}`;
}
exports.getVertexId = getVertexId;
function closeNeptuneClient() {
    return NeptuneClientManager_1.NeptuneClientManager.getInstance().closeNeptuneClient();
}
exports.closeNeptuneClient = closeNeptuneClient;
