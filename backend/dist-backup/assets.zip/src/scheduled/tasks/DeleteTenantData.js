"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteTenantData = void 0;
const lodash_1 = __importDefault(require("lodash"));
const NeptuneDBScheduledTaskProcessor_1 = require("../NeptuneDBScheduledTaskProcessor");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const ResourcesManager_1 = require("../../common/ResourcesManager");
const TenantServices_1 = require("../../common/TenantServices");
const Util_1 = require("../../common/Util");
class DeleteTenantData extends NeptuneDBScheduledTaskProcessor_1.NeptuneDBScheduledTaskProcessor {
    getTaskName() {
        return DeleteTenantData.TASK_NAME;
    }
    processRange() {
        return this.neptuneServices.executeTenantQuery((g) => this.getRangeQuery(g, 0)
            .drop()
            .iterate());
    }
    getRootTraversal(g) {
        return this.neptuneServices.getGraphTraversal(g);
    }
    async postProcess() {
        try {
            const esServices = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
            await esServices.deleteTenant();
            return this.deleteTenantAndTenantConfigs();
        }
        finally {
            await (0, ResourcesManager_1.closeConnections)(true);
        }
    }
    async deleteTenantAndTenantConfigs() {
        const tenantServices = new TenantServices_1.TenantServices();
        const configs = await tenantServices.getAllTenantConfigurations(this.tenantUid);
        await Promise.all(lodash_1.default.map(configs, config => {
            const value = JSON.parse(config.value);
            const producerType = value.source;
            const producerId = value.sourceId;
            const cfgKey = (0, Util_1.toSourceString)(producerType, producerId);
            this.logger.info(`Deleting tenant configuration entry: ${this.tenantUid} ${cfgKey}`);
            return tenantServices.deleteTenantConfiguration(this.tenantUid, cfgKey);
        }));
        this.logger.info(`Deleting tenant entry: ${this.tenantUid}`);
        await tenantServices.deleteTenant(this.tenantUid);
    }
}
exports.DeleteTenantData = DeleteTenantData;
DeleteTenantData.TASK_NAME = 'delete-tenant-data';
