"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobileIronDeviceStateModelService = exports.MobileIronDeviceStateModel = exports.MobileIronDeviceModelService = exports.MobileIronDeviceModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const _ = __importStar(require("lodash"));
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class MobileIronDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.MOBILE_IRON_DEVICE;
    }
    async initProperties(mobileIronDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, mobileIronDevice.guid);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.MobileIronDeviceModel = MobileIronDeviceModel;
class MobileIronDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new MobileIronDeviceModel(this.partitionKey);
    }
}
exports.MobileIronDeviceModelService = MobileIronDeviceModelService;
class MobileIronDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.MOBILE_IRON_DEVICE_STATE;
    }
    async initProperties(mobileIronDevice) {
        var _a, _b;
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(mobileIronDevice, ['lastCheckin'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.IS_MANAGED, true);
        _.forEach(_.toPairs(mobileIronDevice), (pair) => {
            if (!MobileIronDeviceStateModel.EXTERNAL_PROPERTIES.includes(pair[0])) {
                switch (pair[0]) {
                    case 'entityName':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, pair[1]);
                        break;
                    case 'platformType':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(pair[1]));
                        break;
                    case 'platformVersion':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, pair[1]);
                        break;
                    case 'lastCheckin':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, pair[1]);
                        break;
                    case 'osBuildVersion':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, pair[1]);
                        break;
                    case 'complianceState':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT, pair[1]);
                        break;
                    case 'ipAddress':
                        this.setInternalIpAddresses(pair[1]);
                        break;
                    default:
                        this.setProperty(_.camelCase(pair[0]), pair[1]);
                }
            }
        });
        if ((_b = (_a = mobileIronDevice === null || mobileIronDevice === void 0 ? void 0 : mobileIronDevice.osBuildVersion) === null || _a === void 0 ? void 0 : _a.match) === null || _b === void 0 ? void 0 : _b.call(_a, /^\d+(\.\d+)+$/)) {
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(mobileIronDevice.platformVersion, mobileIronDevice.osBuildVersion));
        }
        else {
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)('', mobileIronDevice.platformVersion, mobileIronDevice.osBuildVersion));
        }
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, [mobileIronDevice.platformType, mobileIronDevice.deviceModel].filter(item => item).join(' '), mobileIronDevice.platformVersion);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.MobileIronDeviceStateModel = MobileIronDeviceStateModel;
MobileIronDeviceStateModel.EXTERNAL_PROPERTIES = [
    'guid',
    'emailAddress',
    'wiFiMacAddress',
    'serialNumber',
    'imei',
    'imei2',
    'phoneNumber',
    'udid'
];
class MobileIronDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new MobileIronDeviceStateModel(this.partitionKey);
    }
}
exports.MobileIronDeviceStateModelService = MobileIronDeviceStateModelService;
