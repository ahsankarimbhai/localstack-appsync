"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IncidentTenantAgnosticService = void 0;
const LambdaLogger_1 = require("../../common/LambdaLogger");
const TenantServices_1 = require("../../common/TenantServices");
const lodash_1 = __importDefault(require("lodash"));
class IncidentTenantAgnosticService {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async publishMultiTenantMessage(devicesEs) {
        const tenantDeviceMap = new Map();
        devicesEs.forEach((device) => {
            const tenant = device.tenantUid;
            if (tenantDeviceMap.has(tenant)) {
                tenantDeviceMap.get(tenant).push(device);
            }
            else {
                tenantDeviceMap.set(tenant, [device]);
            }
        });
        for (const [tenantId, devices] of tenantDeviceMap) {
            if (await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantId, TenantServices_1.FeatureFlag.INCIDENTS_ENABLED)) {
                const toPublish = devices.filter((device) => !lodash_1.default.isEmpty(device.incidents));
                if (!lodash_1.default.isEmpty(toPublish)) {
                    const message = this.convertToMessage(toPublish);
                    this.notifyIroh(message);
                }
            }
        }
    }
    notifyIroh(message) {
        this.logger.debug(`Iroh incident notification: ${message}`);
    }
    convertToMessage(toPublish) {
        return toPublish;
    }
}
exports.IncidentTenantAgnosticService = IncidentTenantAgnosticService;
IncidentTenantAgnosticService.MAX_BATCH_SIZE_FOR_IROH_NOTIFICATION = 1000;
