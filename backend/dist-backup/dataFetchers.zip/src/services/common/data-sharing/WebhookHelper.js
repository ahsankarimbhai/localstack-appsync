"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateWebhookColdStart = exports.WEBHOOK_SECRET_KEY_PREFIX = exports.ALL_SOURCE_TYPES = exports.WebhookEventType = void 0;
var WebhookEventType;
(function (WebhookEventType) {
    WebhookEventType["DEVICE_UPDATE"] = "UPDATE";
    WebhookEventType["DEVICE_MERGE"] = "MERGE";
    WebhookEventType["DEVICE_COLD_START"] = "COLD_START";
})(WebhookEventType = exports.WebhookEventType || (exports.WebhookEventType = {}));
exports.ALL_SOURCE_TYPES = 'ALL';
exports.WEBHOOK_SECRET_KEY_PREFIX = 'DSWebhook__';
const updateWebhookColdStart = (webhookColdStart, updateEnable, updateWithHistory, forceRefreshEnabledAt = false) => {
    if (!updateEnable) {
        webhookColdStart.enabledAt = undefined;
    }
    else if (!webhookColdStart.enable || forceRefreshEnabledAt) {
        webhookColdStart.enabledAt = Date.now();
    }
    webhookColdStart.enable = updateEnable;
    webhookColdStart.withHistory = updateWithHistory;
};
exports.updateWebhookColdStart = updateWebhookColdStart;
