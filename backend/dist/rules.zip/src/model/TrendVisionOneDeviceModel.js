"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrendVisionOneDeviceStateModelService = exports.TrendVisionOneDeviceStateModel = exports.TrendVisionOneDeviceModelService = exports.TrendVisionOneDeviceModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class TrendVisionOneDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.TREND_VISION_ONE_DEVICE;
    }
    async initProperties(trendVisionOneDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, trendVisionOneDevice.agentGuid);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.TrendVisionOneDeviceModel = TrendVisionOneDeviceModel;
class TrendVisionOneDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new TrendVisionOneDeviceModel(this.partitionKey);
    }
}
exports.TrendVisionOneDeviceModelService = TrendVisionOneDeviceModelService;
class TrendVisionOneDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.TREND_VISION_ONE_DEVICE_STATE;
    }
    async initProperties(trendVisionOneDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(trendVisionOneDevice));
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, trendVisionOneDevice.endpointName.value);
        const fieldsWithTime = [trendVisionOneDevice.loginAccount, trendVisionOneDevice.endpointName, trendVisionOneDevice.macAddress, trendVisionOneDevice.ip];
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Math.max(...fieldsWithTime.map(field => Date.parse(field.updatedDateTime))));
        this.setInternalIpAddresses(trendVisionOneDevice.ip.value);
        this.setProperty(CommonTypes_1.VertexType.MAC_ADDRESS, trendVisionOneDevice.macAddress.value);
        this.setProperty(CommonTypes_1.VertexType.USER, trendVisionOneDevice.loginAccount.value);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_HUMAN_READABLE_VERSION, trendVisionOneDevice.osDescription);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(trendVisionOneDevice.osName));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, trendVisionOneDevice.osVersion);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.TrendVisionOneDeviceStateModel = TrendVisionOneDeviceStateModel;
TrendVisionOneDeviceStateModel.CREATED_AT = 'createdAt';
TrendVisionOneDeviceStateModel.CREATED_BY = 'createdBy';
TrendVisionOneDeviceStateModel.UPDATED_BY = 'updatedBy';
class TrendVisionOneDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new TrendVisionOneDeviceStateModel(this.partitionKey);
    }
}
exports.TrendVisionOneDeviceStateModelService = TrendVisionOneDeviceStateModelService;
