"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Collection = void 0;
const Util_1 = require("./Util");
const RetryUtil_1 = require("./RetryUtil");
const LambdaLogger_1 = require("./LambdaLogger");
class Collection {
    constructor(client, uri, extractNextLink, extractData, timeBasedAsyncLambdaInvoker, retryUtilConfig) {
        this.client = client;
        this.extractNextLink = extractNextLink;
        this.extractData = extractData;
        this.timeBasedAsyncLambdaInvoker = timeBasedAsyncLambdaInvoker;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.skippedItems = 0;
        this.notLinkableItems = 0;
        this.nextUri = uri;
        this.currentItems = [];
        this.retryUtil = new RetryUtil_1.RetryUtil(timeBasedAsyncLambdaInvoker, retryUtilConfig);
    }
    next() {
        return new Promise(async (resolve, reject) => {
            const nextItem = () => {
                const item = this.currentItems.shift();
                const result = {
                    value: item,
                    done: this.isDone()
                };
                resolve(result);
            };
            if (this.currentItems.length) {
                return nextItem();
            }
            if (await this.timeBasedAsyncLambdaInvoker.invokeNextLambdaIfRequired(this.nextUri)) {
                return nextItem();
            }
            this.getNextPage()
                .then((collection) => {
                this.currentItems = collection;
                return nextItem();
            })
                .catch(reject);
        });
    }
    getNextPage() {
        if (!this.nextUri) {
            return Promise.reject(new Error('nextUri is undefined'));
        }
        this.logger.debug(`fetching next page ${this.nextUri}`);
        if (this.client.fetchNextPage) {
            return this.client.fetchNextPage(this.nextUri, this.retryUtil)
                .then((res) => {
                this.nextUri = this.client.provideNextUri();
                return res;
            })
                .catch(Util_1.logError);
        }
        return this.getWithRetry(this.nextUri)
            .then((res) => {
            this.nextUri = this.extractNextLink(res);
            return this.extractData(res);
        })
            .catch(Util_1.logError);
    }
    getWithRetry(nextUri) {
        const logger = this.logger;
        return this.retryUtil.executeWithRetry(() => this.client.get(nextUri), (err) => {
            if (err.response && (err.response.status === 400 || err.response.status === 401 || err.response.status === 403 || err.response.status === 404)) {
                logger.info(`Last error cannot be resolved (aborting retry) because status=${err.response.status} where nextUri=${nextUri}`);
                return true;
            }
            return false;
        });
    }
    each(iterator, shouldSkipPredicate, isLinkable) {
        const nextItem = async () => {
            const nextResult = await this.next();
            if (!nextResult.value) {
                return;
            }
            if (shouldSkipPredicate && !shouldSkipPredicate(nextResult.value)) {
                this.skippedItems += 1;
                if (nextResult.done) {
                    return;
                }
                return nextItem();
            }
            if (isLinkable && !isLinkable(nextResult.value)) {
                this.notLinkableItems += 1;
                if (nextResult.done) {
                    return;
                }
                return nextItem();
            }
            await iterator(nextResult.value);
            if (nextResult.done) {
                return;
            }
            return nextItem();
        };
        return nextItem();
    }
    isDone() {
        return !this.currentItems.length && !this.nextUri;
    }
    getSkippedItems() {
        return this.skippedItems;
    }
    getNotLinkableItems() {
        return this.notLinkableItems;
    }
    getNextUri() {
        return this.nextUri;
    }
}
exports.Collection = Collection;
