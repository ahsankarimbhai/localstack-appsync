"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LiveOrbitalQueryTaskStatus = exports.LiveOrbitalQueryTask = void 0;
const ScheduleServices_1 = require("../../common/ScheduleServices");
const Util_1 = require("../../common/Util");
const DateUtils_1 = require("../../common/DateUtils");
class LiveOrbitalQueryTask extends ScheduleServices_1.ScheduledTask {
    constructor(tenantUid, deviceId, producer) {
        super((0, Util_1.toSourceString)(LiveOrbitalQueryTask.TASK_NAME, deviceId), tenantUid, ScheduleServices_1.ScheduleType.NOW, producer);
        this.deviceId = deviceId;
        this.producer = producer;
        this.status = LiveOrbitalQueryTaskStatus.RUNNING;
        this.timeToExpire = Math.floor(Date.now() / 1000) + DateUtils_1.DAY_SECONDS;
    }
    getName() {
        return LiveOrbitalQueryTask.TASK_NAME;
    }
}
exports.LiveOrbitalQueryTask = LiveOrbitalQueryTask;
LiveOrbitalQueryTask.TASK_NAME = 'live-orbital-query';
var LiveOrbitalQueryTaskStatus;
(function (LiveOrbitalQueryTaskStatus) {
    LiveOrbitalQueryTaskStatus["RUNNING"] = "RUNNING";
    LiveOrbitalQueryTaskStatus["DONE"] = "DONE";
    LiveOrbitalQueryTaskStatus["ERROR"] = "ERROR";
})(LiveOrbitalQueryTaskStatus = exports.LiveOrbitalQueryTaskStatus || (exports.LiveOrbitalQueryTaskStatus = {}));
