"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CleanupShadowSources = void 0;
const _ = __importStar(require("lodash"));
const gremlin_1 = require("gremlin");
const CommonTypes_1 = require("../../common/CommonTypes");
const Util_1 = require("../../common/Util");
const PostureEndpointService_1 = require("../../model/PostureEndpointService");
const TenantServices_1 = require("../../common/TenantServices");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const ts_retry_promise_1 = require("ts-retry-promise");
const NeptuneDBScheduledTaskProcessor_1 = require("../NeptuneDBScheduledTaskProcessor");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const __ = gremlin_1.process.statics;
class CleanupShadowSources extends NeptuneDBScheduledTaskProcessor_1.NeptuneDBScheduledTaskProcessor {
    constructor(tenantUid) {
        super(tenantUid, 2);
        this.tenantServices = new TenantServices_1.TenantServices();
        this.peServices = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        this.esServices = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    }
    getTaskName() {
        return CleanupShadowSources.TASK_NAME;
    }
    async processRange(startRange) {
        const peUids = await this.neptuneServices.executeTenantQuery((g) => this.getRangeQuery(g, startRange).toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        for (const peUid of peUids) {
            try {
                await this.processPE(peUid);
            }
            catch (e) {
                this.logger.error(`${this.getLogPrefix()} - failed to process PE ${peUid}. Continuing to other records.`, e);
            }
        }
    }
    async processPE(peUid) {
        const currentPEPVs = await this.getOpenPvsForPe(peUid);
        for (const pv of currentPEPVs) {
            try {
                await this.processPV(pv, peUid);
            }
            catch (e) {
                this.logger.error(`${this.getLogPrefix()} - failed to process PV ${pv} for PE ${peUid}. Continuing to other records.`, e);
            }
        }
        await this.deletePeIfNoState(peUid);
    }
    async processPV(pv, peUid) {
        const parsedPvId = this.parsePvId(pv);
        const tenantConfiguration = await this.tenantServices.getTenantConfiguration(parsedPvId.tenantUid, `${parsedPvId.sourceType}${Util_1.SOURCE_SEPARATOR}${parsedPvId.sourceId}`);
        if (!tenantConfiguration || _.has(tenantConfiguration, 'deletedAt')) {
            this.logger.info(`${this.getLogPrefix()} - Found PV [${pv}] without a matching source configuration, deleted at ${_.get(tenantConfiguration, 'deletedAt')}. Should be fixing it`);
            let attempt = 1;
            await (0, ts_retry_promise_1.retry)(async () => {
                try {
                    this.logger.info(`${this.getLogPrefix()} - Attempt ${attempt} to fix  PV [${pv}] without a matching source configuration, deleted at ${_.get(tenantConfiguration, 'deletedAt')}`);
                    const relevantPvs = await this.getPvsConnectedToUnreliableIvsOfPv(pv);
                    const relevantPvsWithCurrentPv = _.union(relevantPvs, [pv]);
                    const relevantPvsOfSameType = _.filter(relevantPvsWithCurrentPv, relevantPv => this.parsePvId(relevantPv).sourceType === parsedPvId.sourceType);
                    this.logger.info(`${this.getLogPrefix()}  - will be closing current state of pv ${pv}`);
                    await this.neptuneServices.closeCurrentState(pv);
                    this.logger.info(`${this.getLogPrefix()}  - will be recalculating IVs unreliability of pv ${pv}`);
                    await this.peServices.recalculateUnreliableIdentifierVerticesIfNeeded(peUid, true);
                    this.logger.info(`${this.getLogPrefix()}  - will be post processing PVs [${_.join(relevantPvsOfSameType, ',')}] that are relevant to unreliable IVs of pv ${pv}`);
                    for (const recalculatePv of relevantPvsOfSameType) {
                        this.logger.info(`${this.getLogPrefix()}  - getting the PE that is relevant to pv ${recalculatePv}, post processing for pv ${pv}`);
                        const recalculatePe = await this.neptuneServices.getPostureEndpointByPV(recalculatePv);
                        this.logger.info(`${this.getLogPrefix()}  - checking if merging is needed for pv ${recalculatePv}, post processing for pv ${pv}`);
                        const epUid = await this.mergeIfNeeded(recalculatePv);
                        if (epUid !== recalculatePe) {
                            this.logger.info(`${this.getLogPrefix()}  - checking if deletion is needed for pe ${epUid}, post processing for pv ${pv}`);
                            await this.deletePeIfNoState(recalculatePe);
                        }
                    }
                }
                catch (e) {
                    this.logger.error(`Failed attempt ${attempt} to fix  PV [${pv}] without a matching source configuration, deleted at ${_.get(tenantConfiguration, 'deletedAt')}`, e);
                    attempt += 1;
                    throw e;
                }
            }, CleanupShadowSources.DEFAULT_RETRY_CONFIG);
        }
        else {
            this.logger.info(`${this.getLogPrefix()}  - checking if merging is needed for pv ${pv}, that had a good state`);
            await this.peServices.recalculateUnreliableIdentifierVerticesIfNeeded(peUid, true);
            await this.mergeIfNeeded(pv);
        }
    }
    async mergeIfNeeded(pvID) {
        const parsedPvId = this.parsePvId(pvID);
        let isPEMerged = false;
        let epUid = await this.peServices.linkDirectCandidateDetailed(parsedPvId.vertexType, pvID);
        if (epUid) {
            isPEMerged = true;
        }
        if (!epUid) {
            const res = await this.peServices.linkProducerCandidates(pvID);
            epUid = res.peUid;
            isPEMerged = res.isMergedToExistingPE;
        }
        if (epUid) {
            await this.peServices.updateSearchableVertex(epUid, true);
            await this.peServices.sendNotifications(epUid, isPEMerged);
        }
        return epUid;
    }
    async deletePeIfNoState(peUid) {
        const currentPvs = await this.getOpenPvsForPe(peUid);
        if (_.isEmpty(currentPvs)) {
            this.logger.debug(`Drop PE ${peUid} which has no more PVs`);
            await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, peUid).drop().iterate());
            await this.esServices.deleteDeviceInformation(peUid);
        }
    }
    async getOpenPvsForPe(peUid) {
        const results = await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, peUid)
            .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .where(__.outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL))
            .id()
            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        const resultSet = new gremlin_1.driver.ResultSet(results);
        return resultSet.toArray();
    }
    parsePvId(pv) {
        const tokenStruct = _.split(pv, Util_1.SOURCE_SEPARATOR);
        if (tokenStruct[3] === 'Duo') {
            return { tenantUid: tokenStruct[5], sourceType: tokenStruct[3], sourceId: tokenStruct[4], vertexType: tokenStruct[2] };
        }
        return { tenantUid: tokenStruct[4], sourceType: tokenStruct[2], sourceId: tokenStruct[3], vertexType: tokenStruct[1] };
    }
    async getPvsConnectedToUnreliableIvsOfPv(vertexId) {
        try {
            await (0, ts_retry_promise_1.retry)(async () => {
                this.logger.debug(`getting PVs connected to unreliable IVs of PV ${vertexId}`);
                const results = await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, vertexId)
                    .outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).inV()
                    .outE()
                    .inV()
                    .hasLabel(...(0, CommonTypes_1.identifierVertexTypes)())
                    .has(PostureEndpointService_1.PostureEndpointService.UNRELIABLE)
                    .as('iv')
                    .inE(CommonTypes_1.EdgeType.HAS, CommonTypes_1.EdgeType.USES)
                    .outV()
                    .as('ps')
                    .inE(CommonTypes_1.EdgeType.HAS_STATE)
                    .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
                    .outV()
                    .dedup()
                    .as('pv')
                    .id()
                    .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
                const resultSet = new gremlin_1.driver.ResultSet(results);
                const foundPVs = resultSet.toArray();
                this.logger.debug(`PVs connected to unreliable IVs of PV ${vertexId} are ${_.join(foundPVs, ',')}`);
                return foundPVs;
            }, {
                retries: 3,
                delay: 100,
                backoff: 'LINEAR',
                timeout: 15000
            });
        }
        catch (e) {
            this.logger.debug(`failed while getting PVs connected to unreliable IVs of PV ${vertexId}. Will not be processing the connected PVs`);
        }
        return [];
    }
    async nextRangeCount(startRange) {
        this.logger.debug(`Executing nextRangeCount for tenant ${this.tenantUid}`);
        const rangeCountValue = await this.neptuneServices.executeTenantQuery((g) => this.getRangeQuery(g, startRange).count().next());
        this.logger.debug(`Returning from nextRangeCount for tenant ${this.tenantUid}`);
        return rangeCountValue.value;
    }
    getRootTraversal(g) {
        return this.neptuneServices.getGraphTraversalBasedOnLabel(g, CommonTypes_1.VertexType.POSTURE_ENDPOINT).hasNot(CommonTypes_1.EdgeBasicProperty.DELETED);
    }
}
exports.CleanupShadowSources = CleanupShadowSources;
CleanupShadowSources.TASK_NAME = 'cleanup-shadow-sources';
CleanupShadowSources.DEFAULT_RETRY_CONFIG = {
    retries: 3,
    delay: 100,
    backoff: 'LINEAR',
    timeout: 70000
};
