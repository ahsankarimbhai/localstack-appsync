"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CyberVisionDeviceStateModelService = exports.CyberVisionDeviceStateModel = exports.CyberVisionDeviceModelService = exports.CyberVisionDeviceModel = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class CyberVisionDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.CYBER_VISION_DEVICE;
    }
    async initProperties(cyberVisionDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, cyberVisionDevice.id);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.CyberVisionDeviceModel = CyberVisionDeviceModel;
class CyberVisionDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new CyberVisionDeviceModel(this.partitionKey);
    }
}
exports.CyberVisionDeviceModelService = CyberVisionDeviceModelService;
class CyberVisionDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.CYBER_VISION_DEVICE_STATE;
    }
    async initProperties(cyberVisionDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(cyberVisionDevice, [CyberVisionDeviceStateModel.LAST_ACTIVE_TIME])));
        this.setProperty(CyberVisionDeviceStateModel.CREATION_TIME, Date.parse(cyberVisionDevice.creationTime));
        this.setProperty(CyberVisionDeviceStateModel.FIRST_ACTIVE_TIME, Date.parse(cyberVisionDevice.firstActiveTime));
        this.setProperty(CyberVisionDeviceStateModel.LAST_ACTIVE_TIME, Date.parse(cyberVisionDevice.lastActiveTime));
        _.forEach(_.toPairs(cyberVisionDevice), (pair) => {
            if (!CyberVisionDeviceStateModel.SKIP_PROPERTIES.includes(pair[0])) {
                if (pair[0] === CyberVisionDeviceStateModel.ID) {
                    return;
                }
                this.setProperty(_.camelCase(pair[0]), pair[1]);
                switch (pair[0]) {
                    case CyberVisionDeviceStateModel.LABEL:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, pair[1]);
                        break;
                    case CyberVisionDeviceStateModel.OS_NAMES:
                        if (pair[1].length > 0) {
                            try {
                                const os = pair[1].toString();
                                this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(os));
                                this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, (0, CommonTypes_1.getOsVersion)(os));
                            }
                            catch {
                            }
                        }
                        break;
                    case CyberVisionDeviceStateModel.LAST_ACTIVE_TIME:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(pair[1]));
                        break;
                    case CyberVisionDeviceStateModel.IPS:
                        this.setInternalIpAddresses(pair[1]);
                        break;
                    default:
                }
            }
        });
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.CyberVisionDeviceStateModel = CyberVisionDeviceStateModel;
CyberVisionDeviceStateModel.ID = 'id';
CyberVisionDeviceStateModel.FIRST_ACTIVE_TIME = 'firstActiveTime';
CyberVisionDeviceStateModel.LAST_ACTIVE_TIME = 'lastActiveTime';
CyberVisionDeviceStateModel.CREATION_TIME = 'creationTime';
CyberVisionDeviceStateModel.LABEL = 'label';
CyberVisionDeviceStateModel.TYPE = 'type';
CyberVisionDeviceStateModel.MACRO_TYPE = 'macroType';
CyberVisionDeviceStateModel.IPS = 'ips';
CyberVisionDeviceStateModel.MACS = 'macs';
CyberVisionDeviceStateModel.VLAN_IDS = 'vlanIds';
CyberVisionDeviceStateModel.VENDORS = 'vendors';
CyberVisionDeviceStateModel.OS_NAMES = 'osNames';
CyberVisionDeviceStateModel.EXPLANATION = 'explanation';
CyberVisionDeviceStateModel.MODEL_NAMES = 'modelNames';
CyberVisionDeviceStateModel.FIRMWARE_VERSIONS = 'firmwareVersions';
CyberVisionDeviceStateModel.VULNERABILITY_COUNT = 'vulnerabilityCount';
CyberVisionDeviceStateModel.SKIP_PROPERTIES = [
    CyberVisionDeviceStateModel.EXPLANATION
];
class CyberVisionDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new CyberVisionDeviceStateModel(this.partitionKey);
    }
}
exports.CyberVisionDeviceStateModelService = CyberVisionDeviceStateModelService;
