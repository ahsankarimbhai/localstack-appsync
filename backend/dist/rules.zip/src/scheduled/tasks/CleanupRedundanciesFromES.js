"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CleanupRedundanciesFromES = void 0;
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const NeptuneServicesFactory_1 = require("../../common/neptune/NeptuneServicesFactory");
const lodash_1 = __importDefault(require("lodash"));
const EsScrollProcessingScheduledTask_1 = require("./EsScrollProcessingScheduledTask");
class CleanupRedundanciesFromES extends EsScrollProcessingScheduledTask_1.EsScrollProcessingScheduledTask {
    constructor(timeBasedAsyncLambdaInvoker, tenantUid, scrollId, cumulativeTotal) {
        super(timeBasedAsyncLambdaInvoker, tenantUid, scrollId, cumulativeTotal);
        this.timeBasedAsyncLambdaInvoker = timeBasedAsyncLambdaInvoker;
        this.tenantUid = tenantUid;
        this.scrollId = scrollId;
        this.cumulativeTotal = cumulativeTotal;
        this.neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
    }
    execute() {
        return Promise.resolve(undefined);
    }
    getTaskName() {
        return CleanupRedundanciesFromES.TASK_NAME;
    }
    async processBatch(devices) {
        if (devices.length === 0) {
            return Promise.resolve();
        }
        const neptuneStartTime = Date.now();
        const vertices = await this.findTenantVerticesInNeptune(devices);
        const neptuneElapsedTime = Date.now() - neptuneStartTime;
        let count = 0;
        this.logger.debug(`${this.getLogPrefix()} found ${vertices.found.length} of ${vertices.found.length + vertices.missing.length} entries (missing ${vertices.missing.length}) from Elastic Search in Neptune`);
        for (const vertex of vertices.missing) {
            count += 1;
            this.logger.debug(`${this.getLogPrefix()} (${count}/${vertices.missing.length}) Vertex ${vertex} missing from tenant ${this.tenantUid}`);
        }
        if (count > 0) {
            this.logger.debug(`${this.getLogPrefix()} attempting to delete ${count} missing vertices from Elastic Search index`);
            const esServices = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
            for (const vertex of vertices.missing) {
                try {
                    await esServices.deleteDeviceInformation(vertex);
                }
                catch (err) {
                    this.logger.error(`Failed to delete Elastic Search entry ${vertex} from tenant ${this.tenantUid}`, err);
                }
            }
        }
        this.logger.debug(`${this.getLogPrefix()} elapsed time to call neptune: ${neptuneElapsedTime} ms`);
        return Promise.resolve(vertices);
    }
    async findTenantVerticesInNeptune(devices) {
        let found = [];
        let missing = [];
        const deviceIds = lodash_1.default.map(devices, (device) => device.uid);
        try {
            const result = await this.neptuneServices.fetchVerticesById(deviceIds);
            const resultIds = lodash_1.default.map(result, (r) => r.id);
            found = found.concat(resultIds);
            const missingIds = lodash_1.default.differenceWith(deviceIds, resultIds, lodash_1.default.isEqual);
            if (missingIds.length > 0) {
                missing = missing.concat(missingIds);
            }
        }
        catch (err) {
            this.logger.error(`Error searching in Neptune where tenant=${this.tenantUid} for these vertices=${deviceIds}`, err);
        }
        return { found, missing };
    }
    async handleSuccess() {
        this.logger.debug(`${this.getLogPrefix()} cumulatively reviewed ${this.cumulativeTotal} entries.`);
        await super.handleSuccess();
    }
}
exports.CleanupRedundanciesFromES = CleanupRedundanciesFromES;
CleanupRedundanciesFromES.TASK_NAME = 'cleanup-es-redundancies';
