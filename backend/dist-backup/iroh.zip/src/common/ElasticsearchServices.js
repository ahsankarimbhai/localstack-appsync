"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ElasticsearchGlobalServices = exports.ElasticsearchServices = exports.DevicesModifiedNotification = void 0;
const elastic_builder_1 = __importDefault(require("elastic-builder"));
const _ = __importStar(require("lodash"));
const elasticsearch_1 = require("@elastic/elasticsearch");
const LambdaLogger_1 = require("./LambdaLogger");
const CommonTypes_1 = require("./CommonTypes");
const AmpComputerModel_1 = require("../model/AmpComputerModel");
const Util_1 = require("./Util");
const OsVersionsServices_1 = require("./OsVersionsServices");
const PolicyServices_1 = require("../services/common/PolicyServices");
const GroupServices_1 = require("../services/common/GroupServices");
const DateUtils_1 = require("./DateUtils");
const NotificationService_1 = require("./notification-service/NotificationService");
const NotificationServiceInterfaces_1 = require("./notification-service/NotificationServiceInterfaces");
const ElasticsearchFactory_1 = require("./ElasticsearchFactory");
const TimestreamWriteServices_1 = require("./TimestreamWriteServices");
const Common_1 = require("./rules-system/Common");
const RetryUtil_1 = require("./RetryUtil");
const DeploymentUtil_1 = require("../helpers/DeploymentUtil");
const LabelService_1 = require("../services/common/LabelService");
const range = (start, end) => Array.from({ length: (end - start) }, (v, k) => k + start);
const ES_OPERATORS = ['NOT', 'OR', 'AND'];
const DEFAULT_AGG_NUMBER_HITS = 50;
class DevicesModifiedNotification extends NotificationServiceInterfaces_1.Notification {
    constructor(devicesModified, delayUntilModificationEventuallyConsistent, devicesSpecifierIndirect = false) {
        super();
        this.devicesModified = devicesModified;
        this.delayUntilModificationEventuallyConsistent = delayUntilModificationEventuallyConsistent;
        this.devicesSpecifierIndirect = devicesSpecifierIndirect;
        this.metrics = [];
        this.timeWhenModificationEventuallyConsistent = this.timeStamp + delayUntilModificationEventuallyConsistent;
    }
    static fromResultRequestEvent(result, indexRefreshInterval) {
        try {
            const method = result.meta.request.params.path;
            if (result.meta.context === 'index') {
                return new DevicesModifiedNotification([{ devicesSpecifier: result.body._id, devicesModificationAction: result.body.result }], indexRefreshInterval);
            }
            if (method.startsWith('/_bulk')) {
                const devicesModified = [];
                for (const item of result.body.items) {
                    const operation = Object.values(item)[0];
                    if (operation.result && operation.result !== 'deleted') {
                        devicesModified.push({ devicesSpecifier: operation._id, devicesModificationAction: operation.result });
                    }
                }
                return new DevicesModifiedNotification(devicesModified, indexRefreshInterval);
            }
            if (method.startsWith('/posture-devices/_doc/_update_by_query') && result.meta.request.params.body) {
                const body = result.meta.request.params.body.toString();
                const query = JSON.stringify(JSON.parse(body).query);
                if (result.body.total && query) {
                    return new DevicesModifiedNotification([{ devicesSpecifier: query, devicesModificationAction: 'updated' }], indexRefreshInterval, true);
                }
            }
            if (method.startsWith('/posture-devices/_update')) {
                if (result.body.result === 'noop') {
                    return null;
                }
                return new DevicesModifiedNotification([{ devicesSpecifier: result.body._id, devicesModificationAction: result.body.result }], indexRefreshInterval);
            }
            return null;
        }
        catch (e) {
            new LambdaLogger_1.LambdaLogger().error('Non critical error. Continuing after notifyResponseEventAsNotification failed', e);
            return null;
        }
    }
}
exports.DevicesModifiedNotification = DevicesModifiedNotification;
class ElasticsearchServices {
    constructor(tenantUid, elasticSearchClient) {
        this.tenantUid = tenantUid;
        this.elasticSearchClient = elasticSearchClient;
        this.indexRefreshInterval = +(process.env.ELASTIC_SEARCH_POSTURE_DEVICES_REFRESH_RATE_MS || 1000);
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.notificationService = null;
        this.rulesMetrics = new Common_1.RulesMetrics();
        this.osVersions = async () => {
            if (!this._osVersions) {
                this._osVersions = await new OsVersionsServices_1.OsVersionsServices().getOsVersions();
            }
            return this._osVersions;
        };
        this.osVersionsMap = async () => {
            if (!this._osVersionsMap) {
                this._osVersionsMap = (0, CommonTypes_1.osVersionsToMap)(await this.osVersions());
            }
            return this._osVersionsMap;
        };
        this.deploymentsMap = async () => {
            if (!this._deploymentsMap) {
                this._deploymentsMap = await (0, DeploymentUtil_1.getDeploymentsMap)(this.tenantUid);
            }
            return this._deploymentsMap;
        };
        this.labelsMap = async () => {
            if (!this._labelsMap) {
                this._labelsMap = await new LabelService_1.LabelService(this.tenantUid).getLabelsMetadataMap();
            }
            return this._labelsMap;
        };
    }
    async getIndexRefreshInterval(fetchNow = false) {
        if (!this.indexRefreshInterval || fetchNow) {
            const settingsObj = await this.elasticSearchClient.indices.getSettings({
                index: ElasticsearchServices.INDEX_NAME,
                include_defaults: true
            });
            if (settingsObj.statusCode === 200) {
                this.indexRefreshInterval = 1000 * parseInt(Object.values(settingsObj.body)[0].settings.index.refresh_interval || Object.values(settingsObj.body)[0].defaults.index.refresh_interval, 10);
            }
            else {
                throw new Error(`Error: ${settingsObj.statusCode}`);
            }
        }
        return this.indexRefreshInterval;
    }
    static addEsDevicesModifiedMetrics(devicesModifiedNotification) {
        if (devicesModifiedNotification.devicesSpecifierIndirect) {
            devicesModifiedNotification.metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.ES_DEVICES_UPDATED_BY_FILTER));
        }
        else {
            const { created, updated } = (0, Common_1.countCreatedUpdated)(devicesModifiedNotification);
            if (created) {
                devicesModifiedNotification.metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.ES_DEVICES_CREATED, created));
            }
            if (updated) {
                devicesModifiedNotification.metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.ES_DEVICES_UPDATED, updated));
            }
        }
    }
    async handleClientResponse(result) {
        if (process.env.RULES_ENABLED === 'true') {
            try {
                this.logger.debug('handleClientResponse: RULES_ENABLED', JSON.stringify(result));
                if (![200, 201].includes(result.statusCode || 0)) {
                    throw new Error(String(result.statusCode));
                }
                this.logger.debug('handleClientResponse: statusCode', result.statusCode);
                const devicesModifiedNotification = await DevicesModifiedNotification.fromResultRequestEvent(result, await this.getIndexRefreshInterval());
                if (devicesModifiedNotification) {
                    this.logger.debug('handleClientResponse: notifying devicesModifiedNotification', JSON.stringify(devicesModifiedNotification));
                    this.notificationService = this.notificationService ? this.notificationService : new NotificationService_1.NotificationService(this.tenantUid);
                    ElasticsearchServices.addEsDevicesModifiedMetrics(devicesModifiedNotification);
                    await this.notificationService.notify(devicesModifiedNotification);
                    await this.rulesMetrics.reportMetrics(devicesModifiedNotification.metrics, this.tenantUid);
                }
                else {
                    this.logger.debug('handleClientResponse: not notifying. No devicesModifiedNotification');
                }
            }
            catch (e) {
                this.logger.error('Failed notifying ES client response. This will impair rules system functionality. Continuing...', e);
            }
        }
    }
    async indexDeviceInformation(deviceInfo) {
        try {
            const indexParams = {
                index: ElasticsearchServices.INDEX_NAME,
                id: deviceInfo.postureEndpointId,
                body: deviceInfo
            };
            const response = await this.elasticSearchClient.index(indexParams, { context: 'index' });
            await this.handleClientResponse(response);
            this.logger.debug(`Successfully indexed the device information for ${this.tenantUid} // ${deviceInfo.postureEndpointId} // ${deviceInfo.hostname}. OP result: ${response.body.result}, status code ${response.statusCode}`);
            return response;
        }
        catch (e) {
            this.logger.error(`Failed to index device information for ${this.tenantUid} // ${deviceInfo.postureEndpointId} // ${deviceInfo.hostname}. Response: ${JSON.stringify(e.meta)}`, e);
            throw e;
        }
    }
    async update(deviceInformation) {
        try {
            const request = {
                index: ElasticsearchServices.INDEX_NAME,
                id: deviceInformation.postureEndpointId,
                doc_as_upsert: true,
                body: { doc: deviceInformation }
            };
            const response = await this.elasticSearchClient.update(request);
            await this.handleClientResponse(response);
            this.logger.debug(`Successfully updated device for ${this.tenantUid} // update request: ${JSON.stringify(deviceInformation)} `);
            return response;
        }
        catch (e) {
            this.logger.error(`Failed to update device for ${this.tenantUid} // update request: ${deviceInformation}. Response: ${JSON.stringify(e.meta)}`, e);
            throw e;
        }
    }
    async updatePerson(personInformation) {
        try {
            const request = {
                index: ElasticsearchServices.PERSON_INDEX_NAME,
                id: personInformation.posturePersonId,
                doc_as_upsert: true,
                body: { doc: personInformation }
            };
            await this.elasticSearchClient.update(request);
            this.logger.debug(`Successfully updated person for ${this.tenantUid} // update request: ${personInformation} `);
        }
        catch (e) {
            this.logger.error(`Failed to update person for ${this.tenantUid} // update request: ${personInformation}. Response: ${JSON.stringify(e.meta)}`, e);
            throw e;
        }
    }
    async deleteTenantEndpointData() {
        this.logger.info(`All devices for tenant ${this.tenantUid} will be deleted`);
        return this.performDeleteByQuery(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid), ElasticsearchServices.DELETE_TENANT_TASK_STATUS_WAIT_TIME, 'deleting tenant device data');
    }
    async deleteTenant() {
        return this.deleteTenantEndpointData();
    }
    async deleteTenantPersonData() {
        this.logger.info(`All users for tenant ${this.tenantUid} will be deleted`);
        return this.performDeleteByQuery(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid), ElasticsearchServices.DELETE_TENANT_TASK_STATUS_WAIT_TIME, 'deleting tenant person data', ElasticsearchServices.PERSON_INDEX_NAME);
    }
    async deleteProducer(sourceId) {
        const deleteQuery = elastic_builder_1.default.boolQuery().must([elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid), elastic_builder_1.default.matchQuery('producers.producerId.keyword', sourceId)]);
        const deleteEndpoints = this.performDeleteByQuery(deleteQuery, 2000, `deleting endpoints for producer ${sourceId}`);
        const deletePersons = this.performDeleteByQuery(deleteQuery, 2000, `deleting persons for producer ${sourceId}`, ElasticsearchServices.PERSON_INDEX_NAME);
        return Promise.all([deleteEndpoints, deletePersons]);
    }
    async deleteIrrelevantProducers(currentSources) {
        const boolQuery = elastic_builder_1.default.boolQuery();
        const queries = [];
        queries.push(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        queries.push(elastic_builder_1.default.boolQuery().must(_.map(currentSources, producer => elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('producers.producerId.keyword', producer)))));
        const deleteEndpoints = this.performDeleteByQuery(boolQuery.must(queries), 2000, `deleting endpoints for producers that do not match following sources ${currentSources.toString()}`);
        const deletePersons = this.performDeleteByQuery(boolQuery.must(queries), 2000, `deleting persons for producers that do not match following sources ${currentSources.toString()}`, ElasticsearchServices.PERSON_INDEX_NAME);
        return Promise.allSettled([deleteEndpoints, deletePersons]);
    }
    async performDeleteByQuery(query, waitingTime, loggingInfo, index = ElasticsearchServices.INDEX_NAME) {
        const startTime = Date.now();
        this.logger.debug(`Starting ${loggingInfo} for tenant ${this.tenantUid}`);
        try {
            const deleteByQueryResponse = await this.elasticSearchClient.deleteByQuery({
                wait_for_completion: false,
                conflicts: 'proceed',
                index,
                body: elastic_builder_1.default.requestBodySearch().query(query)
            });
            if (!deleteByQueryResponse) {
                return Promise.reject(new Error(`Failed registering deleteByQuery execution for ${loggingInfo}, tenantId=${this.tenantUid}`));
            }
            this.logger.debug(`deleteByQueryResponse of ${query} for tenant ${this.tenantUid} is ${JSON.stringify(deleteByQueryResponse.body)}`);
            const deleteByQueryTask = deleteByQueryResponse.body.task;
            let processing = true;
            while (processing) {
                await (0, Util_1.delay)(waitingTime);
                const result = await this.elasticSearchClient.tasks.get({
                    task_id: deleteByQueryTask
                });
                if (!result) {
                    return Promise.reject(new Error(`Failed to check deleteByQuery task=${deleteByQueryTask} execution for ${loggingInfo}, tenantId=${this.tenantUid}`));
                }
                this.logger.debug(`ES delete task result for ${waitingTime} of tenant ${this.tenantUid} is ${JSON.stringify(result.body)}`);
                processing = processing && !result.body.completed;
            }
        }
        catch (e) {
            this.logger.error(`Failed to ${loggingInfo} for tenant ${this.tenantUid}. Error: ${e.message}`);
            if (e instanceof elasticsearch_1.errors.ResponseError) {
                this.logger.error(`ES response error of ${loggingInfo} for tenant ${this.tenantUid} is ${JSON.stringify(e.meta)}`);
            }
            throw e;
        }
        finally {
            this.logger.debug(`${loggingInfo} for tenant ${this.tenantUid} finished in ${Date.now() - startTime}`);
        }
        return Promise.resolve();
    }
    async deleteDeviceInformation(postureEndpointId) {
        var _a;
        try {
            const deleteParams = {
                index: ElasticsearchServices.INDEX_NAME,
                id: postureEndpointId
            };
            const deleteResponse = await this.elasticSearchClient.delete(deleteParams);
            this.logger.debug(`Successfully deleted the device information from ES for ${postureEndpointId}. OP result: ${deleteResponse.body.result}, status code ${deleteResponse.statusCode}`);
        }
        catch (e) {
            if (((_a = e.meta) === null || _a === void 0 ? void 0 : _a.statusCode) !== 404) {
                this.logger.error(`Failed to delete device information from ES for ${postureEndpointId}. Response: ${JSON.stringify(e.meta)}`, e);
                throw new Error(e);
            }
            else {
                this.logger.debug(`No device information to delete in ES for ${postureEndpointId}. Response: ${JSON.stringify(e.meta)}`, e);
            }
        }
    }
    async deletePersonInformation(posturePersonId) {
        var _a;
        try {
            const deleteParams = {
                index: ElasticsearchServices.PERSON_INDEX_NAME,
                id: posturePersonId
            };
            const deleteResponse = await this.elasticSearchClient.delete(deleteParams);
            this.logger.debug(`Successfully deleted the person information from ES for ${posturePersonId}. OP result: ${deleteResponse.body.result}, status code ${deleteResponse.statusCode}`);
        }
        catch (e) {
            if (((_a = e.meta) === null || _a === void 0 ? void 0 : _a.statusCode) !== 404) {
                this.logger.error(`Failed to delete person information from ES for ${posturePersonId}. Response: ${JSON.stringify(e.meta)}`, e);
                throw new Error(e);
            }
            else {
                this.logger.debug(`No person information to delete in ES for ${posturePersonId}. Response: ${JSON.stringify(e.meta)}`, e);
            }
        }
    }
    async updateMergedPerson(mergedPerson, posturePersonId) {
        if (!mergedPerson) {
            return this.deletePersonInformation(posturePersonId);
        }
        const personInformation = await this.convertMergedPersonToPersonInformation(mergedPerson);
        return this.updatePerson(personInformation);
    }
    async updateMergedEndpoint(mergedEndpoint, postureEndpointId) {
        if (!mergedEndpoint) {
            return this.deleteDeviceInformation(postureEndpointId);
        }
        const deviceInformation = await this.convertMergedEndpointToDeviceInformation(mergedEndpoint);
        return this.update(deviceInformation);
    }
    async bulkUpdate(updatePayload) {
        try {
            this.logger.debug(`Bulk update for tenant: ${this.tenantUid}, device: ${JSON.stringify(updatePayload)}`);
            for (const payload of updatePayload) {
                if (!payload.uid) {
                    this.logger.error(`Bulk update validation failed, no uid in payload. For tenant: ${this.tenantUid}, payload: ${JSON.stringify(updatePayload)}`);
                    throw new Error('Payload not contains uid');
                }
            }
            return this.elasticSearchClient.helpers.bulk({
                datasource: updatePayload,
                onDocument(document) {
                    return [
                        { update: { _index: ElasticsearchServices.INDEX_NAME, _type: '_doc', _id: document.uid } },
                        { doc_as_upsert: false }
                    ];
                }
            });
        }
        catch (err) {
            this.logger.error(`Failed to bulk update merged endpoints. Tenant: ${this.tenantUid}, payload: ${updatePayload}, err: `, err);
            throw err;
        }
    }
    async addLabelsByFilter(filter, labelIds, exclusionList) {
        const searchQuery = await this.buildSearchQuery(filter);
        searchQuery.mustNot(elastic_builder_1.default.idsQuery(undefined, exclusionList));
        return this.updateByQuery(ElasticsearchServices.ADD_LABELS_SCRIPT, labelIds, searchQuery);
    }
    async removeLabelsByFilter(filter, labelIds, exclusionList) {
        const searchQuery = await this.buildSearchQuery(filter);
        searchQuery.mustNot(elastic_builder_1.default.idsQuery(undefined, exclusionList));
        return this.updateByQuery(ElasticsearchServices.REMOVE_LABELS_SCRIPT, labelIds, searchQuery);
    }
    async removeLabelsByQuery(labelIds, deviceIds) {
        const searchQuery = elastic_builder_1.default.boolQuery();
        searchQuery.must(elastic_builder_1.default.idsQuery(undefined, deviceIds)).must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        return this.updateByQuery(ElasticsearchServices.REMOVE_LABELS_SCRIPT, labelIds, searchQuery);
    }
    async cleanLabelsOnDevicesFromNoLongerExisting(existingLabels) {
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, this.getRetryConfig());
        const searchQuery = elastic_builder_1.default.boolQuery();
        searchQuery.must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid)).must(elastic_builder_1.default.existsQuery('labels.keyword'));
        return retryUtil.executeWithRetry(async () => this.updateByQuery(ElasticsearchServices.REMOVE_NOT_EXISTING_LABELS_SCRIPT, existingLabels, searchQuery));
    }
    async cleanRulesLabelsOnDevicesFromNoLongerExisting(existingLabels) {
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, this.getRetryConfig());
        const searchQuery = elastic_builder_1.default.boolQuery();
        searchQuery.must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid)).must(elastic_builder_1.default.existsQuery('rulesLabels.keyword'));
        return retryUtil.executeWithRetry(async () => this.updateByQuery(ElasticsearchServices.REMOVE_NOT_EXISTING_RULES_LABELS_SCRIPT, existingLabels, searchQuery));
    }
    getRetryConfig() {
        return {
            retries: 4,
            backoff: 'FIXED',
            delay: 300,
            retryIf: (err) => { var _a; return (_a = err.message) === null || _a === void 0 ? void 0 : _a.toLowerCase().includes('response error'); }
        };
    }
    async addLabelsToDevices(labelIds, deviceIds) {
        const searchQuery = elastic_builder_1.default.boolQuery();
        searchQuery.must(elastic_builder_1.default.idsQuery(undefined, deviceIds)).must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        return this.updateByQuery(ElasticsearchServices.ADD_LABELS_SCRIPT, labelIds, searchQuery);
    }
    async removeLabelsFromAllDevices(labelIds) {
        const searchQuery = elastic_builder_1.default.boolQuery();
        const queries = [];
        queries.push(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        queries.push(elastic_builder_1.default.boolQuery().must(_.map(labelIds, label => elastic_builder_1.default.boolQuery().should([elastic_builder_1.default.matchQuery('labels.keyword', label), elastic_builder_1.default.matchQuery('rulesLabels.keyword', label)]))));
        return this.updateByQuery(ElasticsearchServices.REMOVE_LABELS_AND_RULES_LABELS_SCRIPT, labelIds, searchQuery.must(queries));
    }
    includeLabelsSearchQuery(labelIds) {
        const searchQuery = elastic_builder_1.default.boolQuery();
        const queries = [];
        queries.push(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        queries.push(elastic_builder_1.default.termsQuery('labels.keyword', labelIds));
        return searchQuery.must(queries);
    }
    async modifyAssetValueOnDevices(assetValue, deviceIds) {
        const searchQuery = elastic_builder_1.default.boolQuery();
        searchQuery.must(elastic_builder_1.default.idsQuery(undefined, deviceIds)).must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        return this.updateByQuery(ElasticsearchServices.UPDATE_ASSET_VALUE_SCRIPT, assetValue, searchQuery);
    }
    async setDevicesAssetValueWithFilter(assetValue, filter, exclusionList) {
        const searchQuery = await this.buildSearchQuery(filter);
        searchQuery.mustNot(elastic_builder_1.default.idsQuery(undefined, exclusionList));
        return this.updateByQuery(ElasticsearchServices.UPDATE_ASSET_VALUE_SCRIPT, assetValue, searchQuery);
    }
    async buildQueryWithExcludedDeviceIds(filter, exclusionList) {
        const searchQuery = await this.buildSearchQuery(filter);
        searchQuery.mustNot(elastic_builder_1.default.idsQuery(undefined, exclusionList));
        return searchQuery;
    }
    async addIncidentToDevices(incidentId, deviceIds) {
        const searchQuery = elastic_builder_1.default.boolQuery();
        searchQuery.must(elastic_builder_1.default.idsQuery(undefined, deviceIds)).must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        return this.updateByQuery(ElasticsearchServices.ADD_INCIDENTS_SCRIPT, incidentId, searchQuery);
    }
    async updateByQuery(script, attrs, searchQuery) {
        this.logger.debug(`Update devices for tenant: ${this.tenantUid} labels: ${attrs} by query: ${JSON.stringify(searchQuery)}`);
        try {
            const response = await this.elasticSearchClient.update_by_query({
                index: ElasticsearchServices.INDEX_NAME,
                type: '_doc',
                body: {
                    query: searchQuery,
                    script: {
                        inline: script,
                        params: {
                            param: attrs
                        }
                    }
                }
            });
            await this.handleClientResponse(response);
            return response;
        }
        catch (err) {
            this.logger.error(`Failed to update merged endpoints. Tenant: ${this.tenantUid}, err: `, err);
            throw err;
        }
    }
    async countRules() {
        this.logger.debug(`Will be count rules for tenant ${this.tenantUid} in elasticsearch`);
        const req = {
            index: ElasticsearchServices.INDEX_NAME,
            size: 0,
            body: elastic_builder_1.default.requestBodySearch()
                .query(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid))
                .aggs([
                elastic_builder_1.default.termsAggregation('rules', 'modifiedByRules.keyword')
            ])
                .toJSON()
        };
        const response = await this.elasticSearchClient.search(req);
        const result = new Map();
        response.body.aggregations.rules.buckets.forEach(bucket => result.set(bucket.key, bucket.doc_count));
        return result;
    }
    async countLabelsAndRuleLabels() {
        return this.countGeneral([{ name: 'rulesLabels', field: 'rulesLabels.keyword' }, { name: 'labels', field: 'labels.keyword' }]);
    }
    async countGeneral(aggregations) {
        this.logger.debug(`Count ${JSON.stringify(aggregations)} for tenant ${this.tenantUid}`);
        const terms = aggregations.map(ag => elastic_builder_1.default.termsAggregation(ag.name, ag.field));
        const req = {
            index: ElasticsearchServices.INDEX_NAME,
            size: 0,
            body: elastic_builder_1.default.requestBodySearch()
                .query(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid))
                .aggs(terms)
                .toJSON()
        };
        const response = await this.elasticSearchClient.search(req);
        const result = new Map();
        for (const aggregated of Object.entries(response.body.aggregations)) {
            result.set(aggregated[0], aggregated[1].buckets);
        }
        return result;
    }
    static buildAssetValueFiltersAggregationQueries(assetValueObj) {
        const assetValuesArr = range(CommonTypes_1.ASSET_VALUE_LOWER_BOUND, CommonTypes_1.ASSET_VALUE_UPPER_BOUND + 1);
        let queriesTuplesArray = [];
        const origin = assetValueObj === null || assetValueObj === void 0 ? void 0 : assetValueObj.origin;
        if (origin && [CommonTypes_1.ModificationOrigin.MANUAL, CommonTypes_1.ModificationOrigin.RULES_BASED].includes(origin)) {
            queriesTuplesArray = assetValuesArr.map(val => [val, elastic_builder_1.default.termQuery({ manual: 'assetValue', rules: 'rulesAssetValue' }[origin], val)]);
        }
        else {
            if (origin !== CommonTypes_1.ModificationOrigin.DEFAULT) {
                queriesTuplesArray = assetValuesArr.map(val => [val, elastic_builder_1.default.boolQuery().should([
                        elastic_builder_1.default.boolQuery().must([elastic_builder_1.default.termQuery('assetValue', val), elastic_builder_1.default.boolQuery().should([elastic_builder_1.default.rangeQuery('rulesAssetValue').lte(val), elastic_builder_1.default.boolQuery().mustNot([elastic_builder_1.default.existsQuery('rulesAssetValue')])])]),
                        elastic_builder_1.default.boolQuery().must([elastic_builder_1.default.termQuery('rulesAssetValue', val), elastic_builder_1.default.boolQuery().should([elastic_builder_1.default.rangeQuery('assetValue').lte(val), elastic_builder_1.default.boolQuery().mustNot([elastic_builder_1.default.existsQuery('assetValue')])])])
                    ])]);
            }
            queriesTuplesArray.push(['noval', elastic_builder_1.default.boolQuery().mustNot([elastic_builder_1.default.existsQuery('assetValue'), elastic_builder_1.default.existsQuery('rulesAssetValue')])]);
        }
        return Object.fromEntries(queriesTuplesArray);
    }
    static assetValueBucketsAsCountPairs(buckets) {
        var _a, _b;
        const internalBuckets = { ...buckets };
        internalBuckets[ElasticsearchServices.DEFAULT_ASSET_VALUE] = { doc_count: (((_a = buckets[ElasticsearchServices.DEFAULT_ASSET_VALUE]) === null || _a === void 0 ? void 0 : _a.doc_count) || 0) + (((_b = buckets === null || buckets === void 0 ? void 0 : buckets.noval) === null || _b === void 0 ? void 0 : _b.doc_count) || 0) };
        delete internalBuckets.noval;
        return Object.entries(internalBuckets || {}).filter(bucket => { var _a; return (_a = bucket[1]) === null || _a === void 0 ? void 0 : _a.doc_count; }).map((bucket) => { var _a; return ({ value: bucket[0], count: (_a = bucket[1]) === null || _a === void 0 ? void 0 : _a.doc_count }); });
    }
    static mergeBuckets(agg1, agg2) {
        const agg1BucketsObj = Object.fromEntries((agg1 === null || agg1 === void 0 ? void 0 : agg1.buckets.map((bucket) => [bucket.key, bucket.doc_count])) || []);
        for (const bucket2 of (agg2 === null || agg2 === void 0 ? void 0 : agg2.buckets) || []) {
            agg1BucketsObj[bucket2.key] = (agg1BucketsObj[bucket2.key] || 0) + (bucket2.doc_count || 0);
        }
        return { buckets: Object.entries(agg1BucketsObj).filter(bucket => bucket[0] !== 'ignore').map(bucket => ({ key: bucket[0], doc_count: bucket[1] })) };
    }
    async getPropertyAggregations(index, searchQuery, properties, limit = 100) {
        const aggregations = _.map(properties, (property) => elastic_builder_1.default.termsAggregation(property, `${property}.keyword`).size(limit));
        const req = {
            index,
            size: 0,
            body: elastic_builder_1.default.requestBodySearch()
                .query(searchQuery)
                .aggs(aggregations)
                .toJSON()
        };
        const promises = [];
        promises.push(this.elasticSearchClient.search(req));
        const results = await Promise.all(promises);
        const apiResponse = results[0];
        const toCountPairs = (agg) => ((agg === null || agg === void 0 ? void 0 : agg.buckets) ? _.map(agg.buckets, bucket => ({ value: bucket.key_as_string || bucket.key, count: bucket.doc_count })) : []);
        const propertyValues = {};
        properties.forEach(property => _.set(propertyValues, property, toCountPairs(apiResponse.body.aggregations[property])));
        return propertyValues;
    }
    async getPersonPropertyAggregations(filter, properties, limit = 100) {
        return this.getPropertyAggregations(ElasticsearchServices.PERSON_INDEX_NAME, this.buildPersonSearchQuery(filter), properties, limit);
    }
    async countPosturePersons(filter) {
        this.logger.debug(`Will be counting posture persons for tenant ${this.tenantUid} by filter ${JSON.stringify(filter)} in elasticsearch`);
        const searchQuery = this.buildPersonSearchQuery(filter);
        const req = {
            index: ElasticsearchServices.PERSON_INDEX_NAME,
            size: 0,
            body: elastic_builder_1.default.requestBodySearch()
                .query(searchQuery)
                .aggs([
                elastic_builder_1.default.valueCountAggregation('countPersons', 'posturePersonId.keyword'),
                elastic_builder_1.default.termsAggregation('producerId', 'producers.producerId.keyword').size(100),
                elastic_builder_1.default.termsAggregation('personType', 'personType.keyword')
            ])
                .toJSON()
        };
        const promises = [];
        promises.push(this.elasticSearchClient.search(req));
        const results = await Promise.all(promises);
        const apiResponse = results[0];
        const personsCount = apiResponse.body.aggregations.countPersons.value;
        this.logger.debug(`The count of all posture persons for tenant ${this.tenantUid} is ${personsCount}`);
        const toCountPairs = (agg) => ((agg === null || agg === void 0 ? void 0 : agg.buckets) ? _.map(agg.buckets, bucket => ({ value: bucket.key_as_string || bucket.key, count: bucket.doc_count })) : []);
        const groupService = new GroupServices_1.GroupServices(this.tenantUid);
        const azureGroupsCount = (await groupService.countGroupsForSource(CommonTypes_1.Source.AZURE_USERS)).Count;
        const groupsTotal = azureGroupsCount;
        const filteredCounts = {
            total: personsCount,
            groupsTotal,
            producerId: toCountPairs(apiResponse.body.aggregations.producerId),
            personType: toCountPairs(apiResponse.body.aggregations.personType),
            assetValue: [{ value: '10', count: personsCount }],
            labels: [{ value: 'nolabel', count: personsCount }]
        };
        return filteredCounts;
    }
    async countPostureEndpoints(filter) {
        var _a, _b, _c, _d;
        this.logger.debug(`Will be counting posture devices for tenant ${this.tenantUid} by filter ${JSON.stringify(filter)} in elasticsearch`);
        const onlySecureClientDevices = (0, CommonTypes_1.isOnlySecureClientDevices)(filter);
        let cloudMgmtVersionOutOfDateFilter;
        if (onlySecureClientDevices || filter.cloudMgmtVersionOutOfDate === true) {
            cloudMgmtVersionOutOfDateFilter = filter.cloudMgmtVersionOutOfDate || true;
            delete filter.cloudMgmtVersionOutOfDate;
        }
        const searchQuery = await this.buildSearchQuery(filter);
        const req = {
            index: ElasticsearchServices.INDEX_NAME,
            size: 0,
            body: elastic_builder_1.default.requestBodySearch()
                .query(searchQuery)
                .aggs([
                elastic_builder_1.default.valueCountAggregation('countEndpoints', 'postureEndpointId.keyword'),
                elastic_builder_1.default.termsAggregation('producerId', 'producers.producerId.keyword').size(100),
                elastic_builder_1.default.termsAggregation('policyId', 'policies.uid.keyword').size(1000),
                elastic_builder_1.default.termsAggregation('groupId', 'groups.uid.keyword').size(1000),
                elastic_builder_1.default.termsAggregation('tagName', 'tagNames.name.keyword').size(1000),
                elastic_builder_1.default.termsAggregation('osType', 'osType.keyword').size(Object.values(CommonTypes_1.OS).length),
                elastic_builder_1.default.termsAggregation('endpointType', 'endpointType.keyword'),
                elastic_builder_1.default.termsAggregation('hasFaults', 'hasFaults'),
                elastic_builder_1.default.termsAggregation('avDefinitionsOutOfDate', 'avDefinitionsOutOfDate'),
                elastic_builder_1.default.termsAggregation('isManaged', 'isManaged'),
                elastic_builder_1.default.termsAggregation('deploymentId', 'deploymentId.keyword'),
                elastic_builder_1.default.filtersAggregation('assetValue').filters(ElasticsearchServices.buildAssetValueFiltersAggregationQueries(filter.assetValue)),
                elastic_builder_1.default.termsAggregation('labels', 'labels.keyword').script(elastic_builder_1.default.script('inline', "doc['rulesLabels.keyword'].contains(_value) ? 'ignore' : _value").lang('painless')),
                elastic_builder_1.default.termsAggregation('rulesLabels', 'rulesLabels.keyword'),
                elastic_builder_1.default.filterAggregation('windowsType', elastic_builder_1.default.termQuery('osType', 'windows')).agg(elastic_builder_1.default.termsAggregation('osVersion', 'osVersion.keyword')),
                elastic_builder_1.default.filterAggregation('inactive', elastic_builder_1.default.rangeQuery('providersLastUpdated').lt(Date.now().valueOf() - DateUtils_1.DAY_MILLIS * 7))
            ])
                .toJSON()
        };
        const promises = [];
        promises.push(this.elasticSearchClient.search(req));
        if (cloudMgmtVersionOutOfDateFilter !== undefined) {
            filter.cloudMgmtVersionOutOfDate = cloudMgmtVersionOutOfDateFilter;
            const searchQueryCloudMgmtVersionOutOfDate = await this.buildSearchQuery(filter);
            const reqCloudMgmtVersionOutOfDate = {
                index: ElasticsearchServices.INDEX_NAME,
                size: 0,
                body: elastic_builder_1.default.requestBodySearch().query(searchQueryCloudMgmtVersionOutOfDate).toJSON()
            };
            promises.push(this.elasticSearchClient.search(reqCloudMgmtVersionOutOfDate));
        }
        const results = await Promise.all(promises);
        const apiResponse = results[0];
        if (cloudMgmtVersionOutOfDateFilter !== undefined) {
            const cloudMgmtVersionOutOfDateCount = results[1].body.hits.total.value;
            apiResponse.body.aggregations.cloudMgmtVersionOutOfDate = cloudMgmtVersionOutOfDateCount;
            this.logger.debug(`The count of cloudMgmtVersionOutOfDate for tenant ${this.tenantUid} is ${cloudMgmtVersionOutOfDateCount}`);
        }
        const endpointsCount = apiResponse.body.aggregations.countEndpoints.value;
        this.logger.debug(`The count of all posture devices for tenant ${this.tenantUid} is ${endpointsCount}`);
        const toCountPairs = (agg) => ((agg === null || agg === void 0 ? void 0 : agg.buckets) ? _.map(agg.buckets, bucket => ({ value: bucket.key_as_string || bucket.key, count: bucket.doc_count })) : []);
        function aggregateByMajorWindowsVersion(countedPairs) {
            const server = 'server';
            let w10Count = 0;
            let w11Count = 0;
            countedPairs.forEach(pair => {
                const tempValue = pair.value.toLowerCase().split(/[\s]/);
                if (!tempValue.includes(server)) {
                    if (tempValue.some(x => x === '10')) {
                        w10Count += pair.count;
                    }
                    else if (tempValue.some(x => x === '11')) {
                        w11Count += pair.count;
                    }
                    else if (tempValue.map(x => x.startsWith('10')).includes(true)) {
                        w10Count += pair.count;
                    }
                    else if (tempValue.map(x => x.startsWith('11')).includes(true)) {
                        w11Count += pair.count;
                    }
                }
            });
            return [{ value: '10', count: w10Count }, { value: '11', count: w11Count }];
        }
        const filteredCounts = {
            total: endpointsCount,
            producerId: toCountPairs(apiResponse.body.aggregations.producerId),
            policyId: toCountPairs(apiResponse.body.aggregations.policyId),
            groupId: toCountPairs(apiResponse.body.aggregations.groupId),
            tagName: toCountPairs(apiResponse.body.aggregations.tagName),
            osType: toCountPairs(apiResponse.body.aggregations.osType),
            endpointType: toCountPairs(apiResponse.body.aggregations.endpointType),
            hasFaults: toCountPairs(apiResponse.body.aggregations.hasFaults),
            avDefinitionsOutOfDate: toCountPairs(apiResponse.body.aggregations.avDefinitionsOutOfDate),
            isManaged: toCountPairs(apiResponse.body.aggregations.isManaged),
            deploymentId: toCountPairs(apiResponse.body.aggregations.deploymentId),
            financialRiskFactor: ElasticsearchServices.assetValueBucketsAsCountPairs((_b = (_a = apiResponse.body.aggregations) === null || _a === void 0 ? void 0 : _a.assetValue) === null || _b === void 0 ? void 0 : _b.buckets),
            assetValue: ElasticsearchServices.assetValueBucketsAsCountPairs((_d = (_c = apiResponse.body.aggregations) === null || _c === void 0 ? void 0 : _c.assetValue) === null || _d === void 0 ? void 0 : _d.buckets),
            labels: toCountPairs(ElasticsearchServices.mergeBuckets(apiResponse.body.aggregations.labels, apiResponse.body.aggregations.rulesLabels)),
            windowsType: aggregateByMajorWindowsVersion(toCountPairs(apiResponse.body.aggregations.windowsType.osVersion)),
            inactive: apiResponse.body.aggregations.inactive.doc_count
        };
        if (apiResponse.body.aggregations.cloudMgmtVersionOutOfDate !== undefined) {
            filteredCounts.cloudMgmtVersionOutOfDate = apiResponse.body.aggregations.cloudMgmtVersionOutOfDate;
        }
        return filteredCounts;
    }
    async countDevicePropertyValues(field, filter) {
        var _a, _b;
        const queries = await this.buildSearchQuery(filter);
        const valueCounts = new Map();
        let afterKey;
        do {
            const req = {
                index: ElasticsearchServices.INDEX_NAME,
                body: elastic_builder_1.default.requestBodySearch()
                    .query(queries)
                    .aggs([
                    elastic_builder_1.default.compositeAggregation('aggField')
                        .sources(elastic_builder_1.default.CompositeAggregation.termsValuesSource('aggField', `${field}.keyword`))
                        .size(1000)
                        .after(afterKey)
                ])
                    .toJSON()
            };
            const apiResponse = await this.elasticSearchClient.search(req);
            const aggFieldData = apiResponse.body.aggregations.aggField;
            afterKey = aggFieldData === null || aggFieldData === void 0 ? void 0 : aggFieldData.after_key;
            (_a = aggFieldData === null || aggFieldData === void 0 ? void 0 : aggFieldData.buckets) === null || _a === void 0 ? void 0 : _a.forEach((bucket) => {
                const k = bucket.key.aggField;
                valueCounts.set(k, (valueCounts.get(k) || 0) + bucket.doc_count);
            });
            this.logger.debug(`fetched ${(_b = aggFieldData === null || aggFieldData === void 0 ? void 0 : aggFieldData.buckets) === null || _b === void 0 ? void 0 : _b.length} buckets for ${field}`);
        } while (afterKey);
        return Array.from(valueCounts, ([key, value]) => ({ value: key, count: value }));
    }
    async personPagedSearchScroll(filter, labelMap, scrollId, scrollTimeout) {
        let apiResponse;
        if (!scrollId) {
            const rbs = elastic_builder_1.default.requestBodySearch().query(this.buildPersonSearchQuery(filter));
            if (filter.orderBy) {
                rbs.sorts(this.buildPersonSorts(filter.orderBy));
            }
            else {
                rbs.sorts(this.buildPersonSorts([{ name: 'displayName' }, { name: 'posturePersonId' }]));
            }
            const searchParams = this.preparePersonSearchQueryParams(filter, rbs);
            searchParams.scroll = scrollTimeout || ElasticsearchServices.SCROLL;
            apiResponse = await this.elasticSearchClient.search(searchParams);
        }
        else {
            apiResponse = await this.elasticSearchClient.scroll({
                scroll_id: scrollId,
                scroll: scrollTimeout || ElasticsearchServices.SCROLL
            });
        }
        const mergedPersons = this.parsePersonApiSearchResponse(apiResponse, labelMap);
        const nextScrollId = apiResponse.body._scroll_id;
        const total = apiResponse.body.hits.total.value;
        this.logger.debug(`fetched ${mergedPersons.length} of ${total} posture persons from elasticsearch with scroll_id ${nextScrollId}`);
        return { mergedPersons, scrollId: nextScrollId };
    }
    async pagedSearchScroll(filter, scrollId, scrollTimeout, includeFields) {
        let apiResponse;
        if (!scrollId) {
            this.logger.debug(`Will be enumerating posture devices from elasticsearch using scroll with scrollTimeout ${scrollTimeout || ElasticsearchServices.SCROLL}`);
            const rbs = elastic_builder_1.default.requestBodySearch().query(await this.buildSearchQuery(filter));
            if (filter.orderBy) {
                _.forEach(filter.orderBy, orderByName => { if (orderByName.name === 'financialRiskFactor')
                    orderByName.name = 'assetValue'; });
                rbs.sorts(this.buildSorts(filter.orderBy));
            }
            else {
                rbs.sorts(this.buildSorts([{ name: 'hostname' }, { name: 'postureEndpointId' }]));
            }
            const searchParams = this.prepareSearchQueryParams(filter, rbs, undefined, includeFields);
            searchParams.scroll = scrollTimeout || ElasticsearchServices.SCROLL;
            apiResponse = await this.elasticSearchClient.search(searchParams);
        }
        else {
            this.logger.debug(`Will be enumerating posture devices from elasticsearch using scrollTimeout ${scrollTimeout || ElasticsearchServices.SCROLL} and scrollId ${scrollId}`);
            apiResponse = await this.elasticSearchClient.scroll({
                scroll_id: scrollId,
                scroll: scrollTimeout || ElasticsearchServices.SCROLL
            });
        }
        const mergedEndpoints = await this.parseApiSearchResponse(apiResponse);
        const nextScrollId = apiResponse.body._scroll_id;
        const total = apiResponse.body.hits.total.value;
        this.logger.debug(`fetched ${mergedEndpoints.length} of ${total} posture devices from elasticsearch with scroll_id ${nextScrollId}`);
        return { mergedEndpoints, scrollId: nextScrollId };
    }
    async clearSearchScroll(scrollId) {
        let apiResponse;
        try {
            apiResponse = await this.elasticSearchClient.clearScroll({
                scroll_id: scrollId
            });
            this.logger.debug(`Cleared scroll ${scrollId}`, apiResponse);
        }
        catch (err) {
            this.logger.error(`Error occurred while clearing scroll ${scrollId}`, err);
        }
        return Promise.resolve(apiResponse);
    }
    async listPosturePersons(filter, labelMap) {
        this.logger.debug('Will be listing posture persons from elasticsearch');
        const rbs = elastic_builder_1.default.requestBodySearch().query(this.buildPersonSearchQuery(filter));
        if (filter.orderBy) {
            rbs.sorts(this.buildPersonSorts(filter.orderBy));
        }
        else {
            rbs.sorts(this.buildPersonSorts([{ name: 'displayName' }, { name: 'posturePersonId' }]));
        }
        const searchParams = this.preparePersonSearchQueryParams(filter, rbs);
        this.logger.debug('Fetching searchParams', JSON.stringify(searchParams));
        const apiResponse = await this.elasticSearchClient.search(searchParams);
        const mergedPersons = this.parsePersonApiSearchResponse(apiResponse, labelMap);
        for (let i = 0; i < mergedPersons.length; i += 1) {
            mergedPersons[i].producers = _.sortBy(mergedPersons[i].producers, producer => producer.uid);
        }
        this.logger.debug(`fetched ${mergedPersons.length} posture persons from elasticsearch`);
        return mergedPersons;
    }
    async listPostureEndpoints(filter, excludeFields) {
        this.logger.debug('Will be listing posture devices from elasticsearch');
        const rbs = elastic_builder_1.default.requestBodySearch().query(await this.buildSearchQuery(filter));
        if (filter.orderBy) {
            _.forEach(filter.orderBy, orderByName => {
                if (orderByName.name === 'financialRiskFactor')
                    orderByName.name = 'assetValue';
            });
            rbs.sorts(this.buildSorts(filter.orderBy));
        }
        else {
            rbs.sorts(this.buildSorts([{ name: 'hostname' }, { name: 'postureEndpointId' }]));
        }
        const searchParams = this.prepareSearchQueryParams(filter, rbs, excludeFields);
        this.logger.debug('Fetching searchParams', JSON.stringify(searchParams));
        const apiResponse = await this.elasticSearchClient.search(searchParams);
        const mergedEndpoints = await this.parseApiSearchResponse(apiResponse);
        for (let i = 0; i < mergedEndpoints.length; i += 1) {
            mergedEndpoints[i].producers = _.sortBy(mergedEndpoints[i].producers, producer => producer.uid);
        }
        this.logger.debug(`fetched ${mergedEndpoints.length} posture devices from elasticsearch`);
        return mergedEndpoints;
    }
    async dashboardCounts() {
        this.logger.debug(`Will be aggregating dashboard counts for tenant ${this.tenantUid} in elasticsearch`);
        const osTypesAggregation = elastic_builder_1.default.termsAggregation('osTypes', 'osType.keyword').size(DEFAULT_AGG_NUMBER_HITS);
        const isManagedAggregation = elastic_builder_1.default.termsAggregation('isManaged', 'isManaged');
        const isCompliantAggregation = elastic_builder_1.default.termsAggregation('isCompliant', 'isCompliant.keyword');
        const endpointTypesAggregation = elastic_builder_1.default.termsAggregation('endpointTypes', 'endpointType.keyword');
        const aggQuery = elastic_builder_1.default.filterAggregation('tenant', elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid)).aggs([osTypesAggregation, isManagedAggregation, isCompliantAggregation, endpointTypesAggregation]);
        const req = {
            index: ElasticsearchServices.INDEX_NAME,
            size: 0,
            body: elastic_builder_1.default.requestBodySearch().agg(aggQuery).toJSON()
        };
        const apiResponse = await this.elasticSearchClient.search(req);
        this.logger.debug(`Parsing dashboardCounts response for ${this.tenantUid} of elasticsearch`);
        return this.parseDashboardsCountsResponse(apiResponse);
    }
    async getUidsIfExist(uids) {
        this.logger.debug(`Will be getting ${uids.length} UIDs from elasticsearch`);
        const req = {
            index: ElasticsearchServices.INDEX_NAME,
            size: uids.length,
            body: elastic_builder_1.default.requestBodySearch().query(elastic_builder_1.default.idsQuery(undefined, uids)).toJSON()
        };
        const apiResponse = await this.elasticSearchClient.search(req);
        return _.map(apiResponse.body.hits.hits, '_id');
    }
    async getSpecificFields(uids, fields) {
        this.logger.debug(`Will be getting ${uids.length} endpoint UIDs from elasticsearch with fields: ${fields}`);
        const boolQuery = elastic_builder_1.default.boolQuery();
        boolQuery.must(elastic_builder_1.default.idsQuery(undefined, uids)).must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        const req = {
            index: ElasticsearchServices.INDEX_NAME,
            size: uids.length,
            body: elastic_builder_1.default.requestBodySearch().query(boolQuery).toJSON(),
            _source_includes: fields
        };
        const apiResponse = await this.elasticSearchClient.search(req);
        return this.changeNullsToUndefined(apiResponse.body.hits.hits);
    }
    async getPersonSpecificFields(uids, fields) {
        this.logger.debug(`Will be getting ${uids.length} person UIDs from elasticsearch with fields: ${fields}`);
        const boolQuery = elastic_builder_1.default.boolQuery();
        boolQuery.must(elastic_builder_1.default.idsQuery(undefined, uids)).must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        const req = {
            index: ElasticsearchServices.PERSON_INDEX_NAME,
            size: uids.length,
            body: elastic_builder_1.default.requestBodySearch().query(boolQuery).toJSON(),
            _source_includes: fields
        };
        const apiResponse = await this.elasticSearchClient.search(req);
        return this.changeNullsToUndefined(apiResponse.body.hits.hits);
    }
    async getPostureEndpointIdsWithTimeControl(query, timeBasedAsyncLambdaInvoker, scrollId) {
        let shouldStop = false;
        let stoppedByTime = false;
        const deviceIds = [];
        do {
            const result = await this.getSpecificFieldsWithScroll(query, ['postureEndpointId'], scrollId);
            scrollId = result.scrollId;
            stoppedByTime = timeBasedAsyncLambdaInvoker.isItTimeToStop();
            shouldStop = _.isEmpty(result.hits) || stoppedByTime;
            if (!_.isEmpty(result.hits)) {
                deviceIds.push(...result.hits.map((hit) => hit._id));
            }
        } while (!shouldStop);
        return {
            scrollId: stoppedByTime ? scrollId : undefined,
            deviceIds
        };
    }
    async getSpecificFieldsWithScroll(query, fields, scrollId) {
        return this.getSpecificFieldsWithScrollWithBody(elastic_builder_1.default.requestBodySearch().query(query).toJSON(), fields, scrollId);
    }
    async getSpecificFieldsWithScrollWithBody(body, fields, scrollId, maxScrollSize = ElasticsearchServices.MAX_SCROLL_SIZE) {
        const scrollTimeout = '3m';
        this.logger.debug(`For tenant ${this.tenantUid} will fetch fields: ${fields} with scroll size: ${maxScrollSize} and with scroll by: ${JSON.stringify(body)}`);
        let apiResponse;
        if (!scrollId) {
            const req = {
                index: ElasticsearchServices.INDEX_NAME,
                body,
                _source_includes: fields,
                size: maxScrollSize,
                scroll: scrollTimeout
            };
            apiResponse = await this.elasticSearchClient.search(req);
        }
        else {
            apiResponse = await this.elasticSearchClient.scroll({
                scroll_id: scrollId,
                scroll: scrollTimeout
            });
        }
        const nextScrollId = apiResponse.body._scroll_id;
        return { hits: apiResponse.body.hits.hits, scrollId: nextScrollId };
    }
    async getPostureEndpointsByUids(uids, includeFields) {
        this.logger.debug(`Getting for tenant ${this.tenantUid} devices by ids ${JSON.stringify(uids)} from elasticsearch`);
        const boolQuery = elastic_builder_1.default.boolQuery();
        boolQuery.must(elastic_builder_1.default.idsQuery(undefined, uids)).must(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        const req = {
            index: ElasticsearchServices.INDEX_NAME,
            size: uids.length,
            body: elastic_builder_1.default.requestBodySearch()
                .query(boolQuery).toJSON(),
            _source_includes: includeFields
        };
        const apiResponse = await this.elasticSearchClient.search(req);
        return this.parseApiSearchResponse(apiResponse);
    }
    parseDashboardsCountsResponse(apiResponse) {
        const osTypesAggregationRes = apiResponse.body.aggregations.tenant.osTypes.buckets;
        const isManagedAggregationRes = apiResponse.body.aggregations.tenant.isManaged.buckets;
        const isCompliantAggregationRes = apiResponse.body.aggregations.tenant.isCompliant.buckets;
        const endpointTypesAggregationRes = apiResponse.body.aggregations.tenant.endpointTypes.buckets;
        const dropNumOsTypes = apiResponse.body.aggregations.tenant.osTypes.sum_other_doc_count;
        if (dropNumOsTypes) {
            this.logger.info(`The number of possible osTypes on aggregation call is more than the imposed limit as ${DEFAULT_AGG_NUMBER_HITS}. `
                + `${dropNumOsTypes} of bottom osTypes has not been included in aggregation. Consider increasing the limit`);
        }
        const osTypes = Object.values(CommonTypes_1.OS);
        return {
            isManaged: [
                this.safelyGetCountFromAgg(isManagedAggregationRes, 'key_as_string', 'true', true),
                this.safelyGetCountFromAgg(isManagedAggregationRes, 'key_as_string', 'false', false)
            ],
            compliant: [
                this.safelyGetCountFromAgg(isCompliantAggregationRes, 'key', 'true', 'true'),
                this.safelyGetCountFromAgg(isCompliantAggregationRes, 'key', 'false', 'false'),
                this.safelyGetCountFromAgg(isCompliantAggregationRes, 'key', ElasticsearchServices.UNKNOWN, ElasticsearchServices.UNKNOWN)
            ],
            osTypes: _.map(osTypes, os => this.safelyGetCountFromAgg(osTypesAggregationRes, 'key', os.toString(), os)),
            endpointTypes: _.map(Object.values(CommonTypes_1.EndpointType), endpointType => this.safelyGetCountFromAgg(endpointTypesAggregationRes, 'key', endpointType.toString(), endpointType))
        };
    }
    safelyGetCountFromAgg(arr, keyName, valToFind, valToReturn) {
        const foundRes = _.find(arr, agg => _.get(agg, keyName) === valToFind);
        return { value: valToReturn, count: (foundRes === null || foundRes === void 0 ? void 0 : foundRes.doc_count) || 0 };
    }
    async convertMergedEndpointToDeviceInformation(mergedEndpoint) {
        var _a, _b;
        let versionForOsSupport;
        if (!((_b = (_a = mergedEndpoint.osExtractedNumericVersion) === null || _a === void 0 ? void 0 : _a.match) === null || _b === void 0 ? void 0 : _b.call(_a, CommonTypes_1.NUMERIC_DOTTED_PATTERN))) {
            versionForOsSupport = (0, CommonTypes_1.parseVersionForOsSupport)(await this.osVersions(), mergedEndpoint.osType, mergedEndpoint.osVersion, mergedEndpoint.endpointType);
        }
        const di = {
            tenantUid: this.tenantUid,
            postureEndpointId: mergedEndpoint.uid,
            hostname: mergedEndpoint.hostname,
            osType: mergedEndpoint.osType,
            osVersion: mergedEndpoint.osVersion,
            osExtractedNumericVersion: mergedEndpoint.osExtractedNumericVersion,
            osHumanReadableVersion: mergedEndpoint.osHumanReadableVersion,
            isManaged: mergedEndpoint.isManaged || false,
            isCompliant: _.isNil(mergedEndpoint.isCompliant) ? ElasticsearchServices.UNKNOWN : mergedEndpoint.isCompliant.toString(),
            isCompromised: _.isNil(mergedEndpoint.isCompromised) ? ElasticsearchServices.UNKNOWN : mergedEndpoint.isCompromised.toString(),
            emails: (mergedEndpoint.emails || []),
            appUsers: (mergedEndpoint.appUsers || []),
            users: (mergedEndpoint.users || []),
            owners: (mergedEndpoint.owners || []),
            internalIpAddresses: ((mergedEndpoint.internalIpAddresses || [])),
            externalIpAddresses: (mergedEndpoint.externalIpAddresses || []),
            producers: _.map(mergedEndpoint.producers, this.producerToSlimProducer),
            providersLastUpdated: mergedEndpoint.lastUpdated || '',
            osStatusBase: mergedEndpoint.osStatusBase || (versionForOsSupport === null || versionForOsSupport === void 0 ? void 0 : versionForOsSupport.baseVersion),
            osStatusVersion: (mergedEndpoint.osStatusVersion || (versionForOsSupport === null || versionForOsSupport === void 0 ? void 0 : versionForOsSupport.version) || 0) * ElasticsearchServices.SCALE_FACTOR || undefined,
            hasFaults: this.hasAmpFaults(mergedEndpoint),
            avDefinitionsOutOfDate: mergedEndpoint.avDefinitionsOutOfDate || false,
            policies: await this.extractPolicies(mergedEndpoint),
            groups: await this.extractGroups(mergedEndpoint),
            tagNames: mergedEndpoint.tags || [],
            endpointType: mergedEndpoint.endpointType,
            macAddresses: mergedEndpoint.macAddresses,
            serialNumber: mergedEndpoint.serialNumber,
            hardwareId: mergedEndpoint.hardwareId,
            systemModel: mergedEndpoint.systemModel,
            isEncrypted: mergedEndpoint.isEncrypted,
            jailBroken: mergedEndpoint.jailBroken,
            imei: mergedEndpoint.imei,
            orbitalNodeId: mergedEndpoint.orbitalNodeId,
            ampConnectorGUID: mergedEndpoint.ampConnectorGUID,
            computerSID: mergedEndpoint.computerSID,
            isSupervised: mergedEndpoint.isSupervised,
            tampered: mergedEndpoint.tampered,
            ucId: mergedEndpoint.ucId,
            acUdId: mergedEndpoint.acUdId,
            cscVersion: mergedEndpoint.cscVersion,
            secureEndpointVersion: mergedEndpoint.secureEndpointVersion,
            cloudMgmtVersion: mergedEndpoint.cloudMgmtVersion,
            modules: mergedEndpoint.modules,
            deploymentId: mergedEndpoint.deploymentId,
            wantedDeploymentId: mergedEndpoint.wantedDeploymentId
        };
        if (mergedEndpoint.cloudMgmtVersion) {
            const { major, minor, patch, revision } = (0, CommonTypes_1.getCloudMgmtVersionNumbers)(mergedEndpoint.cloudMgmtVersion);
            di.cloudMgmtVersionMajor = major;
            di.cloudMgmtVersionMinor = minor;
            di.cloudMgmtVersionPatch = patch;
            di.cloudMgmtVersionRevision = revision;
        }
        return this.changeUndefinedToNulls(di);
    }
    async convertMergedPersonToPersonInformation(mergedPerson) {
        const pi = {
            tenantUid: this.tenantUid,
            posturePersonId: mergedPerson.uid,
            producers: _.map(mergedPerson.producers, this.producerToSlimProducer),
            providersLastUpdated: mergedPerson.lastUpdated || '',
            accountEnabled: mergedPerson.accountEnabled,
            blockSignin: mergedPerson.blockSignin,
            businessPhones: mergedPerson.businessPhones || [],
            companyName: mergedPerson.companyName,
            createdDateTime: mergedPerson.createdDateTime,
            deletedDateTime: mergedPerson.deletedDateTime,
            department: mergedPerson.department,
            displayName: mergedPerson.displayName,
            emails: mergedPerson.emails || [],
            employeeId: mergedPerson.employeeId,
            employeeHireDateTime: mergedPerson.employeeHireDateTime,
            employeeLeaveDateTime: mergedPerson.employeeLeaveDateTime,
            givenName: mergedPerson.givenName,
            groupNames: mergedPerson.groupNames || [],
            groupDescriptions: mergedPerson.groupDescriptions || [],
            jobTitle: mergedPerson.jobTitle,
            lastSignInDateTime: mergedPerson.lastSignInDateTime,
            mailNickname: mergedPerson.mailNickname,
            manager: mergedPerson.manager,
            mobilePhones: mergedPerson.mobilePhones,
            officeLocation: mergedPerson.officeLocation,
            ownedDevices: mergedPerson.ownedDevices,
            usedDevices: mergedPerson.usedDevices,
            passwordPolicies: mergedPerson.passwordPolicies,
            personType: mergedPerson.personType,
            surname: mergedPerson.surname,
            usageLocation: mergedPerson.usageLocation,
            users: mergedPerson.users || [],
            windowsSID: mergedPerson.windowsSID || [],
            assetValue: mergedPerson.assetValue
        };
        return this.changeUndefinedToNulls(pi);
    }
    changeNullsToUndefined(obj, iterationCount = 0) {
        if (_.isNull(obj)) {
            return undefined;
        }
        if (typeof obj === 'object' && iterationCount < 10) {
            for (const key in obj) {
                obj[key] = this.changeNullsToUndefined(obj[key], iterationCount + 1);
            }
        }
        return obj;
    }
    changeUndefinedToNulls(obj, iterationCount = 0) {
        if (_.isUndefined(obj)) {
            return null;
        }
        if (typeof obj === 'object' && iterationCount < 10) {
            for (const key in obj) {
                obj[key] = this.changeUndefinedToNulls(obj[key], iterationCount + 1);
            }
        }
        return obj;
    }
    async extractGroups(mergedEndpoint) {
        const out = [];
        const groupService = new GroupServices_1.GroupServices(this.tenantUid);
        const extractGroup = async (src, groupValueFn) => {
            const producers = _.filter(mergedEndpoint.producers, { type: src });
            for (const producer of producers) {
                const groupValue = groupValueFn(producer);
                if (groupValue) {
                    const groupArray = Array.isArray(groupValue) ? groupValue : [groupValue];
                    for (const groupId of groupArray) {
                        const group = await groupService.getGroup({
                            id: groupId,
                            source: src,
                            sourceId: producer.producerId
                        });
                        if (group) {
                            out.push({
                                uid: group.id,
                                producerId: group.sourceId,
                                type: group.source
                            });
                        }
                    }
                }
            }
        };
        await extractGroup(CommonTypes_1.Source.AMP, (producer) => _.get(_.find(producer.properties, { key: 'groupGuid' }), 'value'));
        await extractGroup(CommonTypes_1.Source.CROWDSTRIKE, (producer) => {
            const groupsString = _.get(_.find(producer.properties, { key: 'groups' }), 'value');
            return (groupsString) ? JSON.parse(groupsString) : undefined;
        });
        return out;
    }
    async extractPolicies(mergedEndpoint) {
        const out = [];
        const policyService = new PolicyServices_1.PolicyServices(this.tenantUid);
        const extractPolicy = async (src, policyIdFn) => {
            const producers = _.filter(mergedEndpoint.producers, { type: src });
            for (const producer of producers) {
                const policyId = policyIdFn(producer);
                if (policyId) {
                    const policy = await policyService.getPolicy({
                        id: policyId,
                        source: src,
                        sourceId: producer.producerId
                    });
                    if (policy) {
                        out.push({
                            uid: policy.id,
                            producerId: policy.sourceId,
                            type: policy.source
                        });
                    }
                }
            }
        };
        await extractPolicy(CommonTypes_1.Source.AMP, (producer) => {
            const policy = _.find(producer.properties, { key: 'policy' });
            if (policy) {
                const parsed = JSON.parse(policy.value);
                return parsed.guid;
            }
            return undefined;
        });
        await extractPolicy(CommonTypes_1.Source.UMBRELLA, (producer) => _.get(_.find(producer.properties, { key: 'appliedBundle' }), 'value'));
        return out;
    }
    hasAmpFaults(mergedEndpoint) {
        return _
            .chain(mergedEndpoint.producers)
            .filter({ type: CommonTypes_1.Source.AMP })
            .map('properties')
            .map(props => _.find(props, { key: AmpComputerModel_1.AmpComputerStateModel.FAULTS_KEY }))
            .filter(prop => !_.isNil(prop))
            .map('value')
            .map(JSON.parse)
            .map(faults => faults.length)
            .sum()
            .value() > 0;
    }
    producerToSlimProducer(producer) {
        const extId = (0, Util_1.getProducerExtId)(producer.uid);
        const slimProducer = {
            producerId: producer.producerId,
            type: producer.type,
            uid: producer.uid,
            extId,
            lastUpdated: producer.lastUpdated
        };
        const labelsPair = _.find(producer.properties, { key: 'labelIds' });
        if (labelsPair === null || labelsPair === void 0 ? void 0 : labelsPair.value) {
            try {
                const parsedLabelIds = JSON.parse(labelsPair.value);
                slimProducer.labelIds = Array.isArray(parsedLabelIds) ? parsedLabelIds : [parsedLabelIds];
            }
            catch (error) {
                this.logger.error(`Unable to parse labels where uid=${producer.uid} and labelIds=${labelsPair.value}`);
            }
        }
        const valuePair = _.find(producer.properties, { key: 'assetValue' });
        if (valuePair === null || valuePair === void 0 ? void 0 : valuePair.value) {
            slimProducer.assetValue = valuePair.value;
        }
        return slimProducer;
    }
    prepareSearchQueryParams(filter, requestBody, excludeFields, includeFields) {
        const processedFilterPagination = this.validateFilterAndGetOffset(filter);
        return {
            index: ElasticsearchServices.INDEX_NAME,
            from: processedFilterPagination.offset,
            size: processedFilterPagination.pageSize,
            _source_excludes: excludeFields,
            _source_includes: includeFields,
            body: requestBody.toJSON()
        };
    }
    preparePersonSearchQueryParams(filter, requestBody) {
        const processedFilterPagination = this.validateFilterAndGetOffset(filter);
        return {
            index: ElasticsearchServices.PERSON_INDEX_NAME,
            from: processedFilterPagination.offset,
            size: processedFilterPagination.pageSize,
            body: requestBody.toJSON()
        };
    }
    validateFilterAndGetOffset(filter) {
        const pageNumber = filter.pageNumber || 0;
        const pageSize = filter.pageSize || ElasticsearchServices.PAGE_SIZE;
        if (pageNumber < 0) {
            throw new Error(`pageNumber must not be negative: ${pageNumber}`);
        }
        if (pageSize <= 0) {
            throw new Error(`pageSize must be positive: ${pageSize}`);
        }
        if (pageSize > ElasticsearchServices.MAX_PAGE_SIZE) {
            throw new Error(`pageSize ${pageSize} must not exceed ${ElasticsearchServices.MAX_PAGE_SIZE}`);
        }
        return { offset: pageNumber * pageSize, pageSize, pageNumber };
    }
    buildSorts(sorts) {
        return _.map(sorts, esSortField => {
            const ret = (esSortField.name !== 'assetValue')
                ? elastic_builder_1.default.sort(`${esSortField.name}.keyword`, esSortField.order)
                : elastic_builder_1.default.sort(undefined, esSortField.order).script(elastic_builder_1.default.script('inline', `doc['assetValue'].size() == 0 ? doc['rulesAssetValue'].size() == 0 ? ${ElasticsearchServices.DEFAULT_ASSET_VALUE} : doc['rulesAssetValue'].value : doc['rulesAssetValue'].size() == 0 ? doc['assetValue'].value : doc['assetValue'].value > doc['rulesAssetValue'].value ? doc['assetValue'].value : doc['rulesAssetValue'].value`).lang('painless')).type('number');
            return ret;
        });
    }
    buildPersonSorts(sorts) {
        return _.map(sorts, esSortField => {
            let sortingOp = elastic_builder_1.default.sort(ElasticsearchServices.FIELDS_WITHOUT_KEYWORD.includes(esSortField.name) ? esSortField.name : `${esSortField.name}.keyword`, esSortField.order);
            sortingOp = sortingOp.missing('_first');
            return sortingOp;
        });
    }
    buildRulesContainsQuery(ruleId) {
        const boolQuery = elastic_builder_1.default.boolQuery();
        const queries = [];
        queries.push(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        queries.push(elastic_builder_1.default.matchQuery('modifiedByRules.keyword', ruleId));
        boolQuery.must(queries);
        return boolQuery;
    }
    async buildSearchQuery(filter) {
        const queries = [];
        queries.push(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        return ElasticsearchGlobalServices.buildSearchQuery(filter, this.osVersions, this.deploymentsMap, queries);
    }
    buildPersonSearchQuery(filter) {
        const boolQuery = elastic_builder_1.default.boolQuery();
        const queries = [];
        queries.push(elastic_builder_1.default.matchQuery('tenantUid.keyword', this.tenantUid));
        if (filter.freeText) {
            queries.push(elastic_builder_1.default.queryStringQuery(ElasticsearchGlobalServices.buildQueryTerms(filter.freeText)).fields(ElasticsearchServices.FIELDS_FOR_USERS_TEXT_SEARCH).allowLeadingWildcard(true));
        }
        if (filter.luceneQuery) {
            queries.push(elastic_builder_1.default.queryStringQuery(filter.luceneQuery).analyzeWildcard(true));
        }
        if (filter.personType) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.personType, personType => elastic_builder_1.default.matchQuery('personType.keyword', personType))));
        }
        if (filter.producers) {
            queries.push(elastic_builder_1.default.boolQuery().must(_.map(filter.producers, producer => {
                const producerQuery = [];
                producerQuery.push(elastic_builder_1.default.matchQuery('producers.type.keyword', producer.type));
                producerQuery.push(elastic_builder_1.default.matchQuery('producers.producerId.keyword', producer.producerId));
                return (!producer.exclude) ? elastic_builder_1.default.boolQuery().must(producerQuery) : elastic_builder_1.default.boolQuery().mustNot(producerQuery);
            })));
        }
        if (filter.company) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.company, company => elastic_builder_1.default.matchQuery('companyName.keyword', company))));
        }
        if (filter.department) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.department, department => elastic_builder_1.default.matchQuery('department.keyword', department))));
        }
        if (filter.officeLocation) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.officeLocation, officeLocation => elastic_builder_1.default.matchQuery('officeLocation.keyword', officeLocation))));
        }
        if (filter.ownedDevices) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.ownedDevices, ownedDevices => elastic_builder_1.default.matchQuery('ownedDevices.displayName.keyword', ownedDevices))));
        }
        if (filter.usedDevices) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.usedDevices, usedDevices => elastic_builder_1.default.matchQuery('usedDevices.displayName.keyword', usedDevices))));
        }
        if (filter.jobTitle) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.jobTitle, jobTitle => elastic_builder_1.default.matchQuery('jobTitle.keyword', jobTitle))));
        }
        if (filter.manager) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.manager, manager => elastic_builder_1.default.matchQuery('manager.keyword', manager))));
        }
        if (filter.accountStatus) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.accountStatus, accountStatus => elastic_builder_1.default.matchQuery('accountEnabled', accountStatus === CommonTypes_1.AccountStatus.ENABLED ? 'true' : 'false'))));
        }
        if (filter.groups) {
            queries.push(elastic_builder_1.default.boolQuery().must(_.map(filter.groups, group => {
                const groupQuery = [];
                groupQuery.push(elastic_builder_1.default.matchQuery('groupNames.keyword', group));
                return elastic_builder_1.default.boolQuery().must(groupQuery);
            })));
        }
        if (filter.lastActiveStart) {
            queries.push(elastic_builder_1.default.rangeQuery('providersLastUpdated').gte(filter.lastActiveStart));
        }
        if (filter.lastActiveEnd) {
            queries.push(elastic_builder_1.default.rangeQuery('providersLastUpdated').lte(filter.lastActiveEnd));
        }
        if (filter.lastLogonStart) {
            queries.push(elastic_builder_1.default.rangeQuery('lastSignInDateTime').gte(filter.lastLogonStart));
        }
        if (filter.lastLogonEnd) {
            queries.push(elastic_builder_1.default.rangeQuery('lastSignInDateTime').lte(filter.lastLogonEnd));
        }
        if (filter.accountCreatedStart) {
            queries.push(elastic_builder_1.default.rangeQuery('createdDateTime').gte(filter.accountCreatedStart));
        }
        if (filter.accountCreatedEnd) {
            queries.push(elastic_builder_1.default.rangeQuery('createdDateTime').lte(filter.accountCreatedEnd));
        }
        boolQuery.must(queries);
        return boolQuery;
    }
    async parseApiSearchResponse(apiResponse) {
        return (await Promise.all(apiResponse.body.hits.hits.map((hit) => this.convertHitToMergedEndpoint(hit)))).filter((item) => item);
    }
    parsePersonApiSearchResponse(apiResponse, labelsMap) {
        return _.compact(_.map(apiResponse.body.hits.hits, hit => this.convertHitToMergedPerson(hit, labelsMap)));
    }
    async convertHitToMergedEndpoint(hit) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const hitFields = hit._source;
        const dsi = hitFields;
        if (_.isEmpty(dsi.producers)) {
            return undefined;
        }
        let osSupport = {};
        if ((_b = (_a = dsi.osExtractedNumericVersion) === null || _a === void 0 ? void 0 : _a.match) === null || _b === void 0 ? void 0 : _b.call(_a, CommonTypes_1.NUMERIC_DOTTED_PATTERN)) {
            osSupport = (0, CommonTypes_1.getOsSupport)(await this.osVersionsMap(), dsi.osType, dsi.osExtractedNumericVersion, dsi.endpointType);
        }
        const endpoint = {
            uid: dsi.postureEndpointId,
            hostname: dsi.hostname,
            osType: dsi.osType,
            osVersion: dsi.osVersion,
            osExtractedNumericVersion: dsi.osExtractedNumericVersion,
            osHumanReadableVersion: dsi.osHumanReadableVersion,
            osSupport: osSupport.osSupport,
            isManaged: dsi.isManaged,
            isCompliant: _.isEmpty(dsi.isCompliant) || _.isEqual(dsi.isCompliant, ElasticsearchServices.UNKNOWN) ? undefined : dsi.isCompliant === 'true',
            isCompromised: _.isEmpty(dsi.isCompromised) || _.isEqual(dsi.isCompromised, ElasticsearchServices.UNKNOWN) ? undefined : dsi.isCompromised === 'true',
            emails: dsi.emails,
            appUsers: dsi.appUsers,
            users: dsi.users,
            internalIpAddresses: dsi.internalIpAddresses,
            externalIpAddresses: dsi.externalIpAddresses,
            producers: _.sortBy(_.map(dsi.producers, producer => producer), producer => producer.uid),
            lastUpdated: dsi.providersLastUpdated,
            endpointType: dsi.endpointType,
            hasFaults: dsi.hasFaults,
            avDefinitionsOutOfDate: dsi.avDefinitionsOutOfDate,
            policies: dsi.policies,
            groups: dsi.groups,
            tags: dsi.tagNames,
            macAddresses: dsi.macAddresses,
            serialNumber: dsi.serialNumber,
            hardwareId: dsi.hardwareId,
            systemModel: dsi.systemModel,
            isEncrypted: dsi.isEncrypted,
            jailBroken: dsi.jailBroken,
            isSupervised: dsi.isSupervised,
            tampered: dsi.tampered,
            ucId: dsi.ucId,
            acUdId: dsi.acUdId,
            cscVersion: dsi.cscVersion,
            secureEndpointVersion: dsi.secureEndpointVersion,
            cloudMgmtVersion: dsi.cloudMgmtVersion,
            modules: dsi.modules,
            deploymentId: dsi.deploymentId,
            deploymentName: (dsi.deploymentId) ? (_c = (await this.deploymentsMap()).get(dsi.deploymentId)) === null || _c === void 0 ? void 0 : _c.name : undefined,
            wantedDeploymentId: dsi.wantedDeploymentId,
            wantedDeploymentName: (dsi.wantedDeploymentId) ? (_d = (await this.deploymentsMap()).get(dsi.wantedDeploymentId)) === null || _d === void 0 ? void 0 : _d.name : undefined,
            labels: (dsi.labels || dsi.rulesLabels) ? this.getLabelMetadata(dsi, await this.labelsMap()) : undefined,
            financialRiskFactor: (_e = dsi.assetValue) !== null && _e !== void 0 ? _e : ElasticsearchServices.DEFAULT_ASSET_VALUE,
            assetValue: (_f = dsi.assetValue) !== null && _f !== void 0 ? _f : ElasticsearchServices.DEFAULT_ASSET_VALUE,
            effectiveAssetValueWithOrigin: ElasticsearchServices.getActualAssetValue(dsi),
            propertyTimestamp: {}
        };
        if (endpoint.osType && endpoint.osVersion && endpoint.endpointType && !((_h = (_g = dsi.osExtractedNumericVersion) === null || _g === void 0 ? void 0 : _g.match) === null || _h === void 0 ? void 0 : _h.call(_g, CommonTypes_1.NUMERIC_DOTTED_PATTERN))) {
            (0, CommonTypes_1.setOsSupport)(await this.osVersions(), endpoint);
        }
        return this.changeNullsToUndefined(endpoint);
    }
    convertHitToMergedPerson(hit, labelsMap) {
        const hitFields = hit._source;
        const dsi = hitFields;
        if (_.isEmpty(dsi.producers)) {
            return undefined;
        }
        const person = {
            uid: dsi.posturePersonId,
            producers: _.sortBy(_.map(dsi.producers, producer => producer), producer => producer.uid),
            lastUpdated: dsi.providersLastUpdated,
            accountEnabled: dsi.accountEnabled,
            blockSignin: dsi.blockSignin,
            businessPhones: dsi.businessPhones,
            companyName: dsi.companyName,
            createdDateTime: dsi.createdDateTime,
            deletedDateTime: dsi.deletedDateTime,
            department: dsi.department,
            displayName: dsi.displayName,
            emails: dsi.emails,
            employeeId: dsi.employeeId,
            employeeHireDateTime: dsi.employeeHireDateTime,
            employeeLeaveDateTime: dsi.employeeLeaveDateTime,
            givenName: dsi.givenName,
            groupNames: dsi.groupNames,
            groupDescriptions: dsi.groupDescriptions,
            jobTitle: dsi.jobTitle,
            lastSignInDateTime: dsi.lastSignInDateTime,
            mailNickname: dsi.mailNickname,
            manager: dsi.manager,
            mobilePhones: dsi.mobilePhones,
            officeLocation: dsi.officeLocation,
            ownedDevices: dsi.ownedDevices,
            usedDevices: dsi.usedDevices,
            passwordPolicies: dsi.passwordPolicies,
            personType: dsi.personType,
            surname: dsi.surname,
            usageLocation: dsi.usageLocation,
            users: dsi.users,
            windowsSID: dsi.windowsSID,
            assetValue: dsi.assetValue,
            propertyTimestamp: {}
        };
        return this.changeNullsToUndefined(person);
    }
    static getActualAssetValue(dsi) {
        var _a, _b, _c, _d;
        if (!dsi.assetValue && !dsi.rulesAssetValue) {
            return { value: ElasticsearchServices.DEFAULT_ASSET_VALUE, origin: CommonTypes_1.ModificationOrigin.DEFAULT };
        }
        return (((_a = dsi.assetValue) !== null && _a !== void 0 ? _a : 0) > ((_b = dsi.rulesAssetValue) !== null && _b !== void 0 ? _b : 0)) ? { value: (_c = dsi.assetValue) !== null && _c !== void 0 ? _c : 0, origin: CommonTypes_1.ModificationOrigin.MANUAL } : { value: (_d = dsi.rulesAssetValue) !== null && _d !== void 0 ? _d : 0, origin: CommonTypes_1.ModificationOrigin.RULES_BASED };
    }
    getLabelMetadata(dsi, labelsMap) {
        const labelMetadataObj = {};
        let origin = CommonTypes_1.ModificationOrigin.MANUAL;
        let labels = dsi.labels || [];
        for (let i = 0; i < 2; i += 1) {
            for (const id of labels) {
                const labelMetadataOfCurrentLabelId = labelMetadataObj[id] || labelsMap.get(id);
                if (!labelMetadataOfCurrentLabelId) {
                    this.logger.error(`For ${dsi.postureEndpointId} label ${id} does not exist in labels metadata by label id map`);
                    continue;
                }
                labelMetadataObj[id] = { ...labelMetadataOfCurrentLabelId, origin };
            }
            origin = CommonTypes_1.ModificationOrigin.RULES_BASED;
            labels = dsi.rulesLabels || [];
        }
        return Object.values(labelMetadataObj);
    }
}
exports.ElasticsearchServices = ElasticsearchServices;
ElasticsearchServices.ADD_LABELS_SCRIPT = 'if (ctx._source.labels == null) {ctx._source.labels = [];} ctx._source.labels.addAll(params.param); ctx._source.labels = ctx._source.labels.stream().distinct().collect(Collectors.toList())';
ElasticsearchServices.ADD_INCIDENTS_SCRIPT = 'if (ctx._source.incidents == null) {ctx._source.incidents = [];} ctx._source.incidents.add(params.param); ctx._source.incidents = ctx._source.incidents.stream().distinct().collect(Collectors.toList())';
ElasticsearchServices.REMOVE_LABELS_SCRIPT = 'if (ctx._source.labels != null) {ctx._source.labels = ctx._source.labels.stream().filter(element -> !params.param.contains(element)).collect(Collectors.toList())}';
ElasticsearchServices.REMOVE_NOT_EXISTING_LABELS_SCRIPT = 'if (ctx._source.labels != null) {ctx._source.labels = ctx._source.labels.stream().filter(element -> params.param.contains(element)).collect(Collectors.toList())}';
ElasticsearchServices.REMOVE_NOT_EXISTING_RULES_LABELS_SCRIPT = 'if (ctx._source.rulesLabels != null) {ctx._source.rulesLabels = ctx._source.rulesLabels.stream().filter(element -> params.param.contains(element)).collect(Collectors.toList())}';
ElasticsearchServices.UPDATE_ASSET_VALUE_SCRIPT = 'ctx._source.assetValue = params.param';
ElasticsearchServices.REMOVE_LABELS_AND_RULES_LABELS_SCRIPT = 'if (ctx._source.labels != null) {ctx._source.labels = ctx._source.labels.stream().filter(element -> !params.param.contains(element)).collect(Collectors.toList())} if (ctx._source.rulesLabels != null) {ctx._source.rulesLabels = ctx._source.rulesLabels.stream().filter(element -> !params.param.contains(element)).collect(Collectors.toList())}';
ElasticsearchServices.INDEX_NAME = 'posture-devices';
ElasticsearchServices.PERSON_INDEX_NAME = 'posture-persons';
ElasticsearchServices.UNKNOWN = 'unknown';
ElasticsearchServices.ES_ADDRESS = 'http://posaas-localstack-search.us-east-1.es.localhost.localstack.cloud:4566';
ElasticsearchServices.DELETE_TENANT_TASK_STATUS_WAIT_TIME = 15000;
ElasticsearchServices.SCALE_FACTOR = 1000000;
ElasticsearchServices.MAX_SCROLL_SIZE = 10000;
ElasticsearchServices.SCROLL = '1m';
ElasticsearchServices.PAGE_SIZE = 50;
ElasticsearchServices.MAX_PAGE_SIZE = 200;
ElasticsearchServices.DEFAULT_ASSET_VALUE = 10;
ElasticsearchServices.FIELDS_FOR_TEXT_SEARCH = ['postureEndpointId.keyword', 'hostname.keyword', 'osType.keyword', 'osVersion.keyword',
    'osExtractedNumericVersion.keyword', 'owners.keyword', 'emails.keyword', 'appUsers.keyword', 'users.keyword', 'internalIpAddresses.keyword',
    'externalIpAddresses.keyword', 'producers.uid.keyword', 'policies.uid.keyword',
    'endpointType.keyword', 'macAddresses.keyword', 'serialNumber.keyword', 'hardwareId.keyword', 'systemModel.keyword',
    'ucId.keyword', 'acUdId.keyword', 'cscVersion.keyword', 'secureEndpointVersion.keyword', 'cloudMgmtVersion.keyword',
    'modules.keyword', 'deploymentId.keyword', 'wantedDeploymentId.keyword'];
ElasticsearchServices.FIELDS_FOR_USERS_TEXT_SEARCH = ['displayName.keyword', 'givenName.keyword', 'surname.keyword',
    'users.keyword', 'emails.keyword', 'companyName.keyword', 'department.keyword', 'manager.keyword', 'jobTitle.keyword',
    'groupNames.keyword'];
ElasticsearchServices.FIELDS_WITHOUT_KEYWORD = ['assetValue'];
ElasticsearchServices.DEFAULT_VALUE_FOR_SORT_FIELDS = new Map([['assetValue', ElasticsearchServices.DEFAULT_ASSET_VALUE]]);
ElasticsearchServices.LABELS_AND_VALUE_FIELDS = ['labels', 'assetValue'];
class ElasticsearchGlobalServices {
    constructor(esClient = (0, ElasticsearchFactory_1.getElasticSearchClient)()) {
        this.esClient = esClient;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    static async buildSearchQuery(filter, osVersions = async () => [], deploymentsMap = async () => new Map(), queries = []) {
        var _a, _b, _c, _d;
        const boolQuery = elastic_builder_1.default.boolQuery();
        if (filter.freeText) {
            queries.push(elastic_builder_1.default.queryStringQuery(this.buildQueryTerms(filter.freeText)).fields(ElasticsearchServices.FIELDS_FOR_TEXT_SEARCH).allowLeadingWildcard(true));
        }
        if (filter.luceneQuery) {
            queries.push(elastic_builder_1.default.queryStringQuery(filter.luceneQuery).analyzeWildcard(true));
        }
        if (filter.osTypes) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.osTypes, osType => elastic_builder_1.default.matchQuery('osType.keyword', osType))));
        }
        if (filter.hasFaults) {
            queries.push(elastic_builder_1.default.boolQuery().should(elastic_builder_1.default.matchPhraseQuery('hasFaults', _.toString(filter.hasFaults))));
        }
        if (filter.avDefinitionsOutOfDate) {
            queries.push(elastic_builder_1.default.boolQuery().should(elastic_builder_1.default.matchPhraseQuery('avDefinitionsOutOfDate', _.toString(filter.avDefinitionsOutOfDate))));
        }
        if (filter.endpointType) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.endpointType, endpointType => elastic_builder_1.default.matchQuery('endpointType.keyword', endpointType))));
        }
        if (filter.osSupport) {
            const osSupportQueries = [];
            if (_.includes(filter.osSupport, CommonTypes_1.OsSupport.eol)) {
                for (const osType of Object.values(CommonTypes_1.OS)) {
                    const familyVersions = _.find(await osVersions(), { osFamily: (0, CommonTypes_1.osToFamily)(osType) });
                    if (familyVersions) {
                        const eolBaseVersions = _.filter(familyVersions.osVersion, { eol: true });
                        for (const eolBaseVersion of eolBaseVersions) {
                            osSupportQueries.push(elastic_builder_1.default.boolQuery().must([
                                elastic_builder_1.default.matchQuery('osType.keyword', osType),
                                elastic_builder_1.default.matchQuery('osStatusBase.keyword', eolBaseVersion.baseVersion)
                            ]));
                        }
                    }
                }
            }
            if (_.includes(filter.osSupport, CommonTypes_1.OsSupport.outOfDate)) {
                for (const osType of Object.values(CommonTypes_1.OS)) {
                    const familyVersions = _.find(await osVersions(), { osFamily: (0, CommonTypes_1.osToFamily)(osType) });
                    if (familyVersions) {
                        const outOfDateBaseVersions = _.filter(familyVersions.osVersion, ver => _.has(ver, 'current'));
                        for (const outOfDateBaseVersion of outOfDateBaseVersions) {
                            osSupportQueries.push(elastic_builder_1.default.boolQuery().must([
                                elastic_builder_1.default.matchQuery('osType.keyword', osType),
                                elastic_builder_1.default.matchQuery('osStatusBase.keyword', outOfDateBaseVersion.baseVersion),
                                elastic_builder_1.default.rangeQuery('osStatusVersion').lt(outOfDateBaseVersion.current * ElasticsearchServices.SCALE_FACTOR)
                            ]));
                        }
                    }
                }
            }
            queries.push(elastic_builder_1.default.boolQuery().should(osSupportQueries));
        }
        if (filter.producers) {
            queries.push(elastic_builder_1.default.boolQuery().must(_.map(filter.producers, producer => {
                const producerQuery = [];
                producerQuery.push(elastic_builder_1.default.matchQuery('producers.type.keyword', producer.type));
                producerQuery.push(elastic_builder_1.default.matchQuery('producers.producerId.keyword', producer.producerId));
                if (producer.assetValue) {
                    producerQuery.push(elastic_builder_1.default.matchQuery('producers.assetValue.keyword', producer.assetValue));
                }
                return (!producer.exclude) ? elastic_builder_1.default.boolQuery().must(producerQuery) : elastic_builder_1.default.boolQuery().mustNot(producerQuery);
            })));
        }
        if (filter.policies) {
            if (filter.policies.length > 0) {
                queries.push(elastic_builder_1.default.boolQuery().must(_.map(filter.policies, policy => {
                    const policyQuery = [];
                    if (policy.exclude) {
                        if (policy.policyId) {
                            policyQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('policies.uid.keyword', policy.policyId)));
                        }
                        else if (policy.producerId) {
                            policyQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('policies.producerId.keyword', policy.producerId)));
                        }
                        else if (policy.type) {
                            policyQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('policies.type.keyword', policy.type)));
                        }
                    }
                    else {
                        if (policy.policyId) {
                            policyQuery.push(elastic_builder_1.default.matchQuery('policies.uid.keyword', policy.policyId));
                        }
                        if (policy.type) {
                            policyQuery.push(elastic_builder_1.default.matchQuery('policies.type.keyword', policy.type));
                        }
                        if (policy.producerId) {
                            policyQuery.push(elastic_builder_1.default.matchQuery('policies.producerId.keyword', policy.producerId));
                        }
                    }
                    return elastic_builder_1.default.boolQuery().must(policyQuery);
                })));
            }
            else {
                queries.push(elastic_builder_1.default.existsQuery('policies.uid'));
            }
        }
        if (filter.groups) {
            if (filter.groups.length > 0) {
                queries.push(elastic_builder_1.default.boolQuery().must(_.map(filter.groups, group => {
                    const groupQuery = [];
                    if (group.exclude) {
                        if (group.groupId) {
                            groupQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('groups.uid.keyword', group.groupId)));
                        }
                        else if (group.producerId) {
                            groupQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('groups.producerId.keyword', group.producerId)));
                        }
                        else if (group.type) {
                            groupQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('groups.type.keyword', group.type)));
                        }
                    }
                    else {
                        if (group.groupId) {
                            groupQuery.push(elastic_builder_1.default.matchQuery('groups.uid.keyword', group.groupId));
                        }
                        if (group.type) {
                            groupQuery.push(elastic_builder_1.default.matchQuery('groups.type.keyword', group.type));
                        }
                        if (group.producerId) {
                            groupQuery.push(elastic_builder_1.default.matchQuery('groups.producerId.keyword', group.producerId));
                        }
                    }
                    return elastic_builder_1.default.boolQuery().must(groupQuery);
                })));
            }
            else {
                queries.push(elastic_builder_1.default.existsQuery('groups.uid'));
            }
        }
        if (filter.tags) {
            if (filter.tags.length > 0) {
                queries.push(elastic_builder_1.default.boolQuery().must(_.map(filter.tags, tag => {
                    const tagQuery = [];
                    if (tag.exclude) {
                        if (tag.name) {
                            tagQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('tagNames.name.keyword', tag.name)));
                        }
                        else if (tag.producerId) {
                            tagQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('tagNames.sources.producerId.keyword', tag.producerId)));
                        }
                        else if (tag.type) {
                            tagQuery.push(elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('tagNames.sources.type.keyword', tag.type)));
                        }
                    }
                    else {
                        if (tag.name) {
                            tagQuery.push(elastic_builder_1.default.matchQuery('tagNames.name.keyword', tag.name));
                        }
                        if (tag.type) {
                            tagQuery.push(elastic_builder_1.default.matchQuery('tagNames.sources.type.keyword', tag.type));
                        }
                        if (tag.producerId) {
                            tagQuery.push(elastic_builder_1.default.matchQuery('tagNames.sources.producerId.keyword', tag.producerId));
                        }
                    }
                    return elastic_builder_1.default.boolQuery().must(tagQuery);
                })));
            }
            else {
                queries.push(elastic_builder_1.default.existsQuery('tagNames.name'));
            }
        }
        if (filter.compliant) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.compliant, compliant => elastic_builder_1.default.matchQuery('isCompliant', compliant))));
        }
        if (filter.isManaged) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(filter.isManaged, isManaged => elastic_builder_1.default.matchQuery('isManaged', isManaged.toString()))));
        }
        if (filter.deployments) {
            queries.push(elastic_builder_1.default.boolQuery().must(_.map(filter.deployments, deployment => {
                const deploymentQuery = [];
                deploymentQuery.push(elastic_builder_1.default.matchQuery('deploymentId.keyword', deployment.deploymentId));
                return (!deployment.exclude) ? elastic_builder_1.default.boolQuery().must(deploymentQuery) : elastic_builder_1.default.boolQuery().mustNot(deploymentQuery);
            })));
        }
        if (filter.cloudMgmtVersionOutOfDate && ((_a = (await deploymentsMap())) === null || _a === void 0 ? void 0 : _a.size) > 0) {
            queries.push(elastic_builder_1.default.boolQuery().should(_.map(Array.from((await deploymentsMap()).entries()), deploymentEntry => {
                const deployment = {
                    id: deploymentEntry[0],
                    ...deploymentEntry[1]
                };
                const deploymentVersion = (0, CommonTypes_1.getCloudMgmtVersionNumbers)(deployment.cloudMgmtVersion);
                if (deploymentVersion.major === undefined) {
                    return elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.matchQuery('deploymentId.keyword', deployment.id));
                }
                const deploymentQuery = [];
                deploymentQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.matchQuery('deploymentId.keyword', deployment.id)));
                const versionQuery = [];
                if (deploymentVersion.major !== undefined) {
                    versionQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.rangeQuery('cloudMgmtVersionMajor').lt(deploymentVersion.major)));
                    if (deploymentVersion.minor !== undefined) {
                        const versionMinorQuery = [];
                        versionMinorQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.matchQuery('cloudMgmtVersionMajor', deploymentVersion.major.toString())));
                        versionMinorQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.rangeQuery('cloudMgmtVersionMinor').lt(deploymentVersion.minor)));
                        versionQuery.push(elastic_builder_1.default.boolQuery().must(versionMinorQuery));
                        if (deploymentVersion.patch !== undefined) {
                            const versionPatchQuery = [];
                            versionPatchQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.matchQuery('cloudMgmtVersionMajor', deploymentVersion.major.toString())));
                            versionPatchQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.matchQuery('cloudMgmtVersionMinor', deploymentVersion.minor.toString())));
                            versionPatchQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.rangeQuery('cloudMgmtVersionPatch').lt(deploymentVersion.patch)));
                            versionQuery.push(elastic_builder_1.default.boolQuery().must(versionPatchQuery));
                            if (deploymentVersion.revision !== undefined) {
                                const versionRevisionQuery = [];
                                versionRevisionQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.matchQuery('cloudMgmtVersionMajor', deploymentVersion.major.toString())));
                                versionRevisionQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.matchQuery('cloudMgmtVersionMinor', deploymentVersion.minor.toString())));
                                versionRevisionQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.matchQuery('cloudMgmtVersionPatch', deploymentVersion.patch.toString())));
                                versionRevisionQuery.push(elastic_builder_1.default.boolQuery().must(elastic_builder_1.default.rangeQuery('cloudMgmtVersionRevision').lt(deploymentVersion.revision)));
                                versionQuery.push(elastic_builder_1.default.boolQuery().must(versionRevisionQuery));
                            }
                        }
                    }
                }
                deploymentQuery.push(elastic_builder_1.default.boolQuery().should(versionQuery));
                return elastic_builder_1.default.boolQuery().must(deploymentQuery);
            })));
        }
        if (filter.inactive) {
            queries.push(elastic_builder_1.default.rangeQuery('providersLastUpdated').lt(Date.now().valueOf() - DateUtils_1.DAY_MILLIS * 7));
        }
        if ((_b = filter.labels) === null || _b === void 0 ? void 0 : _b.length) {
            this.buildMultipleTermsMustAllQueryWithExclusions(queries, filter.labels.map(item => ({ exclude: item.exclude, id: item.labelId })), ['labels.keyword', 'rulesLabels.keyword']);
        }
        if (filter.financialRiskFactor && !filter.assetValue) {
            filter.assetValue = filter.financialRiskFactor;
        }
        if (filter.assetValue) {
            const valuesBool = Array(CommonTypes_1.ASSET_VALUE_UPPER_BOUND);
            let values = (_d = (_c = filter.assetValue) === null || _c === void 0 ? void 0 : _c.values) === null || _d === void 0 ? void 0 : _d.reduce((res, value) => {
                if (!valuesBool[value] && (value >= CommonTypes_1.ASSET_VALUE_LOWER_BOUND && value <= CommonTypes_1.ASSET_VALUE_UPPER_BOUND)) {
                    valuesBool[value] = true;
                    res.push(value);
                }
                return res;
            }, []);
            const assetValueQueries = [];
            values = (values === null || values === void 0 ? void 0 : values.length) ? values : range(CommonTypes_1.ASSET_VALUE_LOWER_BOUND, CommonTypes_1.ASSET_VALUE_UPPER_BOUND + 1);
            if (filter.assetValue.origin !== CommonTypes_1.ModificationOrigin.DEFAULT) {
                for (const value of values || []) {
                    assetValueQueries.push(elastic_builder_1.default.boolQuery().should([
                        (filter.assetValue.origin === CommonTypes_1.ModificationOrigin.RULES_BASED) || elastic_builder_1.default.boolQuery().must([
                            elastic_builder_1.default.termQuery('assetValue', value),
                            elastic_builder_1.default.boolQuery().should([
                                elastic_builder_1.default.rangeQuery('rulesAssetValue').lte(value),
                                elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.existsQuery('rulesAssetValue'))
                            ])
                        ]),
                        (filter.assetValue.origin === CommonTypes_1.ModificationOrigin.MANUAL) || elastic_builder_1.default.boolQuery().must([
                            elastic_builder_1.default.termQuery('rulesAssetValue', value),
                            elastic_builder_1.default.boolQuery().should([
                                elastic_builder_1.default.rangeQuery('assetValue').lte(value),
                                elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.existsQuery('assetValue'))
                            ])
                        ])
                    ].filter(item => item !== true)));
                }
            }
            if ((values.includes(ElasticsearchServices.DEFAULT_ASSET_VALUE) && ![CommonTypes_1.ModificationOrigin.MANUAL, CommonTypes_1.ModificationOrigin.RULES_BASED].includes(filter.assetValue.origin)) || filter.assetValue.origin === CommonTypes_1.ModificationOrigin.DEFAULT) {
                assetValueQueries.push(elastic_builder_1.default.boolQuery().must([
                    elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.existsQuery('assetValue')),
                    elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.existsQuery('rulesAssetValue'))
                ]));
            }
            if (assetValueQueries.length) {
                queries.push(elastic_builder_1.default.boolQuery().should(assetValueQueries));
            }
        }
        boolQuery.must(queries);
        return boolQuery;
    }
    static buildQueryTerms(freeText) {
        const tokens = _.map(_.trim(freeText).split(' '), (token) => {
            if (_.includes(ES_OPERATORS, _.toUpper(token))) {
                return _.toUpper(token);
            }
            const escapedStr = `${this.escape(token)}`;
            return _.isEmpty(escapedStr) ? '' : `*${escapedStr}*`;
        });
        const hasSearchTerm = _.filter(tokens, token => !_.includes(ES_OPERATORS, token));
        if ((hasSearchTerm === null || hasSearchTerm === void 0 ? void 0 : hasSearchTerm.length) > 0) {
            const last = _.findLastIndex(tokens, token => !_.includes(ES_OPERATORS, token));
            return _.join(tokens.slice(0, last < 0 ? tokens.length : last + 1), ' ');
        }
        return '*';
    }
    static escape(text) {
        return _.chain(text)
            .replace(/\\/g, '\\\\')
            .replace(/\+/g, '\\+')
            .replace(/-/g, '\\-')
            .replace(/=/g, '\\=')
            .replace(/!/g, '\\!')
            .replace(/\(/g, '\\(')
            .replace(/\)/g, '\\)')
            .replace(/\{/g, '\\{')
            .replace(/\}/g, '\\}')
            .replace(/\[/g, '\\[')
            .replace(/\]/g, '\\]')
            .replace(/\^/g, '\\^')
            .replace(/"/g, '\\"')
            .replace(/~/g, '\\~')
            .replace(/\*/g, '\\*')
            .replace(/\?/g, '\\?')
            .replace(/:/g, '\\:')
            .replace(/\//g, '\\/')
            .value();
    }
    static buildMultipleTermsMustAllQueryWithExclusions(queries, terms, fields) {
        let includeTermsQuery;
        let excludeTermsQuery;
        terms = terms.filter(item => item.id);
        if (fields.length < 2) {
            const exclude = [];
            const include = [];
            terms.forEach((term) => (term.exclude ? exclude : include).push(term.id));
            includeTermsQuery = include.length ? elastic_builder_1.default.termsSetQuery(fields[0], include).minimumShouldMatchScript({ source: 'params.num_terms' }) : undefined;
            excludeTermsQuery = include.length ? elastic_builder_1.default.termsSetQuery(fields[0], exclude).minimumShouldMatchScript({ source: 'params.num_terms' }) : undefined;
        }
        else {
            const includeTermsQueriesList = [];
            const excludeTermsQueriesList = [];
            for (const term of terms) {
                const termQueriesList = [];
                for (const field of fields) {
                    termQueriesList.push(elastic_builder_1.default.termQuery(field, term.id));
                }
                (term.exclude ? excludeTermsQueriesList : includeTermsQueriesList).push(elastic_builder_1.default.boolQuery().should(termQueriesList));
            }
            includeTermsQuery = includeTermsQueriesList.length ? elastic_builder_1.default.boolQuery().must(includeTermsQueriesList) : undefined;
            excludeTermsQuery = excludeTermsQueriesList.length ? elastic_builder_1.default.boolQuery().must(excludeTermsQueriesList) : undefined;
        }
        if (includeTermsQuery) {
            queries.push(includeTermsQuery);
        }
        if (excludeTermsQuery) {
            queries.push(elastic_builder_1.default.boolQuery().mustNot(excludeTermsQuery));
        }
    }
    async deleteAllDocumentsInIndex(index) {
        const waitingTime = 1000;
        this.logger.debug(`Starting deletion of all documents in index ${index}`);
        const deleteByQueryResponse = await this.esClient.deleteByQuery({
            wait_for_completion: false,
            conflicts: 'proceed',
            index,
            body: {
                query: {
                    match_all: {}
                }
            }
        });
        if (!deleteByQueryResponse) {
            throw new Error(`Failed to initiate delete by query for index ${index}`);
        }
        const deleteByQueryTask = deleteByQueryResponse.body.task;
        let processing = true;
        while (processing) {
            await (0, Util_1.delay)(waitingTime);
            const result = await this.esClient.tasks.get({
                task_id: deleteByQueryTask
            });
            if (!result) {
                throw new Error(`Failed to check delete by query task=${deleteByQueryTask} execution for index ${index}`);
            }
            processing = processing && !result.body.completed;
        }
    }
    async bulkUpdateRulesLabelsAndAssetValue(devicesToUpdateInEsList) {
        this.esClient.helpers.bulk({
            datasource: devicesToUpdateInEsList,
            onDocument(document) {
                var _a;
                return [
                    { update: { _index: ElasticsearchServices.INDEX_NAME, _id: document.postureEndpointId } },
                    { doc_as_upsert: false, doc: { rulesLabels: ((document.labelsUpdated || (((_a = document.rulesLabels) === null || _a === void 0 ? void 0 : _a.length) === 0)) ? document.rulesLabels : undefined), rulesAssetValue: ((document.assetValueUpdated || document.rulesAssetValue === null) ? document.rulesAssetValue : undefined), modifiedByRules: document.modifiedByRules, rulesLatestProcessed: document.rulesLatestProcessed, matchedByRules: document.matchedByRules } }
                ];
            }
        });
    }
    async bulkReadWholeDevicesByDeviceIds(ids) {
        if (!ids.length) {
            return {};
        }
        const req = {
            index: ElasticsearchServices.INDEX_NAME,
            body: { ids }
        };
        const apiResponse = await this.esClient.mget(req);
        return Object.fromEntries(apiResponse.body.docs.filter((item) => item.found).map((item) => [item._id, item._source]));
    }
    async multiQuery(queries, returnDocsSource = true, returnMaxSize = ElasticsearchServices.MAX_SCROLL_SIZE) {
        if (!queries.length) {
            return [];
        }
        try {
            const requestBody = [];
            for (const query of queries) {
                requestBody.push({ index: ElasticsearchServices.INDEX_NAME }, { query, _source: returnDocsSource, size: returnMaxSize });
            }
            const { body } = await this.esClient.msearch({
                body: requestBody
            });
            return body.responses;
        }
        catch (err) {
            this.logger.error('Failed to execute multiQueryElasticSearch: ', err);
            throw err;
        }
    }
    async *scrollGenerator(query, returnDocsSource = true, returnMaxSize = ElasticsearchServices.MAX_SCROLL_SIZE, scrollId = '') {
        var _a, _b, _c, _d, _e, _f;
        const scrollTimeout = '3m';
        let response;
        if (query && !scrollId) {
            const searchResult = await this.esClient.search({
                index: ElasticsearchServices.INDEX_NAME,
                body: elastic_builder_1.default.requestBodySearch()
                    .query(query)
                    .source(returnDocsSource)
                    .size(returnMaxSize)
                    .toJSON(),
                scroll: scrollTimeout
            });
            scrollId = (_a = searchResult === null || searchResult === void 0 ? void 0 : searchResult.body) === null || _a === void 0 ? void 0 : _a._scroll_id;
            response = (_c = (_b = searchResult === null || searchResult === void 0 ? void 0 : searchResult.body) === null || _b === void 0 ? void 0 : _b.hits) === null || _c === void 0 ? void 0 : _c.hits;
            yield [response, scrollId];
        }
        do {
            const scrollResult = await this.esClient.scroll({
                scroll_id: scrollId,
                scroll: scrollTimeout
            });
            scrollId = (_d = scrollResult === null || scrollResult === void 0 ? void 0 : scrollResult.body) === null || _d === void 0 ? void 0 : _d._scroll_id;
            response = (_f = (_e = scrollResult === null || scrollResult === void 0 ? void 0 : scrollResult.body) === null || _e === void 0 ? void 0 : _e.hits) === null || _f === void 0 ? void 0 : _f.hits;
            if (!(response === null || response === void 0 ? void 0 : response.length)) {
                break;
            }
            yield [response, scrollId];
        } while (true);
    }
    async clearScroll(scrollId) {
        try {
            await this.esClient.clearScroll({ scroll_id: scrollId });
        }
        catch (err) {
            this.logger.error(`Error occurred while clearing scroll ${scrollId}`, err);
        }
    }
}
exports.ElasticsearchGlobalServices = ElasticsearchGlobalServices;
