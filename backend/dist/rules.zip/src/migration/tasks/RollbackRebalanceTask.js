"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RollbackRebalanceTask = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const NeptuneShardRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardRepo");
const bluebird_1 = require("bluebird");
const ALL_TENANTS = 'all';
class RollbackRebalanceTask extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor() {
        super(...arguments);
        this.neptuneShardMigrationLogRepo = new NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationLogRepo();
        this.neptuneShardRepo = new NeptuneShardRepo_1.NeptuneShardRepo();
    }
    getTaskName() {
        return RollbackRebalanceTask.TASK_NAME;
    }
    async execute() {
        const taskParam = this.getTaskParamsObj();
        if (!taskParam || !taskParam.tenant) {
            throw new Error(`must provide the tenant with either the value "${ALL_TENANTS}" or an actual tenantUid`);
        }
        await this.rollback(taskParam.tenant);
        return bluebird_1.Promise.resolve();
    }
    getTaskParamsObj() {
        try {
            return JSON.parse(this.taskParams);
        }
        catch {
            return undefined;
        }
    }
    async rollback(tenant) {
        let logsToRollback = [];
        if (tenant === ALL_TENANTS) {
            this.logger.info('start rollback process for all...');
            logsToRollback = await this.neptuneShardMigrationLogRepo.getLogsByStatus([NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.DONE]);
        }
        else {
            this.logger.info(`start rollback process for tenant ${tenant}...`);
            const migrationLog = await this.neptuneShardMigrationLogRepo.getTenantMigrationLog(tenant);
            if (migrationLog) {
                logsToRollback.push(migrationLog);
            }
        }
        if (logsToRollback.length === 0) {
            this.logger.info('end rollback process, not a tenant need rollback');
            return;
        }
        let hasErr = false;
        await bluebird_1.Promise.map(logsToRollback, async (migrationLog) => {
            try {
                await this.neptuneShardRepo.updateNeptuneShard(migrationLog.tenantUid, migrationLog.migrateFromShardId);
                this.logger.debug(`neptune shard id for tenant ${migrationLog.tenantUid} is reverted back to ${migrationLog.migrateFromShardId}`);
            }
            catch (err) {
                hasErr = true;
                this.logger.error(`failed to roll back tenant ${migrationLog.tenantUid}, error: ${err.message}`);
            }
        }, { concurrency: 500 });
        if (hasErr) {
            throw new Error('Error occurred in rollback process');
        }
        this.logger.info('end rollback process');
    }
}
exports.RollbackRebalanceTask = RollbackRebalanceTask;
RollbackRebalanceTask.TASK_NAME = 'rebalance-neptune-rollback-task';
