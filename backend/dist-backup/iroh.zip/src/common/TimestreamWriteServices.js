"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimestreamWriteServices = exports.DimensionName = exports.Dimension = exports.MetricName = exports.Metric = void 0;
const LambdaLogger_1 = require("./LambdaLogger");
const client_timestream_write_1 = require("@aws-sdk/client-timestream-write");
class Metric {
    constructor(name, value = 1) {
        this.name = name;
        this.value = value;
    }
}
exports.Metric = Metric;
var MetricName;
(function (MetricName) {
    MetricName["RECORDS_TOTAL"] = "recordsTotal";
    MetricName["RECORDS_SKIPPED"] = "recordsSkipped";
    MetricName["RECORDS_FAILED"] = "recordsFailed";
    MetricName["RECORDS_NOT_LINKABLE"] = "recordsNotLinkable";
    MetricName["RECORDS_BLOCKED"] = "recordsBlocked";
    MetricName["RETRIES"] = "retries";
    MetricName["WORKFLOW_STARTED"] = "started";
    MetricName["WORKFLOW_COMPLETED"] = "completed";
    MetricName["WORKFLOW_FAILED"] = "failed";
    MetricName["STARTED_FETCH_NEW_PRODUCER_SCHEDULED"] = "startedFetchNewProducerScheduled";
    MetricName["STARTED_FETCH_SCHEDULED_TRIGGER"] = "startedFetchScheduledTrigger";
    MetricName["STARTED_FETCH_MANUAL_TRIGGER"] = "startedFetchManualTrigger";
    MetricName["DURATION"] = "duration";
    MetricName["POST_PROCESSING_DURATION"] = "postProcessingDuration";
    MetricName["POST_PROCESSING_GRAPH_DURATION"] = "postProcessingGraphDuration";
    MetricName["POST_PROCESSING_ES_DURATION"] = "postProcessingEsDuration";
    MetricName["ES_DEVICES_CREATED"] = "esDevicesCreated";
    MetricName["ES_DEVICES_UPDATED"] = "esDevicesUpdated";
    MetricName["ES_DEVICES_UPDATED_BY_FILTER"] = "esDevicesUpdatedByFilter";
    MetricName["RULES_DEVICES_CREATED_SUBMITTED"] = "rulesDevicesCreatedSubmitted";
    MetricName["RULES_DEVICES_UPDATED_SUBMITTED"] = "rulesDevicesUpdatedSubmitted";
    MetricName["RULES_DEVICES_SUBMITION_DURATION"] = "rulesDevicesSubmitionDuration";
    MetricName["RULES_DEVICES_UPDATED_BY_FILTER_SUBMITTED"] = "rulesDevicesUpdatedByFilterSubmitted";
    MetricName["RULES_DEVICES_BY_FILTER_SUBMITION_DURATION"] = "rulesDevicesByFilterSubmitionDuration";
    MetricName["RULES_DEVICES_CREATED_RECEIVED"] = "rulesDevicesCreatedReceived";
    MetricName["RULES_DEVICES_UPDATED_RECEIVED"] = "rulesDevicesUpdatedReceived";
    MetricName["RULES_DEVICES_TENANTS_IN_BATCH"] = "rulesDevicesTenantsInBatch";
    MetricName["RULES_DEVICES_UPDATED_BY_FILTER_RECEIVED"] = "rulesDevicesUpdatedByFilterReceived";
    MetricName["RULES_CREATED"] = "rulesCreated";
    MetricName["RULES_UPDATED"] = "rulesUpdated";
    MetricName["RULES_DELETED"] = "rulesDeleted";
    MetricName["RULES_CHANGES_EFFECT_DURATION"] = "rulesChangesEffectDuration";
    MetricName["RULES_DEVICES_IDENTIFIED_APPLY_SUBMITTED"] = "rulesDevicesIdentifiedApplySubmitted";
    MetricName["RULES_DEVICES_IDENTIFIED_UPDATE_SUBMITTED"] = "rulesDevicesIdentifiedUpdateSubmitted";
    MetricName["RULES_DEVICES_IDENTIFIED_UPDATED_BY_FILTER_SUBMITTED"] = "rulesDevicesIdentifiedUpdatedByFilterSubmitted";
    MetricName["RULES_DEVICES_IDENTIFIED_APPLY_RECEIVED"] = "rulesDevicesIdentifiedApplyReceived";
    MetricName["RULES_DEVICES_IDENTIFICATION_DURATION"] = "rulesDevicesIdentificationDuration";
    MetricName["RULES_DEVICES_RECEIVED_DURATION"] = "rulesDevicesReceivedDuration";
    MetricName["RULES_EXEC_UC_APPLIED_DELAY"] = "rulesExecAppliedDelay";
    MetricName["RULES_EXEC_APPLY_RULES_FROM_RECORDS"] = "rulesExecApplyRulesFromRecords";
    MetricName["RULES_EXEC_APPLY_RULES_FROM_DB"] = "rulesExecApplyRulesFromDb";
    MetricName["RULES_EXEC_APPLY_MERGED_RULES"] = "rulesExecApplyMergedRules";
    MetricName["RULES_EXEC_APPLY_RULES_TO_APPLY"] = "rulesExecApplyRulesToApply";
    MetricName["RULES_EXEC_UC_RULES_FROM_DB"] = "rulesExecUcRulesFromDb";
    MetricName["RULES_EXEC_UC_RULES_TO_APPLY"] = "rulesExecUcRulesToApply";
    MetricName["RULES_EXEC_QUERIES_DURATION"] = "rulesExecQueriesDuration";
    MetricName["RULES_EXEC_APPLY_DEVICES_MATCHING_RULES"] = "rulesExecApplyDevicesMatchingRules";
    MetricName["RULES_EXEC_UC_DEVICES_MATCHING_RULES"] = "rulesExecUcDevicesMatchingRules";
    MetricName["RULES_EXEC_APPLY_DEVICES_TO_UPDATE_IN_ES"] = "rulesExecApplyDevicesToUpdateInEs";
    MetricName["RULES_EXEC_APPLY_DEVICES_TO_UPDATE_IN_ES_DURATION"] = "rulesExecApplyDevicesToUpdateInEsDuration";
    MetricName["RULES_EXEC_UC_DEVICES_TO_UPDATE_IN_ES"] = "rulesExecUcDevicesToUpdateInEs";
    MetricName["RULES_EXEC_UC_DEVICES_TO_UPDATE_IN_ES_DURATION"] = "rulesExecUcDevicesToUpdateInEsDuration";
    MetricName["RULES_EXEC_RULES_WITH_OUTPUT_FIELDS_IN_MATCHING_CRITERIA"] = "rulesExecRulesWithOutputFieldsInMatchingCriteria";
    MetricName["RULES_EXEC_RULES_WITHOUT_OUTPUT_FIELDS_IN_MATCHING_CRITERIA"] = "rulesExecRulesWithoutOutputFieldsInMatchingCriteria";
    MetricName["RULES_EXEC_DEVICES_MANUALLY_ADHERING_TO_OUTPUT_FIELDS"] = "rulesExecDevicesManuallyAdheringToOutputFields";
    MetricName["RULES_DISCR_RULES_REMAINING_INPUT"] = "rulesDiscrRulesRemainingInput";
    MetricName["RULES_DISCR_RULES_REMAINING_OUTPUT"] = "rulesDiscrRulesRemainingOutput";
    MetricName["RULES_DISCR_RULES_FROM_DB"] = "rulesDiscrRulesFromDb";
    MetricName["RULES_DISCR_RULES_IN_GRACE"] = "rulesDiscrRulesInGrace";
    MetricName["RULES_DISCR_RULES_IN_FF"] = "rulesDiscrRulesInFf";
    MetricName["RULES_DISCR_Q_AND_R_MATCHING_DEVICES"] = "rulesDiscrQAndRMatchingDevices";
    MetricName["RULES_DISCR_Q_AND_R_SENT_EVENTS"] = "rulesDiscrQAndRSentEvents";
    MetricName["RULES_DISCR_Q_AND_R_STOPPED_BY_TIME"] = "rulesDiscrQAndRStoppedByTime";
    MetricName["RULES_DISCR_Q_AND_R_COMPLETED_SUCCESSFULLY"] = "rulesDiscrQAndRCompletedSuccessfully";
    MetricName["RULES_DISCR_RULES_IMPAIRED_RULES_FOR_NEW_PROCESSING"] = "rulesDiscrRulesImpairedRulesForNewProcessing";
    MetricName["RULES_DISCR_RULES_IMPAIRED_ALL_RULES"] = "rulesDiscrRulesImpairedAllRules";
    MetricName["RULES_DISCR_RULES_IMPAIRED_ACCUMULATED_DEVICES_COUNT"] = "rulesDiscrRulesImpairedAccumulatedDevicesCount";
    MetricName["RULES_DISCR_RULES_IMPAIRED_DELETED_RULES"] = "rulesDiscrRulesImpairedDeletedRules";
    MetricName["RULES_DISCR_RULES_IMPAIRED_DELETED_RULES_WITH_ADHERING_DEVICES"] = "rulesDiscrRulesImpairedDeletedRulesWithAdheringDevices";
    MetricName["RULES_DISCR_RULES_IMPAIRED_DELETED_RULES_ENABLED"] = "rulesDiscrRulesImpairedDeletedRulesEnabled";
    MetricName["RULES_DISCR_RULES_IMPAIRED_NOT_PENDING_APPLY_PROCESSING"] = "rulesDiscrRulesImpairedNotPendingApplyProcessing";
    MetricName["RULES_DISCR_RULES_IMPAIRED_NOT_PENDING_APPLY_TO_HARD_DELETE"] = "rulesDiscrRulesImpairedNotPendingApplyToHardDelete";
    MetricName["RULES_DISCR_NOT_EXISTING_LABEL_PART_OF_THE_RULE"] = "rulesDiscrNotExistingLabelIsPartOfTheRule";
})(MetricName = exports.MetricName || (exports.MetricName = {}));
class Dimension {
    constructor(name, value) {
        this.name = name;
        this.value = value;
    }
}
exports.Dimension = Dimension;
var DimensionName;
(function (DimensionName) {
    DimensionName["TENANT"] = "tenant";
    DimensionName["PRODUCER"] = "producer";
    DimensionName["WORKFLOW"] = "workflow";
})(DimensionName = exports.DimensionName || (exports.DimensionName = {}));
class TimestreamWriteServices {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.writeClient = new client_timestream_write_1.TimestreamWriteClient({ region: process.env.AWS_REGION === 'ap-southeast-2' ? 'eu-central-1' : process.env.AWS_REGION });
        this.initialized = false;
        if (!process.env.ENV_PREFIX) {
            throw new Error('ENV_PREFIX is not set');
        }
    }
    async sendRequest(params) {
        await this.init();
        return this.writeClient.send(new client_timestream_write_1.WriteRecordsCommand(params))
            .catch((err) => {
            this.logger.error('Error writing records to Timestream:', err);
            throw err;
        });
    }
    async init() {
        if (this.initialized) {
            return;
        }
        await this.createDatabase();
        await this.createTable();
        this.initialized = true;
    }
    createDatabase() {
        const params = {
            DatabaseName: TimestreamWriteServices.getDatabaseName()
        };
        return this.writeClient.send(new client_timestream_write_1.CreateDatabaseCommand(params))
            .catch((err) => {
            if (err.name !== 'ConflictException') {
                throw err;
            }
        });
    }
    createTable() {
        const params = {
            DatabaseName: TimestreamWriteServices.getDatabaseName(),
            TableName: TimestreamWriteServices.TABLE_NAME,
            RetentionProperties: {
                MemoryStoreRetentionPeriodInHours: TimestreamWriteServices.TTL_HOURS,
                MagneticStoreRetentionPeriodInDays: TimestreamWriteServices.TTL_DAYS
            }
        };
        return this.writeClient.send(new client_timestream_write_1.CreateTableCommand(params))
            .catch((err) => {
            if (err.name !== 'ConflictException') {
                throw err;
            }
        });
    }
    static getDatabaseName() {
        return `${process.env.ENV_PREFIX}-${TimestreamWriteServices.DATABASE_NAME}`;
    }
}
exports.TimestreamWriteServices = TimestreamWriteServices;
TimestreamWriteServices.DATABASE_NAME = 'timeseries';
TimestreamWriteServices.TABLE_NAME = 'metrics';
TimestreamWriteServices.TTL_HOURS = 24;
TimestreamWriteServices.TTL_DAYS = 90;
