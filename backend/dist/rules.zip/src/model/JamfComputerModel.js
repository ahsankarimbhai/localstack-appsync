"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JamfComputerStateModelService = exports.JamfComputerStateModel = exports.JamfComputerModelService = exports.JamfComputerModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class JamfComputerModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.JAMF_COMPUTER;
    }
    async initProperties(jamfComputer) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, jamfComputer.id);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.JamfComputerModel = JamfComputerModel;
class JamfComputerModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new JamfComputerModel(this.partitionKey);
    }
}
exports.JamfComputerModelService = JamfComputerModelService;
class JamfComputerStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.JAMF_COMPUTER_STATE;
    }
    async initProperties(input) {
        if (input.general) {
            const jamfComputer = input;
            const id = {
                name: jamfComputer.general.name,
                ipAddress: jamfComputer.general.lastIpAddress,
                reportedIpAddress: jamfComputer.general.lastReportedIp,
                macAddress: jamfComputer.hardware.macAddress,
                modelIdentifier: jamfComputer.hardware.modelIdentifier,
                isManaged: jamfComputer.general.remoteManagement.managed,
                username: jamfComputer.userAndLocation.username,
                email: jamfComputer.userAndLocation.email,
                serialNumber: jamfComputer.hardware.serialNumber,
                udid: jamfComputer.udid,
                osVersion: jamfComputer.operatingSystem.version,
                osBuild: jamfComputer.operatingSystem.build
            };
            this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(id));
            this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, jamfComputer.general.name);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, CommonTypes_1.OS.MAC_OS);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, jamfComputer.operatingSystem.version);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(CommonTypes_1.OS.MAC_OS, jamfComputer.operatingSystem.version, jamfComputer.operatingSystem.build));
            (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, jamfComputer.operatingSystem.name, [jamfComputer.operatingSystem.version, jamfComputer.operatingSystem.build].filter(item => item).join('.'));
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, jamfComputer.operatingSystem.build);
            this.setProperty(CommonTypes_1.VertexBasicProperty.IS_MANAGED, jamfComputer.general.remoteManagement.managed);
            this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(jamfComputer.general.lastContactTime));
            this.setProperty(JamfComputerStateModel.LAST_REPORT_DATE_KEY, jamfComputer.general.reportDate);
            this.setProperty(JamfComputerStateModel.MODEL_IDENTIFIER_KEY, jamfComputer.hardware.modelIdentifier);
            this.setProperty('general', jamfComputer.general);
            this.setProperty('hardware', jamfComputer.hardware);
            this.setProperty('operatingSystem', jamfComputer.operatingSystem);
            this.setProperty('userAndLocation', jamfComputer.userAndLocation);
            this.setProperty('diskEncryption', jamfComputer.diskEncryption);
            this.setProperty('security', jamfComputer.security);
        }
        else if (input.type) {
            const jamfMobileDevice = input;
            const id = {
                name: jamfMobileDevice.name,
                serialNumber: jamfMobileDevice.serialNumber,
                macAddress: jamfMobileDevice.wifiMacAddress,
                udid: jamfMobileDevice.udid,
                username: jamfMobileDevice.username,
                modelIdentifier: jamfMobileDevice.modelIdentifier
            };
            this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(id));
            this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, jamfMobileDevice.name);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, CommonTypes_1.OS.IOS);
            this.setProperty(JamfComputerStateModel.MODEL_IDENTIFIER_KEY, jamfMobileDevice.modelIdentifier);
            this.setProperty('type', jamfMobileDevice.type);
            (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, jamfMobileDevice.type);
        }
        else {
            const jamfComputer = input;
            if (!jamfComputer.isMobile) {
                const id = {
                    name: jamfComputer.name,
                    ipAddress: jamfComputer.ipAddress,
                    reportedIpAddress: jamfComputer.reportedIpAddress,
                    macAddress: jamfComputer.macAddress,
                    modelIdentifier: jamfComputer.modelIdentifier,
                    isManaged: jamfComputer.isManaged,
                    username: jamfComputer.username,
                    email: jamfComputer.emailAddress,
                    serialNumber: jamfComputer.serialNumber,
                    udid: jamfComputer.udid,
                    osVersion: jamfComputer.operatingSystemVersion,
                    osBuild: jamfComputer.operatingSystemBuild
                };
                this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(id));
            }
            else {
                const id = {
                    name: jamfComputer.name,
                    serialNumber: jamfComputer.serialNumber,
                    macAddress: jamfComputer.macAddress,
                    udid: jamfComputer.udid,
                    username: jamfComputer.username,
                    modelIdentifier: jamfComputer.modelIdentifier
                };
                this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(id));
            }
            this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, jamfComputer.name);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, jamfComputer.isMobile ? CommonTypes_1.OS.IOS : CommonTypes_1.OS.MAC_OS);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, jamfComputer.operatingSystemVersion);
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)('', jamfComputer.operatingSystemVersion, jamfComputer.operatingSystemBuild));
            (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, jamfComputer.name, [jamfComputer.operatingSystemVersion, jamfComputer.operatingSystemBuild].filter(item => item).join('.'));
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, jamfComputer.operatingSystemBuild);
            this.setProperty(CommonTypes_1.VertexBasicProperty.IS_MANAGED, jamfComputer.isManaged);
            this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(jamfComputer.lastContactDate));
            this.setProperty(JamfComputerStateModel.LAST_REPORT_DATE_KEY, jamfComputer.lastReportDate);
            this.setProperty(JamfComputerStateModel.MODEL_IDENTIFIER_KEY, jamfComputer.modelIdentifier);
            this.setProperty(JamfComputerStateModel.MDM_ACCESS_RIGHTS_KEY, jamfComputer.mdmAccessRights);
            this.setInternalIpAddresses(jamfComputer.reportedIpAddress);
        }
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.JamfComputerStateModel = JamfComputerStateModel;
JamfComputerStateModel.LAST_REPORT_DATE_KEY = 'lastReportDate';
JamfComputerStateModel.MODEL_IDENTIFIER_KEY = 'modelIdentifier';
JamfComputerStateModel.MDM_ACCESS_RIGHTS_KEY = 'mdmAccessRights';
class JamfComputerStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new JamfComputerStateModel(this.partitionKey);
    }
}
exports.JamfComputerStateModelService = JamfComputerStateModelService;
