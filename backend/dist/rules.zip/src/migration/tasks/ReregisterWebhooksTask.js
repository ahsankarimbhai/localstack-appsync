"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReregisterWebhooksTask = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const LambdaServices_1 = require("../../common/LambdaServices");
class ReregisterWebhooksTask extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor() {
        super(...arguments);
        this.lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
    }
    async execute() {
        const sourceOptions = this.getTaskParamsObj();
        const functionName = `${process.env.ENV_PREFIX}-update-query-for-all-sharded`;
        const lmdErr = [];
        for (const opt of sourceOptions) {
            try {
                this.logger.info(`starting processing source ${opt.source} with ${opt.numOfShards} shards.`);
                await this.lambdaServices.asyncInvoke(functionName, JSON.stringify({
                    source: opt.source,
                    numOfShards: opt.numOfShards,
                    registerAll: opt.registerAll,
                    forceRefreshWebhooks: opt.forceRefreshWebhooks,
                    whatif: opt.whatif
                }));
            }
            catch (e) {
                lmdErr.push(`error when invoking ${functionName} for source ${opt.source} with ${opt.numOfShards} shards.`);
            }
        }
        if (lmdErr.length > 0) {
            const errMsgs = lmdErr.join(' ');
            this.logger.error(errMsgs);
            throw new Error(errMsgs);
        }
        return Promise.resolve();
    }
    getTaskParamsObj() {
        try {
            return JSON.parse(this.taskParams);
        }
        catch {
            return [];
        }
    }
    getTaskName() {
        return ReregisterWebhooksTask.TASK_NAME;
    }
}
exports.ReregisterWebhooksTask = ReregisterWebhooksTask;
ReregisterWebhooksTask.TASK_NAME = 'reregister-webhooks-task';
