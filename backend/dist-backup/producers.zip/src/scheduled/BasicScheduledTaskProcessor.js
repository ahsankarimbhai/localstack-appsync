"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BasicScheduledTaskProcessor = exports.BasicStatusHandler = void 0;
const TimestreamUtil_1 = require("../common/TimestreamUtil");
const TimestreamRequestBuilder_1 = require("../common/TimestreamRequestBuilder");
const TimestreamWriteServices_1 = require("../common/TimestreamWriteServices");
const LambdaLogger_1 = require("../common/LambdaLogger");
const ResourcesManager_1 = require("../common/ResourcesManager");
class BasicStatusHandler {
    handleFailure(error) {
        return Promise.resolve(error);
    }
    handleSuccess() {
        return Promise.resolve();
    }
}
exports.BasicStatusHandler = BasicStatusHandler;
class BasicScheduledTaskProcessor {
    constructor(tenantUid, producer, taskParams) {
        this.tenantUid = tenantUid;
        this.producer = producer;
        this.taskParams = taskParams;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.timestreamUtil = new TimestreamUtil_1.TimestreamUtil();
        this.timestreamRequestBuilder = new TimestreamRequestBuilder_1.TimestreamRequestBuilder();
    }
    async processTask() {
        const startTime = Date.now();
        this.logger.debug(`${this.getLogPrefix()}  Started ${this.getTaskName()} processing`);
        this.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.WORKFLOW_STARTED)]);
        try {
            const res = await this.execute();
            if (res === null || res === void 0 ? void 0 : res.shouldContinue) {
                return {
                    tenantUid: this.tenantUid,
                    taskParams: this.taskParams,
                    shouldContinue: true
                };
            }
            await this.handleSuccess();
        }
        catch (err) {
            this.logger.debug(`${this.getLogPrefix()} ${this.getTaskName()} failed, ${JSON.stringify(err)}`);
            await this.handleFailure(err);
        }
        finally {
            this.logger.debug(`${this.getLogPrefix()} ${this.getTaskName()} completed`, Date.now() - startTime);
            await (0, ResourcesManager_1.closeConnections)();
            await this.timestreamUtil.sendRequestsToStream(this.timestreamRequestBuilder.createRequestsAndReset());
        }
        return {
            tenantUid: this.tenantUid,
            taskParams: this.taskParams,
            shouldContinue: false
        };
    }
    async triggerNewLambdaGeneric(timeBasedAsyncLambdaInvoker, invokeParamsObj) {
        this.logger.debug(`${this.getLogPrefix()} remaining time in millis: ${timeBasedAsyncLambdaInvoker.getRemainingTimeInMillis()}, threshold: ${timeBasedAsyncLambdaInvoker.timeoutThreshold}`);
        if (timeBasedAsyncLambdaInvoker.getRemainingTimeInMillis() < timeBasedAsyncLambdaInvoker.timeoutThreshold) {
            const invokeParams = JSON.stringify(invokeParamsObj);
            this.logger.debug(`${this.getLogPrefix()} close to timeout: ${timeBasedAsyncLambdaInvoker.getRemainingTimeInMillis()}, trigger new invocation of function: ${timeBasedAsyncLambdaInvoker.context.functionName} with params: ${invokeParams}`);
            await timeBasedAsyncLambdaInvoker.lambdaServices.asyncInvoke(timeBasedAsyncLambdaInvoker.context.functionName, invokeParams);
            return true;
        }
        return false;
    }
    getStatusHandler() {
        return new BasicStatusHandler();
    }
    getLogTenantPrefix() {
        return `task: ${this.getTaskName()} for tenant: ${this.tenantUid}`;
    }
    getLogPrefix() {
        return `${this.getLogTenantPrefix()}${this.producer ? ` and producer: ${this.producer}` : ''}`;
    }
    addRecordMetrics(metrics) {
        const dimensions = TimestreamRequestBuilder_1.TimestreamRequestBuilder.batchJobDimensions(this.tenantUid, this.getTaskName(), this.producer);
        this.timestreamRequestBuilder.add(metrics, dimensions);
    }
    postProcess() {
        return Promise.resolve();
    }
    async handleSuccess() {
        this.logger.debug(`${this.getLogPrefix()} completed successfully. Starting post processing...`);
        this.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.WORKFLOW_COMPLETED)]);
        await this.getStatusHandler().handleSuccess();
        return this.postProcess();
    }
    async handleFailure(error) {
        this.logger.error(`${this.getLogPrefix()} failed with error`, error);
        this.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.WORKFLOW_FAILED)]);
        await this.getStatusHandler().handleFailure(error);
        return Promise.resolve();
    }
}
exports.BasicScheduledTaskProcessor = BasicScheduledTaskProcessor;
