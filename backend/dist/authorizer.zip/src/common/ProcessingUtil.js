"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessingUtil = void 0;
const _ = __importStar(require("lodash"));
const fs_1 = __importDefault(require("fs"));
const readline_1 = __importDefault(require("readline"));
const uuid_1 = require("uuid");
const CommonTypes_1 = require("./CommonTypes");
const S3Services_1 = require("./S3Services");
const LambdaLogger_1 = require("./LambdaLogger");
const TenantServices_1 = require("./TenantServices");
const TimestreamWriteServices_1 = require("./TimestreamWriteServices");
const FunctionStateServices_1 = require("./FunctionStateServices");
const TimestreamRequestBuilder_1 = require("./TimestreamRequestBuilder");
const TimestreamUtil_1 = require("./TimestreamUtil");
const Util_1 = require("./Util");
const csvtojson_1 = __importDefault(require("csvtojson"));
const DuoEndpointService_1 = require("../collectors/services/DuoEndpointService");
const DuoUserService_1 = require("../collectors/services/DuoUserService");
const JamfEndpointService_1 = require("../collectors/services/JamfEndpointService");
const InTuneEndpointService_1 = require("../collectors/services/InTuneEndpointService");
const MerakiEndpointService_1 = require("../collectors/services/MerakiEndpointService");
const AmpEndpointService_1 = require("../collectors/services/AmpEndpointService");
const OrbitalEndpointService_1 = require("../collectors/services/OrbitalEndpointService");
const CustomEndpointService_1 = require("../collectors/services/CustomEndpointService");
const UmbrellaEndpointService_1 = require("../collectors/services/UmbrellaEndpointService");
const MobileIronEndpointService_1 = require("../collectors/services/MobileIronEndpointService");
const UnifiedConnectorEndpointService_1 = require("../collectors/services/UnifiedConnectorEndpointService");
const AirWatchEndpointService_1 = require("../collectors/services/AirWatchEndpointService");
const ServiceNowEndpointService_1 = require("../collectors/services/ServiceNowEndpointService");
const SentinelOneEndpointService_1 = require("../collectors/services/SentinelOneEndpointService");
const CyberVisionEndpointService_1 = require("../collectors/services/CyberVisionEndpointService");
const CrowdStrikeEndpointService_1 = require("../collectors/services/CrowdStrikeEndpointService");
const DefenderEndpointService_1 = require("../collectors/services/DefenderEndpointService");
const AzureUserService_1 = require("../collectors/services/AzureUserService");
const KinesisHelper_1 = require("./kinesis/KinesisHelper");
const KinesisBatchServices_1 = require("./kinesis/KinesisBatchServices");
const ShardedKinesisBatchServices_1 = require("./kinesis/ShardedKinesisBatchServices");
const LabelService_1 = require("../services/common/LabelService");
const TrendVisionOneEndpointService_1 = require("../collectors/services/TrendVisionOneEndpointService");
const GenericSourceUtils_1 = require("./generic/GenericSourceUtils");
const GenericSourceEndpointService_1 = require("../collectors/services/GenericSourceEndpointService");
class ProcessingUtil {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.timestreamUtil = new TimestreamUtil_1.TimestreamUtil();
        this.timestreamRequestBuilder = new TimestreamRequestBuilder_1.TimestreamRequestBuilder();
        const envBulkSize = _.parseInt(process.env.ENTRIES_BULK_SIZE || '');
        this.bulkSize = Number.isInteger(envBulkSize) ? envBulkSize : ProcessingUtil.DEFAULT_BULK_SIZE;
        this.preProcessingStream = new KinesisBatchServices_1.KinesisBatchServices(KinesisHelper_1.PRE_PROCESSING_STREAM, this.bulkSize);
        this.processingStream = new ShardedKinesisBatchServices_1.ShardedKinesisBatchServices(JSON.parse(process.env.PROCESSING_STREAM_SETTINGS || '[]'), this.bulkSize);
        this.tenantServices = new TenantServices_1.TenantServices();
    }
    async backupRecords(records) {
        const date = Date.now();
        const fds = [];
        try {
            for (const record of records) {
                const recordData = (0, KinesisHelper_1.decodeData)(record);
                const { backupFile, fd, isNew } = ProcessingUtil.getBackupFileFd(fds, recordData.producer, recordData.tenantUid, date);
                if (isNew) {
                    fds.push({ backupFile, fd });
                }
                fs_1.default.writeSync(fd, `${JSON.stringify(recordData.data)}\n`);
            }
        }
        finally {
            for await (const backupFileFd of fds) {
                await ProcessingUtil.uploadFileToS3(backupFileFd.backupFile);
                fs_1.default.closeSync(backupFileFd.fd);
            }
        }
    }
    static getBackupFileFd(fds, producer, tenantUid, date) {
        const backupFile = ProcessingUtil.getFileMetadata(producer, tenantUid, date);
        const backupFileFd = _.find(fds, { backupFile });
        if (!backupFileFd) {
            const fd = fs_1.default.openSync(backupFile.filePath, 'w');
            return { backupFile, fd, isNew: true };
        }
        return backupFileFd;
    }
    static getMetricValueOrZero(metrics, name) {
        return _.get(_.find(metrics, { name }), 'value', 0);
    }
    async collectionProcessing(collection, producer, tenantUid, tenantName, shouldSkipPredicate, isLinkable) {
        let recordsTotal = 0;
        await collection.each((item) => {
            recordsTotal += 1;
            return ProcessingUtil.addRecordToBatch(this.preProcessingStream, item, producer, tenantUid, tenantName);
        }, shouldSkipPredicate, isLinkable);
        await this.preProcessingStream.commit();
        const metrics = [new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, recordsTotal)];
        this.addRecordMetrics(metrics, tenantUid, producer, CommonTypes_1.WorkFlow.COLLECTION);
        try {
            await this.reportCurrentMetrics();
        }
        catch (error) {
            this.logger.error('Error reporting current metrics to kinesis stream in collectionProcessing', error);
        }
    }
    getFileUploadUrl(tenantUid, sourceId) {
        if (!process.env.S3_BUCKET) {
            throw new Error('S3_BUCKET is not set');
        }
        const date = Date.now();
        const s3Key = `${ProcessingUtil.S3_WORK_DIR}/${CommonTypes_1.Source.CUSTOM}__${sourceId}/${CommonTypes_1.Source.CUSTOM}__${sourceId}.${tenantUid}.${date}.csv`;
        const s3Services = new S3Services_1.S3Services(process.env.S3_BUCKET);
        return s3Services.getSignedUrlForPutObject(s3Key);
    }
    async getCollectionErrors(tenantUid) {
        const collectionErrors = [];
        const producerConfigurations = await this.tenantServices.getProducerConfigurations(tenantUid);
        const functionStateServices = new FunctionStateServices_1.FunctionStateServices();
        for (const producerConfiguration of producerConfigurations) {
            const { producerType, producerId } = producerConfiguration;
            if ((0, CommonTypes_1.sourceNotSupportingPull)(producerType)) {
                continue;
            }
            const source = (0, Util_1.toSourceString)(producerType, producerId);
            let functionName;
            if (await this.tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.GENERIC_SOURCE) && GenericSourceUtils_1.GenericSourceUtils.isSourceConfiguration(producerType)) {
                functionName = 'fetch-generic-devices';
            }
            else {
                functionName = `${process.env.ENV_PREFIX}-${(0, CommonTypes_1.sourceToFetchFunctionName)(producerType)}`;
            }
            const functionState = await functionStateServices.getByKey(tenantUid, functionName, source);
            const state = FunctionStateServices_1.FunctionStateServices.getState(functionState);
            if (_.has(state, FunctionStateServices_1.FunctionState.COLLECTION_ERROR)) {
                collectionErrors.push({
                    producerType,
                    producerId,
                    collectionError: JSON.stringify(_.get(state, FunctionStateServices_1.FunctionState.COLLECTION_ERROR))
                });
            }
        }
        return collectionErrors;
    }
    static addRecordToBatch(kinesisBatchService, item, producer, tenantUid, tenantName) {
        const data = JSON.stringify((0, KinesisHelper_1.getRecordData)(producer, tenantUid, item, tenantName));
        return kinesisBatchService.addRecord({
            Data: data,
            PartitionKey: (0, KinesisHelper_1.getPK)(producer, tenantUid, [(0, uuid_1.v4)()])
        });
    }
    static async uploadFileToS3(backupFile) {
        const s3Services = new S3Services_1.S3Services(backupFile.bucket);
        await s3Services.uploadFile(backupFile.bucketPath, backupFile.filePath);
    }
    static getFileMetadata(source, tenantUid, date, bucketRoot = ProcessingUtil.S3_DONE_DIR) {
        if (!process.env.S3_BUCKET) {
            throw new Error('S3_BUCKET is not set');
        }
        const bucket = process.env.S3_BUCKET;
        const fileName = `${source}.${tenantUid}.${date}.json`;
        const filePath = `/tmp/${fileName}`;
        const bucketPath = `${bucketRoot}/${source}/${fileName}`;
        return {
            fileName,
            filePath,
            bucketPath,
            bucket
        };
    }
    static async validateAndTransformValues(tenantUid, parsedLine, labelMap) {
        if (parsedLine.osType) {
            const osType = (0, CommonTypes_1.getOsType)(parsedLine.osType);
            if (osType === CommonTypes_1.OS.UNKNOWN) {
                throw new Error(`Unsupported os type: ${parsedLine.osType}. Use one of ${Object.values(CommonTypes_1.OS)} only`);
            }
            else {
                parsedLine.osType = osType;
            }
        }
        if (parsedLine.lastUpdated && (!Number.isInteger(Number(parsedLine.lastUpdated)) || Number(parsedLine.lastUpdated) <= 0)) {
            throw new Error(`lastUpdated: ${parsedLine.lastUpdated} is not a valid number. Use number of milliseconds since the UNIX epoch only`);
        }
        if (parsedLine.labels) {
            if (!Array.isArray(parsedLine.labels)) {
                parsedLine.labels = [parsedLine.labels];
            }
            parsedLine.labelIds = await ProcessingUtil.convertLabelNamesIntoIds(tenantUid, parsedLine.labels, labelMap);
            delete parsedLine.labels;
        }
        if (parsedLine.assetValue || parsedLine.value) {
            parsedLine.assetValue = parseInt(parsedLine.value ? parsedLine.value : parsedLine.assetValue, 10);
            if (parsedLine.assetValue > 10 || parsedLine.assetValue < 1) {
                throw new Error(`value is out of range [1-10]: ${parsedLine.assetValue}`);
            }
            if (Number.isNaN(parsedLine.assetValue)) {
                throw new Error(`value is not a number [1-10]: ${parsedLine.assetValue}`);
            }
            delete parsedLine.value;
        }
    }
    static async convertLabelNamesIntoIds(partitionKey, labelNames, labelMap) {
        let labelService;
        if (!labelMap) {
            labelService = new LabelService_1.LabelService(partitionKey);
            labelMap = await labelService.getLabelsMetadataMap();
        }
        const labelIds = [];
        for (const newLabelName of labelNames) {
            let labelFound = false;
            if (labelMap.has(newLabelName)) {
                labelIds.push(newLabelName);
                continue;
            }
            for (const [labelId, existingLabel] of labelMap) {
                if (newLabelName === existingLabel.name) {
                    labelIds.push(labelId);
                    labelFound = true;
                    break;
                }
            }
            if (!labelFound) {
                const newLabelColor = '#00ACC1';
                const newLabel = { name: newLabelName, color: newLabelColor };
                if (!labelService) {
                    labelService = new LabelService_1.LabelService(partitionKey);
                }
                const createdLabel = await labelService.createLabel(newLabel);
                const createdLabelId = createdLabel.labelId;
                labelIds.push(createdLabelId);
                labelMap.set(createdLabelId, createdLabel);
            }
        }
        return _.uniq(labelIds);
    }
    async s3UploadFileTrigger(s3Event) {
        const { objectKey, fileName, s3Services, tempFileName } = this.createReadStreamForS3Object(s3Event);
        const { producer, tenantUid, fileFormat } = ProcessingUtil.getFromS3FileName(fileName);
        let recordsTotal = 0;
        let recordsFailed = 0;
        let headers = [];
        let parsedLine;
        try {
            await this.reportWorkflowState(TimestreamWriteServices_1.MetricName.WORKFLOW_STARTED, tenantUid, producer, CommonTypes_1.WorkFlow.COLLECTION);
            const labelMap = await (new LabelService_1.LabelService(tenantUid)).getLabelsMetadataMap();
            const res = await s3Services.getObject(objectKey);
            fs_1.default.writeFileSync(tempFileName, await (0, Util_1.streamToString)(res.Body));
            const rl = readline_1.default.createInterface({
                input: fs_1.default.createReadStream(tempFileName)
            });
            let firstLine = true;
            for await (const line of rl) {
                if (firstLine && ProcessingUtil.isCsvFormat(fileFormat)) {
                    headers = ProcessingUtil.parseAndValidateHeaders(line, producer);
                    firstLine = false;
                    continue;
                }
                try {
                    parsedLine = (ProcessingUtil.isCsvFormat(fileFormat))
                        ? _.first(await (0, csvtojson_1.default)({ headers, noheader: true, checkColumn: true }).fromString(line)) : JSON.parse(line);
                    await ProcessingUtil.validateAndTransformValues(tenantUid, parsedLine, labelMap);
                    await ProcessingUtil.addRecordToBatch(this.preProcessingStream, parsedLine, producer, tenantUid);
                }
                catch (err) {
                    this.logger.error(`failed to parse this line for tenant ${tenantUid}:`, line, err);
                    recordsFailed += 1;
                }
                finally {
                    recordsTotal += 1;
                }
            }
            await this.preProcessingStream.commit();
            const metrics = [new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, recordsTotal), new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_FAILED, recordsFailed)];
            this.addRecordMetrics(metrics, tenantUid, producer, CommonTypes_1.WorkFlow.COLLECTION);
            try {
                await this.reportCurrentMetrics();
            }
            catch (error) {
                this.logger.error('Error reporting current metrics to kinesis stream in s3UploadFileTrigger', error);
            }
        }
        finally {
            await ProcessingUtil.cleanup(fileFormat, objectKey, s3Services);
            await this.reportWorkflowState(TimestreamWriteServices_1.MetricName.WORKFLOW_COMPLETED, tenantUid, producer, CommonTypes_1.WorkFlow.COLLECTION);
        }
    }
    async parseOrbitalWebhookNotificationS3File(s3Event) {
        var _a, _b, _c, _d;
        const { objectKey, s3Services } = this.createReadStreamForS3Object(s3Event);
        if (objectKey === 'orbital-rds-ping.json') {
            this.logger.debug('received ping from Orbital webhook');
            return undefined;
        }
        const res = await s3Services.getObject(objectKey);
        const notificationData = JSON.parse(await (0, Util_1.streamToString)(res.Body) || '{}');
        const extId = (_b = (_a = _.get(notificationData, 'job-results')[0]) === null || _a === void 0 ? void 0 : _a.results[0]) === null || _b === void 0 ? void 0 : _b.organization;
        const osQueryId = (_d = (_c = _.get(notificationData, 'job-results')[0]) === null || _c === void 0 ? void 0 : _c.query) === null || _d === void 0 ? void 0 : _d.id;
        if (!extId || !osQueryId) {
            throw new Error('missing extId or osQueryId in job-results');
        }
        const { tenantUid, producerId } = await this.tenantServices.getOrbitalProducerByQueryId(extId, osQueryId);
        return {
            tenantUid,
            producerId,
            notificationData
        };
    }
    async processNotifications(body, tenantUid, producer) {
        const processor = await this.getEndpointServiceOrFail(producer, tenantUid);
        if (!processor) {
            throw new Error(`Failed to find service for ${producer}`);
        }
        const started = Date.now();
        const metrics = [];
        if (processor.isDeleteEvent(body)) {
            const deletedEvents = processor.getDeletedEvents(body);
            _.forEach(deletedEvents, (record) => {
                ProcessingUtil.addRecordToBatch(this.preProcessingStream, record, producer, tenantUid);
            });
            await this.preProcessingStream.commit();
            metrics.push(new TimestreamWriteServices_1.Metric(CommonTypes_1.ChangeType.DELETE, deletedEvents.length), new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, deletedEvents.length));
        }
        else {
            const records = processor.processNotifications(body);
            _.forEach(records, (record) => {
                ProcessingUtil.addRecordToBatch(this.preProcessingStream, record, producer, tenantUid);
            });
            await this.preProcessingStream.commit();
            metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, records.length));
        }
        metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.DURATION, Date.now() - started));
        this.addRecordMetrics(metrics, tenantUid, producer, CommonTypes_1.WorkFlow.NOTIFICATION_PROCESSING);
        try {
            await this.reportCurrentMetrics();
        }
        catch (error) {
            this.logger.error('Error reporting current metrics to kinesis stream in processNotifications', error);
        }
    }
    async triggerFetchForTenantAndProducer(tenantUid, source, sourceId, snsServices, onDemand, metricName) {
        let snsTopicArnName = `${_.toUpper(source)}_SNS_TOPIC_ARN`;
        if (await this.tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.GENERIC_SOURCE) && GenericSourceUtils_1.GenericSourceUtils.isSourceConfiguration(source)) {
            snsTopicArnName = 'GENERIC_SNS_TOPIC_ARN';
        }
        const snsTopicArn = process.env[snsTopicArnName];
        if (!snsTopicArn) {
            throw new Error(`${snsTopicArnName} is not set`);
        }
        const cfgKey = (0, Util_1.toSourceString)(source, sourceId);
        const tenantConfiguration = await this.tenantServices.getTenantConfiguration(tenantUid, cfgKey);
        if (tenantConfiguration) {
            const parsedTenantConfiguration = JSON.parse(tenantConfiguration.value);
            if (!onDemand && !(0, Util_1.isScheduledForNextWindow)(parsedTenantConfiguration.schedule, ProcessingUtil.SCHEDULE_WINDOW_IN_MILLISECONDS)) {
                return;
            }
            this.reportMetrics([new TimestreamWriteServices_1.Metric(metricName)], tenantUid, cfgKey, CommonTypes_1.WorkFlow.COLLECTION);
            const snsMessage = {
                tenant: _.merge({
                    tenantUid
                }, _.omit(parsedTenantConfiguration, 'schedule'))
            };
            const attributes = {
                target: { DataType: 'String', StringValue: 'fetch' }
            };
            try {
                await snsServices.publish(snsTopicArn, JSON.stringify(snsMessage), attributes);
            }
            catch (e) {
                throw new Error(`Failed to trigger fetch posture data for tenant: ${tenantUid}, producer: ${source}, sourceId: ${sourceId}, with error: ${e.message}`);
            }
        }
    }
    static parseAndValidateHeaders(line, producer) {
        const headers = _.split(line, ',');
        if (ProcessingUtil.isCustomSource(producer) && _.indexOf(headers, CommonTypes_1.VertexBasicProperty.EXT_ID) === -1) {
            throw new Error(`csv header does not include mandatory property: ${CommonTypes_1.VertexBasicProperty.EXT_ID}`);
        }
        return headers;
    }
    static cleanup(fileFormat, objectKey, s3Services) {
        if (ProcessingUtil.isCsvFormat(fileFormat)) {
            const destinationObjectKey = _.replace(objectKey, ProcessingUtil.S3_WORK_DIR, ProcessingUtil.S3_DONE_DIR);
            return s3Services.moveObject(objectKey, destinationObjectKey);
        }
        return s3Services.deleteObject(objectKey);
    }
    static getFromS3FileName(fileName) {
        const splittedFileName = _.split(fileName, '.');
        const producer = _.nth(splittedFileName, 0);
        const tenantUid = _.nth(splittedFileName, 1);
        const fileFormat = _.nth(splittedFileName, 3);
        if (!producer) {
            throw new Error(`Can't parse producer from the objectKey: ${fileName}`);
        }
        if (!tenantUid) {
            throw new Error(`Can't parse tenantUid from the objectKey: ${fileName}`);
        }
        if (!fileFormat) {
            throw new Error(`Can't parse fileFormat from the objectKey: ${fileName}`);
        }
        return { producer, tenantUid, fileFormat };
    }
    createReadStreamForS3Object(s3Event) {
        const objectKey = decodeURIComponent(s3Event.object.key.replace(/\+/g, ' '));
        const bucketName = s3Event.bucket.name;
        this.logger.debug(`triggered for object ${objectKey} in bucket: ${bucketName}`);
        const s3Services = new S3Services_1.S3Services(bucketName);
        const fileName = objectKey.split('/').pop() || '';
        const tempFileName = `/tmp/${fileName}`;
        return { objectKey, fileName, s3Services, tempFileName };
    }
    reportMetrics(metrics, tenantUid, producer, workflow) {
        const timestreamRequestBuilder = new TimestreamRequestBuilder_1.TimestreamRequestBuilder();
        timestreamRequestBuilder.add(metrics, TimestreamRequestBuilder_1.TimestreamRequestBuilder.basicDimensions(tenantUid, producer, workflow));
        return this.timestreamUtil.sendRequestsToStream(timestreamRequestBuilder.createRequestsAndReset());
    }
    reportWorkflowState(state, tenantUid, producer, workflow) {
        return this.reportMetrics([new TimestreamWriteServices_1.Metric(state)], tenantUid, producer, workflow);
    }
    addRecordMetrics(metrics, tenantUid, producer, workflow) {
        const dimensions = TimestreamRequestBuilder_1.TimestreamRequestBuilder.basicDimensions(tenantUid, producer, workflow);
        this.timestreamRequestBuilder.add(metrics, dimensions);
    }
    static isCustomSource(source) {
        return _.startsWith(source, CommonTypes_1.Source.CUSTOM);
    }
    static isCsvFormat(fileFormat) {
        return fileFormat === 'csv';
    }
    reportCurrentMetrics() {
        return this.timestreamUtil.sendRequestsToStream(this.timestreamRequestBuilder.createRequestsAndReset());
    }
    async getEndpointServiceOrFail(producer, tenantUid) {
        const source = _.split(producer, Util_1.SOURCE_SEPARATOR)[0];
        if (await this.tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.GENERIC_SOURCE) && GenericSourceUtils_1.GenericSourceUtils.isSourceConfiguration(source)) {
            return new GenericSourceEndpointService_1.GenericSourceEndpointService(tenantUid, source, GenericSourceUtils_1.GenericSourceUtils.getSourceConfiguration(source));
        }
        switch (source) {
            case CommonTypes_1.Source.DUO:
                return new DuoEndpointService_1.DuoEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.DUO_USERS:
                return new DuoUserService_1.DuoUserService(tenantUid, producer);
            case CommonTypes_1.Source.JAMF:
                return new JamfEndpointService_1.JamfEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.INTUNE:
                return new InTuneEndpointService_1.InTuneEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.MERAKI:
                return new MerakiEndpointService_1.MerakiEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.AMP:
                return new AmpEndpointService_1.AmpEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.ORBITAL:
                return new OrbitalEndpointService_1.OrbitalEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.UMBRELLA:
                return new UmbrellaEndpointService_1.UmbrellaEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.MOBILEIRON:
                return new MobileIronEndpointService_1.MobileIronEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.UNIFIED_CONNECTOR:
                return new UnifiedConnectorEndpointService_1.UnifiedConnectorEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.AIRWATCH:
                return new AirWatchEndpointService_1.AirWatchEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.SERVICENOW:
                return new ServiceNowEndpointService_1.ServiceNowEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.SENTINEL_ONE:
                return new SentinelOneEndpointService_1.SentinelOneEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.CYBERVISION:
                return new CyberVisionEndpointService_1.CyberVisionEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.CROWDSTRIKE:
                return new CrowdStrikeEndpointService_1.CrowdStrikeEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.DEFENDER:
                return new DefenderEndpointService_1.DefenderEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.AZURE_USERS:
                return new AzureUserService_1.AzureUserService(tenantUid, producer);
            case CommonTypes_1.Source.TREND_VISION_ONE:
                return new TrendVisionOneEndpointService_1.TrendVisionOneEndpointService(tenantUid, producer);
            case CommonTypes_1.Source.CUSTOM:
                return new CustomEndpointService_1.CustomEndpointService(tenantUid, producer);
            default:
                return undefined;
        }
    }
}
exports.ProcessingUtil = ProcessingUtil;
ProcessingUtil.DEFAULT_BULK_SIZE = 100;
ProcessingUtil.S3_WORK_DIR = 'work';
ProcessingUtil.S3_DONE_DIR = 'done';
ProcessingUtil.SCHEDULE_WINDOW_IN_MILLISECONDS = 15 * 60 * 1000;
