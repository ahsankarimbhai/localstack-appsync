"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cloneVertex = exports.createVertexOfType = exports.createSimpleVertex = exports.createComplexVertexWithPreProcess = exports.createComplexVertex = exports.ALL_MODELS = exports.SIMPLE_MODELS = exports.COMPLEX_MODELS = void 0;
const _ = __importStar(require("lodash"));
const AmpComputerModel_1 = require("./AmpComputerModel");
const MerakiDeviceModel_1 = require("./MerakiDeviceModel");
const JamfComputerModel_1 = require("./JamfComputerModel");
const SharedTypesModel_1 = require("./SharedTypesModel");
const DuoEndpointModel_1 = require("./DuoEndpointModel");
const DuoUserModel_1 = require("./DuoUserModel");
const InTuneDeviceModel_1 = require("./InTuneDeviceModel");
const OrbitalEndpointModel_1 = require("./OrbitalEndpointModel");
const PostureEndpointModel_1 = require("./PostureEndpointModel");
const PosturePersonModel_1 = require("./PosturePersonModel");
const CustomEndpointModel_1 = require("./CustomEndpointModel");
const UmbrellaRoamingComputerModel_1 = require("./UmbrellaRoamingComputerModel");
const MobileIronDeviceModel_1 = require("./MobileIronDeviceModel");
const UnifiedConnectorDeviceModel_1 = require("./UnifiedConnectorDeviceModel");
const AirWatchDeviceModel_1 = require("./AirWatchDeviceModel");
const ServiceNowDeviceModel_1 = require("./ServiceNowDeviceModel");
const CyberVisionDeviceModel_1 = require("./CyberVisionDeviceModel");
const SentinelOneDeviceModel_1 = require("./SentinelOneDeviceModel");
const CrowdStrikeDeviceModel_1 = require("./CrowdStrikeDeviceModel");
const DefenderDeviceModel_1 = require("./DefenderDeviceModel");
const AzureUserModel_1 = require("./AzureUserModel");
const TrendVisionOneDeviceModel_1 = require("./TrendVisionOneDeviceModel");
const GenericSourceDeviceModel_1 = require("./GenericSourceDeviceModel");
exports.COMPLEX_MODELS = {
    ampComputer: AmpComputerModel_1.AmpComputerModel,
    ampComputerState: AmpComputerModel_1.AmpComputerStateModel,
    merakiSmDevice: MerakiDeviceModel_1.MerakiDeviceModel,
    merakiSmDeviceState: MerakiDeviceModel_1.MerakiDeviceStateModel,
    jamfComputer: JamfComputerModel_1.JamfComputerModel,
    jamfComputerState: JamfComputerModel_1.JamfComputerStateModel,
    umbrellaRoamingComputer: UmbrellaRoamingComputerModel_1.UmbrellaRoamingComputerModel,
    umbrellaRoamingComputerState: UmbrellaRoamingComputerModel_1.UmbrellaRoamingComputerStateModel,
    mobileIronDevice: MobileIronDeviceModel_1.MobileIronDeviceModel,
    mobileIronDeviceState: MobileIronDeviceModel_1.MobileIronDeviceStateModel,
    unifiedConnectorDevice: UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceModel,
    unifiedConnectorDeviceState: UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel,
    duoEndpoint: DuoEndpointModel_1.DuoEndpointModel,
    duoEndpointState: DuoEndpointModel_1.DuoEndpointStateModel,
    duoUser: DuoUserModel_1.DuoUserModel,
    duoUserState: DuoUserModel_1.DuoUserStateModel,
    inTuneDevice: InTuneDeviceModel_1.InTuneDeviceModel,
    inTuneDeviceState: InTuneDeviceModel_1.InTuneDeviceStateModel,
    airWatchDevice: AirWatchDeviceModel_1.AirWatchDeviceModel,
    airWatchDeviceState: AirWatchDeviceModel_1.AirWatchDeviceStateModel,
    postureEndpoint: PostureEndpointModel_1.PostureEndpointModel,
    posturePerson: PosturePersonModel_1.PosturePersonModel,
    orbitalEndpoint: OrbitalEndpointModel_1.OrbitalEndpointModel,
    orbitalEndpointState: OrbitalEndpointModel_1.OrbitalEndpointStateModel,
    customEndpoint: CustomEndpointModel_1.CustomEndpointModel,
    customEndpointState: CustomEndpointModel_1.CustomEndpointStateModel,
    browser: SharedTypesModel_1.Browser,
    serviceNowDevice: ServiceNowDeviceModel_1.ServiceNowDeviceModel,
    serviceNowDeviceState: ServiceNowDeviceModel_1.ServiceNowDeviceStateModel,
    sentinelOneDevice: SentinelOneDeviceModel_1.SentinelOneDeviceModel,
    sentinelOneDeviceState: SentinelOneDeviceModel_1.SentinelOneDeviceStateModel,
    cyberVisionDevice: CyberVisionDeviceModel_1.CyberVisionDeviceModel,
    cyberVisionDeviceState: CyberVisionDeviceModel_1.CyberVisionDeviceStateModel,
    crowdStrikeDevice: CrowdStrikeDeviceModel_1.CrowdStrikeDeviceModel,
    crowdStrikeDeviceState: CrowdStrikeDeviceModel_1.CrowdStrikeDeviceStateModel,
    defenderDevice: DefenderDeviceModel_1.DefenderDeviceModel,
    defenderDeviceState: DefenderDeviceModel_1.DefenderDeviceStateModel,
    azureUser: AzureUserModel_1.AzureUserModel,
    azureUserState: AzureUserModel_1.AzureUserStateModel,
    trendVisionOneDevice: TrendVisionOneDeviceModel_1.TrendVisionOneDeviceModel,
    trendVisionOneDeviceState: TrendVisionOneDeviceModel_1.TrendVisionOneDeviceStateModel,
    genericSourceDevice: GenericSourceDeviceModel_1.GenericSourceDeviceModel,
    genericSourceDeviceState: GenericSourceDeviceModel_1.GenericSourceDeviceStateModel
};
exports.SIMPLE_MODELS = {
    externalIpAddress: SharedTypesModel_1.ExternalIpAddress,
    macAddress: SharedTypesModel_1.MacAddress,
    hardwareId: SharedTypesModel_1.HardwareId,
    computerSID: SharedTypesModel_1.ComputerSID,
    serialNumber: SharedTypesModel_1.SerialNumber,
    cookie: SharedTypesModel_1.Cookie,
    user: SharedTypesModel_1.User,
    appUser: SharedTypesModel_1.AppUser,
    email: SharedTypesModel_1.Email,
    imei: SharedTypesModel_1.Imei,
    phoneNumber: SharedTypesModel_1.PhoneNumber,
    hostname: SharedTypesModel_1.Hostname,
    externalReference: SharedTypesModel_1.ExternalReference
};
exports.ALL_MODELS = { ...exports.SIMPLE_MODELS, ...exports.COMPLEX_MODELS };
async function createComplexVertex(name, label, partitionKey, input, source, sourceConfiguration) {
    const vertex = createVertexOfType(name, partitionKey);
    vertex.setLabel(label);
    await vertex.initVertex(input, source, sourceConfiguration);
    return vertex;
}
exports.createComplexVertex = createComplexVertex;
async function createComplexVertexWithPreProcess(name, label, partitionKey, input, source, sourceConfiguration) {
    const vertex = createVertexOfType(name, partitionKey);
    vertex.setLabel(label);
    await vertex.preProcessInitVertex(input, partitionKey, source);
    await vertex.initVertex(input, source, sourceConfiguration);
    return vertex;
}
exports.createComplexVertexWithPreProcess = createComplexVertexWithPreProcess;
async function createSimpleVertex(name, partitionKey, value, input) {
    const vertex = createVertexOfType(name, partitionKey);
    vertex.setValue(value);
    vertex.setLabel(vertex.type);
    await vertex.initVertex(input || {});
    return vertex;
}
exports.createSimpleVertex = createSimpleVertex;
function createVertexOfType(name, partitionKey) {
    const ctor = exports.ALL_MODELS[name];
    return new ctor(partitionKey);
}
exports.createVertexOfType = createVertexOfType;
function cloneVertex(partitionKey, vertex) {
    if (!vertex) {
        throw new Error('cannot clone undefined vertex');
    }
    const name = vertex.type;
    const ctor = exports.ALL_MODELS[name];
    const newVertex = new ctor(partitionKey);
    newVertex.properties = vertex.properties;
    newVertex.setLabel(vertex.getLabel());
    newVertex.secondaryLabels = vertex.secondaryLabels;
    newVertex.updateId(_.get(vertex, 'id'));
    return newVertex;
}
exports.cloneVertex = cloneVertex;
