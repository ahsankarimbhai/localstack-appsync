"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupServices = void 0;
const _ = __importStar(require("lodash"));
const DynamoDBServices_1 = require("../../common/awsclient/dynamodb/DynamoDBServices");
const TenantServices_1 = require("../../common/TenantServices");
const DateUtils_1 = require("../../common/DateUtils");
const Util_1 = require("../../common/Util");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const DynamodbServiceFactory_1 = require("../../common/awsclient/dynamodb/DynamodbServiceFactory");
class GroupServices {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    upsertGroup(group) {
        return this.dynamoDBServices.save(GroupServices.TABLE_NAME, {
            ...group,
            lowercaseName: _.toLower(group.name),
            tenantKey: this.getGroupKey(group),
            tenantUid: this.tenantUid,
            timeToExpire: Math.floor(Date.now() / 1000) + GroupServices.TTL_SECONDS
        });
    }
    getGroupKey(group) {
        return TenantServices_1.TenantServices.getTenantConfigKey(this.tenantUid, [group.id, group.source, group.sourceId].join(Util_1.SOURCE_SEPARATOR));
    }
    getGroup(group) {
        return this.dynamoDBServices.getByKey(GroupServices.TABLE_NAME, GroupServices.TENANT_KEY, this.getGroupKey(group));
    }
    async getGroups(filter, lastEvaluatedKey) {
        let expression;
        let expressionAttributeValues;
        if (filter) {
            expression = 'contains(lowercaseName, :filter)';
            expressionAttributeValues = { ':filter': _.toLower(filter) };
        }
        return this.dynamoDBServices.getItemsBySecondaryIndex(GroupServices.TABLE_NAME, GroupServices.getDynamoDBTenantUidIndex(), GroupServices.TENANT_UID, this.tenantUid, expression, undefined, expressionAttributeValues, lastEvaluatedKey);
    }
    async countGroupsForSource(source) {
        return this.dynamoDBServices.getItemCountBySecondaryIndex(GroupServices.TABLE_NAME, GroupServices.getDynamoDBTenantUidIndex(), GroupServices.TENANT_UID, this.tenantUid, '#source = :s', { '#source': 'source' }, { ':s': source });
    }
    async removeAllGroups() {
        this.logger.info(`All groups for the tenant ${this.tenantUid} will be deleted`);
        return this.deleteGroups(await this.getGroups());
    }
    deleteGroups(groups) {
        return Promise.all(_.map(groups, (group) => this.deleteByKey(_.get(group, GroupServices.TENANT_KEY))));
    }
    deleteByKey(tenantKey) {
        return this.dynamoDBServices.delete(GroupServices.TABLE_NAME, GroupServices.TENANT_KEY, tenantKey);
    }
    static getDynamoDBTenantUidIndex() {
        return DynamoDBServices_1.DynamoDBServices.getTableName(GroupServices.TENANT_UID_INDEX);
    }
}
exports.GroupServices = GroupServices;
GroupServices.TABLE_NAME = 'group';
GroupServices.TENANT_KEY = 'tenantKey';
GroupServices.TENANT_UID = 'tenantUid';
GroupServices.TENANT_UID_INDEX = 'group-tenant-uid-idx';
GroupServices.TTL_SECONDS = 30 * DateUtils_1.DAY_SECONDS;
