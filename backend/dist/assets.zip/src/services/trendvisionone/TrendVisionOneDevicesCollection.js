"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrendVisionOneDevicesCollection = void 0;
const TrendVisionOneCollection_1 = require("./TrendVisionOneCollection");
class TrendVisionOneDevicesCollection extends TrendVisionOneCollection_1.TrendVisionOneCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.TrendVisionOneDevicesCollection = TrendVisionOneDevicesCollection;
