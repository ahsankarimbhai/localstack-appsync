"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericSourceCollection = void 0;
const Collection_1 = require("../../common/Collection");
class GenericSourceCollection extends Collection_1.Collection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, () => undefined, () => undefined, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.GenericSourceCollection = GenericSourceCollection;
