"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuoAuthLogsCollection = void 0;
const lodash_1 = __importDefault(require("lodash"));
const Collection_1 = require("../../common/Collection");
class DuoAuthLogsCollection extends Collection_1.Collection {
    constructor(fetcher, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(fetcher, uri, () => undefined, lodash_1.default.noop, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.DuoAuthLogsCollection = DuoAuthLogsCollection;
