"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneClient = void 0;
const lodash_1 = __importDefault(require("lodash"));
const gremlin_1 = require("gremlin");
const LambdaLogger_1 = require("../LambdaLogger");
var DriverRemoteConnection = gremlin_1.driver.DriverRemoteConnection;
var Graph = gremlin_1.structure.Graph;
class NeptuneClient {
    constructor(url, options = { rejectUnauthorized: false }, repeatMode, evaluationTimeout = 60000) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.driverRemoteConnection = new DriverRemoteConnection(url, options);
        this.driverRemoteConnection.addListener('close', (code, message) => {
            if (code === 1006) {
                this.logger.warn(`Neptune connection closed prematurely, ${message}`);
            }
        });
        this.repeatMode = repeatMode || 'BFS';
        this.evaluationTimeout = evaluationTimeout;
    }
    getDriverRemoteConnection() {
        return this.driverRemoteConnection;
    }
    closeConnection() {
        return this.getDriverRemoteConnection().close();
    }
    getGraphTraversalSource() {
        const traversalSource = new Graph().traversal()
            .withRemote(this.getDriverRemoteConnection())
            .withSideEffect('Neptune#repeatMode', this.repeatMode)
            .with_('evaluationTimeout', this.evaluationTimeout);
        const implV = lodash_1.default.bind(traversalSource.V, traversalSource);
        const loggingV = function (...args) {
            const res = implV(...args);
            const implToList = lodash_1.default.bind(res.toList, res);
            const loggingToList = function () {
                return implToList().catch((e) => {
                    new LambdaLogger_1.LambdaLogger().error(`Error executing Neptune toList: ${JSON.stringify(res.getBytecode())}`);
                    throw e;
                });
            };
            res.toList = lodash_1.default.bind(loggingToList, res);
            const implIterate = lodash_1.default.bind(res.iterate, res);
            const loggingIterate = function () {
                return implIterate().catch((e) => {
                    new LambdaLogger_1.LambdaLogger().error(`Error executing Neptune iterate: ${JSON.stringify(res.getBytecode())}`);
                    throw e;
                });
            };
            res.iterate = lodash_1.default.bind(loggingIterate, res);
            const implNext = lodash_1.default.bind(res.next, res);
            const loggingNext = function () {
                return implNext().catch((e) => {
                    new LambdaLogger_1.LambdaLogger().error(`Error executing Neptune next: ${JSON.stringify(res.getBytecode())}`);
                    throw e;
                });
            };
            res.next = lodash_1.default.bind(loggingNext, res);
            return res;
        };
        traversalSource.V = lodash_1.default.bind(loggingV, traversalSource);
        return traversalSource;
    }
}
exports.NeptuneClient = NeptuneClient;
