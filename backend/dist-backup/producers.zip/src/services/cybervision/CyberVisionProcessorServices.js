"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CyberVisionProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const CyberVisionEndpointService_1 = require("../../collectors/services/CyberVisionEndpointService");
class CyberVisionProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(cyberVisionDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, cyberVisionDevice.id, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new CyberVisionEndpointService_1.CyberVisionEndpointService(tenantUid, sourceId);
    }
}
exports.CyberVisionProcessorServices = CyberVisionProcessorServices;
