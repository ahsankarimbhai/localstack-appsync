"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceNowSystemRuleService = void 0;
const RuleService_1 = require("../common/RuleService");
const CommonTypes_1 = require("../../common/CommonTypes");
const uuid_1 = require("uuid");
const ProducerSystemRuleService_1 = require("../common/ProducerSystemRuleService");
class ServiceNowSystemRuleService extends ProducerSystemRuleService_1.ProducerSystemRuleService {
    constructor() {
        super(...arguments);
        this.sourceType = CommonTypes_1.Source.SERVICENOW;
    }
    getSystemRules(sourceId) {
        const newRules = [];
        newRules.push({ ruleId: (0, uuid_1.v4)(), name: 'ServiceNow Value 1', description: 'Set asset value to 10', actionToTake: { setAssetValue: 10 }, matchingCondition: { producers: [{ type: this.sourceType, producerId: sourceId, assetValue: '1 - most critical' }] }, origin: RuleService_1.RuleOrigin.SYSTEM, enabled: true });
        newRules.push({ ruleId: (0, uuid_1.v4)(), name: 'ServiceNow Value 2', description: 'Set asset value to 6', actionToTake: { setAssetValue: 6 }, matchingCondition: { producers: [{ type: this.sourceType, producerId: sourceId, assetValue: '2 - somewhat critical' }] }, origin: RuleService_1.RuleOrigin.SYSTEM, enabled: true });
        newRules.push({ ruleId: (0, uuid_1.v4)(), name: 'ServiceNow Value 3', description: 'Set asset value to 3', actionToTake: { setAssetValue: 3 }, matchingCondition: { producers: [{ type: this.sourceType, producerId: sourceId, assetValue: '3 - less critical' }] }, origin: RuleService_1.RuleOrigin.SYSTEM, enabled: true });
        newRules.push({ ruleId: (0, uuid_1.v4)(), name: 'ServiceNow Value 4', description: 'Set asset value to 1', actionToTake: { setAssetValue: 1 }, matchingCondition: { producers: [{ type: this.sourceType, producerId: sourceId, assetValue: '4 - not critical' }] }, origin: RuleService_1.RuleOrigin.SYSTEM, enabled: true });
        return newRules;
    }
}
exports.ServiceNowSystemRuleService = ServiceNowSystemRuleService;
