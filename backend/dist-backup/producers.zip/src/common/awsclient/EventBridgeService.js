"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventBridgeService = void 0;
const client_eventbridge_1 = require("@aws-sdk/client-eventbridge");
const LambdaLogger_1 = require("../LambdaLogger");
class EventBridgeService {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.client = new client_eventbridge_1.EventBridgeClient({ logger: this.logger });
    }
    publish(events) {
        if (!events || events.length === 0 || events.length > 10) {
            throw new Error('Should send 1-10 events at once.');
        }
        return this.client.send(new client_eventbridge_1.PutEventsCommand({ Entries: events })).then((resp) => {
            const errs = [];
            if (resp.Entries) {
                for (const entry of resp.Entries) {
                    if (entry.ErrorCode || entry.ErrorMessage) {
                        errs.push(JSON.stringify(entry));
                    }
                }
            }
            if (errs.length > 0) {
                throw new Error('Failed to publish events, err: '.concat(errs.join(', ')));
            }
        }).catch((err) => {
            this.logger.error(`Error occurred during publish events, err: ${err.message}`);
            throw err;
        });
    }
}
exports.EventBridgeService = EventBridgeService;
