"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VulnerabilityComputersCollection = exports.VulnerabilitiesCollection = void 0;
const AmpCollection_1 = require("./AmpCollection");
class VulnerabilitiesCollection extends AmpCollection_1.AmpCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker, VulnerabilitiesCollection.RETRY_CONFIG);
        this.functionState = functionState;
    }
}
exports.VulnerabilitiesCollection = VulnerabilitiesCollection;
VulnerabilitiesCollection.RETRY_CONFIG = {
    retries: 5,
    delay: 30000,
    timeout: 120000,
    backoff: 'NEXT_RETRY_DELAY'
};
class VulnerabilityComputersCollection extends AmpCollection_1.AmpCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker, VulnerabilityComputersCollection.RETRY_CONFIG);
        this.functionState = functionState;
    }
}
exports.VulnerabilityComputersCollection = VulnerabilityComputersCollection;
VulnerabilityComputersCollection.RETRY_CONFIG = {
    retries: 5,
    delay: 30000,
    backoff: 'NEXT_RETRY_DELAY'
};
