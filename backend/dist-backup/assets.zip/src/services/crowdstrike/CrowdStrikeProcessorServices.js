"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrowdStrikeProcessorServices = void 0;
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const CrowdStrikeEndpointService_1 = require("../../collectors/services/CrowdStrikeEndpointService");
const CommonTypes_1 = require("../../common/CommonTypes");
class CrowdStrikeProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(crowdStrikeDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, crowdStrikeDevice.hostname, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        await this.verifyChange(currentTopology, crowdStrikeDevice.serial_number, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, crowdStrikeDevice.mac_address, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        await this.verifyChange(currentTopology, crowdStrikeDevice.external_ip, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new CrowdStrikeEndpointService_1.CrowdStrikeEndpointService(tenantUid, sourceId);
    }
}
exports.CrowdStrikeProcessorServices = CrowdStrikeProcessorServices;
