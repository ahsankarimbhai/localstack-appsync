"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InTuneDevicesCollection = void 0;
const InTuneCollection_1 = require("./InTuneCollection");
class InTuneDevicesCollection extends InTuneCollection_1.InTuneCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.InTuneDevicesCollection = InTuneDevicesCollection;
