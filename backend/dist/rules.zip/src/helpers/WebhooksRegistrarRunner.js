"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const WebhooksRegistrar_1 = require("./WebhooksRegistrar");
const tenantUid = process.argv[2];
const producerType = process.argv[3];
const producerId = process.argv[4];
const action = process.argv[5];
console.log(`${action} webhooks for tenant ${tenantUid} producerType ${producerType} producerId ${producerId}`);
const exec = new WebhooksRegistrar_1.WebhooksRegistrar(tenantUid, producerType, producerId);
const start = Date.now();
if (action === 'register') {
    exec.registerWebhooks({ functionName: 'runner' }).finally(() => {
        console.log('WebhooksRegistrar runtime', Date.now() - start);
    });
}
else {
    exec.deleteWebhooks({ functionName: 'runner' }).finally(() => {
        console.log('WebhooksRegistrar runtime', Date.now() - start);
    });
}
