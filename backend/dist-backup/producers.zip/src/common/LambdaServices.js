"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LambdaServices = void 0;
const client_lambda_1 = require("@aws-sdk/client-lambda");
const LambdaLogger_1 = require("./LambdaLogger");
class LambdaServices {
    constructor(region) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.lambda = new client_lambda_1.LambdaClient({ endpoint: `http://${process.env.LOCALSTACK_HOSTNAME}:4566`, region, apiVersion: '2015-03-31', logger: console });
    }
    async syncInvoke(functionName, payLoad) {
        const response = await this.lambda.send(new client_lambda_1.InvokeCommand({
            FunctionName: functionName,
            InvocationType: 'RequestResponse',
            Payload: payLoad
        }));
        return {
            ...response,
            Payload: (response === null || response === void 0 ? void 0 : response.Payload) ? response.Payload.transformToString() : undefined
        };
    }
    async asyncInvoke(functionName, payLoad) {
        const response = await this.lambda.send(new client_lambda_1.InvokeCommand({
            FunctionName: functionName,
            InvocationType: 'Event',
            Payload: payLoad
        }));
        return {
            ...response,
            Payload: (response === null || response === void 0 ? void 0 : response.Payload) ? response.Payload.transformToString() : undefined
        };
    }
}
exports.LambdaServices = LambdaServices;
