"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DevicesCollection = void 0;
const MerakiCollection_1 = require("./MerakiCollection");
class DevicesCollection extends MerakiCollection_1.MerakiCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.DevicesCollection = DevicesCollection;
