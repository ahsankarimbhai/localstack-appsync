"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookRegistrationService = void 0;
const LambdaLogger_1 = require("../../../common/LambdaLogger");
const TenantServices_1 = require("../../../common/TenantServices");
const AwsSecretsService_1 = require("../../../common/AwsSecretsService");
const WebhookRegistrationRepo_1 = require("../../../common/dynamoDBRepo/WebhookRegistrationRepo");
const WebhookNotificationRepo_1 = require("../../../common/dynamoDBRepo/WebhookNotificationRepo");
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../../../common/CommonTypes");
const Util_1 = require("../../../common/Util");
const WebhookHelper_1 = require("./WebhookHelper");
const bluebird_1 = require("bluebird");
class WebhookRegistrationService {
    constructor() {
        this.webhookRegistrationRepo = new WebhookRegistrationRepo_1.WebhookRegistrationRepo();
        this.webhookNotificationRepo = new WebhookNotificationRepo_1.WebhookNotificationRepo();
        this.tenantServices = new TenantServices_1.TenantServices();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async verifyFeature(tenantUid) {
        return this.tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.DATA_SHARING_WEBHOOKS);
    }
    async registerWebhook(tenantUid, webhookRequest) {
        var _a, _b;
        try {
            const webhook = new WebhookRegistrationRepo_1.WebhookRegistrationEntity(tenantUid, webhookRequest.sourceTypes.includes(WebhookHelper_1.ALL_SOURCE_TYPES) ? [WebhookHelper_1.ALL_SOURCE_TYPES] : webhookRequest.sourceTypes, webhookRequest.notificationType, webhookRequest.targetUrl, new WebhookRegistrationRepo_1.WebhookRegistrationColdStart(!!((_a = webhookRequest.coldStart) === null || _a === void 0 ? void 0 : _a.enable), (_b = webhookRequest.coldStart) === null || _b === void 0 ? void 0 : _b.withHistory), webhookRequest.compressionFormat);
            const secretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
            await secretsService.setSecretValue(`${WebhookHelper_1.WEBHOOK_SECRET_KEY_PREFIX}${webhook.webhookId}`, { secret: webhookRequest.secret }, true);
            await this.webhookRegistrationRepo.upsert(webhook);
            return webhook;
        }
        catch (err) {
            this.logger.error(`error occurred during registerWebhook, err: ${err.message}`);
            throw err;
        }
    }
    async validateRegisterWebhookRequest(tenantUid, webhookRequest) {
        const errMsgs = await this.validateWebhookRequest(webhookRequest);
        const exist = await this.webhookRegistrationRepo.getWebhookByTarget(tenantUid, webhookRequest.targetUrl);
        if (exist) {
            errMsgs.push(`webhookId ${exist.webhookId} exists with same targetUrl: ${webhookRequest.targetUrl}`);
        }
        return errMsgs;
    }
    async updateWebhook(webhookId, webhookRequest) {
        var _a, _b, _c;
        try {
            const webhook = await this.webhookRegistrationRepo.getByWebhookId(webhookId);
            if (!webhook) {
                throw new Error(`webhook ${webhookId} is not found`);
            }
            const oldColdStartEnabled = webhook.coldStart.enabledAt;
            const updatedSourceTypes = webhookRequest.sourceTypes.includes(WebhookHelper_1.ALL_SOURCE_TYPES) ? [WebhookHelper_1.ALL_SOURCE_TYPES] : webhookRequest.sourceTypes;
            const isSourceTypesChanged = !_.isEqual(webhook.sourceTypes.sort(), updatedSourceTypes.sort());
            webhook.sourceTypes = updatedSourceTypes;
            webhook.notificationType = webhookRequest.notificationType;
            webhook.compressionFormat = (_a = webhookRequest.compressionFormat) !== null && _a !== void 0 ? _a : WebhookRegistrationRepo_1.WebhookCompressionFormat.GZIP;
            webhook.targetUrl = webhookRequest.targetUrl;
            (0, WebhookHelper_1.updateWebhookColdStart)(webhook.coldStart, !!((_b = webhookRequest.coldStart) === null || _b === void 0 ? void 0 : _b.enable), (_c = webhookRequest.coldStart) === null || _c === void 0 ? void 0 : _c.withHistory, isSourceTypesChanged);
            const secretsService = new AwsSecretsService_1.AwsSecretsService(webhook.tenantUid);
            const secret = { secret: webhookRequest.secret };
            await secretsService.setSecretValue(`DSWebhook__${webhook.webhookId}`, secret, true);
            await this.webhookRegistrationRepo.upsert(webhook);
            return {
                webhook,
                shouldInvokeColdStart: webhook.coldStart.enable && webhook.coldStart.enabledAt !== oldColdStartEnabled
            };
        }
        catch (err) {
            this.logger.error(`error occurred during updateWebhook, err: ${err.message}`);
            throw err;
        }
    }
    async validateUpdateWebhookRequest(webhookId, tenantUid, webhookRequest) {
        const errMsgs = await this.validateWebhookRequest(webhookRequest);
        const webhook = await this.webhookRegistrationRepo.getByWebhookId(webhookId);
        if (!webhook || webhook.tenantUid !== tenantUid) {
            errMsgs.push(`webhookId ${webhookId} is not found`);
            return errMsgs;
        }
        const exist = await this.webhookRegistrationRepo.getWebhookByTarget(tenantUid, webhookRequest.targetUrl);
        if (exist && webhookId !== exist.webhookId) {
            errMsgs.push(`webhookId ${exist.webhookId} exists with same targetUrl: ${webhookRequest.targetUrl}`);
        }
        return errMsgs;
    }
    async validateWebhookRequest(webhookRequest) {
        const errMsgs = [];
        if (!Array.isArray(webhookRequest.sourceTypes) || _.isEmpty(webhookRequest.sourceTypes)) {
            errMsgs.push('sourceTypes array is required');
        }
        else {
            const unSupportSources = _.filter(webhookRequest.sourceTypes, sourceTypes => sourceTypes !== WebhookHelper_1.ALL_SOURCE_TYPES && !Object.values(CommonTypes_1.Source).includes(sourceTypes));
            if (unSupportSources.length > 0) {
                errMsgs.push(`sourceTypes ${unSupportSources.join(', ')} are not supported`);
            }
        }
        if (_.isNil(webhookRequest.notificationType)) {
            errMsgs.push('notificationType is required');
        }
        else if (!Object.values(WebhookRegistrationRepo_1.WebhookNotificationType).includes(webhookRequest.notificationType)) {
            errMsgs.push(`notificationType ${webhookRequest.notificationType} is not supported`);
        }
        if (webhookRequest.compressionFormat && !Object.values(WebhookRegistrationRepo_1.WebhookCompressionFormat).includes(webhookRequest.compressionFormat)) {
            errMsgs.push(`compressionFormat ${webhookRequest.compressionFormat} is not supported`);
        }
        if (webhookRequest.coldStart) {
            if (_.isNil(webhookRequest.coldStart.enable)) {
                errMsgs.push('coldStart.enable is required');
            }
            else if (!webhookRequest.coldStart.enable && webhookRequest.coldStart.withHistory) {
                errMsgs.push('withHistory can be true only when coldStart is enabled');
            }
        }
        if (_.isNil(webhookRequest.targetUrl)) {
            errMsgs.push('targetUrl is required');
        }
        if (_.isNil(webhookRequest.secret)) {
            errMsgs.push('secret is required');
        }
        return errMsgs;
    }
    async listActiveWebhooks(tenantUid) {
        const webhooks = await this.webhookRegistrationRepo.getTenantActiveWebhooks(tenantUid);
        return webhooks.map(webhook => ({
            webhookId: webhook.webhookId,
            targetUrl: webhook.targetUrl,
            sourceTypes: webhook.sourceTypes,
            notificationType: webhook.notificationType,
            compressionFormat: webhook.compressionFormat,
            coldStart: webhook.coldStart,
            status: webhook.status,
            createdAt: (0, Util_1.epochToISOString)(webhook.createdAt)
        }));
    }
    async getWebhookById(webhookId, tenantUid) {
        const webhook = await this.webhookRegistrationRepo.getByWebhookId(webhookId);
        if (!webhook || webhook.tenantUid !== tenantUid) {
            return undefined;
        }
        return {
            webhookId: webhook.webhookId,
            targetUrl: webhook.targetUrl,
            sourceTypes: webhook.sourceTypes,
            notificationType: webhook.notificationType,
            compressionFormat: webhook.compressionFormat,
            coldStart: webhook.coldStart,
            status: webhook.status,
            createdAt: (0, Util_1.epochToISOString)(webhook.createdAt)
        };
    }
    async deleteWebhookById(webhookId, tenantUid) {
        if (!await this.getWebhookById(webhookId, tenantUid)) {
            return;
        }
        await this.webhookRegistrationRepo.hardDelete(webhookId);
        await this.webhookNotificationRepo.hardDelete(webhookId);
    }
    async deleteTenantWebhooks(tenantUid) {
        const webhooks = await this.webhookRegistrationRepo.getAllTenantWebhooks(tenantUid);
        await bluebird_1.Promise.map(webhooks, async (webhook) => {
            await this.webhookRegistrationRepo.hardDelete(webhook.webhookId);
            await this.webhookNotificationRepo.hardDelete(webhook.webhookId);
        });
    }
}
exports.WebhookRegistrationService = WebhookRegistrationService;
