"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationService = void 0;
const LambdaLogger_1 = require("../LambdaLogger");
const ElasticSearchDevicesModificationsNotificationsHandling_1 = require("../rules-system/ElasticSearchDevicesModificationsNotificationsHandling");
const logger = new LambdaLogger_1.LambdaLogger();
class NotificationService {
    constructor(tenantUid, enableDefaultHandler = true) {
        this.tenantUid = tenantUid;
        this.enableDefaultHandler = enableDefaultHandler;
        this.handlerRegistrations = [];
        if (enableDefaultHandler) {
            this.register(new ElasticSearchDevicesModificationsNotificationsHandling_1.ElasticSearchDevicesModificationsNotificationsHandler(tenantUid));
        }
    }
    async callHandlers(notification) {
        try {
            const callbackResults = await Promise.allSettled(this.handlerRegistrations.map(async (handler) => this.mapHandlersCallback(handler, notification)));
            const failedOperations = callbackResults.filter(res => res.status === 'rejected');
            if (failedOperations.length) {
                throw new Error(`Failed to call handlers. Reason: ${JSON.stringify(failedOperations)}`);
            }
        }
        catch (e) {
            logger.error('Non critical error. Continuing after notification handlers failed', e);
        }
    }
    async mapHandlersCallback(handler, notification) {
        logger.debug('checking is enabled', JSON.stringify(handler));
        if (await handler.isEnabled()) {
            logger.debug('notifying: ', JSON.stringify(notification));
            await handler.callback(notification);
        }
    }
    async notify(notification) {
        await this.callHandlers(notification);
    }
    register(handler) {
        this.handlerRegistrations.push(handler);
    }
}
exports.NotificationService = NotificationService;
