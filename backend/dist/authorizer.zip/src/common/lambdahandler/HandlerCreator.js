"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createHandler = void 0;
const lodash_1 = __importDefault(require("lodash"));
const LambdaLogger_1 = require("../LambdaLogger");
const ServiceError_1 = require("../ServiceError");
const LambdaHandler_1 = require("./LambdaHandler");
const MetricsTelemetryMiddleware_1 = require("./MetricsTelemetryMiddleware");
const lambdaLogger = new LambdaLogger_1.LambdaLogger();
const createHandler = (mapping, integrationType) => async (event, context) => {
    lambdaLogger.log('in createHandler');
    lambdaLogger.log(event, context);
    const fieldName = lodash_1.default.get(event, 'query.fieldName');
    const handler = mapping[fieldName];
    if (!lodash_1.default.isFunction(handler)) {
        const msg = `No mapping for field '${fieldName}' found`;
        lambdaLogger.error(msg);
        return new ServiceError_1.BadRequestError(msg);
    }
    try {
        const pipelines = new LambdaHandler_1.LambdaHandler(handler).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(integrationType, lambdaLogger)).toPipelines();
        const res = await pipelines(event, context);
        return res;
    }
    catch (err) {
        return (0, ServiceError_1.toServiceError)(err);
    }
};
exports.createHandler = createHandler;
