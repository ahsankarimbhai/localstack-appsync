"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseProcessorService = void 0;
const TimestreamWriteServices_1 = require("../../common/TimestreamWriteServices");
const GraphFactory_1 = require("../../model/GraphFactory");
const CommonTypes_1 = require("../../common/CommonTypes");
const NeptuneServicesFactory_1 = require("../../common/neptune/NeptuneServicesFactory");
const _ = __importStar(require("lodash"));
const gremlin_1 = require("gremlin");
const ModelServiceFactory_1 = require("../../model/ModelServiceFactory");
const Services_1 = require("../../common/Services");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const BaseGraphElement_1 = require("../../model/BaseGraphElement");
const BaseGraphService_1 = require("../../model/BaseGraphService");
const ts_retry_promise_1 = require("ts-retry-promise");
const NeptuneClientHelper_1 = require("../../common/neptune/NeptuneClientHelper");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const IrohEntitlementSummaryClient_1 = require("../../common/IrohEntitlementSummaryClient");
const MemoryCache_1 = require("../../common/cache/MemoryCache");
const DateUtils_1 = require("../../common/DateUtils");
class BaseProcessorService {
    constructor(tenantUid, sourceId, useStaleCheck = true) {
        this.tenantUid = tenantUid;
        this.sourceId = sourceId;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.useStaleCheck = useStaleCheck;
        this.initProcessorService(tenantUid, sourceId);
    }
    getSourceConfiguration() {
        return undefined;
    }
    getPvType() {
        return this.entityService.getPvType();
    }
    getPsType() {
        return this.entityService.getPsType();
    }
    getPvLabel() {
        return this.entityService.getPvLabel();
    }
    getPsLabel() {
        return this.entityService.getPsLabel();
    }
    hasPropertiesToMergeBy(entry) {
        return true;
    }
    async processEntryImpl(entry) {
        const results = await this.obtainChanges(entry);
        return this.applyChanges(results.changes).then(r => r.savedVertex);
    }
    getCachedRetentionPolicy() {
        return new IrohEntitlementSummaryClient_1.IrohEntitlementSummaryClient(this.tenantUid).getRetentionPolicy();
    }
    async obtainChanges(entry) {
        const started = Date.now();
        let metrics;
        let changes = [];
        const unchanged = [];
        if (!this.hasPropertiesToMergeBy(entry)) {
            return { changes, metrics: [new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_NOT_LINKABLE)] };
        }
        const vertexState = await (0, GraphFactory_1.createComplexVertexWithPreProcess)(this.getPsType(), this.getPsLabel(), this.tenantUid, entry, this.sourceId, this.getSourceConfiguration());
        if (this.useStaleCheck) {
            if (vertexState.getPropertyValue(CommonTypes_1.VertexBasicProperty.LAST_UPDATED) < started - await this.getCachedRetentionPolicy()) {
                return { changes, metrics: [new TimestreamWriteServices_1.Metric(CommonTypes_1.ChangeType.STALE)] };
            }
        }
        const neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
        const vertex = await (0, GraphFactory_1.createComplexVertex)(this.getPvType(), this.getPvLabel(), this.tenantUid, entry, this.sourceId, this.getSourceConfiguration());
        const currentTopology = await neptuneServices.getCurrentPSWithOutgoingVertices({ id: vertex.getId() });
        this.verifyChangeForVertex(currentTopology, vertexState, changes, unchanged);
        await this.obtainIdentifierChanges(entry, vertexState, currentTopology, changes, unchanged);
        if (_.some(changes, change => change.type !== CommonTypes_1.ChangeType.LAST_UPDATED_UPDATE)) {
            const changeType = currentTopology.length ? CommonTypes_1.ChangeType.UPDATE : CommonTypes_1.ChangeType.NEW;
            changes.push(new Services_1.PostureTopologyChange(changeType, vertex));
            if (_.find(changes, { type: CommonTypes_1.ChangeType.LAST_UPDATED_UPDATE })) {
                changes = _.filter(changes, change => change.type !== CommonTypes_1.ChangeType.LAST_UPDATED_UPDATE);
            }
            metrics = this.getChangeMetrics(changes);
            changes = _.union(changes, unchanged);
        }
        else {
            metrics = _.find(changes, { type: CommonTypes_1.ChangeType.LAST_UPDATED_UPDATE }) ? [new TimestreamWriteServices_1.Metric(CommonTypes_1.ChangeType.LAST_UPDATED_UPDATE)] : [];
        }
        metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.DURATION, Date.now() - started));
        return { changes, metrics };
    }
    toVertex(change) {
        const obj = Object.assign(Object.create(BaseGraphElement_1.BaseGraphVertex.prototype), change.newVertex);
        return (0, GraphFactory_1.cloneVertex)(this.tenantUid, obj);
    }
    executeTraversal(graphTraversal) {
        return (0, ts_retry_promise_1.retry)(() => graphTraversal.iterate(), { retries: 1, delay: 100, backoff: 'LINEAR', timeout: 120000, retryIf: (err) => !(0, NeptuneClientHelper_1.isConnectionError)(err) });
    }
    async getPostureEntityForPs(ps, edgeType) {
        if (ps) {
            const neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
            const results = await neptuneServices.executeTenantQuery((g) => neptuneServices.getGraphTraversal(g, _.get(ps, 'id')).inE(CommonTypes_1.EdgeType.HAS_STATE).outV().inE(edgeType)
                .outV()
                .id()
                .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
            const resultSet = new gremlin_1.driver.ResultSet(results);
            return resultSet.toArray().length > 0 ? resultSet.toArray()[0] : undefined;
        }
        return undefined;
    }
    getChangeMetrics(changes) {
        if (_.find(changes, { type: CommonTypes_1.ChangeType.NEW })) {
            return [new TimestreamWriteServices_1.Metric(CommonTypes_1.ChangeType.NEW)];
        }
        const filteredChanges = _.filter(changes, change => change.type !== CommonTypes_1.ChangeType.UPDATE);
        return _.map(filteredChanges, change => new TimestreamWriteServices_1.Metric(change.type));
    }
    addUpsertTraversal(graphTraversal, vertex, withFold = false) {
        const vertexService = (0, ModelServiceFactory_1.getModelService)(vertex.type, this.tenantUid);
        return vertexService.addUpsertTraversal(graphTraversal, vertex, withFold);
    }
    async processEntry(entry) {
        return this.processEntryImpl(entry);
    }
    async postProcessing(savedVertex) {
        const durationMetrics = [];
        const startTime = Date.now();
        await this.getPostureService().markUnreliableIdentifierVertices(savedVertex.getId());
        let isPEMerged = false;
        let epUid = await this.getPostureService().linkDirectCandidate(savedVertex);
        if (epUid) {
            isPEMerged = true;
        }
        if (!epUid) {
            const res = await this.getPostureService().linkProducerCandidates(savedVertex.getId());
            epUid = res.peUid;
            isPEMerged = res.isMergedToExistingPE;
        }
        if (!epUid) {
            throw new Error(`Failed to create PE to ${savedVertex.getId()}`);
        }
        durationMetrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.POST_PROCESSING_GRAPH_DURATION, Date.now() - startTime));
        const esStartTime = Date.now();
        await this.getPostureService().updateSearchableVertex(epUid);
        await this.getPostureService().sendNotifications(epUid, isPEMerged);
        durationMetrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.POST_PROCESSING_ES_DURATION, Date.now() - esStartTime));
        durationMetrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.POST_PROCESSING_DURATION, Date.now() - startTime));
        return { savedVertex, durationMetrics };
    }
    addVertexTraversal(graphTraversal, model, vertex, edgeType) {
        const vertexService = (0, ModelServiceFactory_1.getModelService)(vertex.type, this.tenantUid);
        if (vertexService.skipUpdate(vertex)) {
            return graphTraversal;
        }
        const upsertVertexTraversalStep = vertexService.addUpsertTraversal(graphTraversal, vertex);
        return (0, BaseGraphService_1.addEdgeTraversal)(upsertVertexTraversalStep, model, vertex, edgeType, { [CommonTypes_1.EdgeBasicProperty.IS_CURRENT]: true });
    }
    async verifyChange(currentTopology, extId, type, changes, unchanged, input, edgeType) {
        if ((0, CommonTypes_1.empty)(extId)) {
            return;
        }
        const vertex = await (0, GraphFactory_1.createSimpleVertex)(type, this.tenantUid, extId, input);
        this.verifyChangeForVertex(currentTopology, vertex, changes, unchanged, edgeType);
    }
    verifyChangeForVertex(currentTopology, vertex, changes, unchanged, customChangeType) {
        const vertexService = (0, ModelServiceFactory_1.getModelService)(vertex.type, this.tenantUid);
        if (vertexService.skipUpdate(vertex)) {
            return;
        }
        const changeType = customChangeType !== null && customChangeType !== void 0 ? customChangeType : (0, CommonTypes_1.getChangeType)(vertex.type);
        const id = vertex.getId();
        const existingVertex = _.find(currentTopology, { id });
        if (!existingVertex) {
            changes.push(new Services_1.PostureTopologyChange(changeType, vertex));
        }
        else {
            unchanged.push(new Services_1.PostureTopologyChange(changeType, vertex));
            if (vertex.type === this.getPsType() && (vertex.getPropertyValue(CommonTypes_1.VertexBasicProperty.LAST_UPDATED) !== BaseGraphElement_1.BaseGraphElement.getPropertyValue(existingVertex, CommonTypes_1.VertexBasicProperty.LAST_UPDATED))) {
                changes.push(new Services_1.PostureTopologyChange(CommonTypes_1.ChangeType.LAST_UPDATED_UPDATE, vertex));
            }
        }
    }
    async closeCurrentState(pv, edgeType) {
        const neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
        const pvData = await neptuneServices.executeTenantQuery((g) => neptuneServices.getGraphTraversal(g, pv.getId())
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
            .count()
            .next(), NeptuneClientManager_1.NeptuneClientType.Reader);
        if (pvData && pvData.value > 0) {
            await neptuneServices.closeCurrentState(pv.getId());
            const results = await neptuneServices.getPostureEntitiesByPV(pv.getId(), edgeType);
            if (_.isEmpty(results)) {
                this.logger.debug(`Cannot obtain PE for PV: ${pv.getId()}, the PE was already deleted`);
            }
            else {
                const pe = _.first(results);
                this.logger.debug(`Closing state of PV ${pv.getId()} and removing PE ${pe.id}`);
                await this.getPostureService().updateSearchableVertex(pe.id, true);
                await this.getPostureService().sendNotifications(pe.id);
            }
        }
        else {
            this.logger.debug(`No need to close state of ${pv.getId()}`);
        }
    }
}
__decorate([
    (0, MemoryCache_1.memCacheDecorator)(IrohEntitlementSummaryClient_1.IrohEntitlementSummaryClient.RETENTION_POLICY_CACHE_PREFIX, _.parseInt(process.env.RETENTION_POLICY_CASHE_TIMEOUT_SECONDS || DateUtils_1.DAY_SECONDS.toString()))
], BaseProcessorService.prototype, "getCachedRetentionPolicy", null);
exports.BaseProcessorService = BaseProcessorService;
