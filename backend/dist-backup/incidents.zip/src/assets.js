"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assetsErrorResponse = exports.describe = exports.resolve = exports.resolveLatest = exports.health = void 0;
const Util_1 = require("./common/Util");
const AssetsService_1 = require("./assets/AssetsService");
const AssetsModel_1 = require("./assets/AssetsModel");
const LambdaLogger_1 = require("./common/LambdaLogger");
const LambdaHandler_1 = require("./common/lambdahandler/LambdaHandler");
const MetricsTelemetryMiddleware_1 = require("./common/lambdahandler/MetricsTelemetryMiddleware");
const NeptuneClientManager_1 = require("./common/neptune/NeptuneClientManager");
const logger = new LambdaLogger_1.LambdaLogger();
const neptuneClientManager = NeptuneClientManager_1.NeptuneClientManager.getInstance();
const health = async () => {
    const postureHealthResponse = {
        data: { status: 'ok' }
    };
    return (0, Util_1.lambdaProxyResponse)('POST', JSON.stringify(postureHealthResponse));
};
exports.health = health;
exports.resolveLatest = new LambdaHandler_1.LambdaHandler(async (event) => {
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, exports.assetsErrorResponse)('POST', 'missing [tenantUid] value mandatory for resolve latest API', AssetsModel_1.AssetsErrorCode.MISSING_TENANT);
    }
    try {
        const resolveRequest = JSON.parse(event.body);
        const assetsService = new AssetsService_1.AssetsService(tenantUid);
        const postureAssetResponse = await assetsService.resolveLatest(resolveRequest);
        return (0, Util_1.lambdaProxyResponse)('POST', JSON.stringify(postureAssetResponse));
    }
    catch (e) {
        return (0, exports.assetsErrorResponse)('POST', e.message, AssetsModel_1.AssetsErrorCode.GENERIC_ERROR);
    }
}).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(MetricsTelemetryMiddleware_1.IntegrationType.LambdaProxy, logger)).toPipelines();
exports.resolve = new LambdaHandler_1.LambdaHandler(async (event) => {
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, exports.assetsErrorResponse)('POST', 'missing [tenantUid] value mandatory for resolve API', AssetsModel_1.AssetsErrorCode.MISSING_TENANT);
    }
    try {
        const resolveRequest = JSON.parse(event.body);
        const assetsService = new AssetsService_1.AssetsService(tenantUid);
        const postureAssetResponse = await assetsService.resolve(resolveRequest);
        return (0, Util_1.lambdaProxyResponse)('POST', JSON.stringify(postureAssetResponse));
    }
    catch (e) {
        return (0, exports.assetsErrorResponse)('POST', e.message, AssetsModel_1.AssetsErrorCode.GENERIC_ERROR);
    }
}).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(MetricsTelemetryMiddleware_1.IntegrationType.LambdaProxy, logger)).toPipelines();
exports.describe = new LambdaHandler_1.LambdaHandler(async (event) => {
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, exports.assetsErrorResponse)('POST', 'missing [tenantUid] value mandatory for describe API', AssetsModel_1.AssetsErrorCode.MISSING_TENANT);
    }
    try {
        const describeRequest = JSON.parse(event.body);
        const assetsService = new AssetsService_1.AssetsService(tenantUid);
        const postureAssetResponse = await assetsService.describe(describeRequest);
        return (0, Util_1.lambdaProxyResponse)('POST', JSON.stringify(postureAssetResponse));
    }
    catch (e) {
        return (0, exports.assetsErrorResponse)('POST', e.message, AssetsModel_1.AssetsErrorCode.GENERIC_ERROR);
    }
}).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(MetricsTelemetryMiddleware_1.IntegrationType.LambdaProxy, logger)).toPipelines();
const assetsErrorResponse = (method, errMsg, errorCode) => {
    logger.debug(`Failed to process asset request ${errMsg}`);
    const response = {
        statusCode: 200,
        headers: (0, Util_1.getLambdaResponseHeaders)(method)
    };
    response.body = JSON.stringify({
        data: {},
        errors: [
            {
                code: errorCode,
                message: errMsg,
                type: AssetsModel_1.AssetsErrorType.ERROR
            }
        ]
    });
    return response;
};
exports.assetsErrorResponse = assetsErrorResponse;
