"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.duoNotification = exports.orbitalS3ProducerNotification = exports.producerNotification = exports.logger = void 0;
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("./common/CommonTypes");
const ProcessingUtil_1 = require("./common/ProcessingUtil");
const JwtHelper_1 = require("./common/tokenhelper/JwtHelper");
const AwsSecretsService_1 = require("./common/AwsSecretsService");
const Util_1 = require("./common/Util");
const DuoNotificationAuthorizer_1 = require("./authorizer/DuoNotificationAuthorizer");
const LambdaLogger_1 = require("./common/LambdaLogger");
const MemoryCache_1 = require("./common/cache/MemoryCache");
const cacheManager = MemoryCache_1.MemoryCacheManager.getInstance();
exports.logger = new LambdaLogger_1.LambdaLogger();
const producerNotification = async (event) => {
    const successResult = {
        statusCode: 200
    };
    const body = JSON.parse(event.body);
    if (_.get(body, 'ping')) {
        return Promise.resolve(successResult);
    }
    const tenantUid = event.requestContext.authorizer.tenantUid;
    const source = event.requestContext.authorizer.source;
    exports.logger.info(`received notification for tenant ${tenantUid} and source uid: ${source}`);
    if (_.startsWith(source, CommonTypes_1.Source.AMP)) {
        await verifyAmpWebhookSignature(event, tenantUid, source);
    }
    try {
        await new ProcessingUtil_1.ProcessingUtil().processNotifications(body, tenantUid, source);
    }
    catch (err) {
        exports.logger.error(`Failed to process notifications tenant=${tenantUid}, source=${source}`, err);
        return Promise.reject(new Error(`Failed to process notifications tenant=${tenantUid}, source=${source}`));
    }
    return Promise.resolve(successResult);
};
exports.producerNotification = producerNotification;
const orbitalS3ProducerNotification = async (event) => {
    const s3Event = event.Records[0].s3;
    try {
        const processingUtil = new ProcessingUtil_1.ProcessingUtil();
        const notification = await processingUtil.parseOrbitalWebhookNotificationS3File(s3Event);
        if (notification) {
            exports.logger.info(`received Orbital notification for tenant ${notification.tenantUid} and source uid: ${notification.producerId}`);
            await processingUtil.processNotifications(notification.notificationData, notification.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, notification.producerId));
        }
    }
    catch (err) {
        exports.logger.error(`Failed to process Orbital notifications for s3 event: ${JSON.stringify(s3Event)}, err: ${err.message}`);
    }
};
exports.orbitalS3ProducerNotification = orbitalS3ProducerNotification;
const duoNotification = async (event) => {
    const authorization = await (0, DuoNotificationAuthorizer_1.authorize)(event);
    if (authorization.statusCode) {
        exports.logger.error('duo webhook authorization failed', authorization);
        return authorization;
    }
    const { jwt, tenantUid, source } = authorization;
    await new ProcessingUtil_1.ProcessingUtil().processNotifications(jwt.events, tenantUid, source);
    return {
        statusCode: 200
    };
};
exports.duoNotification = duoNotification;
async function verifyAmpWebhookSignature(event, tenantUid, source) {
    const fpHeader = event.headers[JwtHelper_1.AMP_FINGERPRINT_HEADER_NAME];
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const webhookSecret = awsSecretsService.getSecret(source).webhookSecret;
    if (!(0, JwtHelper_1.verifyWebhookSignature)(event.body, fpHeader, webhookSecret)) {
        throw Util_1.UNAUTHORIZED;
    }
}
