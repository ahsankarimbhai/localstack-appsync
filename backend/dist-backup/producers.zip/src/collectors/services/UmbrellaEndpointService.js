"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UmbrellaEndpointService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
class UmbrellaEndpointService extends Services_1.BaseEndpointService {
    getPvType() {
        return CommonTypes_1.VertexType.UMBRELLA_ROAMING_COMPUTER;
    }
    getPsType() {
        return CommonTypes_1.VertexType.UMBRELLA_ROAMING_COMPUTER_STATE;
    }
}
exports.UmbrellaEndpointService = UmbrellaEndpointService;
