"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelDeviceService = void 0;
const LambdaLogger_1 = require("../../common/LambdaLogger");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const _ = __importStar(require("lodash"));
const LabelService_1 = require("./LabelService");
const Util_1 = require("../../common/Util");
class LabelDeviceService {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.esService = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        this.labelService = new LabelService_1.LabelService(this.tenantUid);
    }
    async addLabelsForDevices(labelIds, deviceIds) {
        const failureArray = [];
        this.emptyValidationForIds(labelIds, deviceIds, failureArray);
        this.duplicationValidationForIds(deviceIds, labelIds, failureArray);
        if (_.isEmpty(failureArray)) {
            const labelMap = await this.labelService.getLabelsMetadataMap();
            const validatedLabels = this.validateLabels(labelIds, labelMap, failureArray);
            if (_.isEmpty(validatedLabels)) {
                this.logger.error('No labels found, validation failed');
            }
            else {
                const updateResponse = await this.esService.addLabelsToDevices(validatedLabels, deviceIds);
                if (updateResponse.body.total !== deviceIds.length) {
                    this.logger.error(`Total of updated records is not equal to ${JSON.stringify(deviceIds)} length, response: ${JSON.stringify(updateResponse)}`);
                    const existing = await this.esService.getUidsIfExist(deviceIds);
                    _.difference(deviceIds, existing)
                        .forEach(missingId => failureArray.push(`Unable to assign label to device ${missingId}, no such device found`));
                }
            }
        }
        return {
            failure: failureArray
        };
    }
    async removeLabelsFromDevices(labelIds, deviceIds) {
        const failuresWithDetails = [];
        if (_.isEmpty(labelIds) || _.isEmpty(deviceIds)) {
            this.logger.error(`Input data can not be empty. LabelIds ${labelIds}, deviceIds: ${deviceIds}`);
            if (_.isEmpty(deviceIds)) {
                failuresWithDetails.push({ deviceId: '', labelIds, failure: 'Input data can not be empty' });
            }
            else {
                deviceIds.forEach(deviceId => failuresWithDetails.push({ deviceId, labelIds: [], failure: 'Input data can not be empty' }));
            }
        }
        if ((0, Util_1.hasDuplicatesInArray)(deviceIds) || (0, Util_1.hasDuplicatesInArray)(labelIds)) {
            this.logger.error(`Input data should not contain duplicates. LabelIds: ${labelIds}, deviceIds: ${deviceIds}`);
            deviceIds.forEach(deviceId => failuresWithDetails.push({ deviceId, labelIds, failure: 'Input data should not contain duplicates' }));
        }
        if (_.isEmpty(failuresWithDetails)) {
            const [removeResult, deviceIdsAndRuleBasedLabels] = await Promise.all([this.esService.removeLabelsByQuery(labelIds, deviceIds), this.esService.getSpecificFields(deviceIds, ['rulesLabels', 'hostname'])]);
            if (removeResult.body.total !== deviceIds.length) {
                this.logger.error(`Total of updated records is not equal to ${deviceIds} length, response: ${removeResult}`);
                const existingIds = deviceIdsAndRuleBasedLabels.map(deviceDetails => deviceDetails._id);
                deviceIds
                    .filter(id => !existingIds.includes(id))
                    .forEach(id => {
                    this.logger.error(`Could not remove any label from device ${id}, devise does not exist`);
                    failuresWithDetails.push({ deviceId: id, labelIds, failure: 'Device does not exist' });
                });
            }
            for (const deviceDetails of deviceIdsAndRuleBasedLabels) {
                const deviceRuleLabels = deviceDetails._source.rulesLabels;
                const deviceId = deviceDetails._id;
                if (deviceRuleLabels && !_.isEmpty(deviceRuleLabels)) {
                    const ruleBasedLabelsThatCanNotBeDeleted = labelIds.filter(labelToDelete => deviceRuleLabels.includes(labelToDelete));
                    if (!_.isEmpty(ruleBasedLabelsThatCanNotBeDeleted)) {
                        this.logger.error(`Could not remove labels ${JSON.stringify(ruleBasedLabelsThatCanNotBeDeleted)} from device ${deviceId}`);
                        failuresWithDetails.push({ deviceId, labelIds: ruleBasedLabelsThatCanNotBeDeleted, failure: 'Could not delete label, that was assigned by rule' });
                    }
                }
            }
        }
        return { failuresWithDetails };
    }
    async addLabelsForDevicesMatchingFilter(labelIds, filter, exclusionList) {
        const failureArray = [];
        if (_.isEmpty(labelIds)) {
            this.logger.error(`labelIds parameter can't be empty. Tenant: ${this.tenantUid}`);
            failureArray.push('labelIds parameter can\'t be empty');
        }
        if ((0, Util_1.hasDuplicatesInArray)(labelIds) || (0, Util_1.hasDuplicatesInArray)(exclusionList)) {
            this.logger.error(`Input data should not contain duplicates. LabelIds ${labelIds}, exclusionList: ${exclusionList}`);
            failureArray.push(`Input data should not contain duplicates. LabelIds ${labelIds}, exclusionList: ${exclusionList}`);
        }
        if (_.isEmpty(failureArray)) {
            const labelMap = await this.labelService.getLabelsMetadataMap();
            const validateLabels = this.validateLabels(labelIds, labelMap, failureArray);
            if (_.isEmpty(validateLabels)) {
                return {
                    failure: failureArray
                };
            }
            try {
                const updateResponse = await this.esService.addLabelsByFilter(filter, validateLabels, exclusionList);
                if (updateResponse.body.failures.length === updateResponse.body.total) {
                    this.logger.error(`Experienced an error when trying to update labels for a filter. Response: ${updateResponse}`);
                    failureArray.push('Failed to update all documents');
                }
            }
            catch (e) {
                failureArray.push('Failed to update all documents, system error');
            }
        }
        return {
            failure: failureArray
        };
    }
    async removeLabelsFromDevicesMatchingFilter(labelIds, filter, exclusionList) {
        const failureArray = [];
        if (_.isEmpty(labelIds)) {
            this.logger.error(`labelIds parameter can't be empty. Tenant: ${this.tenantUid}`);
            failureArray.push('labelIds parameter can\'t be empty');
        }
        if ((0, Util_1.hasDuplicatesInArray)(labelIds) || (0, Util_1.hasDuplicatesInArray)(exclusionList)) {
            this.logger.error(`Input data should not contain duplicates. LabelIds ${labelIds}, exclusionList: ${exclusionList}`);
            failureArray.push(`Input data should not contain duplicates. LabelIds ${labelIds}, exclusionList: ${exclusionList}`);
        }
        if (_.isEmpty(failureArray)) {
            try {
                const updateResponse = await this.esService.removeLabelsByFilter(filter, labelIds, exclusionList);
                if (updateResponse.body.failures.length === updateResponse.body.total) {
                    this.logger.error(`Experienced an error when trying to update labels for a filter. Response: ${updateResponse}`);
                    failureArray.push('Failed to update all documents');
                }
            }
            catch (e) {
                failureArray.push('Failed to update all documents, system error');
            }
        }
        return {
            failure: failureArray
        };
    }
    async removeLabelsFromAllDevices(labelIds) {
        this.logger.debug(`From all devices will be removed labels: ${labelIds}`);
        if (!_.isEmpty(labelIds)) {
            try {
                await this.esService.removeLabelsFromAllDevices(labelIds);
            }
            catch (e) {
                this.logger.error(`Failed to delete labels: ${labelIds} from devices for tenant: ${this.tenantUid}, ${e.message}`);
            }
        }
    }
    emptyValidationForIds(labelIds, deviceIds, failureArray) {
        if (_.isEmpty(labelIds) || _.isEmpty(deviceIds)) {
            this.logger.error(`Input data can not be empty. LabelIds ${labelIds}, deviceIds: ${deviceIds}`);
            failureArray.push(`Input data can not be empty. LabelIds ${labelIds}, deviceIds: ${deviceIds}`);
        }
    }
    duplicationValidationForIds(deviceIds, labelIds, failureArray) {
        if ((0, Util_1.hasDuplicatesInArray)(deviceIds) || (0, Util_1.hasDuplicatesInArray)(labelIds)) {
            this.logger.error(`Input data should not contain duplicates. LabelIds ${labelIds}, deviceIds: ${deviceIds}`);
            failureArray.push(`Input data should not contain duplicates. LabelIds ${labelIds}, deviceIds: ${deviceIds}`);
        }
    }
    validateLabels(labelIds, labelMap, failureArray) {
        const validatedLabels = [];
        for (const id of labelIds) {
            const tempLabel = labelMap.get(id);
            if (!tempLabel) {
                this.logger.error(`Label ${id} can not be added to any device, could not find any matching label record for it.`);
                failureArray.push(`Label ${id} can not be added to any device, could not find any matching label record for it.`);
            }
            else {
                validatedLabels.push(id);
            }
        }
        return validatedLabels;
    }
}
exports.LabelDeviceService = LabelDeviceService;
