"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefenderDeviceStateModelService = exports.DefenderDeviceStateModel = exports.DefenderDeviceModelService = exports.DefenderDeviceModel = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class DefenderDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.DEFENDER_DEVICE;
    }
    async initProperties(device) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, device.id);
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, device.computerDnsName);
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, new Date(device.lastSeen).getTime());
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.DefenderDeviceModel = DefenderDeviceModel;
class DefenderDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new DefenderDeviceModel(this.partitionKey);
    }
}
exports.DefenderDeviceModelService = DefenderDeviceModelService;
class DefenderDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.DEFENDER_DEVICE_STATE;
    }
    async initProperties(device) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(device, ['lastSeen'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, device.computerDnsName);
        this.setProperty(CommonTypes_1.VertexType.HOSTNAME, device.computerDnsName);
        this.setInternalIpAddresses(device.lastIpAddress);
        this.setProperty(CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, device.lastExternalIpAddress);
        if (Array.isArray(device.ipAddresses)) {
            for (const address of device.ipAddresses) {
                if (address.macAddress) {
                    this.setProperty(CommonTypes_1.VertexType.MAC_ADDRESS, address.macAddress);
                    break;
                }
            }
        }
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(device.osPlatform));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, device.osVersion || (0, CommonTypes_1.isOSVersionTextOnly)(device.version) ? undefined : device.version);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(device.osPlatform, '', device.osBuild));
        this.setProperty(DefenderDeviceStateModel.OS_BUILD, device.osBuild);
        this.setProperty(DefenderDeviceStateModel.HEALTH_STATUS, device.healthStatus);
        this.setProperty(DefenderDeviceStateModel.DEVICE_VALUE, device.deviceValue);
        this.setProperty(DefenderDeviceStateModel.RISK_SCORE, device.riskScore);
        this.setProperty(DefenderDeviceStateModel.EXPOSURE_LEVEL, device.exposureLevel);
        this.setProperty(DefenderDeviceStateModel.CREATED_AT, new Date(device.firstSeen).getTime());
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, new Date(device.lastSeen).getTime());
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.DefenderDeviceStateModel = DefenderDeviceStateModel;
DefenderDeviceStateModel.OS_BUILD = 'osBuild';
DefenderDeviceStateModel.HEALTH_STATUS = 'healthStatus';
DefenderDeviceStateModel.DEVICE_VALUE = 'deviceValue';
DefenderDeviceStateModel.RISK_SCORE = 'riskScore';
DefenderDeviceStateModel.EXPOSURE_LEVEL = 'exposureLevel';
DefenderDeviceStateModel.CREATED_AT = 'createdAt';
class DefenderDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new DefenderDeviceStateModel(this.partitionKey);
    }
}
exports.DefenderDeviceStateModelService = DefenderDeviceStateModelService;
