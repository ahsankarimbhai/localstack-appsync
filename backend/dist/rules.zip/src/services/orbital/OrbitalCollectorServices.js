"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrbitalAxiosWrapper = exports.OrbitalCollectorServices = void 0;
const axios_1 = __importDefault(require("axios"));
const Util_1 = require("../../common/Util");
const OrbitalModel_1 = require("../../collectors/model/OrbitalModel");
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../../common/CommonTypes");
const OrbitalEndpointModel_1 = require("../../model/OrbitalEndpointModel");
const Services_1 = require("../../common/Services");
const DateUtils_1 = require("../../common/DateUtils");
const AwsSecretsService_1 = require("../../common/AwsSecretsService");
const TenantServices_1 = require("../../common/TenantServices");
const OrbitalProcessorServices_1 = require("./OrbitalProcessorServices");
const NeptuneServicesFactory_1 = require("../../common/neptune/NeptuneServicesFactory");
const IrohClient_1 = require("../../common/IrohClient");
const LambdaLogger_1 = require("../../common/LambdaLogger");
class OrbitalCollectorServices extends Services_1.BasePushCollectorService {
    constructor(secrets, tenantUid, sourceId, baseUrl) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.baseUrl = baseUrl;
        if (!baseUrl) {
            throw new Error('Orbital baseUrl is not set');
        }
        this.tenantServices = new TenantServices_1.TenantServices();
        this.orbitalS3WebhookAwsSecretsService = new AwsSecretsService_1.OrbitalS3WebhookAwsSecretsService();
        this.awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
        this.restAxios = undefined;
    }
    async init() {
        if (this.restAxios) {
            return;
        }
        this.restAxios = new OrbitalAxiosWrapper(this.tenantUid, this.baseUrl);
    }
    async query(query) {
        await this.init();
        const queryWithExpiry = _.isUndefined(query.expiry) ? {
            ...query,
            expiry: OrbitalCollectorServices.defaultExpiry()
        } : query;
        return this.restAxios.post('/v0/query', queryWithExpiry, {});
    }
    async queryOrbital(webhookId) {
        const now = Date.now();
        const oneYearFromNow = new Date(now);
        oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);
        const promises = [];
        const nodes = ['os:windows', 'os:darwin', 'os:linux'];
        for (const node of nodes) {
            const postureQuery = this.getOsQuery(now, webhookId, Math.floor(oneYearFromNow.getTime() / 1000), undefined, node);
            this.logger.debug(`postureQuery ${node} ${JSON.stringify(postureQuery)}`);
            promises.push(this.query(postureQuery));
        }
        return _.map(await Promise.all(promises), (response) => response.data);
    }
    static defaultExpiry() {
        return Math.floor(Date.now() / 1000 + OrbitalCollectorServices.DEFAULT_EXPIRY_SECS);
    }
    getOsQuery(now, webhookId, expiry, interval = DateUtils_1.DAY_SECONDS, node = 'All', nodeOs = '') {
        let os = nodeOs || node;
        if (os.indexOf('windows') > -1) {
            os = 'Windows';
        }
        else if (os.indexOf('darwin') > -1) {
            os = 'Mac';
        }
        else if (os.indexOf('linux') > -1) {
            os = 'Linux';
        }
        else {
            os = (os.indexOf(':') > -1) ? os.split(':')[1] : os;
            os = os.charAt(0).toUpperCase() + os.slice(1);
        }
        const query = {
            name: `Device Insights ${os} QueryV2 ${now}`,
            nodes: [node],
            expiry,
            interval,
            osQuery: [
                {
                    label: OrbitalEndpointModel_1.OrbitalQueries.SYSTEM_INFO,
                    sql: 'SELECT uuid, hostname, hardware_vendor, hardware_model, hardware_version, hardware_serial, computer_name, local_hostname FROM system_info;'
                },
                {
                    label: OrbitalEndpointModel_1.OrbitalQueries.LOCAL_USERS,
                    sql: 'SELECT username as localUsername FROM users where type == "local";'
                },
                {
                    label: OrbitalEndpointModel_1.OrbitalQueries.LOGGED_IN_USERS,
                    sql: 'SELECT user as loggedInUser FROM logged_in_users where user != "";'
                }
            ]
        };
        if (os === 'Windows') {
            this.addQueriesForWindows(query);
        }
        else if (os === 'Mac') {
            this.addQueriesForMac(query);
        }
        else if (os === 'Linux') {
            this.addQueriesForLinux(query);
        }
        if (webhookId) {
            query.postbacks = [{ webhookid: webhookId }];
        }
        return query;
    }
    addQueriesForWindows(query) {
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.OS_VERSION,
            sql: 'SELECT name, version, major, minor, patch, build, platform, platform_like, codename, arch, install_date FROM os_version;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.PROGRAMS,
            sql: 'SELECT name, version, install_location, install_source, language, publisher, uninstall_string, install_date, identifying_number FROM programs;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.PATCHES,
            sql: 'SELECT csname, hotfix_id, caption, description, fix_comments, installed_by, install_date, installed_on FROM patches;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.KERNEL_INFO,
            sql: 'SELECT version, arguments, path, device FROM kernel_info;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.WIN_SECURITY_CENTER,
            sql: 'SELECT firewall AS "firewall", autoupdate AS "autoupdate", antivirus AS "antivirus", antispyware AS "antispyware", internet_settings AS "internet_settings", windows_security_center_service AS "windows_security_center_service", (SELECT CASE \n WHEN DATA = 1 THEN "Good" \n ELSE "Poor" \n END AS user_account_control \n FROM registry \n WHERE PATH LIKE "HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\EnableLUA"\n) AS "user_account_control" FROM windows_security_center;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.WIN_SECURITY_PRODUCTS,
            sql: 'SELECT * FROM windows_security_products;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.DISK_ENCRYPTION,
            sql: 'SELECT * FROM bitlocker_info'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.MACHINE_SID_REGISTER,
            sql: 'select substr(data, -24, 24) as sid FROM registry WHERE key = "HKEY_LOCAL_MACHINE\\SECURITY\\SAM\\Domains\\Account" AND name == "V";'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.MACHINE_GUID,
            sql: 'select key AS machine_guid FROM registry WHERE key = "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography\\MachineGuid";'
        });
    }
    addQueriesForMac(query) {
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.OS_VERSION,
            sql: 'SELECT name, version, major, minor, patch, build, platform, platform_like, codename, arch FROM os_version;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.DISK_ENCRYPTION,
            sql: 'SELECT name, uuid, encrypted, type, encryption_status, uid, filevault_status FROM disk_encryption;'
        });
    }
    addQueriesForLinux(query) {
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.OS_VERSION,
            sql: 'SELECT name, version, major, minor, patch, build, platform, platform_like, codename, arch, pid_with_namespace, mount_namespace_id FROM os_version;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.RPM_PACKAGES,
            sql: 'SELECT name, version, release, source, size, sha1, arch, epoch, install_time, vendor, package_group FROM rpm_packages;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.DEB_PACKAGES,
            sql: 'SELECT name, version, source, size, arch, revision, status, maintainer, section, priority, admindir FROM deb_packages;'
        });
        query.osQuery.push({
            label: OrbitalEndpointModel_1.OrbitalQueries.DISK_ENCRYPTION,
            sql: 'SELECT name, uuid, encrypted, type, encryption_status, uid, filevault_status FROM disk_encryption;'
        });
    }
    async registerWebhook() {
        await this.init();
        await this.initWebhookToken();
        let webhookData;
        if (await this.tenantServices.isTenantFeatureOn(this.tenantUid, TenantServices_1.FeatureFlag.ORBITAL_WEBHOOK_S3_RECEIVER)) {
            await this.orbitalS3WebhookAwsSecretsService.init();
            const { accesskey, secretkey } = this.orbitalS3WebhookAwsSecretsService.getLatestCredentials();
            webhookData = {
                disabled: false,
                config: {
                    label: this.getWebhookLabel(),
                    url: 'https://s3.amazonaws.com',
                    format: 's3-compact',
                    bucket: process.env.ORBITAL_WEBHOOK_S3_BUCKET,
                    region: process.env.AWS_REGION,
                    accesskey,
                    secretkey
                }
            };
        }
        else {
            const producersWebhookToken = this.secrets.webhookToken;
            const producerSource = this.getProducerSource();
            webhookData = {
                disabled: false,
                config: {
                    label: this.getWebhookLabel(),
                    token: `${this.tenantUid}${Util_1.TOKEN_SEPARATOR}${producerSource}${Util_1.TOKEN_SEPARATOR}${producersWebhookToken}`,
                    url: process.env.GW_API_PRODUCER_NOTIFICATION_URL,
                    format: ''
                }
            };
        }
        const res = await this.restAxios.post('/v0/webhooks', webhookData, {});
        return res.data.id;
    }
    getProducerSource() {
        return (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId);
    }
    async getRegisteredWebhook() {
        const tenantConfigRecord = await this.tenantServices.getTenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId));
        if (tenantConfigRecord.value) {
            let tenantConfig = JSON.parse(tenantConfigRecord.value);
            tenantConfig = await this.rescheduleOsQuery(tenantConfig);
            if (!tenantConfig.osQueryResponse) {
                return undefined;
            }
            const queryResponseIDs = OrbitalCollectorServices.getQueryResponseIDs(tenantConfig.osQueryResponse);
            return { webhookId: tenantConfig.webhookId, queryResponseIDs };
        }
        return undefined;
    }
    async hasRegisteredWebhooks() {
        const registeredWebhook = await this.getRegisteredWebhook();
        return !!registeredWebhook;
    }
    async removeWebhookSecrets() { }
    async refreshWebhookSecrets() {
        const previousSecrets = this.secrets;
        this.secrets = {};
        await this.initWebhookToken();
        let errorResponse;
        try {
            await this.updateWebhook();
        }
        catch (error) {
            errorResponse = error.response || error;
        }
        if (errorResponse) {
            this.logger.error(`Failed to update Orbital webhook for tenant ${this.tenantUid}, producer ${(0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId)} where error.data=${JSON.stringify(errorResponse.data)}`);
            this.secrets = { webhookToken: previousSecrets.webhookToken };
            await this.awsSecretsService.setSecretValue((0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId), this.secrets, true);
        }
    }
    async updateWebhook() {
        await this.init();
        const tenantConfigRecord = await this.tenantServices.getTenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId));
        let tenantConfig = new OrbitalModel_1.OrbitalConfig();
        if (tenantConfigRecord.value) {
            tenantConfig = JSON.parse(tenantConfigRecord.value);
        }
        if (tenantConfig.webhookId) {
            const producersWebhookToken = this.secrets.webhookToken;
            const producerSource = this.getProducerSource();
            const webhookData = {
                disabled: false,
                id: tenantConfig.webhookId,
                config: {
                    label: this.getWebhookLabel(),
                    format: '',
                    token: `${this.tenantUid}${Util_1.TOKEN_SEPARATOR}${producerSource}${Util_1.TOKEN_SEPARATOR}${producersWebhookToken}`,
                    url: process.env.GW_API_PRODUCER_NOTIFICATION_URL
                }
            };
            return this.restAxios.put(`/v0/webhooks/${tenantConfig.webhookId}`, webhookData, {});
        }
        return Promise.reject(new Error('No webhook found'));
    }
    async updateS3Webhook() {
        if (!await this.tenantServices.isTenantFeatureOn(this.tenantUid, TenantServices_1.FeatureFlag.ORBITAL_WEBHOOK_S3_RECEIVER)) {
            throw new Error('FeatureFlag ORBITAL_WEBHOOK_S3_RECEIVER is not enabled');
        }
        await this.init();
        const tenantConfigRecord = await this.tenantServices.getTenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId));
        let tenantConfig = new OrbitalModel_1.OrbitalConfig();
        if (tenantConfigRecord.value) {
            tenantConfig = JSON.parse(tenantConfigRecord.value);
        }
        if (!tenantConfig.webhookId) {
            throw new Error('No webhook found');
        }
        await this.orbitalS3WebhookAwsSecretsService.init();
        const { accesskey, secretkey } = this.orbitalS3WebhookAwsSecretsService.getLatestCredentials();
        const webhookData = {
            disabled: false,
            id: tenantConfig.webhookId,
            config: {
                label: this.getWebhookLabel(),
                url: 'https://s3.amazonaws.com',
                format: 's3-compact',
                bucket: process.env.ORBITAL_WEBHOOK_S3_BUCKET,
                region: process.env.AWS_REGION,
                accesskey,
                secretkey
            }
        };
        return this.restAxios.put(`/v0/webhooks/${tenantConfig.webhookId}`, webhookData, {});
    }
    async getWebhookStatus() {
        var _a, _b, _c, _d;
        await this.init();
        const webhook = await this.getRegisteredWebhook();
        if (!webhook) {
            return this.errorStatus(this.getProducerSource(), OrbitalCollectorServices.ORBITAL_QUERY_NOT_SCHEDULED, 'webhook not found in producer configuration', false);
        }
        const { webhookId, queryResponseIDs } = webhook;
        let webhookResponse;
        try {
            webhookResponse = await this.restAxios.get(`/v0/webhooks/${webhookId}`);
        }
        catch (e) {
            return this.errorStatus(this.getProducerSource(), 'Error fetching webhook status', `get webhook ${webhookId} returned status ${e.response.status} ${e.response.statusText}`, true, `response error: ${(_b = (_a = e.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error}, response error description: ${(_d = (_c = e.response) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.error_description}`);
        }
        const webhookData = webhookResponse.data;
        if (webhookData.errors) {
            return this.errorStatus(this.getProducerSource(), OrbitalCollectorServices.ORBITAL_WEBHOOK_NOT_SCHEDULED, `webhookData.errors ${JSON.stringify(webhookData)}`);
        }
        if (webhookData.disabled) {
            return this.errorStatus(this.getProducerSource(), OrbitalCollectorServices.ORBITAL_WEBHOOK_DISABLED, `${OrbitalCollectorServices.ORBITAL_WEBHOOK_DISABLED} ${JSON.stringify(webhookData)}`);
        }
        const orbitalWebhookStatus = new Services_1.WebhookStatus(this.getProducerSource(), webhookData.laststatus, webhookData.lastcalled);
        let error;
        for (const queryId of queryResponseIDs) {
            try {
                const queryData = await this.getQueryResponse(queryId);
                if (!queryData || !_.get(queryData, 'expiry')) {
                    error = this.errorStatus(this.getProducerSource(), OrbitalCollectorServices.ORBITAL_QUERY_NOT_SCHEDULED, `Could not find expiry in ${JSON.stringify(queryData)}`);
                    this.logger.error(error);
                }
                else if (orbitalWebhookStatus.expiry === undefined || queryData.expiry < orbitalWebhookStatus.expiry) {
                    orbitalWebhookStatus.expiry = queryData.expiry;
                }
            }
            catch (e) {
                error = this.errorStatus(this.getProducerSource(), OrbitalCollectorServices.ORBITAL_QUERY_NOT_SCHEDULED, `get job ${queryId} returned status ${e.response.status} ${e.response.statusText}`);
                this.logger.error(e);
                this.logger.error(error);
            }
        }
        return error || orbitalWebhookStatus;
    }
    async getQueryResponse(queryId) {
        const queryResponse = await this.restAxios.get(`/v0/jobs/${queryId}`);
        return queryResponse.data;
    }
    getWebhookLabel() {
        return `${this.tenantUid}_posaasWebhook`;
    }
    async initWebhookToken() {
        var _a;
        let webhookToken = (_a = this.secrets) === null || _a === void 0 ? void 0 : _a.webhookToken;
        if (!webhookToken) {
            this.logger.info(`generating webhook token for tenant ${this.tenantUid} and Orbital producer ${this.sourceId}`);
            webhookToken = (0, Util_1.generateSecret)(32);
            this.secrets = { webhookToken };
            await this.awsSecretsService.setSecretValue((0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId), this.secrets, true);
        }
    }
    async registerWebhooks() {
        this.logger.debug('OrbitalCollectorServices::registerWebhooks - getting the tenant configuration');
        const tenantConfigRecord = await this.tenantServices.getTenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId));
        let tenantConfig = new OrbitalModel_1.OrbitalConfig();
        if (tenantConfigRecord.value) {
            tenantConfig = JSON.parse(tenantConfigRecord.value);
        }
        if (!tenantConfig.webhookId) {
            this.logger.debug(`OrbitalCollectorServices::registerWebhooks - there is no registered webhook, will be registering a new one (tenantUid:${this.tenantUid})`);
            tenantConfig.webhookId = await this.registerWebhook();
            this.logger.debug(`OrbitalCollectorServices::registerWebhooks - webhook registered (tenantUid:${this.tenantUid})`);
        }
        if (!tenantConfig.osQueryResponse) {
            this.logger.debug(`OrbitalCollectorServices::registerWebhooks - querying orbital (tenantUid:${this.tenantUid})`);
            tenantConfig.osQueryResponse = await this.queryOrbital(tenantConfig.webhookId);
            this.logger.debug(`Updating orbital webhook data ${JSON.stringify(tenantConfig)} on registerWebhooks (tenantUid:${this.tenantUid})`);
            await this.tenantServices.updateTenantConfigurationValue(new TenantServices_1.TenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId), JSON.stringify(tenantConfig)));
        }
        else {
            this.logger.debug(`${(0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId)} query already scheduled (tenantUid:${this.tenantUid})`, JSON.stringify(tenantConfig));
        }
    }
    async deleteQuery(queryId) {
        var _a;
        let queryExists = true;
        try {
            await this.getQueryResponse(queryId);
        }
        catch (err) {
            queryExists = ((_a = err.response) === null || _a === void 0 ? void 0 : _a.status) !== 404;
        }
        if (queryExists) {
            await this.restAxios.delete(`/v0/query/${queryId}`);
        }
    }
    async removeWebhooks() {
        await this.init();
        const tenantConfigRecord = await this.tenantServices.getTenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId));
        let tenantConfig = new OrbitalModel_1.OrbitalConfig();
        if (tenantConfigRecord.value) {
            tenantConfig = JSON.parse(tenantConfigRecord.value);
        }
        let errorInDelete;
        if (tenantConfig.osQueryResponse) {
            const queryResponseIDs = OrbitalCollectorServices.getQueryResponseIDs(tenantConfig.osQueryResponse);
            if (Array.isArray(tenantConfig.osQueryResponse)) {
                let indexToRemove = 0;
                for (const queryId of queryResponseIDs) {
                    try {
                        await this.deleteQuery(queryId);
                        tenantConfig.osQueryResponse.splice(indexToRemove, 1);
                    }
                    catch (e) {
                        const errorMessage = `Error removing Orbital webhook for queryId ${queryId}`;
                        this.logger.error(errorMessage, e);
                        errorInDelete = `${errorMessage} where error=${e.message}`;
                        indexToRemove += 1;
                    }
                }
                if (tenantConfig.osQueryResponse.length === 0) {
                    delete tenantConfig.osQueryResponse;
                }
            }
            else if (queryResponseIDs.length === 1) {
                await this.deleteQuery(queryResponseIDs[0]);
                delete tenantConfig.osQueryResponse;
            }
        }
        this.logger.debug(`Updating orbital webhook data ${JSON.stringify(tenantConfig)} on removeWebhooks`);
        const tenantConfiguration = new TenantServices_1.TenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId), JSON.stringify(tenantConfig));
        await this.tenantServices.updateTenantConfigurationValue(tenantConfiguration);
        return (errorInDelete) ? Promise.reject(new Error(errorInDelete)) : Promise.resolve();
    }
    async removeFailingWebhooks(failingSourceId, whatIf = true) {
        await this.init();
        const failingTenantConfig = await this.tenantServices.getTenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, failingSourceId));
        if (!failingTenantConfig) {
            throw new Error(`No tenant configuration found where tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.ORBITAL}, sourceId=${failingSourceId}`);
        }
        let failingTenantConfigValue = new OrbitalModel_1.OrbitalConfig();
        if (failingTenantConfig.value) {
            failingTenantConfigValue = JSON.parse(failingTenantConfig.value);
        }
        const queryIds = [];
        const osQueryResponseIsArray = Array.isArray(failingTenantConfigValue.osQueryResponse);
        if (failingTenantConfigValue.osQueryResponse) {
            if (osQueryResponseIsArray) {
                for (const osQueryResponse of failingTenantConfigValue.osQueryResponse) {
                    if (osQueryResponse.ID) {
                        queryIds.push(osQueryResponse.ID);
                    }
                }
            }
            else {
                queryIds.push(failingTenantConfigValue.osQueryResponse.ID);
            }
        }
        if (queryIds.length === 0) {
            this.logger.error(`No query ID found in Orbital osQueryResponse for tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.ORBITAL}, activeSourceId=${this.sourceId}, failingSourceId=${failingSourceId}`);
            throw new Error(`No query ID found in Orbital osQueryResponse for tenantUid=${this.tenantUid}, sourceId=${failingSourceId}`);
        }
        this.logger.debug(`${whatIf ? '(whatif) ' : ''}Attempting to delete ${queryIds.length} webhooks where tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.ORBITAL}, sourceId=${failingSourceId}, queryIds=${queryIds} using the credentials from activeSourceId=${this.sourceId}`);
        const errors = [];
        for (let i = 0; i < queryIds.length; i += 1) {
            const queryId = queryIds[i];
            try {
                if (!whatIf) {
                    await this.restAxios.delete(`/v0/query/${queryId}`);
                    this.logger.debug(`Deleted Orbital osQueryResponse ID ${queryId} where tenantUid=${this.tenantUid}, sourceId=${failingSourceId}`);
                    if (osQueryResponseIsArray) {
                        failingTenantConfigValue.osQueryResponse.splice(errors.length, 1);
                    }
                    else {
                        delete failingTenantConfigValue.osQueryResponse;
                    }
                }
                else {
                    this.logger.debug(`(whatif) will attempt to remove Orbital webhook where id=${queryId}, tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.ORBITAL}, failingSourceId=${failingSourceId} using the credentials from activeSourceId=${this.sourceId}`);
                }
            }
            catch (ex) {
                this.logger.error(`Error occurred removing Orbital webhook where error=${ex.message}, queryId=${queryId}, tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.ORBITAL}, activeSourceId=${this.sourceId}, failingSourceId=${failingSourceId}, queryId=${queryId}`);
                errors.push(ex);
            }
        }
        if (!whatIf && queryIds.length > 0 && errors.length < queryIds.length) {
            this.logger.debug(`Updating orbital webhook data ${JSON.stringify(failingTenantConfigValue)} on removeFailingWebhooks`);
            const updatedFailingTenantConfig = new TenantServices_1.TenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, failingSourceId), JSON.stringify(failingTenantConfigValue));
            await this.tenantServices.updateTenantConfigurationValue(updatedFailingTenantConfig);
        }
        if (errors.length > 0) {
            return Promise.reject(errors);
        }
        return Promise.resolve(true);
    }
    async fetchSingleEntity(deviceId) {
        var _a;
        await this.init();
        const service = new OrbitalProcessorServices_1.OrbitalProcessorServices(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId));
        const neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
        const currentState = await neptuneServices.getCurrentState(deviceId);
        const { nodeId, nodeOs, ampuuid } = this.getRequiredFields(currentState);
        const osQuery = this.getOsQuery(Date.now(), undefined, undefined, undefined, nodeId, nodeOs);
        const res = await this.restAxios.post('/v0/probe', osQuery);
        if (!res.data || !res.data.results[0]) {
            return Promise.reject(new Error(`Bad Orbital response ${JSON.stringify(res.data)}`));
        }
        const orbitalResponse = res.data.results[0];
        if (!orbitalResponse.hostinfo) {
            this.logger.debug('Empty Orbital response', JSON.stringify(orbitalResponse));
            return Promise.reject(new Error('No response from endpoint, it may be offline'));
        }
        try {
            orbitalResponse.nodeinfo = {};
            orbitalResponse.nodeinfo.id = nodeId;
            orbitalResponse.nodeinfo.ampuuid = ampuuid;
            orbitalResponse.nodeinfo.os = nodeOs;
            orbitalResponse.nodeinfo.anyconnectuuid = (_a = _.find(currentState.properties, { key: OrbitalEndpointModel_1.OrbitalEndpointStateModel.ANYCONNECT_UUID })) === null || _a === void 0 ? void 0 : _a.value;
            if (!orbitalResponse.reported) {
                const reportedTimestamp = _.find(currentState.properties, { key: OrbitalEndpointModel_1.OrbitalEndpointStateModel.REPORTED });
                if (reportedTimestamp) {
                    orbitalResponse.reported = new Date(_.toNumber(reportedTimestamp.value)).toISOString();
                }
            }
            return service.processEntryImpl(orbitalResponse);
        }
        catch (e) {
            this.logger.error(`Failed to fetch Orbital Endpoint where query=${JSON.stringify(osQuery)} and error=${e}`, e);
            return Promise.reject(new Error('Failed to fetch Orbital Endpoint'));
        }
    }
    getRequiredFields(currentState) {
        let nodeId = '';
        let nodeOs = '';
        let ampuuid = '';
        try {
            nodeId = _.find(currentState.properties, { key: OrbitalEndpointModel_1.OrbitalEndpointStateModel.NODE_ID }).value;
            nodeOs = _.find(currentState.properties, { key: OrbitalEndpointModel_1.OrbitalEndpointStateModel.NODE_OS }).value;
            ampuuid = _.find(currentState.properties, { key: OrbitalEndpointModel_1.OrbitalEndpointStateModel.AMPUUID }).value;
            return { nodeId, nodeOs, ampuuid };
        }
        catch (error) {
            let missingField = '';
            if (nodeId === '') {
                missingField = 'nodeId';
            }
            else if (nodeOs === '') {
                missingField = 'nodeOs';
            }
            else {
                missingField = 'ampuuid';
            }
            throw new Error(`Failed to fetch Orbital Endpoint because ${missingField} is missing`);
        }
    }
    async rescheduleOsQuery(tenantConfig) {
        if (!tenantConfig.osQueryResponse) {
            return tenantConfig;
        }
        let expiry;
        if (Array.isArray(tenantConfig.osQueryResponse)) {
            for (const query of tenantConfig.osQueryResponse) {
                const queryExpiryNumber = _.toNumber(query.expiry);
                if (query.expiry && (!expiry || queryExpiryNumber < expiry)) {
                    expiry = queryExpiryNumber;
                }
            }
        }
        else {
            expiry = _.toNumber(tenantConfig.osQueryResponse.expiry);
        }
        if (expiry === undefined || Number.isNaN(expiry)) {
            return tenantConfig;
        }
        if (expiry * 1000 < Date.now() || expiry * 1000 - Date.now() < DateUtils_1.DAY_MILLIS * 30) {
            this.logger.debug('rescheduling Orbital osQuery');
            await this.removeWebhooks();
            await this.registerWebhooks();
            const tenantConfigRecord = await this.tenantServices.getTenantConfiguration(this.tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, this.sourceId));
            return JSON.parse(tenantConfigRecord.value);
        }
        return tenantConfig;
    }
    static getQueryResponseIDs(osQueryResponse) {
        const queryResponseIDs = [];
        if (Array.isArray(osQueryResponse)) {
            for (const query of osQueryResponse) {
                queryResponseIDs.push(query.ID);
            }
        }
        else {
            queryResponseIDs.push(osQueryResponse.ID);
        }
        return queryResponseIDs;
    }
}
exports.OrbitalCollectorServices = OrbitalCollectorServices;
OrbitalCollectorServices.ORBITAL_WEBHOOK_NOT_SCHEDULED = 'Orbital webhook not scheduled';
OrbitalCollectorServices.ORBITAL_QUERY_NOT_SCHEDULED = 'Orbital query not scheduled';
OrbitalCollectorServices.ORBITAL_WEBHOOK_DISABLED = 'Orbital webhook is disabled';
OrbitalCollectorServices.ORBITAL_APPLICATION_HEADER_NAME = 'x-orbital-application';
OrbitalCollectorServices.ORBITAL_APPLICATION_HEADER_DI_VALUE = 'Device Insights';
OrbitalCollectorServices.DEFAULT_EXPIRY_SECS = 60 * 2;
class OrbitalAxiosWrapper {
    constructor(tenantUid, baseUrl) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.tenantUid = tenantUid;
        if (!baseUrl) {
            throw new Error('Orbital baseUrl is not set');
        }
        this.baseUrl = baseUrl;
    }
    init() {
        if (this.axios) {
            return;
        }
        this.axios = axios_1.default.create({
            baseURL: this.baseUrl,
            responseType: 'json',
            headers: {
                'x-orbital-application': OrbitalCollectorServices.ORBITAL_APPLICATION_HEADER_DI_VALUE
            }
        });
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'OrbitalCollectorServices restAxios');
        this.axios.interceptors.request.use((config) => {
            if (!this.accessToken || (this.expires && this.expires < Date.now())) {
                return this.getAccessToken()
                    .then(({ token, expiry }) => {
                    this.accessToken = token;
                    this.expires = Date.parse(expiry);
                    _.set(config, 'headers.Authorization', `Bearer ${this.accessToken}`);
                    return config;
                });
            }
            _.set(config, 'headers.Authorization', `Bearer ${this.accessToken}`);
            return config;
        });
    }
    async getAccessToken() {
        await this.init();
        const token = await (0, IrohClient_1.getAccessToken)(this.tenantUid);
        this.logger.debug('Refreshed an access token from stored BE token, will be using that for authentication');
        const tokenExp = (0, IrohClient_1.getTokenExp)(token);
        return { token, expiry: new Date(tokenExp).toString() };
    }
    parseErrors(err, method) {
        if (err.isAxiosError && err.response) {
            err.message = `${err.response.statusText} (${err.response.status}).`;
            this.logger.error(`AxiosError occurred in OrbitalAxiosWrapper where method=${method}, message='${err.message}', status=${err.response.status}, statusText='${err.response.statusText}', data=${JSON.stringify(err.response.data)}`, err);
            throw err;
        }
        else {
            const unknownError = err;
            this.logger.error(`Unhandled Error occurred in OrbitalAxiosWrapper where method=${method}, message='${unknownError.message}', name=${unknownError.name}`, unknownError);
            throw err;
        }
    }
    async options(url, method, data) {
        try {
            if (!this.axios) {
                await this.init();
            }
            return this.axios.request({
                url,
                method,
                data
            })
                .catch((err) => this.parseErrors(err, method));
        }
        catch (err) {
            return this.parseErrors(err, method);
        }
    }
    get(url) {
        return this.options(url, 'get');
    }
    post(url, data) {
        return this.options(url, 'post', data);
    }
    put(url, data) {
        return this.options(url, 'put', data);
    }
    delete(url) {
        return this.options(url, 'delete');
    }
}
exports.OrbitalAxiosWrapper = OrbitalAxiosWrapper;
