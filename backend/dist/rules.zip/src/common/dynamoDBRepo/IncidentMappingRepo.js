"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IncidentMappingRepo = exports.IncidentMappingEntity = void 0;
const DateUtils_1 = require("../DateUtils");
const LambdaLogger_1 = require("../LambdaLogger");
const DynamodbServiceFactory_1 = require("../awsclient/dynamodb/DynamodbServiceFactory");
class IncidentMappingEntity {
    constructor(id, tenantId, incidentId, observable, creationTime = Date.now().valueOf() / 1000, irohNotificationTime, expiryPeriod) {
        this.id = id;
        this.tenantId = tenantId;
        this.incidentId = incidentId;
        this.observable = observable;
        this.creationTime = creationTime;
        this.irohNotificationTime = irohNotificationTime;
        this.expiryPeriod = expiryPeriod;
    }
}
exports.IncidentMappingEntity = IncidentMappingEntity;
class IncidentMappingRepo {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async create(incidentMappingEntities) {
        await Promise.all(incidentMappingEntities.map(incidentMappingEntity => this.dynamoDBServices.save(IncidentMappingRepo.TABLE_NAME, incidentMappingEntity)));
    }
    async deleteAllEntities(tenantUid) {
        const entries = await this.getTenantEntities(tenantUid);
        this.logger.info(`Incident mappings to delete: ${JSON.stringify(entries)}`);
        return this.dynamoDBServices.batchDelete(IncidentMappingRepo.TABLE_NAME, entries.map(entry => this.getCompositeKey(tenantUid, entry.id)));
    }
    getTenantEntities(tenantUid) {
        return this.dynamoDBServices.getByPartitionKey(IncidentMappingRepo.TABLE_NAME, IncidentMappingRepo.HASH_KEY, tenantUid);
    }
    async getByObservable(observableValue, tenantId) {
        return this.dynamoDBServices.getItemsByLocalSecondaryIndex(IncidentMappingRepo.TABLE_NAME, IncidentMappingRepo.LOCAL_SECONDARY_INDEX_NAME, IncidentMappingRepo.LOCAL_SECONDARY_INDEX_SORT_KEY, observableValue, IncidentMappingRepo.HASH_KEY, tenantId);
    }
    async markNotifiedAndSetExpirationTime(tenantUid, incidentMappingId) {
        const currentTimeSeconds = Date.now().valueOf() / 1000;
        await this.dynamoDBServices.update(IncidentMappingRepo.TABLE_NAME, this.getCompositeKey(tenantUid, incidentMappingId), { irohNotificationTime: currentTimeSeconds, expiryPeriod: currentTimeSeconds + (DateUtils_1.WEEK_MILLIS / 1000) * 2 });
    }
    getCompositeKey(tenantIdValue, incidentMappingId) {
        return { tenantId: tenantIdValue, id: incidentMappingId };
    }
}
exports.IncidentMappingRepo = IncidentMappingRepo;
IncidentMappingRepo.TABLE_NAME = 'incident-mapping';
IncidentMappingRepo.HASH_KEY = 'tenantId';
IncidentMappingRepo.LOCAL_SECONDARY_INDEX_SORT_KEY = 'observable';
IncidentMappingRepo.LOCAL_SECONDARY_INDEX_NAME = 'idx-observable';
