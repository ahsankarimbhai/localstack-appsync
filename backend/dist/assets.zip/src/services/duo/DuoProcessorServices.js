"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuoProcessorServices = void 0;
const GraphFactory_1 = require("../../model/GraphFactory");
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const DuoEndpointService_1 = require("../../collectors/services/DuoEndpointService");
const LambdaLogger_1 = require("../../common/LambdaLogger");
class DuoProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    static hasPropertiesToMergeBy(ep) {
        const duoEndpoint = ep;
        const hasHardwareId = !!(duoEndpoint.computer_sid
            || duoEndpoint.device_id
            || duoEndpoint.device_udid
            || duoEndpoint.cpu_id
            || duoEndpoint.hardware_uuid);
        const hasDeviceName = !!(duoEndpoint.device_name || duoEndpoint.hostname);
        const hasPropertiesToMergeBy = hasHardwareId && hasDeviceName;
        if (!hasPropertiesToMergeBy) {
            const logger = new LambdaLogger_1.LambdaLogger();
            logger.debug(`Not linkable duo endpoint: hasHardwareId=${hasHardwareId}, hasDeviceName=${hasDeviceName}`);
        }
        return hasPropertiesToMergeBy;
    }
    hasPropertiesToMergeBy(ep) {
        return DuoProcessorServices.hasPropertiesToMergeBy(ep);
    }
    async obtainIdentifierChanges(duoEndpoint, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, duoEndpoint.device_username, CommonTypes_1.VertexType.USER, changes, unchanged);
        await this.verifyChange(currentTopology, duoEndpoint.username, CommonTypes_1.VertexType.APP_USER, changes, unchanged);
        await this.verifyChange(currentTopology, duoEndpoint.email, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
        for (const browser of duoEndpoint.browsers) {
            const browserVertex = await this.createBrowserVertex(browser);
            this.verifyChangeForVertex(currentTopology, browserVertex, changes, unchanged);
        }
        await this.verifyChange(currentTopology, duoEndpoint.epkey, CommonTypes_1.VertexType.EXTERNAL_REFERENCE, changes, unchanged);
        await this.verifyChange(currentTopology, duoEndpoint.hardware_uuid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        await this.verifyChange(currentTopology, duoEndpoint.cpu_id, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        if (!duoEndpoint.hardware_uuid && !duoEndpoint.cpu_id) {
            await this.verifyChange(currentTopology, duoEndpoint.device_id, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
            await this.verifyChange(currentTopology, duoEndpoint.device_udid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        }
        await this.verifyChange(currentTopology, duoEndpoint.device_name || duoEndpoint.hostname, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        await this.verifyChange(currentTopology, duoEndpoint.computer_sid, CommonTypes_1.VertexType.COMPUTER_SID, changes, unchanged);
        if (duoEndpoint.ip_addr) {
            const extId = duoEndpoint.ip_addr;
            await this.verifyChange(currentTopology, extId, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
        }
    }
    createBrowserVertex(browser) {
        return (0, GraphFactory_1.createComplexVertex)(CommonTypes_1.VertexType.BROWSER, CommonTypes_1.VertexType.BROWSER, this.tenantUid, {
            browserFamily: browser.browser_family,
            browserVersion: browser.browser_version,
            flashVersion: browser.flash_version,
            javaVersion: browser.java_version,
            lastUsed: browser.last_used
        }, this.sourceId);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new DuoEndpointService_1.DuoEndpointService(tenantUid, sourceId);
    }
}
exports.DuoProcessorServices = DuoProcessorServices;
