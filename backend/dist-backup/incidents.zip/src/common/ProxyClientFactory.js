"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrendVisionOneIrohProxyClient = exports.AzureUsersIrohProxyClient = exports.SentinelOneIrohProxyClient = exports.UmbrellaIrohProxyClient = exports.ServiceNowIrohProxyClient = exports.MobileIronIrohProxyClient = exports.MerakiIrohProxyClient = exports.JamfIrohProxyClient = exports.CyberVisionIrohProxyClient = exports.IntuneIrohProxyClient = exports.DuoIrohProxyClient = exports.DefenderIrohProxyClient = exports.CrowdStrikeIrohProxyClient = exports.AmpIrohProxyClient = exports.AirwatchIrohProxyClient = exports.GenericSourceIrohProxyClient = exports.SimpleIrohProxyClient = exports.ProxyClientFactory = exports.logger = void 0;
const TenantServices_1 = require("./TenantServices");
const CommonTypes_1 = require("./CommonTypes");
const ProxyClient_1 = require("./ProxyClient");
const IrohClient_1 = require("./IrohClient");
const queryString = __importStar(require("querystring"));
const url_1 = require("url");
const lodash_1 = __importDefault(require("lodash"));
const LambdaLogger_1 = require("./LambdaLogger");
const Util_1 = require("./Util");
exports.logger = new LambdaLogger_1.LambdaLogger();
class ProxyClientFactory {
    static async getProxyClient(tenantUid, producerType, producerId, umbrellaV2support = false) {
        if (!process.env.IROH_URI) {
            throw new Error('IROH_URI is not set');
        }
        const tenantService = new TenantServices_1.TenantServices();
        const producerConfig = await tenantService.getTenantConfigurationOrFail(tenantUid, producerType, producerId);
        const cfgValue = JSON.parse(producerConfig.value);
        let strippedIrohModuleInstanceId = producerConfig.irohModuleInstanceId;
        if (producerConfig.irohModuleInstanceId) {
            const re = new RegExp(`${Util_1.SOURCE_TAG_DYNAMIC}$`);
            strippedIrohModuleInstanceId = producerConfig.irohModuleInstanceId.replace(re, '');
        }
        switch (producerType) {
            case CommonTypes_1.Source.AIRWATCH:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new AirwatchIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.AMP:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new AmpIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.CROWDSTRIKE:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new CrowdStrikeIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.DEFENDER:
                return new DefenderIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.DUO:
            case CommonTypes_1.Source.DUO_USERS:
                return new DuoIrohProxyClient(cfgValue.baseURL, strippedIrohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.INTUNE:
                if (!process.env.MS_GRAPH_URL) {
                    throw new Error(`base url is missing for ${CommonTypes_1.Source.INTUNE}__${producerId} producer`);
                }
                return new IntuneIrohProxyClient(process.env.MS_GRAPH_URL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.CYBERVISION:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new CyberVisionIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.JAMF:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new JamfIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.MERAKI:
                if (!process.env.MERAKI_BASE_URL) {
                    throw new Error(`base url is missing for ${CommonTypes_1.Source.MERAKI}__${producerId} producer`);
                }
                return new MerakiIrohProxyClient(process.env.MERAKI_BASE_URL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.MOBILEIRON:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new MobileIronIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.SERVICENOW:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new ServiceNowIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.UMBRELLA:
                if (!process.env.UMBRELLA_BASE_URL || !process.env.UMBRELLA_V2_BASE_URL) {
                    throw new Error(`base url is missing for ${CommonTypes_1.Source.UMBRELLA}__${producerId} producer`);
                }
                return new UmbrellaIrohProxyClient(umbrellaV2support ? process.env.UMBRELLA_V2_BASE_URL : process.env.UMBRELLA_BASE_URL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.SENTINEL_ONE:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new SentinelOneIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.AZURE_USERS:
                if (!process.env.MS_GRAPH_URL) {
                    throw new Error(`base url is missing for ${CommonTypes_1.Source.AZURE_USERS}__${producerId} producer`);
                }
                return new AzureUsersIrohProxyClient(process.env.MS_GRAPH_URL, producerConfig.irohModuleInstanceId, tenantUid);
            case CommonTypes_1.Source.TREND_VISION_ONE:
                if (!cfgValue.baseURL) {
                    return Promise.reject(new Error(`Base url is missing for ${producerType}__${producerId} producer`));
                }
                return new TrendVisionOneIrohProxyClient(cfgValue.baseURL, producerConfig.irohModuleInstanceId, tenantUid);
            default:
                throw new Error(`Unsupported proxy client type tenantUid=${tenantUid}, producerType=${producerType}, producerId=${producerId}`);
        }
    }
}
exports.ProxyClientFactory = ProxyClientFactory;
ProxyClientFactory.IROH_PREF = '/iroh/iroh-api-gateway/xproxy';
class SimpleIrohProxyClient extends ProxyClient_1.IrohProxyClient {
    constructor(baseUrl, moduleInstanceId, tenantUid) {
        super();
        this.baseUrl = baseUrl;
        this.moduleInstanceId = moduleInstanceId;
        this.tenantUid = tenantUid;
    }
    async options(url, method = 'get', data, configs) {
        if (!this.axios) {
            await this.init();
        }
        let targetUrl = this.baseUrl;
        let requestUrl = url;
        if (url.startsWith('https://')) {
            const urlData = new url_1.URL(url);
            targetUrl = urlData.hostname;
            requestUrl = `${urlData.pathname}${urlData.search}`;
        }
        const token = await (0, IrohClient_1.getAccessToken)(this.tenantUid);
        targetUrl = targetUrl.startsWith('https') ? targetUrl : `https://${targetUrl}`;
        const headers = configs ? configs.headers : {};
        return this.axios.request({
            method,
            data,
            baseURL: this.getURL(requestUrl),
            responseType: 'json',
            headers: lodash_1.default.merge(headers, {
                Authorization: `Bearer ${token}`,
                'target-url': targetUrl,
                'module-instance-id': this.moduleInstanceId
            })
        });
    }
}
exports.SimpleIrohProxyClient = SimpleIrohProxyClient;
class GenericSourceIrohProxyClient extends SimpleIrohProxyClient {
    constructor(baseUrl, moduleInstanceId, tenantUid, source, fetchData) {
        super(baseUrl, moduleInstanceId, tenantUid);
        this.baseUrl = baseUrl;
        this.moduleInstanceId = moduleInstanceId;
        this.tenantUid = tenantUid;
        this.source = source;
        this.fetchData = fetchData;
        this.errorMessagePath = this.fetchData.errorHandling.messagePath;
        this.errorDetailsPath = this.fetchData.errorHandling.detailsPath;
        this.errorCodePath = this.fetchData.errorHandling.codePath;
        this.solutions = (this.fetchData.errorHandling.codesAndSolutions) ? new Map(Object.entries(this.fetchData.errorHandling.codesAndSolutions)) : undefined;
    }
    async options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            if (err.response) {
                const sourceErrorMessage = lodash_1.default.get(err.response, this.errorMessagePath);
                const sourceErrorDetails = (this.errorDetailsPath) ? lodash_1.default.get(err.response, this.errorDetailsPath) : undefined;
                const sourceErrorCode = (this.errorCodePath) ? lodash_1.default.get(err.response, this.errorCodePath) : undefined;
                if (sourceErrorMessage) {
                    err.message = `${sourceErrorMessage}${(sourceErrorCode) ? ` (${sourceErrorCode})` : ''}${(sourceErrorDetails) ? ` - ${sourceErrorDetails}` : ''}. `;
                }
                else if (err.response.data.error && err.response.data.error_description) {
                    err.message = `${err.response.data.error} - ${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                let isSolutionFound = false;
                if (this.solutions) {
                    const messageForCode = this.solutions.get(`${err.response.status}`);
                    if (messageForCode) {
                        err.message += messageForCode;
                        isSolutionFound = true;
                    }
                }
                if (!isSolutionFound && (err.response.status === 400 || err.response.status === 401)) {
                    err.message += `Please verify the ${lodash_1.default.split(this.source, Util_1.SOURCE_SEPARATOR)[0]} module configuration`;
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.GenericSourceIrohProxyClient where method='${method}', message='${err.message}', status=${err.response.status}, statusText='${err.response.statusText}', tenant='${this.tenantUid}, source='${this.source}', data=${JSON.stringify(err.response.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.GenericSourceIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}, tenant='${this.tenantUid}, source='${this.source}'`);
                throw err;
            }
        });
    }
}
exports.GenericSourceIrohProxyClient = GenericSourceIrohProxyClient;
class AirwatchIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c;
            if (err.response) {
                if (typeof err.response.data.message === 'string') {
                    let message = err.response.data.message;
                    const tenantCodeString = 'Tenant code';
                    const tenantCodeIndex = message.indexOf(tenantCodeString);
                    const doesNotIdentifyString = 'does not identify';
                    const doesNotIdentifyIndex = message.indexOf(doesNotIdentifyString);
                    if (tenantCodeIndex > -1 && doesNotIdentifyIndex > -1) {
                        message = `${message.substring(0, tenantCodeIndex + tenantCodeString.length)} ${message.substring(doesNotIdentifyIndex)}`;
                    }
                    if (message.substring(message.length - 1).indexOf('.') === 0) {
                        message = message.substring(0, message.length - 1);
                    }
                    err.message = `${message}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 401) {
                    err.message += 'Please verify the Airwatch module configuration';
                }
                else if (err.response.status === 403) {
                    err.message += 'Please re-enter the Airwatch module TenantId';
                }
                else if (err.response.status === 404) {
                    err.message += 'Please verify the Airwatch module URL';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.AirwatchIrohProxyClient where method='${method}', message='${err.message}', status=${(_a = err.response) === null || _a === void 0 ? void 0 : _a.status}, statusText='${(_b = err.response) === null || _b === void 0 ? void 0 : _b.statusText}', data=${JSON.stringify((_c = err.response) === null || _c === void 0 ? void 0 : _c.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.AirwatchIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.AirwatchIrohProxyClient = AirwatchIrohProxyClient;
class AmpIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d, _e;
            if (err.response) {
                if (((_a = err.response.data.errors) === null || _a === void 0 ? void 0 : _a.length) > 0
                    && err.response.data.errors[0].description
                    && ((_b = err.response.data.errors[0].details) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                    err.message = `${err.response.data.errors[0].description} - ${err.response.data.errors[0].details[0]}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 401) {
                    err.message += 'Please verify the Secure Endpoint module configuration';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.AmpIrohProxyClient where method='${method}', message='${err.message}', status=${(_c = err.response) === null || _c === void 0 ? void 0 : _c.status}, statusText='${(_d = err.response) === null || _d === void 0 ? void 0 : _d.statusText}', data=${JSON.stringify((_e = err.response) === null || _e === void 0 ? void 0 : _e.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.AmpIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.AmpIrohProxyClient = AmpIrohProxyClient;
class CrowdStrikeIrohProxyClient extends SimpleIrohProxyClient {
    async options(url, method = 'get', data, configs) {
        configs = { ...(configs || {}), headers: { ...(configs && configs.headers ? configs.headers : {}), 'User-Agent': 'Cisco-XDR-Insights/1.0' } };
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d;
            if (err.response) {
                if (((_a = err.response.data.errors) === null || _a === void 0 ? void 0 : _a.length) > 0 && err.response.data.errors[0].message && err.response.data.errors[0].code) {
                    err.message = `${err.response.data.errors[0].message} (${err.response.data.errors[0].code}). `;
                }
                else if (err.response.data.error && err.response.data.error_description) {
                    err.message = `${err.response.data.error} - ${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401) {
                    err.message += 'Please verify the CrowdStrike module configuration';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.CloudStrikeIrohProxyClient where method='${method}', message='${err.message}', status=${(_b = err.response) === null || _b === void 0 ? void 0 : _b.status}, statusText='${(_c = err.response) === null || _c === void 0 ? void 0 : _c.statusText}', data=${JSON.stringify((_d = err.response) === null || _d === void 0 ? void 0 : _d.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.CloudStrikeIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.CrowdStrikeIrohProxyClient = CrowdStrikeIrohProxyClient;
class DefenderIrohProxyClient extends SimpleIrohProxyClient {
    async options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d;
            if (err.response) {
                if (((_a = err.response.data.errors) === null || _a === void 0 ? void 0 : _a.length) > 0 && err.response.data.errors[0].message && err.response.data.errors[0].code) {
                    err.message = `${err.response.data.errors[0].message.split('.')[0]} (${err.response.data.errors[0].code}). `;
                }
                else if (err.response.data.error && err.response.data.error.message && err.response.data.error.code) {
                    err.message = `${err.response.data.error.message} (${err.response.data.error.code}). `;
                }
                else if (err.response.data.error && err.response.data.error_description) {
                    err.message = `${err.response.data.error} - ${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401) {
                    err.message += 'Please verify the Defender module configuration';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.DefenderIrohProxyClient where method='${method}', message='${err.message}', status=${(_b = err.response) === null || _b === void 0 ? void 0 : _b.status}, statusText='${(_c = err.response) === null || _c === void 0 ? void 0 : _c.statusText}', data=${JSON.stringify((_d = err.response) === null || _d === void 0 ? void 0 : _d.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.DefenderIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.DefenderIrohProxyClient = DefenderIrohProxyClient;
class DuoIrohProxyClient extends SimpleIrohProxyClient {
    async jsonApiCall(method, path, params, callback) {
        const qs = queryString.stringify(params);
        try {
            const result = await this.get(`${path}?${qs}`);
            return callback(result.data);
        }
        catch (error) {
            this.logger.error(`Error occurred in DuoIrohProxyClient: ${error.message}`);
            return callback(error);
        }
    }
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c;
            if (err.response) {
                if (typeof err.response.data.message === 'string' && err.response.data.code) {
                    err.message = `${err.response.data.message} (Duo code: ${err.response.data.code}). `;
                }
                else if (typeof err.response.data.error_description === 'string') {
                    err.message = `${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401 || err.response.status === 403) {
                    err.message += 'Please verify the Duo module configuration';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.DuoIrohProxyClient where method='${method}', message='${err.message}', status=${(_a = err.response) === null || _a === void 0 ? void 0 : _a.status}, statusText='${(_b = err.response) === null || _b === void 0 ? void 0 : _b.statusText}', data=${JSON.stringify((_c = err.response) === null || _c === void 0 ? void 0 : _c.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.DuoIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.DuoIrohProxyClient = DuoIrohProxyClient;
class IntuneIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d, _e, _f;
            if (err.response) {
                if (typeof ((_a = err.response.data.error) === null || _a === void 0 ? void 0 : _a.message) === 'string') {
                    let message = err.response.data.error.message;
                    if (message.substring(message.length - 1).indexOf('.') === 0) {
                        message = message.substring(0, message.length - 1);
                    }
                    err.message = `${message}. `;
                }
                else if (typeof err.response.data.message === 'string') {
                    err.message = err.response.data.message;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (((_b = err.response) === null || _b === void 0 ? void 0 : _b.status) === 401) {
                    err.message += 'Please verify the Intune module configuration';
                }
                else if (((_c = err.response) === null || _c === void 0 ? void 0 : _c.status) === 500) {
                    err.message += 'Please verify the Intune module token URL';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.IntuneIrohProxyClient where method='${method}', message='${err.message}', status=${(_d = err.response) === null || _d === void 0 ? void 0 : _d.status}, statusText='${(_e = err.response) === null || _e === void 0 ? void 0 : _e.statusText}', data=${JSON.stringify((_f = err.response) === null || _f === void 0 ? void 0 : _f.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.IntuneIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.IntuneIrohProxyClient = IntuneIrohProxyClient;
class CyberVisionIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d, _e;
            if (err.response) {
                if (((_a = err.response.data.error) === null || _a === void 0 ? void 0 : _a.message) && ((_b = err.response.data.error) === null || _b === void 0 ? void 0 : _b.detail)) {
                    err.message = `${err.response.data.error.message} - ${err.response.data.error.detail}. `;
                }
                else if (err.response.data.error && err.response.data.error_description) {
                    err.message = `${err.response.data.error} - ${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401) {
                    err.message += 'Please verify the CyberVision module configuration';
                }
                else if (err.response.status === 403) {
                    err.message += 'CyberVision account requires permission to perform action';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.CyberVisionIrohProxyClient where method='${method}', message='${err.message}', status=${(_c = err.response) === null || _c === void 0 ? void 0 : _c.status}, statusText='${(_d = err.response) === null || _d === void 0 ? void 0 : _d.statusText}', data=${JSON.stringify((_e = err.response) === null || _e === void 0 ? void 0 : _e.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.CyberVisionIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.CyberVisionIrohProxyClient = CyberVisionIrohProxyClient;
class JamfIrohProxyClient extends SimpleIrohProxyClient {
    getClassicApiAxios() {
        return this;
    }
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c;
            if (err.response) {
                if (typeof err.response.data.error_description === 'string') {
                    err.message = `${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401) {
                    err.message += 'Please verify the Jamf Pro module configuration';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.JamfIrohProxyClient where method='${method}', message='${err.message}', status=${(_a = err.response) === null || _a === void 0 ? void 0 : _a.status}, statusText='${(_b = err.response) === null || _b === void 0 ? void 0 : _b.statusText}', data=${JSON.stringify((_c = err.response) === null || _c === void 0 ? void 0 : _c.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.JamfIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.JamfIrohProxyClient = JamfIrohProxyClient;
class MerakiIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d;
            if (err.response) {
                if (((_a = err.response.data.errors) === null || _a === void 0 ? void 0 : _a.length) > 0
                    && typeof err.response.data.errors[0] === 'string') {
                    err.message = `${err.response.data.errors[0]}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 401) {
                    err.message += 'Please verify the Meraki module API key';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.MerakiIrohProxyClient where method='${method}', message='${err.message}', status=${(_b = err.response) === null || _b === void 0 ? void 0 : _b.status}, statusText='${(_c = err.response) === null || _c === void 0 ? void 0 : _c.statusText}', data=${JSON.stringify((_d = err.response) === null || _d === void 0 ? void 0 : _d.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.MerakiIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.MerakiIrohProxyClient = MerakiIrohProxyClient;
class MobileIronIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c;
            if (err.response) {
                this.logger.error(`AxiosError occurred in ProxyClientFactory.MobileIronIrohProxyClient where method='${method}', message='${err.message}', status=${(_a = err.response) === null || _a === void 0 ? void 0 : _a.status}, statusText='${(_b = err.response) === null || _b === void 0 ? void 0 : _b.statusText}', data=${JSON.stringify((_c = err.response) === null || _c === void 0 ? void 0 : _c.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.MobileIronIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.MobileIronIrohProxyClient = MobileIronIrohProxyClient;
class ServiceNowIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d, _e;
            if (err.response) {
                if (((_a = err.response.data.error) === null || _a === void 0 ? void 0 : _a.message) && ((_b = err.response.data.error) === null || _b === void 0 ? void 0 : _b.detail)) {
                    err.message = `${err.response.data.error.message} - ${err.response.data.error.detail}. `;
                }
                else if (err.response.data.error && err.response.data.error_description) {
                    err.message = `${err.response.data.error} - ${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 401) {
                    err.message += 'Please verify the ServiceNow module configuration';
                }
                else if (err.response.status === 403) {
                    err.message += 'ServiceNow account requires permission to perform action';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.ServiceNowIrohProxyClient where method='${method}', message='${err.message}', status=${(_c = err.response) === null || _c === void 0 ? void 0 : _c.status}, statusText='${(_d = err.response) === null || _d === void 0 ? void 0 : _d.statusText}', data=${JSON.stringify((_e = err.response) === null || _e === void 0 ? void 0 : _e.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.ServiceNowIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.ServiceNowIrohProxyClient = ServiceNowIrohProxyClient;
class UmbrellaIrohProxyClient extends SimpleIrohProxyClient {
    getNetworkApiAxios() {
        return this;
    }
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c;
            if (err.response) {
                if (typeof err.response.data.error_description === 'string') {
                    err.message = `${err.response.data.error_description}. `;
                }
                else if (typeof err.response.data.message == 'string') {
                    err.message = `${err.response.data.message}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401) {
                    err.message += 'Please verify the Umbrella module configuration';
                }
                else if (err.response.status === 429) {
                    err.message += 'Please wait a moment then try again';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.UmbrellaIrohProxyClient where method='${method}', message='${err.message}', status=${(_a = err.response) === null || _a === void 0 ? void 0 : _a.status}, statusText='${(_b = err.response) === null || _b === void 0 ? void 0 : _b.statusText}', data=${JSON.stringify((_c = err.response) === null || _c === void 0 ? void 0 : _c.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.UmbrellaIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.UmbrellaIrohProxyClient = UmbrellaIrohProxyClient;
class SentinelOneIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d, _e;
            if (err.response) {
                if (((_a = err.response.data.error) === null || _a === void 0 ? void 0 : _a.message) && ((_b = err.response.data.error) === null || _b === void 0 ? void 0 : _b.detail)) {
                    err.message = `${err.response.data.error.message} - ${err.response.data.error.detail}. `;
                }
                else if (err.response.data.error && err.response.data.error_description) {
                    err.message = `${err.response.data.error} - ${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401) {
                    err.message += 'Please verify the SentinelOne module configuration';
                }
                else if (err.response.status === 403) {
                    err.message += 'SentinelOne account requires permission to perform action';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.SentinelOneIrohProxyClient where method='${method}', message='${err.message}', status=${(_c = err.response) === null || _c === void 0 ? void 0 : _c.status}, statusText='${(_d = err.response) === null || _d === void 0 ? void 0 : _d.statusText}', data=${JSON.stringify((_e = err.response) === null || _e === void 0 ? void 0 : _e.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.SentinelOneIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.SentinelOneIrohProxyClient = SentinelOneIrohProxyClient;
class AzureUsersIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        if (url.includes('transitiveMemberOf') || url.includes('signInActivity')) {
            configs = { ...configs, headers: { ConsistencyLevel: 'eventual' } };
        }
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d, _e;
            if (err.response) {
                if (((_a = err.response.data.error) === null || _a === void 0 ? void 0 : _a.message) && ((_b = err.response.data.error) === null || _b === void 0 ? void 0 : _b.detail)) {
                    err.message = `${err.response.data.error.message} - ${err.response.data.error.detail}. `;
                }
                else if (err.response.data.error && err.response.data.error_description) {
                    err.message = `${err.response.data.error} - ${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401) {
                    err.message += 'Please verify the Azure Users module configuration';
                }
                else if (err.response.status === 403) {
                    err.message += 'Azure account requires permission to perform action';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.AzureUsersIrohProxyClient where method='${method}', message='${err.message}', status=${(_c = err.response) === null || _c === void 0 ? void 0 : _c.status}, statusText='${(_d = err.response) === null || _d === void 0 ? void 0 : _d.statusText}', data=${JSON.stringify((_e = err.response) === null || _e === void 0 ? void 0 : _e.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.AzureUsersIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.AzureUsersIrohProxyClient = AzureUsersIrohProxyClient;
class TrendVisionOneIrohProxyClient extends SimpleIrohProxyClient {
    options(url, method = 'get', data, configs) {
        configs = { ...configs, headers: { ...((configs === null || configs === void 0 ? void 0 : configs.headers) || {}), 'TMV1-Query': "(productCode eq 'sao' or productCode eq 'sds' or productCode eq 'xes')" } };
        return super.options(url, method, data, configs)
            .catch((err) => {
            var _a, _b, _c, _d, _e;
            if (err.response) {
                if (((_a = err.response.data.error) === null || _a === void 0 ? void 0 : _a.message) && ((_b = err.response.data.error) === null || _b === void 0 ? void 0 : _b.detail)) {
                    err.message = `${err.response.data.error.message} - ${err.response.data.error.detail}. `;
                }
                else if (err.response.data.error && err.response.data.error_description) {
                    err.message = `${err.response.data.error} - ${err.response.data.error_description}. `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400 || err.response.status === 401) {
                    err.message += 'Please verify the TrendVisionOne module configuration';
                }
                else if (err.response.status === 403) {
                    err.message += 'TrendVisionOne account requires permission to perform action';
                }
                this.logger.error(`AxiosError occurred in ProxyClientFactory.TrendVisionOneIrohProxyClient where method='${method}', message='${err.message}', status=${(_c = err.response) === null || _c === void 0 ? void 0 : _c.status}, statusText='${(_d = err.response) === null || _d === void 0 ? void 0 : _d.statusText}', data=${JSON.stringify((_e = err.response) === null || _e === void 0 ? void 0 : _e.data)}`);
                throw err;
            }
            else {
                const other = err;
                this.logger.error(`Unhandled Error occurred in ProxyClientFactory.TrendVisionOneIrohProxyClient where method='${method}', message='${other.message}', name=${other.name}`);
                throw err;
            }
        });
    }
}
exports.TrendVisionOneIrohProxyClient = TrendVisionOneIrohProxyClient;
