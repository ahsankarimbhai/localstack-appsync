"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeatureFlag = exports.TenantConfiguration = exports.Tenant = exports.TenantServices = exports.TenantSetupStatus = void 0;
const _ = __importStar(require("lodash"));
const DynamoDBServices_1 = require("./awsclient/dynamodb/DynamoDBServices");
const LambdaLogger_1 = require("./LambdaLogger");
const Util_1 = require("./Util");
const CommonTypes_1 = require("./CommonTypes");
const DateUtils_1 = require("./DateUtils");
const DynamodbServiceFactory_1 = require("./awsclient/dynamodb/DynamodbServiceFactory");
const MemoryCache_1 = require("./cache/MemoryCache");
var TenantSetupStatus;
(function (TenantSetupStatus) {
    TenantSetupStatus["NOT_SETUP"] = "not_setup";
    TenantSetupStatus["SETTING_UP"] = "setting_up";
    TenantSetupStatus["SET_UP"] = "set_up";
    TenantSetupStatus["RESETUP_REQUIRED"] = "resetup_required";
})(TenantSetupStatus = exports.TenantSetupStatus || (exports.TenantSetupStatus = {}));
class TenantServices {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.TENANT_FEATURE_FLAGS = 'featureFlags';
        this.SETUP_STATUS = 'setupStatus';
    }
    static getTenantConfigKey(tenantUid, configKey) {
        return tenantUid + DynamoDBServices_1.DynamoDBServices.KEY_SEPARATOR + configKey;
    }
    async addTenant(tenant) {
        if (_.isNil(tenant.extId)) {
            throw new Error('Tenant extId must be defined');
        }
        if (await this.getTenantById(tenant.id)) {
            throw new Error(`Tenant with id: ${tenant.id} already exists`);
        }
        if (await this.getTenantByExtId(tenant.extId)) {
            throw new Error(`Tenant with extId: ${tenant.extId} already exists`);
        }
        return this.addTenantEntry(tenant);
    }
    activateTenant(tenantUid) {
        return this.updateDeletedAt(tenantUid, undefined);
    }
    addTenantEntry(tenant) {
        const addTenantQuery = {
            id: tenant.id,
            extId: tenant.extId,
            description: tenant.description,
            createdAt: new Date().toISOString()
        };
        this.logger.log(`Creating tenant ${tenant}`);
        return this.dynamoDBServices.save(Tenant.TABLE_NAME, addTenantQuery);
    }
    static considerSoftDeletedTenant(tenant, allowSoftDeleted) {
        if (tenant) {
            if (allowSoftDeleted) {
                return tenant;
            }
            return _.get(tenant, 'deletedAt') ? undefined : tenant;
        }
        return undefined;
    }
    async getTenantById(tenantId, allowSoftDeleted = false) {
        const tenant = await this.dynamoDBServices.getByKey(Tenant.TABLE_NAME, Tenant.TENANT_ID, tenantId);
        return TenantServices.considerSoftDeletedTenant(tenant, allowSoftDeleted);
    }
    async getTenantByExtId(tenantExtId, allowSoftDeleted = false) {
        const tenants = await this.dynamoDBServices
            .getItemsBySecondaryIndex(Tenant.TABLE_NAME, Tenant.EXT_ID_INDEX, Tenant.TENANT_EXT_ID, tenantExtId);
        const tenant = _.isEmpty(tenants) ? undefined : tenants[0];
        return TenantServices.considerSoftDeletedTenant(tenant, allowSoftDeleted);
    }
    deleteTenant(tenantId, soft = false) {
        if (soft) {
            return this.updateDeletedAt(tenantId, Date.now());
        }
        return this.dynamoDBServices.delete(Tenant.TABLE_NAME, Tenant.TENANT_ID, tenantId);
    }
    updateDeletedAt(tenantId, deletedAt) {
        const key = { id: tenantId };
        if (deletedAt) {
            const update = { deletedAt };
            return this.dynamoDBServices.update(Tenant.TABLE_NAME, key, update);
        }
        return this.dynamoDBServices.removeProperties(Tenant.TABLE_NAME, key, Tenant.DELETED_AT);
    }
    addTenantConfiguration(tenantConfig) {
        const addTenantConfigQuery = {
            tenantUid: tenantConfig.tenantUid,
            tenantKey: tenantConfig.getTenantConfigKey(),
            value: tenantConfig.value,
            name: tenantConfig.name,
            description: tenantConfig.description,
            createdAt: new Date().toISOString(),
            irohModuleInstanceId: tenantConfig.irohModuleInstanceId
        };
        return this.dynamoDBServices.save(TenantConfiguration.TABLE_NAME, addTenantConfigQuery);
    }
    updateTenantConfigurationValue(tenantConfig) {
        const key = {};
        key[TenantConfiguration.TENANT_KEY] = tenantConfig.getTenantConfigKey();
        const update = { tenantUid: tenantConfig.tenantUid, value: tenantConfig.value };
        return this.dynamoDBServices.update(TenantConfiguration.TABLE_NAME, key, update);
    }
    getTenantConfiguration(tenantId, configKey) {
        return this.dynamoDBServices.getByKey(TenantConfiguration.TABLE_NAME, TenantConfiguration.TENANT_KEY, TenantServices.getTenantConfigKey(tenantId, configKey));
    }
    getAllTenants() {
        return this.getTenantsByFilter(DynamoDBServices_1.DynamoDBServices.NOT_SOFT_DELETED);
    }
    getInactiveTenants() {
        return this.getTenantsByFilter(DynamoDBServices_1.DynamoDBServices.SOFT_DELETED);
    }
    async getTenantsByFilter(filter) {
        let returnItems = [];
        let lastEvaluatedKey;
        do {
            const response = await this.dynamoDBServices.getFilteredTableEntries(Tenant.TABLE_NAME, filter, undefined, lastEvaluatedKey);
            returnItems = _.concat(returnItems, _.map(response.items, item => new Tenant(_.get(item, Tenant.TENANT_ID), _.get(item, Tenant.TENANT_EXT_ID), _.get(item, Tenant.CREATED_AT), _.get(item, Tenant.DESCR), _.get(item, Tenant.DELETED_AT))));
            lastEvaluatedKey = response.lastEvaluatedKey;
        } while (lastEvaluatedKey);
        return returnItems;
    }
    async getTenantSources(tenantId) {
        const tenantConfigs = await this.getTenantConfigurations(tenantId);
        return _.compact(_.map(tenantConfigs, (config) => {
            try {
                const value = JSON.parse(config.value);
                return (0, Util_1.toSourceString)(value.source, value.sourceId);
            }
            catch (err) {
                this.logger.warn(`Invalid tenant configuration: ${JSON.stringify(config)}`);
                return undefined;
            }
        }));
    }
    async verifyDistinctName(tenantId, name) {
        const allTenantConfigs = await this.getTenantConfigurations(tenantId);
        if (_.find(allTenantConfigs, { name })) {
            throw new Error(`Source with name "${name}" already exists`);
        }
    }
    async getPullEnabledTenantConfigurations(tenantId) {
        const producerConfigurations = await this.getProducerConfigurations(tenantId);
        return _.filter(producerConfigurations, (cfg) => !(0, CommonTypes_1.sourceNotSupportingPull)(cfg.producerType));
    }
    getTenantConfigurations(tenantId) {
        return this.getTenantConfigurationsHelper(tenantId, 'attribute_not_exists(deletedAt)');
    }
    getTenantConfigurationsForAllTenantsAtTime(timeInMilliseconds) {
        return this.getTenantConfigurationsForAllTenants(undefined, 'attribute_not_exists(deletedAt) or deletedAt > :deletedAt', { ':deletedAt': timeInMilliseconds });
    }
    async getTenantConfigurationsForAllTenants(lastEvaluatedKey, filterExpression = 'attribute_not_exists(deletedAt) or deletedAt > :deletedAt', expressionAttributeValues = { ':deletedAt': (Date.now() - DateUtils_1.DAY_MILLIS) }) {
        let returnItems = [];
        const response = await this.dynamoDBServices.getFilteredTableEntries(TenantConfiguration.TABLE_NAME, filterExpression, expressionAttributeValues, lastEvaluatedKey);
        if (response.lastEvaluatedKey) {
            returnItems = await this.getTenantConfigurationsForAllTenants(response.lastEvaluatedKey, filterExpression, expressionAttributeValues);
        }
        return _.concat(returnItems, response.items);
    }
    getAllTenantConfigurations(tenantId) {
        return this.getTenantConfigurationsHelper(tenantId);
    }
    async fetchTenantConfigurationsWithTenantKeyFilters(tenantId, tenantKeyFilters) {
        try {
            let filterExpression = '';
            let index = 1;
            const expressionAttributeNames = { '#deletedAt': 'deletedAt' };
            const expressionAttributeValues = {};
            tenantKeyFilters.forEach((currentValue) => {
                if (!filterExpression) {
                    filterExpression = filterExpression.concat('(');
                }
                else {
                    filterExpression = filterExpression.concat(' or ');
                }
                filterExpression = filterExpression.concat(`contains(#tenantKey, :containsValue${index})`);
                expressionAttributeNames['#tenantKey'] = 'tenantKey';
                expressionAttributeValues[`:containsValue${index}`] = currentValue;
                index += 1;
            });
            if (filterExpression) {
                filterExpression = filterExpression.concat(') and ');
            }
            filterExpression = filterExpression.concat('attribute_not_exists(#deletedAt)');
            return this.getTenantConfigurationsHelper(tenantId, filterExpression, expressionAttributeNames, expressionAttributeValues);
        }
        catch (error) {
            this.logger.error(`Error while fetching tenant configurations containing tenantId: ${tenantId} and tenantKeyFilter: ${tenantKeyFilters}`);
            throw error;
        }
    }
    async verifyWebhookConfigExistence(tenantUid, sourceString) {
        const idParts = _.split(sourceString, Util_1.SOURCE_SEPARATOR);
        if (!idParts || idParts.length !== 2) {
            throw new Error(`Unexpected source string: ${sourceString}`);
        }
        const producerId = idParts[1];
        const source = idParts[0];
        const tenantKeyFilters = [sourceString];
        switch (source) {
            case CommonTypes_1.Source.JAMF:
                tenantKeyFilters.push(`jamf_webhooks_ids__${producerId}`);
                break;
            case CommonTypes_1.Source.AMP:
                tenantKeyFilters.push(`amp_webhook_id__${producerId}`);
                break;
            case CommonTypes_1.Source.UNIFIED_CONNECTOR:
                tenantKeyFilters.push(`unifiedConnector_webhook_id__${producerId}`);
                break;
            case CommonTypes_1.Source.ORBITAL:
                break;
            default:
                throw new Error(`Unhandled source: ${source}`);
        }
        const configs = await this.fetchTenantConfigurationsWithTenantKeyFilters(tenantUid, tenantKeyFilters);
        if (!configs || configs.length < 1) {
            return false;
        }
        if (source === CommonTypes_1.Source.ORBITAL) {
            return true;
        }
        return configs.findIndex(config => config.tenantKey.includes('webhook')) !== -1 && configs.findIndex(config => !config.tenantKey.includes('webhook')) !== -1;
    }
    async getOrbitalProducerByQueryId(extId, osQueryId) {
        const tenant = await this.getTenantByExtId(extId);
        if (!tenant) {
            throw new Error(`tenant does not exist for extId ${extId}`);
        }
        const activeOrbitalConfigs = _.filter(await this.getProducerConfigurations(tenant.id), config => config.producerType === CommonTypes_1.Source.ORBITAL);
        const matchedConfig = activeOrbitalConfigs.find(config => {
            var _a;
            const osQueryResponse = (_a = config.properties.find(p => p.key === 'osQueryResponse')) === null || _a === void 0 ? void 0 : _a.value;
            if (!osQueryResponse) {
                return false;
            }
            if (Array.isArray(osQueryResponse)) {
                return osQueryResponse.some(r => r.ID === osQueryId);
            }
            return osQueryResponse.ID === osQueryId;
        });
        if (!matchedConfig) {
            throw new Error(`Orbital producer is not found for osQueryId ${osQueryId}`);
        }
        return {
            tenantUid: tenant.id,
            producerId: matchedConfig.producerId
        };
    }
    async getTenantConfigurationsHelper(tenantId, filterExpression, expressionAttributeNames, expressionAttributeValues, lastEvaluatedKey) {
        return this.dynamoDBServices.getItemsBySecondaryIndex(TenantConfiguration.TABLE_NAME, TenantConfiguration.getDynamoDBTenantUidIndex(), TenantConfiguration.TENANT_UID, tenantId, filterExpression, expressionAttributeNames, expressionAttributeValues, lastEvaluatedKey);
    }
    deleteTenantConfiguration(tenantId, configKey) {
        return this.dynamoDBServices.delete(TenantConfiguration.TABLE_NAME, TenantConfiguration.TENANT_KEY, TenantServices.getTenantConfigKey(tenantId, configKey));
    }
    updateProducerConfiguration(tenantId, configKey, description, name, value, irohModuleInstanceId) {
        const key = {};
        key[TenantConfiguration.TENANT_KEY] = TenantServices.getTenantConfigKey(tenantId, configKey);
        const update = {
            value
        };
        if (!_.isNil(name)) {
            update.name = name;
        }
        if (!_.isNil(description)) {
            update.description = description;
        }
        if (!_.isNil(irohModuleInstanceId)) {
            update.irohModuleInstanceId = irohModuleInstanceId;
        }
        return this.dynamoDBServices.update(TenantConfiguration.TABLE_NAME, key, update);
    }
    markDeletedProducerConfiguration(tenantId, configKey) {
        const key = {};
        key[TenantConfiguration.TENANT_KEY] = TenantServices.getTenantConfigKey(tenantId, configKey);
        const update = { deletedAt: Date.now() };
        return this.dynamoDBServices.update(TenantConfiguration.TABLE_NAME, key, update);
    }
    deleteTenantConfigurationByKey(key) {
        return this.dynamoDBServices.delete(TenantConfiguration.TABLE_NAME, TenantConfiguration.TENANT_KEY, key);
    }
    async getTenantConfigurationOrFail(tenantUid, producerType, producerId) {
        const cfgKey = (0, Util_1.toSourceString)(producerType, producerId);
        const cfg = await this.getTenantConfiguration(tenantUid, cfgKey);
        if (!cfg) {
            throw new Error(`could not find configuration for producer ${producerType} with id ${producerId}`);
        }
        return cfg;
    }
    async getProducerConfigurations(tenantUid) {
        const configurations = await this.getTenantConfigurations(tenantUid);
        return this.mapToProducerConfigurations(configurations);
    }
    async getDeletedProducerConfigurations(tenantId) {
        const configurations = await this.getTenantConfigurationsHelper(tenantId, 'attribute_exists(deletedAt)');
        return this.mapToProducerConfigurations(configurations);
    }
    mapToProducerConfigurations(configurations) {
        return _
            .chain(configurations)
            .map(cfg => {
            let value;
            try {
                value = JSON.parse(cfg.value);
            }
            catch (e) {
                return undefined;
            }
            return { ...cfg, value };
        })
            .filter(cfg => _.has(cfg, 'value.sourceId'))
            .map(cfg => TenantServices.mapToProducerConfiguration(cfg))
            .value();
    }
    static mapToProducerConfiguration(cfg) {
        return {
            producerType: _.split(cfg.tenantKey, Util_1.SOURCE_SEPARATOR)[1],
            producerId: _.get(cfg, 'value.sourceId'),
            description: cfg.description,
            name: cfg.name,
            irohModuleInstanceId: cfg.irohModuleInstanceId,
            isGeneric: cfg.isGeneric,
            cronSchedule: _.get(cfg, 'value.schedule'),
            properties: _.map(_.omit(cfg.value, ['sourceId', 'schedule']), (value, key) => ({ key, value }))
        };
    }
    async getTenantSetupStatus(tenantUid) {
        const tenantSetupStatusConfig = await this.getTenantConfiguration(tenantUid, this.SETUP_STATUS);
        return _.isEmpty(tenantSetupStatusConfig) ? {} : JSON.parse(tenantSetupStatusConfig.value);
    }
    async setTenantSetupStatus(tenantUid, setupStatus) {
        const updateConfig = new TenantConfiguration(tenantUid, this.SETUP_STATUS, JSON.stringify({ setupStatus, updateTime: new Date().getTime() }));
        this.logger.debug(`Setting the tenant setup status for tenant ${tenantUid} to ${setupStatus}`);
        return this.updateTenantConfigurationValue(updateConfig);
    }
    async isTenantFeatureOn(tenantUid, featureFlag) {
        const tenantFeatures = await this.getFeatureFlags(tenantUid);
        return _.includes(tenantFeatures, featureFlag);
    }
    async isGlobalFeatureOn(featureFlag) {
        const globalFF = await this.getGlobalFeatureFlags();
        return _.includes(globalFF, featureFlag);
    }
    async getGlobalFeatureFlags() {
        const globalFeatures = await this.getTenantConfiguration(TenantServices.GLOBAL, this.TENANT_FEATURE_FLAGS);
        return globalFeatures ? JSON.parse(globalFeatures.value) || [] : [];
    }
    async getFeatureFlags(tenantUid) {
        const featureFlags = await this.getGlobalFeatureFlags();
        const tenantFeatures = await this.getTenantConfiguration(tenantUid, this.TENANT_FEATURE_FLAGS);
        return _.union(_.concat(featureFlags, tenantFeatures ? JSON.parse(tenantFeatures.value) || [] : []));
    }
    async enableFeatureFlagForAllTenants(featureFlag) {
        const tenants = await this.getAllTenants();
        return Promise.all(_.map(tenants, tenant => this.addFeatureFlags(tenant.id, [featureFlag])));
    }
    async disableFeatureFlagForAllTenants(featureFlag) {
        const tenants = await this.getAllTenants();
        return Promise.all(_.map(tenants, tenant => this.removeFeatureFlags(tenant.id, [featureFlag])));
    }
    async addFeatureFlags(tenantUid, featureFlags) {
        await this.validateTenantExistence(tenantUid);
        let tenantFeatures = await this.getTenantConfiguration(tenantUid, this.TENANT_FEATURE_FLAGS);
        if (!tenantFeatures) {
            tenantFeatures = new TenantConfiguration(tenantUid, this.TENANT_FEATURE_FLAGS, JSON.stringify(''), undefined, `${tenantUid} feature flags`);
            await this.addTenantConfiguration(tenantFeatures);
        }
        let features = JSON.parse(tenantFeatures.value) || [];
        features = _.union(_.concat(features, featureFlags));
        return this.updateTenantFeatureFlags(tenantUid, features, tenantFeatures);
    }
    async validateTenantExistence(tenantUid) {
        if (tenantUid !== TenantServices.GLOBAL) {
            const tenant = await this.getTenantById(tenantUid);
            if (!tenant) {
                throw new Error(`Could not find tenant ${tenantUid}`);
            }
        }
    }
    async removeFeatureFlags(tenantUid, featureFlags) {
        await this.validateTenantExistence(tenantUid);
        const tenantFeatures = await this.getTenantConfiguration(tenantUid, this.TENANT_FEATURE_FLAGS);
        let features = [];
        if (tenantFeatures) {
            features = JSON.parse(tenantFeatures.value) || [];
            return this.updateTenantFeatureFlags(tenantUid, _.differenceWith(features, featureFlags), tenantFeatures);
        }
        return Promise.resolve();
    }
    updateTenantFeatureFlags(tenantUid, features, tenantFeatures) {
        const updateConfig = new TenantConfiguration(tenantUid, this.TENANT_FEATURE_FLAGS, JSON.stringify(features), tenantFeatures.description, tenantFeatures.name);
        return this.updateTenantConfigurationValue(updateConfig);
    }
}
TenantServices.GLOBAL = 'global';
__decorate([
    (0, MemoryCache_1.memCacheDecorator)('isTenantFeatureOn', 900)
], TenantServices.prototype, "isTenantFeatureOn", null);
exports.TenantServices = TenantServices;
class Tenant {
    constructor(id, extId, createdAt, description, deletedAt) {
        this.id = id;
        this.extId = extId;
        this.createdAt = createdAt;
        this.description = description;
        this.deletedAt = deletedAt;
        this.toString = () => `Tenant (id: ${this.id}, extId: ${this.extId}, description: ${this.description})`;
    }
}
exports.Tenant = Tenant;
Tenant.TABLE_NAME = 'tenant';
Tenant.TENANT_ID = 'id';
Tenant.TENANT_EXT_ID = 'extId';
Tenant.DESCR = 'description';
Tenant.DELETED_AT = 'deletedAt';
Tenant.CREATED_AT = 'createdAt';
Tenant.EXT_ID_INDEX = DynamoDBServices_1.DynamoDBServices.getTableName('ext-id-idx');
class TenantConfiguration {
    constructor(tenantUid, key, value, description, name, irohModuleInstanceId, isGeneric = false) {
        this.tenantUid = tenantUid;
        this.key = key;
        this.value = value;
        this.description = description;
        this.name = name;
        this.irohModuleInstanceId = irohModuleInstanceId;
        this.isGeneric = isGeneric;
    }
    getTenantConfigKey() {
        return TenantServices.getTenantConfigKey(this.tenantUid, this.key);
    }
    static generateSourceId() {
        return (0, Util_1.generateSecret)(32);
    }
    static getDynamoDBTenantUidIndex() {
        return DynamoDBServices_1.DynamoDBServices.getTableName(this.TENANT_UID_INDEX);
    }
}
exports.TenantConfiguration = TenantConfiguration;
TenantConfiguration.TABLE_NAME = 'tenant-config';
TenantConfiguration.TENANT_KEY = 'tenantKey';
TenantConfiguration.TENANT_UID = 'tenantUid';
TenantConfiguration.TENANT_UID_INDEX = 'tenant-uid-idx';
var FeatureFlag;
(function (FeatureFlag) {
    FeatureFlag["ES_POSTURE_ENDPOINTS"] = "ES_POSTURE_ENDPOINTS";
    FeatureFlag["SERVICE_NOW"] = "SERVICE_NOW";
    FeatureFlag["CYBER_VISION_ENABLED"] = "CYBER_VISION_ENABLED";
    FeatureFlag["TREND_VISION_ONE"] = "TREND_VISION_ONE";
    FeatureFlag["DUO_USERS"] = "DUO_USERS";
    FeatureFlag["GENERIC_SOURCE"] = "GENERIC_SOURCE";
    FeatureFlag["REDUCE_SCHEDULING"] = "REDUCE_SCHEDULING";
    FeatureFlag["IPADOS_ENABLED"] = "IPADOS_ENABLED";
    FeatureFlag["PRE_RELEASE_ENABLED"] = "PRE_RELEASE_ENABLED";
    FeatureFlag["MANUAL_LABELS_VALUE"] = "MANUAL_LABELS_VALUE";
    FeatureFlag["INCIDENTS_ENABLED"] = "INCIDENTS_ENABLED";
    FeatureFlag["DATA_SHARING_WEBHOOKS"] = "DATA_SHARING_WEBHOOKS";
    FeatureFlag["ES_BASED_SEARCH"] = "ES_BASED_SEARCH";
    FeatureFlag["ORBITAL_WEBHOOK_S3_RECEIVER"] = "ORBITAL_WEBHOOK_S3_RECEIVER";
    FeatureFlag["ASSETS_MULTIPLE_SOURCE_EXT_IDS_ENABLED"] = "ASSETS_MULTIPLE_SOURCE_EXT_IDS_ENABLED";
    FeatureFlag["NONE"] = "NONE";
})(FeatureFlag = exports.FeatureFlag || (exports.FeatureFlag = {}));
