"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneShardMigrationLogRepo = exports.NeptuneShardMigrationStatus = void 0;
const _ = __importStar(require("lodash"));
const DynamodbServiceFactory_1 = require("../awsclient/dynamodb/DynamodbServiceFactory");
var NeptuneShardMigrationStatus;
(function (NeptuneShardMigrationStatus) {
    NeptuneShardMigrationStatus["CREATE"] = "CREATE";
    NeptuneShardMigrationStatus["START"] = "START";
    NeptuneShardMigrationStatus["EXPORTING"] = "EXPORTING";
    NeptuneShardMigrationStatus["EXPORT_FAILED"] = "EXPORT_FAILED";
    NeptuneShardMigrationStatus["LOADING"] = "LOADING";
    NeptuneShardMigrationStatus["LOAD_FAILED"] = "LOAD_FAILED";
    NeptuneShardMigrationStatus["DONE"] = "DONE";
    NeptuneShardMigrationStatus["FAILED"] = "FAILED";
})(NeptuneShardMigrationStatus = exports.NeptuneShardMigrationStatus || (exports.NeptuneShardMigrationStatus = {}));
class NeptuneShardMigrationLogRepo {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    }
    async getTenantMigrationLog(tenantUid) {
        return this.dynamoDBServices.getByKey(NeptuneShardMigrationLogRepo.TABLE_NAME, NeptuneShardMigrationLogRepo.TENANT_UID, tenantUid);
    }
    async getAllMigrationLogs() {
        return this.dynamoDBServices.getAllTableEntries(NeptuneShardMigrationLogRepo.TABLE_NAME);
    }
    async getLogsByStatus(status) {
        if (status.length === 0) {
            return Promise.resolve([]);
        }
        const filters = [];
        const expValues = {};
        status.forEach(s => {
            const exp = `:${s}`;
            expValues[exp] = s;
            filters.push(exp);
        });
        return this.dynamoDBServices.getAllFilteredTableEntries(NeptuneShardMigrationLogRepo.TABLE_NAME, `migrationStatus IN (${filters.join(', ')})`, expValues);
    }
    async anyTenantStartMigration() {
        const tenantsInMigration = await this.getLogsByStatus([
            NeptuneShardMigrationStatus.START,
            NeptuneShardMigrationStatus.EXPORTING,
            NeptuneShardMigrationStatus.EXPORT_FAILED,
            NeptuneShardMigrationStatus.LOADING,
            NeptuneShardMigrationStatus.LOAD_FAILED
        ]);
        return tenantsInMigration.length > 0;
    }
    async upsertTenantMigrationLog(migrationLog) {
        const query = {
            tenantUid: migrationLog.tenantUid,
            migrateFromShardId: migrationLog.migrateFromShardId,
            migrateToShardId: migrationLog.migrateToShardId,
            migrationStatus: migrationLog.migrationStatus,
            exportDetails: migrationLog.exportDetails,
            loadDetails: migrationLog.loadDetails,
            startAt: migrationLog.startAt,
            endAt: migrationLog.endAt,
            failedAttempts: migrationLog.failedAttempts,
            manualKickOff: migrationLog.manualKickOff
        };
        return this.dynamoDBServices.save(NeptuneShardMigrationLogRepo.TABLE_NAME, query);
    }
    async updateTenantMigrationLog(tenantUid, status, startAt, endAt, failedAttempts) {
        const key = { tenantUid };
        const update = {};
        if (!_.isNil(status)) {
            update.migrationStatus = status;
        }
        if (!_.isNil(startAt)) {
            update.startAt = startAt;
        }
        if (!_.isNil(endAt)) {
            update.endAt = endAt;
        }
        if (!_.isNil(failedAttempts)) {
            update.failedAttempts = failedAttempts;
        }
        return this.dynamoDBServices.update(NeptuneShardMigrationLogRepo.TABLE_NAME, key, update);
    }
    async deleteTenantMigrationLog(tenantUid) {
        return this.dynamoDBServices.delete(NeptuneShardMigrationLogRepo.TABLE_NAME, NeptuneShardMigrationLogRepo.TENANT_UID, tenantUid);
    }
}
exports.NeptuneShardMigrationLogRepo = NeptuneShardMigrationLogRepo;
NeptuneShardMigrationLogRepo.TABLE_NAME = 'neptune-shard-migration-log';
NeptuneShardMigrationLogRepo.TENANT_UID = 'tenantUid';
