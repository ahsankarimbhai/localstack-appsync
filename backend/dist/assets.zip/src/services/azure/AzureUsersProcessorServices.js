"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureUserProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const AzureUserService_1 = require("../../collectors/services/AzureUserService");
const PersonProcessorService_1 = require("../common/PersonProcessorService");
class AzureUserProcessorServices extends PersonProcessorService_1.PersonProcessorService {
    async verifyChangeIfNotNull(currentTopology, identifier, vertexType, changes, unchanged) {
        if (identifier) {
            await this.verifyChange(currentTopology, identifier, vertexType, changes, unchanged);
        }
    }
    async obtainIdentifierChanges(azureUser, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, azureUser.userPrincipalName, CommonTypes_1.VertexType.USER, changes, unchanged);
        await this.verifyChange(currentTopology, azureUser.mail, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
        await this.verifyChange(currentTopology, azureUser.securityIdentifier, CommonTypes_1.VertexType.COMPUTER_SID, changes, unchanged);
        await this.verifyChangeIfNotNull(currentTopology, azureUser.onPremisesUserPrincipalName, CommonTypes_1.VertexType.USER, changes, unchanged);
        await this.verifyChangeIfNotNull(currentTopology, azureUser.onPremisesSecurityIdentifier, CommonTypes_1.VertexType.COMPUTER_SID, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new AzureUserService_1.AzureUserService(tenantUid, sourceId);
    }
}
exports.AzureUserProcessorServices = AzureUserProcessorServices;
