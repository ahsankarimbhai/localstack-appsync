"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AirWatchCollectorServices = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const AirWatchDevicesCollection_1 = require("./AirWatchDevicesCollection");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
class AirWatchCollectorServices extends Services_1.BaseCollectorService {
    constructor(secrets, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.functionName = functionName;
    }
    async getAirWatchDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.AIRWATCH, this.sourceId);
        }
        const bulkLength = limit || AirWatchCollectorServices.LIMIT;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.AIRWATCH));
        const lastSuccessfulFetch = new Date(functionState.lastSuccessfulSequence).toISOString().replace('Z', '');
        return new AirWatchDevicesCollection_1.AirWatchDevicesCollection(this.client, nextUri || `/mdm/devices/search?seensince=${lastSuccessfulFetch}&pagesize=${bulkLength}&page=0`, timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.AirWatchCollectorServices = AirWatchCollectorServices;
AirWatchCollectorServices.LIMIT = 500;
