"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AmpComputerStateModelService = exports.AmpComputerStateModel = exports.AmpComputerModelService = exports.AmpComputerModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const _ = __importStar(require("lodash"));
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class AmpComputerModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.AMP_COMPUTER;
    }
    async initProperties(ampComputer) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, ampComputer.connector_guid);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.AmpComputerModel = AmpComputerModel;
class AmpComputerModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new AmpComputerModel(this.partitionKey);
    }
    getInputKeyProperties() {
        return ['connector_guid'];
    }
}
exports.AmpComputerModelService = AmpComputerModelService;
class AmpComputerStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.AMP_COMPUTER_STATE;
    }
    async initProperties(ampComputer) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(ampComputer, ['last_seen'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, ampComputer.hostname);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(ampComputer.operating_system));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, (0, CommonTypes_1.getOsVersion)(ampComputer.operating_system));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(ampComputer.operating_system, ampComputer.os_version));
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, ampComputer.operating_system, ampComputer.os_version);
        this.setProperty(AmpComputerStateModel.INSTALL_DATE_KEY, Date.parse(ampComputer.install_date));
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(ampComputer.last_seen));
        this.setProperty(AmpComputerStateModel.ACTIVE_KEY, ampComputer.active);
        this.setProperty(AmpComputerStateModel.CONNECTOR_VERSION_KEY, ampComputer.connector_version);
        this.setProperty(AmpComputerStateModel.GROUP_GUID_KEY, ampComputer.group_guid);
        this.setProperty(AmpComputerStateModel.POLICY_KEY, ampComputer.policy);
        this.setProperty(AmpComputerStateModel.FAULTS_KEY, ampComputer.faults);
        this.setProperty(AmpComputerStateModel.ISOLATION_KEY, ampComputer.isolation);
        this.setProperty(AmpComputerStateModel.ORBITAL_KEY, ampComputer.orbital);
        this.setProperty(AmpComputerStateModel.IS_COMPROMISED_KEY, ampComputer.is_compromised);
        this.setProperty(AmpComputerStateModel.AV_UPDATE_DEFINITIONS, ampComputer.av_update_definitions);
        this.setInternalIpAddresses(ampComputer.internal_ips);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.AmpComputerStateModel = AmpComputerStateModel;
AmpComputerStateModel.INSTALL_DATE_KEY = 'installDate';
AmpComputerStateModel.ISOLATION_KEY = 'isolation';
AmpComputerStateModel.ACTIVE_KEY = 'active';
AmpComputerStateModel.CONNECTOR_VERSION_KEY = 'connectorVersion';
AmpComputerStateModel.GROUP_GUID_KEY = 'groupGuid';
AmpComputerStateModel.POLICY_KEY = 'policy';
AmpComputerStateModel.FAULTS_KEY = 'faults';
AmpComputerStateModel.ORBITAL_KEY = 'orbital';
AmpComputerStateModel.IS_COMPROMISED_KEY = 'isCompromised';
AmpComputerStateModel.AV_UPDATE_DEFINITIONS = 'avUpdateDefinitions';
class AmpComputerStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new AmpComputerStateModel(this.partitionKey);
    }
}
exports.AmpComputerStateModelService = AmpComputerStateModelService;
