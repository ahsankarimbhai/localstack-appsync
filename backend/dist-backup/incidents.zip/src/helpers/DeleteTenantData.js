"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const LambdaLogger_1 = require("../common/LambdaLogger");
const ResourcesManager_1 = require("../common/ResourcesManager");
const TenantDataRemover_1 = require("./TenantDataRemover");
const tenantUid = process.argv[2];
const logger = new LambdaLogger_1.LambdaLogger();
logger.log(`dropping data for tenant ${tenantUid}`);
const rm = new TenantDataRemover_1.TenantDataRemover(tenantUid);
const start = Date.now();
Promise.all([
    rm.dropTenantNeptuneData(),
    rm.dropTenantElasticSearchData()
])
    .then(() => {
    logger.log('TenantDataRemover runtime', Date.now() - start);
})
    .catch()
    .finally(ResourcesManager_1.closeConnections);
