"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrbitalProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const _ = __importStar(require("lodash"));
const OrbitalEndpointModel_1 = require("../../model/OrbitalEndpointModel");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const OrbitalEndpointService_1 = require("../../collectors/services/OrbitalEndpointService");
class OrbitalProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    getModelKeyProperties() {
        return ['ampuuid'];
    }
    async obtainIdentifierChanges(orbitalEndpoint, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, orbitalEndpoint.hostinfo.hostname, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        const externalInfo = orbitalEndpoint.hostinfo.external;
        if (externalInfo) {
            if (externalInfo.ipv4) {
                await this.verifyChange(currentTopology, externalInfo.ipv4, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
            }
            if (externalInfo.mac) {
                await this.verifyChange(currentTopology, externalInfo.mac, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
            }
        }
        const interfaces = orbitalEndpoint.hostinfo.interfaces;
        if (interfaces) {
            for (const deviceInterface of Object.values(interfaces)) {
                if (deviceInterface.mac) {
                    await this.verifyChange(currentTopology, deviceInterface.mac, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
                }
            }
        }
        const systemInfo = vertexState.getProperty(OrbitalEndpointModel_1.OrbitalQueries.SYSTEM_INFO);
        if (_.get(systemInfo, 'value[0].hardware_serial')) {
            await this.verifyChange(currentTopology, _.get(systemInfo, 'value[0].hardware_serial'), CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        }
        await this.verifyUserChanges(vertexState.getProperty(OrbitalEndpointModel_1.OrbitalQueries.LOCAL_USERS), 'localUsername', currentTopology, changes, unchanged);
        await this.verifyUserChanges(vertexState.getProperty(OrbitalEndpointModel_1.OrbitalQueries.LOGGED_IN_USERS), 'loggedInUser', currentTopology, changes, unchanged);
        const computerSID = vertexState.getProperty(OrbitalEndpointModel_1.OrbitalEndpointStateModel.COMPUTER_SID);
        if (computerSID) {
            await this.verifyChange(currentTopology, computerSID.value, CommonTypes_1.VertexType.COMPUTER_SID, changes, unchanged);
        }
    }
    async verifyUserChanges(users, propertyName, currentTopology, changes, unchanged) {
        for (const user of (_.slice(_.get(users, 'value'), 0, OrbitalProcessorServices.MAX_USERS_THRESHOLD))) {
            const username = user[propertyName];
            if (!_.includes(OrbitalEndpointModel_1.OrbitalEndpointModel.ADMIN_USERS, username)) {
                await this.verifyChange(currentTopology, username, CommonTypes_1.VertexType.USER, changes, unchanged);
            }
        }
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new OrbitalEndpointService_1.OrbitalEndpointService(tenantUid, sourceId);
    }
}
exports.OrbitalProcessorServices = OrbitalProcessorServices;
OrbitalProcessorServices.MAX_USERS_THRESHOLD = 100;
