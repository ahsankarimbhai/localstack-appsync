"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceNowEndpointService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const _ = __importStar(require("lodash"));
class ServiceNowEndpointService extends Services_1.BaseEndpointService {
    getPvType() {
        return CommonTypes_1.VertexType.SERVICE_NOW_DEVICE;
    }
    getPsType() {
        return CommonTypes_1.VertexType.SERVICE_NOW_DEVICE_STATE;
    }
    processNotifications(body) {
        var _a;
        const data = _.get(body, 'data');
        if (!data) {
            throw new Error(`missing ServiceNow data ${JSON.stringify(body)}`);
        }
        return [{
                id: data.sys_id,
                name: data.name,
                ip_address: data.ip_address,
                mac_address: data.mac_address,
                serial_number: data.serial_number,
                comments: data.comments,
                model_number: data.model_number,
                model_id: (_a = data.model_id) === null || _a === void 0 ? void 0 : _a.value,
                asset: data.asset,
                busines_criticality: data.busines_criticality,
                created_at: data.sys_created_on,
                created_by: data.sys_created_by,
                updated_at: data.sys_updated_on,
                updated_by: data.sys_updated_by
            }];
    }
}
exports.ServiceNowEndpointService = ServiceNowEndpointService;
