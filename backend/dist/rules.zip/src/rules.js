"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rulesCleanDiscrepanciesHandleOnFailure = exports.rulesCleanDevicesDiscrepancies = exports.deleteSystemRules = exports.createSystemRules = exports.rulesCleanDiscrepancies = exports.rulesDevicesFilteredModificationsHandling = exports.rulesChangesHandling = exports.kinesisEventsHandling = void 0;
const LambdaLogger_1 = require("./common/LambdaLogger");
const IdentifyDevicesForRules_1 = require("./common/rules-system/IdentifyDevicesForRules");
const RulesExecution_1 = require("./common/rules-system/RulesExecution");
const Util_1 = require("./common/Util");
const CleanDiscrepancies_1 = require("./common/rules-system/CleanDiscrepancies");
const TenantServices_1 = require("./common/TenantServices");
const SystemRuleService_1 = require("./services/common/SystemRuleService");
const Common_1 = require("./common/rules-system/Common");
const logger = new LambdaLogger_1.LambdaLogger();
const kinesisEventsHandling = async (event) => {
    const concurrencyLevel = process.env.INTERNAL_CONCURRENCY ? +process.env.INTERNAL_CONCURRENCY : 10;
    logger.debug('kinesisEventsHandling: ', event.Records, concurrencyLevel);
    const rulesExecution = new RulesExecution_1.RulesExecution(concurrencyLevel);
    await rulesExecution.handleRecordsBatch(event.Records);
};
exports.kinesisEventsHandling = kinesisEventsHandling;
const rulesChangesHandling = async (event, context) => {
    await new IdentifyDevicesForRules_1.IdentifyDevicesForRules(context).identifyForRuleEvent(event);
};
exports.rulesChangesHandling = rulesChangesHandling;
const rulesDevicesFilteredModificationsHandling = async (event) => {
    logger.debug('rulesDevicesFilteredModificationsHandling: ', JSON.stringify((0, Util_1.parseEvent)(event)));
    await new IdentifyDevicesForRules_1.IdentifyDevicesForRules(undefined).identifyForFilterEvent((0, Util_1.parseEvent)(event));
};
exports.rulesDevicesFilteredModificationsHandling = rulesDevicesFilteredModificationsHandling;
const rulesCleanDiscrepancies = async (event) => {
    logger.debug('rulesCleanDiscrepancies: ', JSON.stringify((0, Util_1.parseEvent)(event)));
    const message = (0, Util_1.parseEvent)(event);
    const tenantUid = message.tenantUid;
    await new CleanDiscrepancies_1.CleanDiscrepancies().rulesDiscrepancies(tenantUid);
};
exports.rulesCleanDiscrepancies = rulesCleanDiscrepancies;
const getTenantOrAllTenants = async (tenantUid) => {
    const tenantServices = new TenantServices_1.TenantServices();
    const tenants = (tenantUid) ? [await tenantServices.getTenantById(tenantUid)].filter(x => x !== undefined) : await tenantServices.getAllTenants();
    if (tenants.length === 0) {
        let error;
        if (tenantUid) {
            error = `Could not find tenant by ID ${tenantUid}`;
        }
        else {
            error = 'Could not find any tenants';
        }
        logger.error(error);
        throw new Error(error);
    }
    return tenants;
};
const createSystemRules = async (event) => {
    const { tenantUid, sourceType, resetSystemRules } = event;
    logger.debug(`Create system rules for ${tenantUid ? `tenant ${tenantUid}` : 'all tenants'} where sourceType=${sourceType || 'all sources'} and resetSystemRules=${resetSystemRules}`);
    const tenants = await getTenantOrAllTenants(tenantUid);
    for (const tenant of tenants) {
        await new SystemRuleService_1.SystemRuleService(tenant.id).createSystemRulesForTenant(sourceType, resetSystemRules);
    }
};
exports.createSystemRules = createSystemRules;
const deleteSystemRules = async (event) => {
    const { tenantUid, sourceType } = event;
    logger.debug(`Delete system rules for ${tenantUid ? `tenant ${tenantUid}` : 'all tenants'} where sourceType=${sourceType || 'all sources'}`);
    const tenants = await getTenantOrAllTenants(tenantUid);
    for (const tenant of tenants) {
        await new SystemRuleService_1.SystemRuleService(tenant.id).deleteSystemRulesForTenant(sourceType);
    }
};
exports.deleteSystemRules = deleteSystemRules;
const rulesCleanDevicesDiscrepancies = async (event, context) => {
    await new CleanDiscrepancies_1.CleanDiscrepancies(new Common_1.RulesMetrics(event === null || event === void 0 ? void 0 : event.metricsState)).devicesDiscrepancies(event, context);
};
exports.rulesCleanDevicesDiscrepancies = rulesCleanDevicesDiscrepancies;
const rulesCleanDiscrepanciesHandleOnFailure = (event) => {
    logger.info(`Failure details: ${JSON.stringify(event)}`);
};
exports.rulesCleanDiscrepanciesHandleOnFailure = rulesCleanDiscrepanciesHandleOnFailure;
