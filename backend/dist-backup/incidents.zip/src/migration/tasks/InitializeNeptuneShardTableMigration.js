"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InitializeNeptuneShardTableMigration = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const TenantServices_1 = require("../../common/TenantServices");
const NeptuneShardRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardRepo");
const bluebird_1 = require("bluebird");
class InitializeNeptuneShardTableMigration extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor() {
        super(...arguments);
        this.tenantServices = new TenantServices_1.TenantServices();
        this.neptuneShardRepo = new NeptuneShardRepo_1.NeptuneShardRepo();
    }
    async execute() {
        await this.initializeTenants();
        return bluebird_1.Promise.resolve();
    }
    async initializeTenants() {
        const tenants = await this.tenantServices.getAllTenants();
        this.logger.info(`retrieved total ${tenants.length} tenants`);
        let hasErr = false;
        await bluebird_1.Promise.map(tenants, async (tenant) => {
            try {
                const existing = await this.neptuneShardRepo.getNeptuneShard(tenant.id);
                if (existing) {
                    this.logger.info(`tenant ${tenant.id} with shard ${existing.shardId} exists`);
                    return;
                }
                await this.neptuneShardRepo.upsertNeptuneShard({
                    tenantUid: tenant.id,
                    shardId: '1'
                });
                this.logger.info(`tenant ${tenant.id} is assigned successfully`);
            }
            catch (err) {
                hasErr = true;
                this.logger.error(`failed to insert tenant ${tenant.id}, error: ${err.message}`);
            }
        }, { concurrency: 500 });
        if (hasErr) {
            throw new Error('Error occurred when initialize neptune-shard table');
        }
    }
    getTaskName() {
        return InitializeNeptuneShardTableMigration.TASK_NAME;
    }
}
exports.InitializeNeptuneShardTableMigration = InitializeNeptuneShardTableMigration;
InitializeNeptuneShardTableMigration.TASK_NAME = 'initialize-neptune-shard-table-migration';
