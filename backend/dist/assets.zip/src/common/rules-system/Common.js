"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.countCreatedUpdated = exports.RulesMetrics = exports.NO_RULE_ID = exports.EventType = void 0;
const CommonTypes_1 = require("../CommonTypes");
const TimestreamRequestBuilder_1 = require("../TimestreamRequestBuilder");
const TimestreamUtil_1 = require("../TimestreamUtil");
var EventType;
(function (EventType) {
    EventType["APPLY"] = "apply";
    EventType["UPDATED"] = "updated";
})(EventType = exports.EventType || (exports.EventType = {}));
exports.NO_RULE_ID = '';
class RulesMetrics {
    constructor(timestreamRequestBuilder = new TimestreamRequestBuilder_1.TimestreamRequestBuilder()) {
        this.timestreamRequestBuilder = timestreamRequestBuilder;
        this.timestreamUtil = new TimestreamUtil_1.TimestreamUtil();
        this.raisedAlert = false;
    }
    reportMetrics(metrics, tenantUid, producer, workflow = CommonTypes_1.WorkFlow.RULES_FLOW) {
        const timestreamRequestBuilder = new TimestreamRequestBuilder_1.TimestreamRequestBuilder();
        timestreamRequestBuilder.add(metrics, TimestreamRequestBuilder_1.TimestreamRequestBuilder.basicDimensions(tenantUid, producer, workflow));
        return this.timestreamUtil.sendRequestsToStream(timestreamRequestBuilder.createRequestsAndReset());
    }
    addRecordMetrics(metrics, tenantUid, producer, workflow = CommonTypes_1.WorkFlow.RULES_FLOW, evaluateAndRaiseAlert) {
        const dimensions = TimestreamRequestBuilder_1.TimestreamRequestBuilder.basicDimensions(tenantUid, producer, workflow);
        this.timestreamRequestBuilder.add(metrics, dimensions, evaluateAndRaiseAlert);
    }
    reportCurrentMetrics() {
        return this.timestreamUtil.sendRequestsToStream(this.timestreamRequestBuilder.createRequestsAndReset());
    }
    setRaisedAlert() {
        this.raisedAlert = true;
    }
    isAlertRaised() {
        return this.raisedAlert;
    }
}
exports.RulesMetrics = RulesMetrics;
function countCreatedUpdated(devicesModifiedNotification) {
    let updated = 0;
    let created = 0;
    for (const device of devicesModifiedNotification.devicesModified) {
        if (device.devicesModificationAction === 'created') {
            created += 1;
        }
        else if (device.devicesModificationAction === 'updated') {
            updated += 1;
        }
    }
    return { created, updated };
}
exports.countCreatedUpdated = countCreatedUpdated;
