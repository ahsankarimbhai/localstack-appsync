"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostureEntityService = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphService_1 = require("./BaseGraphService");
const CommonTypes_1 = require("../common/CommonTypes");
const gremlin_1 = require("gremlin");
const BaseGraphElement_1 = require("./BaseGraphElement");
const ElasticsearchServices_1 = require("../common/ElasticsearchServices");
const Util_1 = require("../common/Util");
const IncidentService_1 = require("../services/common/IncidentService");
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const TenantServices_1 = require("../common/TenantServices");
const ElasticsearchFactory_1 = require("../common/ElasticsearchFactory");
const NeptuneClientManager_1 = require("../common/neptune/NeptuneClientManager");
const WebhookNotificationService_1 = require("../services/common/data-sharing/WebhookNotificationService");
const GraphFactory_1 = require("./GraphFactory");
const __ = gremlin_1.process.statics;
const t = gremlin_1.process.t;
const withOptions = gremlin_1.process.withOptions;
class PostureEntityService extends BaseGraphService_1.BaseEdgeService {
    constructor(tenantUid) {
        super(tenantUid);
        this.tenantUid = tenantUid;
        this.esServices = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        this.incidentService = new IncidentService_1.IncidentService(tenantUid);
        this.webhookNotificationService = new WebhookNotificationService_1.WebhookNotificationService();
    }
    markUnreliableIdentifierVertices(vertexId) {
        const neptuneSvc = this.getNeptuneServices();
        return neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, vertexId)
            .outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).inV()
            .outE().inV()
            .hasLabel(...this.getIdentifierVertexTypes()).as('iv')
            .hasNot(PostureEntityService.UNRELIABLE)
            .where(__.inE(CommonTypes_1.EdgeType.HAS, CommonTypes_1.EdgeType.USES).outV()
            .inE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).outV()
            .dedup()
            .groupCount().by(t.label).select(gremlin_1.process.column.values).max(gremlin_1.process.scope.local).is(gremlin_1.process.P.gt(1)))
            .dedup()
            .select('iv').property(gremlin_1.process.cardinality.single, PostureEntityService.UNRELIABLE, 'true')
            .iterate());
    }
    getLinkCandidates(vertexId) {
        const neptuneSvc = this.getNeptuneServices();
        return neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, vertexId)
            .outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).inV()
            .outE().inV().hasLabel(...this.getIdentifierVertexTypes())
            .hasNot(PostureEntityService.UNRELIABLE).as('iv')
            .inE(...this.getIdentifierEdgeTypes()).outV().as('ps')
            .inE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).outV().as('pv')
            .inE(this.getEdgeType())
            .outV().as('pe')
            .select('pe', 'pv', 'iv')
            .by(t.id)
            .by(t.id)
            .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    async linkProducerVertices(vertexId, linkCandidates) {
        const ivTypes = this.getIdentifierVertexTypes();
        const edgeType = this.getEdgeType();
        let edge;
        let isMergedToExistingPE = false;
        if (_.isEmpty(linkCandidates)) {
            edge = await this.createNewEntity(vertexId, edgeType);
        }
        else {
            let ep;
            let ivTypeUseToConnectToEp = ivTypes[ivTypes.length - 1];
            const visitedPVs = new Map();
            for (const linkCandidate of linkCandidates) {
                const candidatePvId = linkCandidate.get('pv');
                const candidatePE = linkCandidate.get('pe');
                if (!visitedPVs.has(candidatePE)) {
                    visitedPVs.set(candidatePE, []);
                }
                visitedPVs.get(candidatePE).push(candidatePvId);
                if (candidatePvId === vertexId) {
                    continue;
                }
                const candidateIvType = _.intersectionWith(ivTypes, _.split((linkCandidate.get('iv').get(t.label)), '::'), _.isEqual)[0];
                if (!ep || this.shouldChangeSelectedCandidate(ivTypeUseToConnectToEp, ivTypes, candidateIvType)) {
                    ep = candidatePE;
                    ivTypeUseToConnectToEp = candidateIvType;
                }
            }
            const currentPE = await this.getNeptuneServices().getPostureEntity(vertexId, edgeType);
            ep = ep || currentPE;
            if (!ep) {
                throw new Error(`did not assign entity from list of candidates ${JSON.stringify(linkCandidates)}`);
            }
            edge = new BaseGraphElement_1.BaseGraphEdge(ep, vertexId, this.tenantUid, edgeType);
            if (currentPE && currentPE !== ep) {
                if (!visitedPVs.has(currentPE)) {
                    visitedPVs.set(currentPE, []);
                }
                visitedPVs.get(currentPE).push(vertexId);
                await this.updateExistingPE(ep, currentPE, vertexId, _.union(visitedPVs.get(currentPE)));
            }
            isMergedToExistingPE = true;
        }
        await this.upsert(edge);
        return {
            peUid: edge.sourceId,
            isMergedToExistingPE
        };
    }
    shouldChangeSelectedCandidate(ivTypeUseToConnectToEp, ivTypes, candidateIvType) {
        return !ivTypeUseToConnectToEp || ivTypes.indexOf(candidateIvType) < ivTypes.indexOf(ivTypeUseToConnectToEp);
    }
    async updateExistingPE(ep, currentPE, vertexId, visitedPVs = []) {
        const neptuneSvc = this.getNeptuneServices();
        const edgeType = this.getEdgeType();
        const results = await neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, currentPE).out(edgeType).id().toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        const resultSet = new gremlin_1.driver.ResultSet(results);
        const currentPEPVs = resultSet.toArray();
        const dropOldPE = _.isEmpty(_.differenceWith(currentPEPVs, visitedPVs));
        const pvsToMerge = _.union(_.intersectionWith(currentPEPVs, visitedPVs));
        for (const pv of pvsToMerge) {
            if (!dropOldPE) {
                this.logger.debug(`Handling ${vertexId}, update PE of ${pv}`);
                await neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, pv).inE(edgeType).drop().iterate());
            }
            if (pv !== vertexId) {
                const edge = new BaseGraphElement_1.BaseGraphEdge(ep, pv, this.tenantUid, edgeType);
                await this.upsert(edge);
            }
        }
        if (dropOldPE) {
            this.logger.debug(`Handling ${vertexId}, drop current PE ${currentPE}`);
            await neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, currentPE).drop().iterate());
            await this.deleteEntityFromES(currentPE);
        }
        else {
            this.logger.debug(`Handling ${vertexId}, detach current PE ${currentPE}`);
            await neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, vertexId).inE(edgeType).drop().iterate());
            await this.updateSearchableVertex(currentPE);
        }
    }
    async createNewEntity(vertexId, edgeType) {
        const currentPE = await this.getNeptuneServices().getPostureEntity(vertexId, edgeType);
        if (currentPE) {
            this.logger.debug(`PE exists, skipping new vertex creation, PE=${currentPE} vertexId=${vertexId}`);
            return new BaseGraphElement_1.BaseGraphEdge(currentPE, vertexId, this.tenantUid, edgeType);
        }
        const postureEntityModel = await (0, GraphFactory_1.createComplexVertex)(this.getComplexType(), this.getLabel(), this.tenantUid, { firstConnection: vertexId });
        const postureDerivedModel = await this.getPostureModelService(this.tenantUid).upsert(postureEntityModel);
        return new BaseGraphElement_1.BaseGraphEdge(postureDerivedModel.getId(), vertexId, this.tenantUid, edgeType);
    }
    toKeyValueList(ps) {
        const entries = Object.fromEntries(ps);
        return _.map(_.remove(_.keys(entries), key => !_.includes([CommonTypes_1.BasicProperty.ID, CommonTypes_1.BasicProperty.LABEL, CommonTypes_1.BasicProperty.PARTITION_KEY, CommonTypes_1.VertexStateProperty.STATE_INTERNAL_IP_ADDRESSES], key)), key => ({
            key,
            value: _.isString((0, CommonTypes_1.val)(entries[key])) ? (0, CommonTypes_1.val)(entries[key]) : JSON.stringify((0, CommonTypes_1.val)(entries[key]))
        }));
    }
    parseSourceTypeAndId(vertexLabel) {
        let source = '';
        let sourceId = '';
        const labelParts = _.split(_.split(vertexLabel, '::')[0], Util_1.SOURCE_SEPARATOR);
        if (labelParts.length > 1 && labelParts[1] !== this.tenantUid) {
            source = labelParts[1];
        }
        if (labelParts.length > 2 && labelParts[2] !== this.tenantUid) {
            sourceId = labelParts[2];
        }
        return { source, sourceId };
    }
    addValueToProducerProperties(pvPropertyName, pvPropertyValue, pe, pvUid) {
        if (pvUid) {
            const producer = _.find(pe.producers, { uid: pvUid });
            if (producer) {
                const pvProp = _.find(producer.properties, { key: pvPropertyName });
                const pvPropValue = _.get(pvProp, 'value');
                const pvPropValueArray = pvPropValue ? JSON.parse(pvPropValue) : [];
                pvPropValueArray.push(pvPropertyValue);
                if (pvProp) {
                    _.set(pvProp, 'value', JSON.stringify(pvPropValueArray));
                }
                else {
                    producer.properties.push({ key: pvPropertyName, value: JSON.stringify(pvPropValueArray) });
                }
            }
        }
    }
    addProducerPropertyKvp(pvPropertyName, pvPropertyValue, pe, pvUid) {
        if (pvPropertyValue && pvUid) {
            const producer = _.find(pe.producers, { uid: pvUid });
            if (producer && !_.find(producer.properties, { key: pvPropertyName })) {
                producer.properties.push({ key: pvPropertyName, value: pvPropertyValue });
            }
        }
    }
    async recalculateUnreliableIdentifierVertices(peUid) {
        const neptuneSvc = this.getNeptuneServices();
        const unreliableIvIds = await neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, peUid)
            .out(this.getEdgeType())
            .out(CommonTypes_1.EdgeType.HAS_STATE)
            .out()
            .hasLabel(...this.getIdentifierVertexTypes()).as('iv')
            .has(PostureEntityService.UNRELIABLE, 'true')
            .where(__.inE(CommonTypes_1.EdgeType.HAS, CommonTypes_1.EdgeType.USES).count().is(gremlin_1.process.P.lt(500)))
            .where(__.in_(CommonTypes_1.EdgeType.HAS, CommonTypes_1.EdgeType.USES)
            .inE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).outV()
            .dedup()
            .groupCount().by(t.label)
            .select(gremlin_1.process.column.values)
            .max(gremlin_1.process.scope.local)
            .is(gremlin_1.process.P.eq(1)))
            .dedup()
            .select('iv')
            .by(t.id)
            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        if (unreliableIvIds.length > 0) {
            await neptuneSvc.executeTenantQuery((g) => g.V(...unreliableIvIds)
                .properties(PostureEntityService.UNRELIABLE)
                .drop()
                .iterate());
        }
    }
    async recalculateUnreliableIdentifierVerticesIfNeeded(peUid, recalculateUnreliableIvs) {
        if (recalculateUnreliableIvs) {
            await this.recalculateUnreliableIdentifierVertices(peUid);
        }
    }
    getPsSearchLabels(searchTypes) {
        return searchTypes.map(searchType => this.getPsSearchLabel(searchType)).filter(searchType => searchType);
    }
    getPsSearchLabel(searchType) {
        if ([CommonTypes_1.VertexType.INTERNAL_IP_ADDRESS].includes(searchType.type)) {
            return `${(0, Util_1.base64Encode)(searchType.value)}${Util_1.SOURCE_SEPARATOR}${searchType.type}${Util_1.SOURCE_SEPARATOR}${this.tenantUid}`;
        }
        return undefined;
    }
    async getByExtIdQuery(g, producers, filterStatesConditions, offset, pageSize) {
        await this.initProducerConfiguration();
        const vertexIds = _.flatMap(producers, filterProducer => {
            const sourceProducers = _.filter(this.producerConfigurations, producer => producer.producerType === filterProducer.source);
            return _.flatMap(sourceProducers, producer => (0, NeptuneServicesFactory_1.getVertexId)([filterProducer.extId, (0, CommonTypes_1.sourceToVertexType)(filterProducer.source)].join(Util_1.SOURCE_SEPARATOR), [producer.producerType, producer.producerId].join(Util_1.SOURCE_SEPARATOR), this.tenantUid));
        });
        return this.getNeptuneServices().getSimpleGraphTraversal(g)
            .has(t.id, gremlin_1.process.P.within(...vertexIds))
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .or(...filterStatesConditions)
            .outV()
            .in_(this.getEdgeType()).as('pe')
            .range(offset, offset + pageSize + 1);
    }
    async getByProducerQuery(g, producers, filterStatesConditions, psFilterQueries, offset, pageSize) {
        await this.initProducerConfiguration();
        const vertexIds = _.flatMap(producers, filterProducer => {
            const sourceProducers = _.filter(this.producerConfigurations, producer => producer.producerType === filterProducer.source);
            return _.flatMap(sourceProducers, producer => (0, NeptuneServicesFactory_1.getVertexId)([filterProducer.extId, (0, CommonTypes_1.sourceToVertexType)(filterProducer.source)].join(Util_1.SOURCE_SEPARATOR), [producer.producerType, producer.producerId].join(Util_1.SOURCE_SEPARATOR), this.tenantUid));
        });
        return this.getNeptuneServices().getSimpleGraphTraversal(g)
            .has(t.id, gremlin_1.process.P.within(...vertexIds))
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .or(...filterStatesConditions)
            .inV()
            .or(...psFilterQueries)
            .inE(CommonTypes_1.EdgeType.HAS_STATE)
            .outV()
            .in_(this.getEdgeType()).as('pe')
            .range(offset, offset + pageSize + 1);
    }
    async initProducerConfiguration() {
        if (!this.producerConfigurations) {
            const tenantServices = new TenantServices_1.TenantServices();
            this.producerConfigurations = await tenantServices.getProducerConfigurations(this.tenantUid);
        }
        return this.producerConfigurations;
    }
    getByIVsQuery(g, searchType, filterStatesConditions, offset, pageSize) {
        const vertexId = _.join([searchType.value, searchType.type, this.tenantUid], NeptuneServicesFactory_1.VERTEX_ID_SEPARATOR);
        const neptuneSvc = this.getNeptuneServices();
        const edgeType = this.getEdgeType();
        const searchLabel = this.getPsSearchLabel(searchType);
        if (searchLabel) {
            return neptuneSvc.getGraphTraversal(g)
                .union(__.hasId(vertexId).in_(CommonTypes_1.EdgeType.USES, CommonTypes_1.EdgeType.HAS), __.hasLabel(searchLabel))
                .inE(CommonTypes_1.EdgeType.HAS_STATE)
                .or(...filterStatesConditions)
                .outV()
                .in_(edgeType).as('pe')
                .range(offset, offset + pageSize + 1);
        }
        return neptuneSvc.getGraphTraversal(g, vertexId)
            .in_(CommonTypes_1.EdgeType.USES, CommonTypes_1.EdgeType.HAS)
            .inE(CommonTypes_1.EdgeType.HAS_STATE)
            .or(...filterStatesConditions)
            .outV()
            .in_(edgeType).as('pe')
            .range(offset, offset + pageSize + 1);
    }
    getTimeTicksPerEntity(results, sinceMillis, untilMillis) {
        const resultSet = new gremlin_1.driver.ResultSet(results);
        const timeTicksPerEntities = {};
        for (const result of resultSet.toArray()) {
            const path = result.objects;
            if (path.length === 4) {
                const pe = path[0];
                const peUid = pe.get(t.id);
                const stateEdge = path[2];
                const until = stateEdge.get(CommonTypes_1.EdgeBasicProperty.UNTIL);
                const since = stateEdge.get(CommonTypes_1.EdgeBasicProperty.SINCE);
                const timeTicksPerEntity = timeTicksPerEntities[peUid] || [];
                timeTicksPerEntity.push(Math.max(since, sinceMillis));
                timeTicksPerEntity.push(until ? Math.min(until, untilMillis) : untilMillis);
                timeTicksPerEntities[peUid] = timeTicksPerEntity;
            }
        }
        return _.mapValues(timeTicksPerEntities, timeTicks => _.sortBy(_.uniq(timeTicks)));
    }
    static initMergedEntity(peUid, entityTimeTicks) {
        const res = [];
        for (let i = 0; i < entityTimeTicks.length - 1; i += 1) {
            res.push({
                uid: peUid,
                propertyTimestamp: {},
                since: Math.floor(entityTimeTicks[i] / 1000),
                until: Math.floor(entityTimeTicks[i + 1] / 1000)
            });
        }
        return res;
    }
    async linkDirectCandidate(savedVertex) {
        return this.linkDirectCandidateDetailed(savedVertex.type, savedVertex.getId());
    }
    static hasProducer(postureEntity, type) {
        return _.some(postureEntity.producers, { type });
    }
    async connectToAnotherPE(vertexId, source) {
        const extId = _.split(vertexId, Util_1.SOURCE_SEPARATOR)[0];
        const edgeType = this.getEdgeType();
        if (extId) {
            if (!this.producerConfigurations) {
                const tenantServices = new TenantServices_1.TenantServices();
                this.producerConfigurations = await tenantServices.getProducerConfigurations(this.tenantUid);
            }
            const sourceProducers = _.filter(this.producerConfigurations, producer => producer.producerType === source);
            const neptuneSvc = this.getNeptuneServices();
            for (const producer of sourceProducers) {
                const existingVertexId = (0, NeptuneServicesFactory_1.getVertexId)([extId, (0, CommonTypes_1.sourceToVertexType)(source)].join(Util_1.SOURCE_SEPARATOR), [producer.producerType, producer.producerId].join(Util_1.SOURCE_SEPARATOR), this.tenantUid);
                const results = await neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, existingVertexId).in_(edgeType).limit(1).id().toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
                if (results) {
                    const resultSet = new gremlin_1.driver.ResultSet(results);
                    if (resultSet) {
                        const ep = resultSet.first();
                        if (ep) {
                            const edge = new BaseGraphElement_1.BaseGraphEdge(ep, vertexId, this.tenantUid, edgeType);
                            await this.upsert(edge);
                            return ep;
                        }
                    }
                }
            }
        }
        return undefined;
    }
    async linkProducerCandidates(vertexId) {
        const linkCandidates = await this.getLinkCandidates(vertexId);
        return this.linkProducerVertices(vertexId, linkCandidates);
    }
}
exports.PostureEntityService = PostureEntityService;
PostureEntityService.UNRELIABLE = 'unreliable';
PostureEntityService.HISTORICAL_STATE_PAGE_SIZE = 10;
PostureEntityService.MAX_PAGE_SIZE = 200;
