"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.memCacheDecorator = exports.MemoryCacheManager = void 0;
const memory_cache_1 = require("memory-cache");
const LambdaLogger_1 = require("../LambdaLogger");
const async_lock_1 = __importDefault(require("async-lock"));
class MemoryCacheManager {
    constructor() {
        this.cache = new memory_cache_1.Cache();
        this.defaultTimeoutInSeconds = 600;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    static getInstance() {
        if (!MemoryCacheManager.cacheMgr) {
            this.cacheMgr = new MemoryCacheManager();
        }
        return this.cacheMgr;
    }
    put(key, val, timeoutInSeconds) {
        try {
            this.cache.put(key, val, (timeoutInSeconds && timeoutInSeconds > 0 ? timeoutInSeconds : this.defaultTimeoutInSeconds) * 1000);
        }
        catch (err) {
            this.logger.error(`MemoryCacheManager failed to put key: ${key}, value: ${JSON.stringify(val)}, error: ${err.message}`);
        }
    }
    get(key) {
        return this.cache.get(key);
    }
    clear() {
        this.cache.clear();
    }
    remove(key) {
        this.cache.del(key);
    }
}
exports.MemoryCacheManager = MemoryCacheManager;
function memCacheDecorator(cacheKeyPrefix, timeoutInSeconds) {
    const lock = new async_lock_1.default({ timeout: 300000, maxOccupationTime: 900000 });
    return (_, __, descriptor) => {
        const originalMethod = descriptor.value;
        descriptor.value = async function (...args) {
            const cacheKeySegments = [cacheKeyPrefix];
            cacheKeySegments.push(...args.map((arg) => arg.toString()));
            const cacheKey = cacheKeySegments.join('_');
            const cacheMgr = MemoryCacheManager.getInstance();
            return lock.acquire(cacheKey, async () => {
                let val = cacheMgr.get(cacheKey);
                if (!val) {
                    val = await originalMethod.apply(this, args);
                    if (val) {
                        cacheMgr.put(cacheKey, val, timeoutInSeconds);
                    }
                }
                return val;
            });
        };
    };
}
exports.memCacheDecorator = memCacheDecorator;
