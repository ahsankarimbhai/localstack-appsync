"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TruncateTenantNeptuneData = void 0;
const gremlin_1 = require("gremlin");
const CommonTypes_1 = require("../../common/CommonTypes");
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const lodash_1 = __importDefault(require("lodash"));
const bluebird_1 = require("bluebird");
const __ = gremlin_1.process.statics;
var DeletingType;
(function (DeletingType) {
    DeletingType["EDGE"] = "edge";
    DeletingType["VERTEX"] = "vertex";
})(DeletingType || (DeletingType = {}));
class TruncateTenantNeptuneData extends DataMigrationTaskProcessor_1.DataMigrationTaskProcessor {
    constructor(timeBasedLambdaHandler, tenantUid, taskParams, batchSize = 10000) {
        super(tenantUid, undefined, taskParams);
        this.timeBasedLambdaHandler = timeBasedLambdaHandler;
        this.batchSize = batchSize;
        if (!taskParams || !taskParams.shardId) {
            throw new Error('must provide shardId in taskParams');
        }
        this.neptuneMgr = NeptuneClientManager_1.NeptuneClientManager.getInstance();
        this.shardId = taskParams.shardId;
    }
    getTaskName() {
        return TruncateTenantNeptuneData.TASK_NAME;
    }
    async execute() {
        let totalProcessedRecords = 0;
        try {
            this.deletingType = (await this.hasNext(DeletingType.EDGE)) ? DeletingType.EDGE : DeletingType.VERTEX;
            while (await this.hasNext(this.deletingType)) {
                this.logger.debug(`${this.getLogPrefix()} remaining time in millis: ${this.timeBasedLambdaHandler.getRemainingTimeInMillis()}, threshold: ${this.timeBasedLambdaHandler.timeoutThreshold}`);
                if (this.timeBasedLambdaHandler.isItTimeToStop()) {
                    return { shouldContinue: true };
                }
                const entryIds = [];
                await bluebird_1.Promise.map(lodash_1.default.range(+(process.env.QUERY_RANGE_CONCURRENCY || 10)), async (chunk) => {
                    try {
                        const ids = await this.executeQuery((g) => this.getTypeQuery(g, this.deletingType)
                            .has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid)
                            .range(chunk * this.batchSize, chunk * this.batchSize + this.batchSize)
                            .id()
                            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
                        entryIds.push(...ids);
                    }
                    catch (err) {
                        this.logger.error(`error when fetching ${this.deletingType} entries for chunk ${chunk}, err: ${err.message}`);
                    }
                });
                let deletedCount = 0;
                const chunks = lodash_1.default.chunk(entryIds, +(process.env.DELETE_BATCH_SIZE || 100));
                await bluebird_1.Promise.map(chunks, async (oneChunkOfIds) => {
                    try {
                        await this.executeQuery((g) => this.getIdQuery(g, oneChunkOfIds).drop().iterate());
                        deletedCount += oneChunkOfIds.length;
                    }
                    catch (err) {
                        this.logger.error(`error when deleting ${this.deletingType} ids, err: ${err.message}`);
                    }
                }, { concurrency: 200 });
                totalProcessedRecords += deletedCount;
            }
            return { shouldContinue: this.deletingType === DeletingType.EDGE };
        }
        catch (err) {
            this.logger.error(`${this.getLogPrefix()} - error occurred when executing task. err: ${err.message}`, err);
            throw err;
        }
        finally {
            this.logger.info(`${this.getLogPrefix()} - deleted ${totalProcessedRecords} ${this.deletingType} entries`);
        }
    }
    async hasNext(type) {
        return this.executeQuery((g) => this.getTypeQuery(g, type).has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid).limit(1).hasNext(), NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    getTypeQuery(g, type) {
        return type === DeletingType.VERTEX ? g.V() : g.E();
    }
    getIdQuery(g, ids) {
        return this.deletingType === DeletingType.VERTEX
            ? g.V(...ids)
            : g.E(...ids);
    }
    async executeQuery(queryFunc, clientType = NeptuneClientManager_1.NeptuneClientType.Writer) {
        return this.neptuneMgr.executeQueryScope(this.shardId, clientType, queryFunc, 100);
    }
}
exports.TruncateTenantNeptuneData = TruncateTenantNeptuneData;
TruncateTenantNeptuneData.TASK_NAME = 'truncate-tenant-neptune-data';
