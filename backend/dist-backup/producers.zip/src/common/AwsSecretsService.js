"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrbitalS3WebhookAwsSecretsService = exports.GlobalAwsSecretsService = exports.AwsSecretsService = void 0;
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const _ = __importStar(require("lodash"));
const SecretsService_1 = require("./SecretsService");
const LambdaLogger_1 = require("./LambdaLogger");
const ts_retry_promise_1 = require("ts-retry-promise");
const RetryUtil_1 = require("./RetryUtil");
const MemoryCache_1 = require("./cache/MemoryCache");
class AwsSecretsService extends SecretsService_1.SecretsService {
    constructor(scope) {
        super();
        this.scope = scope;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.secretsManager = new client_secrets_manager_1.SecretsManagerClient({ logger: this.logger });
        this.cache = MemoryCache_1.MemoryCacheManager.getInstance();
        this.secrets = {};
        this.secretId = `posture-${scope}`;
        this.cacheKey = `SECRET_VALUE_${this.secretId}`;
    }
    async init() {
        await super.init(this.scope);
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, {
            retries: 5,
            backoff: 'FIXED',
            delay: 200
        });
        try {
            await retryUtil.executeWithRetry(() => this.readSecrets(process.env.DISABLE_SECRET_CACHE !== 'true').then(secrets => this.secrets = secrets), undefined, undefined, process.env.USE_ATTEMPT_TIMEOUT_FOR_AWS_SM === 'true' ? 10000 : undefined);
        }
        catch (e) {
            this.logger.error(`failed to fetch the secrets for id ${this.scope}. `, e);
            throw e.lastError;
        }
    }
    async readSecrets(readCache = false) {
        if (readCache) {
            const secrets = this.cache.get(this.cacheKey);
            if (secrets) {
                this.logger.debug(`return cached secret for ${this.secretId}`);
                return secrets;
            }
        }
        const response = await this.secretsManager.send(new client_secrets_manager_1.GetSecretValueCommand({
            SecretId: this.secretId
        }));
        if (!response.SecretString) {
            throw new Error('expected to find SecretString');
        }
        const secrets = JSON.parse(response.SecretString);
        this.cache.put(this.cacheKey, secrets);
        return secrets;
    }
    async deleteSecret(forceDeleteWithoutRecovery = false) {
        this.cache.remove(this.cacheKey);
        return this.secretsManager.send(new client_secrets_manager_1.DeleteSecretCommand({
            SecretId: this.secretId,
            ForceDeleteWithoutRecovery: forceDeleteWithoutRecovery
        }));
    }
    async removeSecretValue(secretKey) {
        this.secrets = await this.readSecrets();
        this.logger.debug(`Removing ${secretKey} from secret with id "${this.secretId}"`);
        this.cache.remove(this.cacheKey);
        return this.secretsManager.send(new client_secrets_manager_1.UpdateSecretCommand({
            SecretId: this.secretId,
            SecretString: JSON.stringify(_.omit(this.secrets, [secretKey]))
        })).catch((error) => {
            throw new Error(`can't update AWS SM Secret, error: ${error}`);
        });
    }
    async setSecretValue(key, value, expectExisting = false) {
        let secretFound = true;
        try {
            await (0, ts_retry_promise_1.retry)(() => this.readSecrets().then(secrets => this.secrets = secrets), {
                retries: expectExisting ? 3 : 0,
                backoff: 'FIXED'
            });
        }
        catch (e) {
            if (!expectExisting || !e.message.includes('Secrets Manager can\'t find the specified secret.')) {
                this.logger.error(e);
            }
            if (expectExisting) {
                throw new Error(`expected to find secret ${this.secretId}`);
            }
            secretFound = false;
        }
        this.secrets[key] = JSON.stringify(_.merge(this.secrets[key] ? JSON.parse(this.secrets[key]) : {}, value));
        this.cache.remove(this.cacheKey);
        if (secretFound) {
            this.logger.debug(`Secret with id "${this.secretId}", already exists in AWS SM, updating it's value`);
            return this.secretsManager.send(new client_secrets_manager_1.UpdateSecretCommand({
                SecretId: this.secretId,
                SecretString: JSON.stringify(this.secrets)
            })).catch((error) => {
                throw new Error(`can't update AWS SM Secret, error: ${error}`);
            });
        }
        this.logger.debug(`Create secret with id: ${this.secretId}`);
        return this.secretsManager.send(new client_secrets_manager_1.CreateSecretCommand({
            Name: this.secretId,
            SecretString: JSON.stringify(this.secrets)
        })).catch((error) => {
            throw new Error(`can't create AWS SM Secret, error: ${error}`);
        });
    }
    getSecretByKey(key) {
        const secretStr = this.secrets[key];
        return secretStr ? JSON.parse(secretStr) : _.noop();
    }
    async getSecretWithReloadingOnRetry(key, retryAttempts) {
        if (!retryAttempts) {
            retryAttempts = 0;
        }
        let secretStr;
        let shouldReload = false;
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, {
            retries: retryAttempts,
            backoff: 'FIXED',
            delay: 500,
            timeout: 10000
        });
        try {
            await retryUtil.executeWithRetry(async () => {
                if (shouldReload) {
                    this.cache.remove(this.cacheKey);
                    await this.init();
                }
                secretStr = this.secrets[key];
                if (retryAttempts && secretStr === undefined) {
                    shouldReload = true;
                    throw new Error(`Failed to retrieve secret value with key ${key}`);
                }
            }, undefined, undefined, process.env.USE_ATTEMPT_TIMEOUT_FOR_AWS_SM === 'true' ? 5000 : undefined);
        }
        catch (e) {
            this.logger.error(e);
        }
        this.logger.debug('finished execution of getSecretWithReloadingOnRetry');
        return secretStr ? JSON.parse(secretStr) : _.noop();
    }
}
exports.AwsSecretsService = AwsSecretsService;
class GlobalAwsSecretsService extends AwsSecretsService {
    constructor() {
        super(GlobalAwsSecretsService.getScope());
    }
    static getScope() {
        if (!process.env.ENV) {
            throw new Error('ENV is not set');
        }
        return `${process.env.ENV}-global`;
    }
}
exports.GlobalAwsSecretsService = GlobalAwsSecretsService;
GlobalAwsSecretsService.DUO_VERSIONS = 'duoVersions';
class OrbitalS3WebhookAwsSecretsService extends AwsSecretsService {
    constructor() {
        super('orbital-webhook-credentials');
    }
    getLatestCredentials() {
        return this.getSecretByKey(OrbitalS3WebhookAwsSecretsService.ROTATE_KEY) || this.getSecretByKey(OrbitalS3WebhookAwsSecretsService.CURRENT_KEY);
    }
}
exports.OrbitalS3WebhookAwsSecretsService = OrbitalS3WebhookAwsSecretsService;
OrbitalS3WebhookAwsSecretsService.CURRENT_KEY = 'current';
OrbitalS3WebhookAwsSecretsService.ROTATE_KEY = 'rotate';
