"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RestartFailedMigrationTask = void 0;
const bluebird_1 = require("bluebird");
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const DataMigrationOrchestrator_1 = require("../DataMigrationOrchestrator");
const DynamodbServiceFactory_1 = require("../../common/awsclient/dynamodb/DynamodbServiceFactory");
class RestartFailedMigrationTask extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor() {
        super(...arguments);
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.dataMigrationRunner = new DataMigrationOrchestrator_1.DataMigrationRunner();
    }
    async execute() {
        const taskParamsObj = this.getTaskParamsObj();
        if (!taskParamsObj || !taskParamsObj.tasks) {
            throw new Error('tasks must be provided.');
        }
        let anyTaskToRestart = false;
        for (const taskName of taskParamsObj.tasks) {
            if (await this.resetFailedTasks(taskName)) {
                anyTaskToRestart = true;
            }
        }
        if (anyTaskToRestart) {
            await this.dataMigrationRunner.ensureNextRun();
        }
        return bluebird_1.Promise.resolve();
    }
    getTaskParamsObj() {
        try {
            return JSON.parse(this.taskParams);
        }
        catch {
            return undefined;
        }
    }
    async resetFailedTasks(taskName) {
        const tasks = await this.dynamoDBServices.getAllFilteredTableEntries('data-migration-task', 'contains(taskKey, :taskName) and attribute_exists(ended) and attribute_exists(withErrors)', { ':taskName': taskName });
        this.logger.info(`found total ${tasks.length} failed tasks for ${taskName}`);
        let hasErr = false;
        await bluebird_1.Promise.map(tasks, async (task) => {
            try {
                task.started = undefined;
                task.ended = undefined;
                task.withErrors = undefined;
                await this.dynamoDBServices.save('data-migration-task', task);
            }
            catch (err) {
                hasErr = true;
                this.logger.error(`failed to reset task ${task.taskKey}, error: ${err}`);
            }
        }, { concurrency: 500 });
        if (hasErr) {
            throw new Error('Error occurred when resetting tasks');
        }
        return tasks.length > 0;
    }
    getTaskName() {
        return RestartFailedMigrationTask.TASK_NAME;
    }
}
exports.RestartFailedMigrationTask = RestartFailedMigrationTask;
RestartFailedMigrationTask.TASK_NAME = 'restart-failed-migration-task';
