"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AirWatchDeviceStateModelService = exports.AirWatchDeviceStateModel = exports.AirWatchDeviceModelService = exports.AirWatchDeviceModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const lodash_1 = __importDefault(require("lodash"));
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class AirWatchDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.AIR_WATCH_DEVICE;
    }
    async initProperties(airWatchDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, airWatchDevice.Uuid);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.AirWatchDeviceModel = AirWatchDeviceModel;
class AirWatchDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new AirWatchDeviceModel(this.partitionKey);
    }
}
exports.AirWatchDeviceModelService = AirWatchDeviceModelService;
class AirWatchDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.AIR_WATCH_DEVICE_STATE;
    }
    async initProperties(airWatchDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(lodash_1.default.omit(airWatchDevice, ['LastSeen'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.IS_MANAGED, true);
        lodash_1.default.forEach(lodash_1.default.toPairs(airWatchDevice), (pair) => {
            if (!AirWatchDeviceStateModel.EXTERNAL_PROPERTIES.includes(pair[0])) {
                switch (pair[0]) {
                    case 'DeviceReportedName':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, pair[1]);
                        break;
                    case 'Platform':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(pair[1]));
                        break;
                    case 'OperatingSystem':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, pair[1]);
                        break;
                    case 'OSBuildVersion':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, pair[1]);
                        break;
                    case 'LastSeen':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(pair[1]));
                        break;
                    case 'ComplianceStatus':
                        switch (pair[1]) {
                            case 'Compliant':
                                this.setProperty(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT, true);
                                break;
                            case 'NotCompliant':
                                this.setProperty(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT, false);
                                break;
                        }
                        break;
                    default:
                        this.setProperty(lodash_1.default.camelCase(pair[0]), pair[1]);
                }
            }
        });
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(airWatchDevice.Platform, airWatchDevice.OperatingSystem, airWatchDevice.OSBuildVersion));
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, airWatchDevice.Platform, airWatchDevice.OperatingSystem);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.AirWatchDeviceStateModel = AirWatchDeviceStateModel;
AirWatchDeviceStateModel.EXTERNAL_PROPERTIES = [
    'Uuid',
    'UserEmailAddress',
    'MacAddress',
    'SerialNumber',
    'PhoneNumber',
    'Udid',
    'UserName'
];
AirWatchDeviceStateModel.IS_SUPERVISED_KEY = 'isSupervised';
AirWatchDeviceStateModel.IS_COMPROMISED_KEY = 'compromisedStatus';
class AirWatchDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new AirWatchDeviceStateModel(this.partitionKey);
    }
}
exports.AirWatchDeviceStateModelService = AirWatchDeviceStateModelService;
