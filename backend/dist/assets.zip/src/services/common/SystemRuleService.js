"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemRuleService = void 0;
const lodash_1 = __importDefault(require("lodash"));
const CommonTypes_1 = require("../../common/CommonTypes");
const RuleService_1 = require("./RuleService");
const TenantServices_1 = require("../../common/TenantServices");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const Util_1 = require("../../common/Util");
const ServiceNowSystemRuleService_1 = require("../servicenow/ServiceNowSystemRuleService");
const CustomSystemRuleService_1 = require("../custom/CustomSystemRuleService");
class SystemRuleService {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    getProducerSystemRuleService(sourceType) {
        switch (sourceType) {
            case CommonTypes_1.Source.SERVICENOW:
                return new ServiceNowSystemRuleService_1.ServiceNowSystemRuleService(this.tenantUid);
            case CommonTypes_1.Source.CUSTOM:
                return new CustomSystemRuleService_1.CustomSystemRuleService(this.tenantUid);
            default:
                return null;
        }
    }
    async createSystemRulesForProducer(sourceType, sourceId, sourceName, resetSystemRules = false) {
        const rulesService = new RuleService_1.RuleService(this.tenantUid);
        let rules = await rulesService.getAllRules();
        rules = rules.filter(rule => rule.origin === RuleService_1.RuleOrigin.SYSTEM);
        const producerSystemRuleService = this.getProducerSystemRuleService(sourceType);
        if (producerSystemRuleService) {
            const systemRulesForProducer = lodash_1.default.filter(rules, rule => lodash_1.default.filter(rule.matchingCondition.producers, (ruleProducer) => sourceId === ruleProducer.producerId).length > 0);
            if (systemRulesForProducer.length > 0) {
                this.logger.info(`Producer already has system rules where tenant=${this.tenantUid}, producer=${(0, Util_1.toSourceString)(sourceType, sourceId)}, and count=${systemRulesForProducer.length}`);
                if (!resetSystemRules) {
                    return false;
                }
                this.logger.info(`Delete system rules where tenant=${this.tenantUid}, producer=${(0, Util_1.toSourceString)(sourceType, sourceId)}, and count=${systemRulesForProducer.length}`);
                await producerSystemRuleService.deleteSystemRules(sourceId, systemRulesForProducer);
            }
            this.logger.info(`Create system rules where tenant=${this.tenantUid} and producer=${(0, Util_1.toSourceString)(sourceType, sourceId)}`);
            return producerSystemRuleService.createSystemRules(sourceId, sourceName);
        }
        return false;
    }
    async deleteSystemRulesForProducer(sourceType, sourceId, rules) {
        const rulesService = new RuleService_1.RuleService(this.tenantUid);
        if (!rules) {
            rules = await rulesService.getAllRules();
        }
        rules = rules.filter(rule => rule.origin === RuleService_1.RuleOrigin.SYSTEM);
        const producerSystemRuleService = this.getProducerSystemRuleService(sourceType);
        if (producerSystemRuleService) {
            const systemRulesForProducer = lodash_1.default.filter(rules, rule => lodash_1.default.filter(rule.matchingCondition.producers, (ruleProducer) => sourceId === ruleProducer.producerId).length > 0);
            if (systemRulesForProducer.length > 0) {
                this.logger.info(`Delete system rules where tenant=${this.tenantUid}, producer=${(0, Util_1.toSourceString)(sourceType, sourceId)}, and count=${systemRulesForProducer.length}`);
                await producerSystemRuleService.deleteSystemRules(sourceId, systemRulesForProducer);
                return true;
            }
        }
        return false;
    }
    async createSystemRulesForTenant(sourceType = undefined, resetSystemRules = false) {
        const rulesService = new RuleService_1.RuleService(this.tenantUid);
        let rules = await rulesService.getAllRules();
        rules = rules.filter(rule => rule.origin === RuleService_1.RuleOrigin.SYSTEM);
        const tenantServices = new TenantServices_1.TenantServices();
        const producerConfig = await tenantServices.getProducerConfigurations(this.tenantUid);
        for (const producer of producerConfig) {
            if (!sourceType || producer.producerType === sourceType) {
                const producerSystemRuleService = this.getProducerSystemRuleService(producer.producerType);
                if (producerSystemRuleService) {
                    const systemRulesForProducer = lodash_1.default.filter(rules, rule => lodash_1.default.filter(rule.matchingCondition.producers, (ruleProducer) => producer.producerId === ruleProducer.producerId).length > 0);
                    if (systemRulesForProducer.length > 0) {
                        this.logger.info(`Producer already has system rules where tenant=${this.tenantUid}, producer=${(0, Util_1.toSourceString)(producer.producerType, producer.producerId)}, and count=${systemRulesForProducer.length}`);
                        if (!resetSystemRules) {
                            continue;
                        }
                        this.logger.info(`Delete system rules where tenant=${this.tenantUid}, producer=${(0, Util_1.toSourceString)(producer.producerType, producer.producerId)}, and count=${systemRulesForProducer.length}`);
                        await producerSystemRuleService.deleteSystemRules(producer.producerId, systemRulesForProducer);
                    }
                    this.logger.info(`Create system rules where tenant=${this.tenantUid} and producer=${(0, Util_1.toSourceString)(producer.producerType, producer.producerId)}`);
                    await producerSystemRuleService.createSystemRules(producer.producerId, producer.name);
                }
            }
        }
    }
    async deleteSystemRulesForTenant(sourceType = undefined, rules) {
        const rulesService = new RuleService_1.RuleService(this.tenantUid);
        if (!rules) {
            rules = await rulesService.getAllRules();
        }
        rules = rules.filter(rule => rule.origin === RuleService_1.RuleOrigin.SYSTEM);
        const tenantServices = new TenantServices_1.TenantServices();
        const producerConfig = await tenantServices.getProducerConfigurations(this.tenantUid);
        for (const producer of producerConfig) {
            if (!sourceType || producer.producerType === sourceType) {
                const producerSystemRuleService = this.getProducerSystemRuleService(producer.producerType);
                if (producerSystemRuleService) {
                    const systemRulesForProducer = lodash_1.default.filter(rules, rule => lodash_1.default.filter(rule.matchingCondition.producers, (ruleProducer) => producer.producerId === ruleProducer.producerId).length > 0);
                    if (systemRulesForProducer.length > 0) {
                        this.logger.info(`Delete system rules where tenant=${this.tenantUid}, producer=${(0, Util_1.toSourceString)(producer.producerType, producer.producerId)}, and count=${systemRulesForProducer.length}`);
                        await producerSystemRuleService.deleteSystemRules(producer.producerId, systemRulesForProducer);
                    }
                }
            }
        }
    }
}
exports.SystemRuleService = SystemRuleService;
