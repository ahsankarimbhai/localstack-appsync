"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceNowDeviceStateModelService = exports.ServiceNowDeviceStateModel = exports.ServiceNowDeviceModelService = exports.ServiceNowDeviceModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const BaseGraphService_1 = require("./BaseGraphService");
const CommonTypes_1 = require("../common/CommonTypes");
const lodash_1 = __importDefault(require("lodash"));
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class ServiceNowDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.SERVICE_NOW_DEVICE;
    }
    async initProperties(serviceNowDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, serviceNowDevice.sys_id);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.ServiceNowDeviceModel = ServiceNowDeviceModel;
class ServiceNowDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new ServiceNowDeviceModel(this.partitionKey);
    }
}
exports.ServiceNowDeviceModelService = ServiceNowDeviceModelService;
class ServiceNowDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.SERVICE_NOW_DEVICE_STATE;
    }
    async initProperties(serviceNowDevice) {
        var _a;
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(lodash_1.default.omit(serviceNowDevice, ['sys_updated_on', 'sys_updated_by'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, serviceNowDevice.name);
        this.setProperty(CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, serviceNowDevice.ip_address);
        this.setProperty(CommonTypes_1.VertexType.MAC_ADDRESS, serviceNowDevice.mac_address);
        this.setProperty(CommonTypes_1.VertexType.SERIAL_NUMBER, serviceNowDevice.serial_number);
        this.setProperty(ServiceNowDeviceStateModel.COMMENTS, serviceNowDevice.comments);
        this.setProperty(ServiceNowDeviceStateModel.MODEL_NUMBER, serviceNowDevice.model_number);
        this.setProperty(ServiceNowDeviceStateModel.MODEL_ID, (_a = serviceNowDevice.model_id) === null || _a === void 0 ? void 0 : _a.value);
        this.setProperty(ServiceNowDeviceStateModel.ASSET, serviceNowDevice.asset);
        this.setProperty(ServiceNowDeviceStateModel.ASSET_VALUE, serviceNowDevice.busines_criticality);
        this.setProperty(ServiceNowDeviceStateModel.CREATED_AT, this.convertToMilliseconds(serviceNowDevice.sys_created_on));
        this.setProperty(ServiceNowDeviceStateModel.CREATED_BY, serviceNowDevice.sys_created_by);
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, this.convertToMilliseconds(serviceNowDevice.sys_updated_on));
        this.setProperty(ServiceNowDeviceStateModel.UPDATED_BY, serviceNowDevice.sys_updated_by);
    }
    convertToMilliseconds(stringValue) {
        return new Date(stringValue).getTime();
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.ServiceNowDeviceStateModel = ServiceNowDeviceStateModel;
ServiceNowDeviceStateModel.COMMENTS = 'comments';
ServiceNowDeviceStateModel.MODEL_NUMBER = 'modelNumber';
ServiceNowDeviceStateModel.MODEL_ID = 'modelId';
ServiceNowDeviceStateModel.ASSET = 'asset';
ServiceNowDeviceStateModel.ASSET_VALUE = 'assetValue';
ServiceNowDeviceStateModel.CREATED_AT = 'createdAt';
ServiceNowDeviceStateModel.CREATED_BY = 'createdBy';
ServiceNowDeviceStateModel.UPDATED_BY = 'updatedBy';
class ServiceNowDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new ServiceNowDeviceStateModel(this.partitionKey);
    }
}
exports.ServiceNowDeviceStateModelService = ServiceNowDeviceStateModelService;
