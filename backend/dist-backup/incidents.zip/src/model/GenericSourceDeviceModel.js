"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericSourceDeviceStateModelService = exports.GenericSourceDeviceStateModel = exports.GenericSourceDeviceModelService = exports.GenericSourceDeviceModel = void 0;
const _ = __importStar(require("lodash"));
const Util_1 = require("../common/Util");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphElement_1 = require("./BaseGraphElement");
const BaseGraphService_1 = require("./BaseGraphService");
const GenericSourceConfiguration_1 = require("../common/generic/GenericSourceConfiguration");
class GenericSourceDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.GENERIC_SOURCE_DEVICE;
    }
    async initProperties(genericDevice, source, sourceConfiguration) {
        this.sourceType = _.split(source, Util_1.SOURCE_SEPARATOR)[0];
        this.sourceConfiguration = sourceConfiguration;
        if (!this.sourceConfiguration) {
            throw new Error('Missing sourceConfiguration in GenericSourceDeviceModel.initProperties');
        }
        const filteredStoredFields = Object.entries(this.sourceConfiguration.mergedModelDataMapping.storedFields)
            .filter(([storedFieldName]) => { var _a; return (_a = this.sourceConfiguration) === null || _a === void 0 ? void 0 : _a.mergedModelDataMapping.keyProperties.includes(storedFieldName); });
        _.forEach(filteredStoredFields, ([storedFieldName, storedFieldDetails]) => this.setProperty(storedFieldName, _.get(genericDevice, storedFieldDetails.sourceFieldName)));
    }
    getKeyProperties() {
        var _a, _b, _c;
        return (_c = (_b = (_a = this.sourceConfiguration) === null || _a === void 0 ? void 0 : _a.mergedModelDataMapping) === null || _b === void 0 ? void 0 : _b.keyProperties) !== null && _c !== void 0 ? _c : [];
    }
}
exports.GenericSourceDeviceModel = GenericSourceDeviceModel;
class GenericSourceDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new GenericSourceDeviceModel(this.partitionKey);
    }
}
exports.GenericSourceDeviceModelService = GenericSourceDeviceModelService;
class GenericSourceDeviceStateModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.GENERIC_SOURCE_DEVICE_STATE;
    }
    async initProperties(genericDevice, source, sourceConfiguration) {
        this.sourceType = _.split(source, Util_1.SOURCE_SEPARATOR)[0];
        this.sourceConfiguration = sourceConfiguration;
        _.forEach(Object.entries(this.sourceConfiguration.mergedModelDataMapping.storedFields), ([storedFieldName, storedFieldDetails]) => {
            if (storedFieldName === CommonTypes_1.VertexBasicProperty.EXT_ID) {
                return;
            }
            let value = _.get(genericDevice, storedFieldDetails.sourceFieldName);
            switch (storedFieldDetails.mappedType) {
                case GenericSourceConfiguration_1.StoredFieldMappedType.TIME_IN_MILLIS:
                    value = new Date(value).getTime();
                    break;
                case GenericSourceConfiguration_1.StoredFieldMappedType.OS_TYPE:
                    value = (0, CommonTypes_1.getOsType)(value);
                    break;
                case GenericSourceConfiguration_1.StoredFieldMappedType.OS_VERSION: {
                    const osVersionValue = (0, CommonTypes_1.getOsVersion)(value);
                    value = (osVersionValue !== 'na') ? osVersionValue : value;
                    break;
                }
                default:
            }
            this.setProperty(storedFieldName, value);
        });
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(genericDevice, this.sourceConfiguration.mergedModelDataMapping.sourceFieldsToExcludeInStateHashCalculation || [])));
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.GenericSourceDeviceStateModel = GenericSourceDeviceStateModel;
class GenericSourceDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new GenericSourceDeviceStateModel(this.partitionKey);
    }
}
exports.GenericSourceDeviceStateModelService = GenericSourceDeviceStateModelService;
