"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssetsService = void 0;
const lodash_1 = __importDefault(require("lodash"));
const AssetsModel_1 = require("./AssetsModel");
const PostureEndpointService_1 = require("../model/PostureEndpointService");
const CommonTypes_1 = require("../common/CommonTypes");
const SharedTypesModel_1 = require("../model/SharedTypesModel");
const VulnerabilityUtil_1 = require("../services/common/VulnerabilityUtil");
const uuid_1 = require("uuid");
const TenantServices_1 = require("../common/TenantServices");
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const Util_1 = require("../common/Util");
class AssetsService {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.initialized = false;
        this.labelsFeatureEnabled = false;
        this.assetValueFeatureEnabled = false;
        this.assetsMultipleSourceExtIdsEnabled = false;
    }
    async init() {
        if (!this.initialized) {
            const featureFlags = await new TenantServices_1.TenantServices().getFeatureFlags(this.tenantUid);
            this.labelsFeatureEnabled = featureFlags.includes(TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE);
            this.assetValueFeatureEnabled = featureFlags.includes(TenantServices_1.FeatureFlag.MANUAL_LABELS_VALUE);
            this.assetsMultipleSourceExtIdsEnabled = featureFlags.includes(TenantServices_1.FeatureFlag.ASSETS_MULTIPLE_SOURCE_EXT_IDS_ENABLED);
            this.initialized = true;
        }
    }
    static getESFilter(request) {
        const strongSearchTerms = [];
        const weakSearchTerms = [];
        for (const observable of request.observables) {
            switch (observable.type) {
                case AssetsModel_1.AssetObservablesType.MAC_ADDRESS:
                    weakSearchTerms.push(`macAddresses.keyword:\"${observable.value}\"`);
                    break;
                case AssetsModel_1.AssetObservablesType.IP:
                case AssetsModel_1.AssetObservablesType.IPV6:
                    weakSearchTerms.push(`(internalIpAddresses.keyword:\"${observable.value}\" OR externalIpAddresses.keyword:\"${observable.value}\")`);
                    break;
                case AssetsModel_1.AssetObservablesType.EMAIL:
                    weakSearchTerms.push(`emails.keyword:\"${observable.value}\"`);
                    break;
                case AssetsModel_1.AssetObservablesType.HOSTNAME:
                    weakSearchTerms.push(`hostname.keyword:\"${observable.value}\"`);
                    break;
                case AssetsModel_1.AssetObservablesType.USER:
                    weakSearchTerms.push(`(appUsers.keyword:\"${observable.value}\" OR users.keyword:\"${observable.value}\")`);
                    break;
                case AssetsModel_1.AssetObservablesType.CISCO_UC_ID:
                    strongSearchTerms.push(`ucId.keyword:\"${observable.value}\"`);
                    break;
                case AssetsModel_1.AssetObservablesType.UMBRELLA_ODNS_IDENTITY:
                    strongSearchTerms.push(`(producers.type.keyword:\"${CommonTypes_1.Source.UMBRELLA}\" AND producers.extId.keyword:\"${observable.value}\")`);
                    break;
                case AssetsModel_1.AssetObservablesType.CROWDSTRIKE_ID:
                    strongSearchTerms.push(`(producers.type.keyword:\"${CommonTypes_1.Source.CROWDSTRIKE}\" AND producers.extId.keyword:\"${observable.value}\")`);
                    break;
                case AssetsModel_1.AssetObservablesType.S1_AGENT_ID:
                    strongSearchTerms.push(`(producers.type.keyword:\"${CommonTypes_1.Source.SENTINEL_ONE}\" AND producers.extId.keyword:\"${observable.value}\")`);
                    break;
                case AssetsModel_1.AssetObservablesType.MS_MACHINE_ID:
                    strongSearchTerms.push(`(producers.type.keyword:\"${CommonTypes_1.Source.DEFENDER}\" AND producers.extId.keyword:\"${observable.value}\")`);
                    break;
                case AssetsModel_1.AssetObservablesType.IMEI:
                    strongSearchTerms.push(`imei.keyword:\"${observable.value}\"`);
                    break;
                case AssetsModel_1.AssetObservablesType.ORBITAL_NODE_ID:
                    strongSearchTerms.push(`orbitalNodeId.keyword:\"${observable.value}\"`);
                    break;
                case AssetsModel_1.AssetObservablesType.AMP_COMPUTER_GUID:
                    strongSearchTerms.push(`ampConnectorGUID.keyword:\"${observable.value}\"`);
                    break;
                case AssetsModel_1.AssetObservablesType.SERIAL_NUMBER:
                    strongSearchTerms.push(`serialNumber.keyword:\"${observable.value}\"`);
                    break;
                case AssetsModel_1.AssetObservablesType.TREND_MICRO_ID:
                    strongSearchTerms.push(`(producers.type.keyword:\"${CommonTypes_1.Source.TREND_VISION_ONE}\" AND producers.extId.keyword:\"${observable.value}\")`);
                    break;
                default:
                    break;
            }
        }
        const strongQuery = lodash_1.default.join(strongSearchTerms, ' OR ');
        const weakQuery = lodash_1.default.join(weakSearchTerms, ' AND ');
        let query = '';
        if (!strongQuery) {
            query = weakQuery;
        }
        else {
            query = weakQuery ? `${strongQuery} AND ${weakQuery}` : strongQuery;
        }
        return {
            luceneQuery: query
        };
    }
    static getValidTime(postureEntity) {
        const currentDate = new Date(Date.now());
        const validTime = {
            start_time: postureEntity.since ? new Date(postureEntity.since * 1000).toISOString() : currentDate.toISOString()
        };
        if (postureEntity.until) {
            validTime.end_time = new Date(postureEntity.until * 1000).toISOString();
        }
        return validTime;
    }
    static addProducerObservablesByUid(mergedEndpoint, source, observableType, observables) {
        const producers = lodash_1.default.filter(mergedEndpoint.producers, { type: source });
        for (const producer of producers) {
            const value = lodash_1.default.split(producer.uid, NeptuneServicesFactory_1.VERTEX_ID_SEPARATOR)[0];
            if (value) {
                observables.push({
                    type: observableType,
                    value
                });
            }
        }
    }
    getObservables(mergedEndpoint) {
        const observables = [];
        AssetsService.addProducerObservablesByUid(mergedEndpoint, CommonTypes_1.Source.CROWDSTRIKE, AssetsModel_1.AssetObservablesType.CROWDSTRIKE_ID, observables);
        AssetsService.addProducerObservablesByUid(mergedEndpoint, CommonTypes_1.Source.SENTINEL_ONE, AssetsModel_1.AssetObservablesType.S1_AGENT_ID, observables);
        AssetsService.addProducerObservablesByUid(mergedEndpoint, CommonTypes_1.Source.DEFENDER, AssetsModel_1.AssetObservablesType.MS_MACHINE_ID, observables);
        AssetsService.addProducerObservablesByUid(mergedEndpoint, CommonTypes_1.Source.UMBRELLA, AssetsModel_1.AssetObservablesType.UMBRELLA_ODNS_IDENTITY, observables);
        AssetsService.addProducerObservablesByUid(mergedEndpoint, CommonTypes_1.Source.TREND_VISION_ONE, AssetsModel_1.AssetObservablesType.TREND_MICRO_ID, observables);
        if (mergedEndpoint.ampConnectorGUID) {
            observables.push({
                type: AssetsModel_1.AssetObservablesType.AMP_COMPUTER_GUID,
                value: mergedEndpoint.ampConnectorGUID
            });
        }
        if (mergedEndpoint.orbitalNodeId) {
            observables.push({
                type: AssetsModel_1.AssetObservablesType.ORBITAL_NODE_ID,
                value: mergedEndpoint.orbitalNodeId
            });
        }
        if (mergedEndpoint.ucId) {
            observables.push({
                type: AssetsModel_1.AssetObservablesType.CISCO_UC_ID,
                value: mergedEndpoint.ucId
            });
        }
        if (mergedEndpoint.serialNumber) {
            observables.push({
                type: AssetsModel_1.AssetObservablesType.SERIAL_NUMBER,
                value: mergedEndpoint.serialNumber
            });
        }
        if (mergedEndpoint.hostname) {
            observables.push({
                type: AssetsModel_1.AssetObservablesType.HOSTNAME,
                value: (new SharedTypesModel_1.Hostname(this.tenantUid)).normalizeValue(mergedEndpoint.hostname)
            });
        }
        if (mergedEndpoint.imei) {
            observables.push({
                type: AssetsModel_1.AssetObservablesType.IMEI,
                value: (new SharedTypesModel_1.Imei(this.tenantUid)).normalizeValue(mergedEndpoint.imei)
            });
        }
        if (!lodash_1.default.isEmpty(mergedEndpoint.emails)) {
            lodash_1.default.forEach(mergedEndpoint.emails, email => observables.push({
                type: AssetsModel_1.AssetObservablesType.EMAIL,
                value: email
            }));
        }
        if (!lodash_1.default.isEmpty(mergedEndpoint.appUsers)) {
            lodash_1.default.forEach(mergedEndpoint.appUsers, appUser => observables.push({
                type: AssetsModel_1.AssetObservablesType.USER,
                value: appUser
            }));
        }
        if (!lodash_1.default.isEmpty(mergedEndpoint.users)) {
            lodash_1.default.forEach(mergedEndpoint.users, user => observables.push({
                type: AssetsModel_1.AssetObservablesType.USER,
                value: user
            }));
        }
        if (!lodash_1.default.isEmpty(mergedEndpoint.macAddresses)) {
            const macAddressObj = new SharedTypesModel_1.MacAddress(this.tenantUid);
            lodash_1.default.forEach(mergedEndpoint.macAddresses, macAddress => observables.push({
                type: AssetsModel_1.AssetObservablesType.MAC_ADDRESS,
                value: macAddressObj.normalizeValue(macAddress)
            }));
        }
        if (!lodash_1.default.isEmpty(mergedEndpoint.externalIpAddresses)) {
            lodash_1.default.forEach(mergedEndpoint.externalIpAddresses, externalIpAddress => observables.push({
                type: AssetsModel_1.AssetObservablesType.IP,
                value: externalIpAddress
            }));
        }
        if (!lodash_1.default.isEmpty(mergedEndpoint.internalIpAddresses)) {
            lodash_1.default.forEach(mergedEndpoint.internalIpAddresses, internalIpAddress => observables.push({
                type: AssetsModel_1.AssetObservablesType.IP,
                value: internalIpAddress
            }));
        }
        return observables;
    }
    async getAssetProperties(mergedEndpoint, properties = []) {
        const assetProperties = [];
        if (lodash_1.default.isEmpty(properties) || lodash_1.default.includes(properties, AssetsModel_1.AssetPropertyKey.ASSET_LABELS) || lodash_1.default.includes(properties, AssetsModel_1.AssetPropertyKey.ASSET_VALUE)) {
            if (this.labelsFeatureEnabled || this.assetValueFeatureEnabled) {
                const epService = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
                await epService.addDataFromESToMergedEP(mergedEndpoint);
            }
        }
        lodash_1.default.map(lodash_1.default.keys(mergedEndpoint), (key) => {
            if (!lodash_1.default.includes(AssetsService.SKIP_KEYS, key) && lodash_1.default.get(mergedEndpoint, key)) {
                switch (key) {
                    case 'financialRiskFactor':
                        break;
                    case 'assetValue':
                        if (this.assetValueFeatureEnabled) {
                            AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.ASSET_VALUE);
                        }
                        break;
                    case 'labels':
                        if (this.labelsFeatureEnabled) {
                            if (mergedEndpoint.labels) {
                                const shortLabels = mergedEndpoint.labels.map(obj => obj.labelId);
                                assetProperties.push({
                                    name: `${AssetsModel_1.AssetPropertyKey.ASSET_LABELS}`,
                                    value: JSON.stringify(shortLabels)
                                });
                            }
                        }
                        break;
                    case 'uid':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_ID);
                        break;
                    case 'osType':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_OS_VERSION_NAME);
                        break;
                    case 'osVersion':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_OS_VERSION);
                        break;
                    case 'osSupport':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_OS_SUPPORT);
                        break;
                    case 'isCompromised':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_IS_COMPROMISED);
                        break;
                    case 'isManaged':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_IS_MANAGED);
                        break;
                    case 'isEncrypted':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_IS_ENCRYPTED);
                        break;
                    case 'isSupervised':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_IS_SUPERVISED);
                        break;
                    case 'hardwareId': {
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_HARDWARE_ID);
                        break;
                    }
                    case 'computerSID': {
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_COMPUTER_SID);
                        break;
                    }
                    case 'systemModel':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_MODEL);
                        break;
                    case 'jailBroken':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_MDM_JAIL_BROKEN);
                        break;
                    case 'isCompliant':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_MDM_COMPLIANT);
                        break;
                    case 'androidSecurityPatchLevel':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_MDM_ANDROID_SECURITY);
                        break;
                    case 'tampered':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_MDM_TAMPERED);
                        break;
                    case 'endpointType':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_TYPE);
                        break;
                    case 'hasFaults':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_HAS_FAULTS);
                        break;
                    case 'avDefinitionsOutOfDate':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_AV_DEFINITION_OUT_OF_DATE);
                        break;
                    case 'lastUpdated':
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, AssetsModel_1.AssetPropertyKey.DEVICE_LAST_SYNC_TIME);
                        break;
                    case 'producers':
                        lodash_1.default.forEach(mergedEndpoint.producers, producer => {
                            const producerKey = `${lodash_1.default.toLower(producer.type)}:${producer.irohModuleInstanceId || producer.producerId}`;
                            lodash_1.default.forEach(producer.properties, producerProperty => {
                                let name = `${producerKey}:${producerProperty.key}`;
                                if (lodash_1.default.isEmpty(properties) || lodash_1.default.includes(properties, name)) {
                                    if (this.assetsMultipleSourceExtIdsEnabled) {
                                        name = `${lodash_1.default.toLower(producer.type)}:${(0, Util_1.getProducerExtId)(producer.uid)}:${producerProperty.key}`;
                                    }
                                    assetProperties.push({
                                        name,
                                        value: producerProperty.value
                                    });
                                }
                            });
                        });
                        break;
                    default:
                        AssetsService.addAssetProperty(assetProperties, mergedEndpoint, properties, key, key);
                }
            }
        });
        return assetProperties;
    }
    static addAssetProperty(assetProperties, mergedEndpoint, properties, key, name) {
        if (lodash_1.default.isEmpty(properties) || lodash_1.default.includes(properties, name)) {
            assetProperties.push({
                name,
                value: AssetsService.getValue(mergedEndpoint, key)
            });
        }
    }
    static getValue(mergedEndpoint, key) {
        return lodash_1.default.isString(lodash_1.default.get(mergedEndpoint, key)) ? lodash_1.default.get(mergedEndpoint, key) : JSON.stringify(lodash_1.default.get(mergedEndpoint, key));
    }
    async getAssetMappings(postureEndpoint, assetMapping) {
        const observables = this.getObservables(postureEndpoint);
        lodash_1.default.forEach(observables, observable => assetMapping.push({
            ...AssetsModel_1.postureAssetMapping,
            observable,
            id: `${AssetsService.ASSET_ID_PREF}${(0, uuid_1.v4)()}`,
            asset_ref: `${AssetsService.ASSET_ID_PREF}${postureEndpoint.uid}`,
            valid_time: AssetsService.getValidTime(postureEndpoint),
            timestamp: new Date(Date.now()).toISOString()
        }));
    }
    async getAssetData(postureEndpoint, assetModel, assetMapping, assetProperties, properties = []) {
        assetModel.push(AssetsService.getAssetsDataFromMergedEndpoint(postureEndpoint));
        await this.getAssetMappings(postureEndpoint, assetMapping);
        assetProperties.push({
            ...AssetsModel_1.postureAssetProperties,
            id: `${AssetsService.ASSET_ID_PREF}${(0, uuid_1.v4)()}`,
            asset_ref: `${AssetsService.ASSET_ID_PREF}${postureEndpoint.uid}`,
            valid_time: AssetsService.getValidTime(postureEndpoint),
            properties: await this.getAssetProperties(postureEndpoint, properties),
            timestamp: new Date(Date.now()).toISOString()
        });
    }
    static getAssetsDataFromMergedEndpoint(postureEndpoint) {
        return {
            ...AssetsModel_1.postureAssetModel,
            id: `${AssetsService.ASSET_ID_PREF}${postureEndpoint.uid}`,
            title: postureEndpoint.hostname,
            valid_time: AssetsService.getValidTime(postureEndpoint),
            timestamp: new Date(Date.now()).toISOString()
        };
    }
    async resolveLatest(resolveLatestRequest) {
        await this.init();
        if (!resolveLatestRequest.observables) {
            throw new Error('Missing observables in request');
        }
        const filter = AssetsService.getESFilter(resolveLatestRequest);
        if (filter.luceneQuery === '') {
            return { data: { assets: [] } };
        }
        const postureEndpointService = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        const postureEndpoints = await postureEndpointService.listPostureEndpoints(filter, ['deploymentId', 'wantedDeploymentId', 'labels', 'rulesLabels', 'osExtractedNumericVersion']);
        const assetMapping = [];
        if (resolveLatestRequest.include_mappings) {
            for (const postureEndpoint of postureEndpoints) {
                await this.getAssetMappings(postureEndpoint, assetMapping);
            }
        }
        return {
            data: {
                assets: lodash_1.default.map(postureEndpoints, postureEndpoint => AssetsService.getAssetsDataFromMergedEndpoint(postureEndpoint)),
                'asset-mappings': resolveLatestRequest.include_mappings ? assetMapping : undefined
            }
        };
    }
    async resolve(resolveRequest) {
        await this.init();
        if (!resolveRequest.observables) {
            throw new Error('Missing observables in request');
        }
        if (!resolveRequest.asset_count) {
            throw new Error('asset_count is mandatory field in resolve API');
        }
        const filter = this.getPostureEndpointsHistoricalStateFilter(resolveRequest);
        const postureEndpointService = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        return {
            data: await this.getHistoricalPostureEndpoints(postureEndpointService, filter, resolveRequest.include_mappings)
        };
    }
    async getHistoricalPostureEndpoints(postureEndpointService, filter, include_mappings = true, include_properties = false) {
        const historicalPEs = await postureEndpointService.listPostureEndpointsHistoricalState(filter);
        const assetModel = [];
        const assetMapping = [];
        const assetProperties = [];
        for (const historicalPE of historicalPEs.states) {
            for (const postureEndpoint of historicalPE) {
                await this.getAssetData(postureEndpoint, assetModel, assetMapping, assetProperties);
            }
        }
        return {
            assets: assetModel,
            'asset-mappings': include_mappings ? assetMapping : undefined,
            'asset-properties': include_properties ? assetProperties : undefined
        };
    }
    async describe(describeRequest) {
        await this.init();
        if (!describeRequest.asset_id) {
            throw new Error('Missing asset_id in describe request');
        }
        const postureEndpointService = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        if (!describeRequest.start_time && !describeRequest.end_time) {
            return this.describeLatestPE(postureEndpointService, describeRequest);
        }
        const { since, until } = AssetsService.getTimeFrame({ end_time: describeRequest.end_time, start_time: describeRequest.start_time });
        return {
            data: await this.getHistoricalPostureEndpoints(postureEndpointService, { searchTypes: [], peUid: describeRequest.asset_id, since, until }, describeRequest.include_mappings, describeRequest.include_properties)
        };
    }
    async describeLatestPE(postureEndpointService, describeRequest) {
        const postureEndpoint = await postureEndpointService.getPostureEndpoint(describeRequest.asset_id);
        const assetMapping = [];
        const assetProperties = [];
        const assetModel = [];
        if (postureEndpoint) {
            const vulnerabilityUtil = new VulnerabilityUtil_1.VulnerabilityUtil();
            await vulnerabilityUtil.augmentWithVulnerabilities(postureEndpoint, this.tenantUid);
            await this.getAssetData(postureEndpoint, assetModel, assetMapping, assetProperties, describeRequest.interested_properties);
        }
        return {
            data: {
                assets: assetModel,
                'asset-mappings': describeRequest.include_mappings ? assetMapping : undefined,
                'asset-properties': describeRequest.include_properties ? assetProperties : undefined
            }
        };
    }
    getPostureEndpointsHistoricalStateFilter(resolveRequest) {
        const { since, until } = AssetsService.getTimeFrame({ end_time: resolveRequest.end_time, start_time: resolveRequest.start_time });
        const producers = AssetsService.getProducers(resolveRequest.observables);
        return {
            searchTypes: this.getSearchTypes(resolveRequest.observables),
            pageSize: resolveRequest.asset_count,
            since,
            producers,
            until
        };
    }
    static getTimeFrame(timeFrameRequest) {
        const until = timeFrameRequest.end_time ? new Date(timeFrameRequest.end_time).getTime() : Date.now();
        const currentDate = new Date(until);
        const timeFrame = new Date(until);
        timeFrame.setDate(currentDate.getDate() - 1);
        const since = timeFrameRequest.start_time ? new Date(timeFrameRequest.start_time).getTime() : new Date(timeFrame).getTime();
        return { since, until };
    }
    vertexTypeFromObservable(observable) {
        switch (observable.type) {
            case AssetsModel_1.AssetObservablesType.MAC_ADDRESS:
                return [CommonTypes_1.VertexType.MAC_ADDRESS];
            case AssetsModel_1.AssetObservablesType.IP:
            case AssetsModel_1.AssetObservablesType.IPV6:
                return [CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, CommonTypes_1.VertexType.INTERNAL_IP_ADDRESS];
            case AssetsModel_1.AssetObservablesType.EMAIL:
                return [CommonTypes_1.VertexType.EMAIL];
            case AssetsModel_1.AssetObservablesType.HOSTNAME:
                return [CommonTypes_1.VertexType.HOSTNAME];
            case AssetsModel_1.AssetObservablesType.USER:
                return [CommonTypes_1.VertexType.USER, CommonTypes_1.VertexType.APP_USER];
            case AssetsModel_1.AssetObservablesType.IMEI:
                return [CommonTypes_1.VertexType.IMEI];
            case AssetsModel_1.AssetObservablesType.SERIAL_NUMBER:
                return [CommonTypes_1.VertexType.SERIAL_NUMBER];
            case AssetsModel_1.AssetObservablesType.CISCO_UC_ID:
            case AssetsModel_1.AssetObservablesType.ORBITAL_NODE_ID:
            case AssetsModel_1.AssetObservablesType.AMP_COMPUTER_GUID:
            case AssetsModel_1.AssetObservablesType.UMBRELLA_ODNS_IDENTITY:
            case AssetsModel_1.AssetObservablesType.CROWDSTRIKE_ID:
            case AssetsModel_1.AssetObservablesType.S1_AGENT_ID:
            case AssetsModel_1.AssetObservablesType.MS_MACHINE_ID:
            case AssetsModel_1.AssetObservablesType.TREND_MICRO_ID:
                return [];
            default:
                return [];
        }
    }
    normalizeValue(value, type) {
        switch (type) {
            case CommonTypes_1.VertexType.HOSTNAME:
                return (new SharedTypesModel_1.Hostname(this.tenantUid)).normalizeValue(value);
            case CommonTypes_1.VertexType.IMEI:
                return (new SharedTypesModel_1.Imei(this.tenantUid)).normalizeValue(value);
            case CommonTypes_1.VertexType.MAC_ADDRESS:
                return (new SharedTypesModel_1.MacAddress(this.tenantUid)).normalizeValue(value);
            default:
                return value;
        }
    }
    getSearchTypes(observables) {
        return lodash_1.default.flatMap(observables, observable => {
            const types = this.vertexTypeFromObservable(observable);
            return lodash_1.default.flatMap(types, type => {
                const value = this.normalizeValue(observable.value, type);
                return {
                    type,
                    value
                };
            });
        });
    }
    static getProducers(observables) {
        return lodash_1.default.filter(lodash_1.default.flatMap(observables, observable => this.getProducerInfo(observable)), producer => !lodash_1.default.isUndefined(producer.source));
    }
    static getProducerInfo(observable) {
        switch (observable.type) {
            case AssetsModel_1.AssetObservablesType.CISCO_UC_ID:
                return { source: CommonTypes_1.Source.UNIFIED_CONNECTOR, extId: observable.value };
            case AssetsModel_1.AssetObservablesType.ORBITAL_NODE_ID:
                return { source: CommonTypes_1.Source.ORBITAL, extId: observable.value };
            case AssetsModel_1.AssetObservablesType.AMP_COMPUTER_GUID:
                return { source: CommonTypes_1.Source.AMP, extId: observable.value };
            case AssetsModel_1.AssetObservablesType.UMBRELLA_ODNS_IDENTITY:
                return { source: CommonTypes_1.Source.UMBRELLA, extId: observable.value };
            case AssetsModel_1.AssetObservablesType.CROWDSTRIKE_ID:
                return { source: CommonTypes_1.Source.CROWDSTRIKE, extId: observable.value };
            case AssetsModel_1.AssetObservablesType.S1_AGENT_ID:
                return { source: CommonTypes_1.Source.SENTINEL_ONE, extId: observable.value };
            case AssetsModel_1.AssetObservablesType.MS_MACHINE_ID:
                return { source: CommonTypes_1.Source.DEFENDER, extId: observable.value };
            case AssetsModel_1.AssetObservablesType.TREND_MICRO_ID:
                return { source: CommonTypes_1.Source.TREND_VISION_ONE, extId: observable.value };
            default:
                return { source: undefined, extId: undefined };
        }
    }
}
exports.AssetsService = AssetsService;
AssetsService.SKIP_KEYS = [
    'since',
    'until',
    'propertyTimestamp',
    'serialNumber',
    'imei',
    'orbitalNodeId',
    'ampConnectorGUID',
    'ucId',
    'hostname',
    'emails',
    'appUsers',
    'users',
    'internalIpAddresses',
    'externalIpAddresses',
    'macAddresses'
];
AssetsService.ASSET_ID_PREF = 'transient:';
