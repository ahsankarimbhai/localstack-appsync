"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtendMigrationTaskTTL = void 0;
const BasicScheduledTaskProcessor_1 = require("../../scheduled/BasicScheduledTaskProcessor");
const bluebird_1 = require("bluebird");
const DateUtils_1 = require("../../common/DateUtils");
const DynamodbServiceFactory_1 = require("../../common/awsclient/dynamodb/DynamodbServiceFactory");
class ExtendMigrationTaskTTL extends BasicScheduledTaskProcessor_1.BasicScheduledTaskProcessor {
    constructor() {
        super(...arguments);
        this.defaultDaysToExtend = 30;
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    }
    async execute() {
        const taskParamsObj = this.getTaskParamsObj();
        if (!taskParamsObj || !taskParamsObj.tasks) {
            throw new Error('tasks must be provided.');
        }
        for (const taskName of taskParamsObj.tasks) {
            await this.extendTaskTTL(taskName, (taskParamsObj === null || taskParamsObj === void 0 ? void 0 : taskParamsObj.daysToExtend) || this.defaultDaysToExtend);
        }
        return bluebird_1.Promise.resolve();
    }
    getTaskParamsObj() {
        try {
            return JSON.parse(this.taskParams);
        }
        catch {
            return undefined;
        }
    }
    async extendTaskTTL(taskName, daysToExtend) {
        const tasks = await this.dynamoDBServices.getAllFilteredTableEntries('data-migration-task', 'contains(taskKey, :taskName)', { ':taskName': taskName });
        this.logger.info(`found total ${tasks.length} tasks for ${taskName}`);
        let hasErr = false;
        await bluebird_1.Promise.map(tasks, async (task) => {
            try {
                task.timeToExpire += daysToExtend * DateUtils_1.DAY_SECONDS;
                await this.dynamoDBServices.save('data-migration-task', task);
            }
            catch (err) {
                hasErr = true;
                this.logger.error(`failed to extend task ${task.taskKey}, error: ${err}`);
            }
        }, { concurrency: 500 });
        if (hasErr) {
            throw new Error('Error occurred when resetting tasks');
        }
    }
    getTaskName() {
        return ExtendMigrationTaskTTL.TASK_NAME;
    }
}
exports.ExtendMigrationTaskTTL = ExtendMigrationTaskTTL;
ExtendMigrationTaskTTL.TASK_NAME = 'extend-migration-task-ttl';
