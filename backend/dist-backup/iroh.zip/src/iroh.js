"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initialProducersSync = exports.irohTokenRequest = exports.logger = void 0;
const lodash_1 = __importDefault(require("lodash"));
const Util_1 = require("./common/Util");
const query_string_1 = __importDefault(require("query-string"));
const CommonTypes_1 = require("./common/CommonTypes");
const AwsSecretsService_1 = require("./common/AwsSecretsService");
const IrohClient_1 = require("./common/IrohClient");
const LambdaLogger_1 = require("./common/LambdaLogger");
const TenantServices_1 = require("./common/TenantServices");
const SourceUtils_1 = require("./common/SourceUtils");
const IrohModuleInstanceClient_1 = require("./common/IrohModuleInstanceClient");
const jsonwebtoken_1 = require("jsonwebtoken");
const IdpKeyClientFactory_1 = require("./common/tokenhelper/IdpKeyClientFactory");
const JwtHelper_1 = require("./common/tokenhelper/JwtHelper");
const authorizer_1 = require("./authorizer/authorizer");
exports.logger = new LambdaLogger_1.LambdaLogger();
const irohTokenRequest = async (event) => {
    try {
        const globalSecretsService = new AwsSecretsService_1.GlobalAwsSecretsService();
        await globalSecretsService.init();
        let accessToken;
        const irohClient = new IrohClient_1.IrohExternalClient(globalSecretsService);
        const token = lodash_1.default.get(event.headers, 'Authorization');
        if (token) {
            const decodedToken = (0, jsonwebtoken_1.decode)(token, { complete: true });
            const tokenPayload = lodash_1.default.get(decodedToken, 'payload', '');
            const keyClient = IdpKeyClientFactory_1.IdpKeyClientFactory.getKeyClient((0, JwtHelper_1.getIssuer)(tokenPayload));
            await (0, authorizer_1.validateToken)(keyClient, token, decodedToken);
            accessToken = await irohClient.refreshAccessToken(token);
        }
        else {
            const { code } = query_string_1.default.parse(event.body);
            if ((0, CommonTypes_1.empty)(code)) {
                throw new Error('authorization code is empty');
            }
            accessToken = await irohClient.getAccessToken(code);
        }
        return (0, Util_1.lambdaProxyResponse)('POST', JSON.stringify({ access_token: accessToken }));
    }
    catch (err) {
        return (0, Util_1.lambdaProxyResponse)('POST', `Request failed with error ${err.message}`, 500);
    }
};
exports.irohTokenRequest = irohTokenRequest;
const initialProducersSync = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for handleExistingProducersModuleId');
    }
    const { diModuleTypes, diModuleInstances } = await SourceUtils_1.SourceUtils.extractIrohModuleTypesInformation(tenantUid);
    if (!diModuleTypes || lodash_1.default.isEmpty(diModuleTypes)) {
        exports.logger.debug(`There are no Iroh module types with ${IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS} class`);
        return Promise.reject(new Error(`There are no Iroh module types with ${IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS} class`));
    }
    if (!diModuleInstances || lodash_1.default.isEmpty(diModuleInstances)) {
        exports.logger.debug('There are no Iroh module type instances defined');
        return Promise.reject(new Error('There are no Iroh module type instances defined'));
    }
    const tenantServices = new TenantServices_1.TenantServices();
    const producerConfigs = await tenantServices.getProducerConfigurations(tenantUid);
    const matchingResult = { updated: [], failedToUpdate: [] };
    for (const producer of producerConfigs) {
        const moduleInstance = SourceUtils_1.SourceUtils.getMatchingModuleInstances(producer, diModuleInstances, diModuleTypes);
        if (!moduleInstance) {
            exports.logger.info(`Failed to find matching IROH module instance for producer: ${JSON.stringify(producer)}`);
            matchingResult.failedToUpdate.push(producer);
            continue;
        }
        const moduleType = lodash_1.default.find(diModuleTypes, { id: moduleInstance.module_type_id });
        if (!moduleType) {
            throw new Error(`Failed to find module type for ${JSON.stringify(moduleInstance)}`);
        }
        const baseURL = SourceUtils_1.SourceUtils.extractModuleInstanceBaseUrl(producer.producerType, moduleInstance, moduleType);
        const cfgKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
        const cfgValue = JSON.stringify(lodash_1.default.merge({
            baseURL,
            sourceId: producer.producerId,
            source: producer.producerType,
            schedule: producer.cronSchedule
        }, (0, Util_1.toObject)(producer.properties)));
        exports.logger.info(`Updating ${cfgKey} producer on tenant ${tenantUid}, value: ${cfgValue}`);
        const updatedProducer = await tenantServices.updateProducerConfiguration(tenantUid, cfgKey, undefined, undefined, cfgValue, moduleInstance.id);
        matchingResult.updated.push(updatedProducer);
    }
    return Promise.resolve(matchingResult);
};
exports.initialProducersSync = initialProducersSync;
