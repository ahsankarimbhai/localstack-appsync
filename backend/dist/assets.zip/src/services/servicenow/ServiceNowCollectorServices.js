"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceNowCollectorServices = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const ServiceNowCollection_1 = require("./ServiceNowCollection");
const query_string_1 = __importDefault(require("query-string"));
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
class ServiceNowCollectorServices extends Services_1.BaseCollectorService {
    constructor(baseUrl, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.functionName = functionName;
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.SERVICENOW, this.sourceId);
        }
    }
    async getDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const params = {
            sysparm_query: 'ORDERBYsys_created_on',
            sysparm_limit: limit || ServiceNowCollectorServices.LIMIT
        };
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.SERVICENOW));
        return new ServiceNowCollection_1.ServiceNowCollection(this.client, nextUri || `api/now/table/cmdb_ci_service?${query_string_1.default.stringify(params)}`, timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.ServiceNowCollectorServices = ServiceNowCollectorServices;
ServiceNowCollectorServices.LIMIT = 100;
