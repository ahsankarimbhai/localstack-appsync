"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorize = void 0;
const jsonwebtoken_1 = require("jsonwebtoken");
const AwsSecretsService_1 = require("../common/AwsSecretsService");
const _ = __importStar(require("lodash"));
const Util_1 = require("../common/Util");
const CommonTypes_1 = require("../common/CommonTypes");
const authorize = async (event) => {
    const token = event.body;
    const decoded = (0, jsonwebtoken_1.decode)(token, { complete: true });
    const tenantAndSourceUid = decoded.header.kid;
    const tenantData = _.split(tenantAndSourceUid, Util_1.SOURCE_SEPARATOR);
    if (!tenantData[0]) {
        return {
            statusCode: 403,
            body: 'missing tenant uid'
        };
    }
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantData[0]);
    try {
        await awsSecretsService.init();
    }
    catch (e) {
        return {
            statusCode: 403,
            body: 'invalid tenant uid'
        };
    }
    const sourceId = tenantData[1];
    const publicKey = awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.DUO, sourceId)).duoWebhookSecret;
    const verificationOptions = {
        algorithms: ['HS512']
    };
    try {
        const jwt = (0, jsonwebtoken_1.verify)(token, publicKey, verificationOptions);
        return {
            jwt,
            tenantUid: tenantData[0],
            source: tenantData[1]
        };
    }
    catch (e) {
        return {
            statusCode: 400,
            body: 'invalid signature'
        };
    }
};
exports.authorize = authorize;
