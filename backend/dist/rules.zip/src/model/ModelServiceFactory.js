"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getModelService = void 0;
const CommonTypes_1 = require("../common/CommonTypes");
const AmpComputerModel_1 = require("./AmpComputerModel");
const MerakiDeviceModel_1 = require("./MerakiDeviceModel");
const JamfComputerModel_1 = require("./JamfComputerModel");
const InTuneDeviceModel_1 = require("./InTuneDeviceModel");
const DuoEndpointModel_1 = require("./DuoEndpointModel");
const DuoUserModel_1 = require("./DuoUserModel");
const OrbitalEndpointModel_1 = require("./OrbitalEndpointModel");
const CustomEndpointModel_1 = require("./CustomEndpointModel");
const AirWatchDeviceModel_1 = require("./AirWatchDeviceModel");
const SharedTypesModel_1 = require("./SharedTypesModel");
const UmbrellaRoamingComputerModel_1 = require("./UmbrellaRoamingComputerModel");
const MobileIronDeviceModel_1 = require("./MobileIronDeviceModel");
const UnifiedConnectorDeviceModel_1 = require("./UnifiedConnectorDeviceModel");
const ServiceNowDeviceModel_1 = require("./ServiceNowDeviceModel");
const SentinelOneDeviceModel_1 = require("./SentinelOneDeviceModel");
const CyberVisionDeviceModel_1 = require("./CyberVisionDeviceModel");
const CrowdStrikeDeviceModel_1 = require("./CrowdStrikeDeviceModel");
const DefenderDeviceModel_1 = require("./DefenderDeviceModel");
const AzureUserModel_1 = require("./AzureUserModel");
const TrendVisionOneDeviceModel_1 = require("./TrendVisionOneDeviceModel");
const GenericSourceDeviceModel_1 = require("./GenericSourceDeviceModel");
const getModelService = (producerVertex, partitionKey) => {
    switch (producerVertex) {
        case CommonTypes_1.VertexType.AMP_COMPUTER:
            return new AmpComputerModel_1.AmpComputerModelService(partitionKey);
        case CommonTypes_1.VertexType.AMP_COMPUTER_STATE:
            return new AmpComputerModel_1.AmpComputerStateModelService(partitionKey);
        case CommonTypes_1.VertexType.MERAKI_SM_DEVICE:
            return new MerakiDeviceModel_1.MerakiDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.MERAKI_SM_DEVICE_STATE:
            return new MerakiDeviceModel_1.MerakiDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.JAMF_COMPUTER:
            return new JamfComputerModel_1.JamfComputerModelService(partitionKey);
        case CommonTypes_1.VertexType.JAMF_COMPUTER_STATE:
            return new JamfComputerModel_1.JamfComputerStateModelService(partitionKey);
        case CommonTypes_1.VertexType.UNIFIED_CONNECTOR_DEVICE:
            return new UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.UNIFIED_CONNECTOR_DEVICE_STATE:
            return new UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.UMBRELLA_ROAMING_COMPUTER:
            return new UmbrellaRoamingComputerModel_1.UmbrellaRoamingComputerModelService(partitionKey);
        case CommonTypes_1.VertexType.UMBRELLA_ROAMING_COMPUTER_STATE:
            return new UmbrellaRoamingComputerModel_1.UmbrellaRoamingComputerStateModelService(partitionKey);
        case CommonTypes_1.VertexType.MOBILE_IRON_DEVICE:
            return new MobileIronDeviceModel_1.MobileIronDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.MOBILE_IRON_DEVICE_STATE:
            return new MobileIronDeviceModel_1.MobileIronDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.AIR_WATCH_DEVICE:
            return new AirWatchDeviceModel_1.AirWatchDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.AIR_WATCH_DEVICE_STATE:
            return new AirWatchDeviceModel_1.AirWatchDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.IN_TUNE_DEVICE:
            return new InTuneDeviceModel_1.InTuneDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.IN_TUNE_DEVICE_STATE:
            return new InTuneDeviceModel_1.InTuneDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.CROWD_STRIKE_DEVICE:
            return new CrowdStrikeDeviceModel_1.CrowdStrikeDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.CROWD_STRIKE_DEVICE_STATE:
            return new CrowdStrikeDeviceModel_1.CrowdStrikeDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.CYBER_VISION_DEVICE:
            return new CyberVisionDeviceModel_1.CyberVisionDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.CYBER_VISION_DEVICE_STATE:
            return new CyberVisionDeviceModel_1.CyberVisionDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.DEFENDER_DEVICE:
            return new DefenderDeviceModel_1.DefenderDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.DEFENDER_DEVICE_STATE:
            return new DefenderDeviceModel_1.DefenderDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.DUO_ENDPOINT:
            return new DuoEndpointModel_1.DuoEndpointModelService(partitionKey);
        case CommonTypes_1.VertexType.DUO_ENDPOINT_STATE:
            return new DuoEndpointModel_1.DuoEndpointStateModelService(partitionKey);
        case CommonTypes_1.VertexType.DUO_USER:
            return new DuoUserModel_1.DuoUserModelService(partitionKey);
        case CommonTypes_1.VertexType.DUO_USER_STATE:
            return new DuoUserModel_1.DuoUserStateModelService(partitionKey);
        case CommonTypes_1.VertexType.ORBITAL_ENDPOINT:
            return new OrbitalEndpointModel_1.OrbitalEndpointModelService(partitionKey);
        case CommonTypes_1.VertexType.ORBITAL_ENDPOINT_STATE:
            return new OrbitalEndpointModel_1.OrbitalEndpointStateModelService(partitionKey);
        case CommonTypes_1.VertexType.SERVICE_NOW_DEVICE:
            return new ServiceNowDeviceModel_1.ServiceNowDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.SERVICE_NOW_DEVICE_STATE:
            return new ServiceNowDeviceModel_1.ServiceNowDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.SENTINEL_ONE_DEVICE:
            return new SentinelOneDeviceModel_1.SentinelOneDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.SENTINEL_ONE_DEVICE_STATE:
            return new SentinelOneDeviceModel_1.SentinelOneDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.AZURE_USER:
            return new AzureUserModel_1.AzureUserModelService(partitionKey);
        case CommonTypes_1.VertexType.AZURE_USER_STATE:
            return new AzureUserModel_1.AzureUserStateModelService(partitionKey);
        case CommonTypes_1.VertexType.TREND_VISION_ONE_DEVICE:
            return new TrendVisionOneDeviceModel_1.TrendVisionOneDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.TREND_VISION_ONE_DEVICE_STATE:
            return new TrendVisionOneDeviceModel_1.TrendVisionOneDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.CUSTOM_ENDPOINT:
            return new CustomEndpointModel_1.CustomEndpointModelService(partitionKey);
        case CommonTypes_1.VertexType.CUSTOM_ENDPOINT_STATE:
            return new CustomEndpointModel_1.CustomEndpointStateModelService(partitionKey);
        case CommonTypes_1.VertexType.GENERIC_SOURCE_DEVICE:
            return new GenericSourceDeviceModel_1.GenericSourceDeviceModelService(partitionKey);
        case CommonTypes_1.VertexType.GENERIC_SOURCE_DEVICE_STATE:
            return new GenericSourceDeviceModel_1.GenericSourceDeviceStateModelService(partitionKey);
        case CommonTypes_1.VertexType.MAC_ADDRESS:
            return new SharedTypesModel_1.MacAddressService(partitionKey);
        case CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS:
            return new SharedTypesModel_1.ExternalIpAddressService(partitionKey);
        case CommonTypes_1.VertexType.SERIAL_NUMBER:
            return new SharedTypesModel_1.SerialNumberService(partitionKey);
        case CommonTypes_1.VertexType.IMEI:
            return new SharedTypesModel_1.ImeiService(partitionKey);
        case CommonTypes_1.VertexType.PHONE_NUMBER:
            return new SharedTypesModel_1.PhoneNumberService(partitionKey);
        case CommonTypes_1.VertexType.HARDWARE_ID:
            return new SharedTypesModel_1.HardwareIdService(partitionKey);
        case CommonTypes_1.VertexType.COMPUTER_SID:
            return new SharedTypesModel_1.ComputerSIDService(partitionKey);
        case CommonTypes_1.VertexType.USER:
            return new SharedTypesModel_1.UserService(partitionKey);
        case CommonTypes_1.VertexType.APP_USER:
            return new SharedTypesModel_1.AppUserService(partitionKey);
        case CommonTypes_1.VertexType.EMAIL:
            return new SharedTypesModel_1.EmailService(partitionKey);
        case CommonTypes_1.VertexType.BROWSER:
            return new SharedTypesModel_1.BrowserService(partitionKey);
        case CommonTypes_1.VertexType.EXTERNAL_REFERENCE:
            return new SharedTypesModel_1.ExternalReferenceService(partitionKey);
        case CommonTypes_1.VertexType.COOKIE:
            return new SharedTypesModel_1.CookieService(partitionKey);
        case CommonTypes_1.VertexType.HOSTNAME:
            return new SharedTypesModel_1.HostnameService(partitionKey);
        default:
            throw new Error(`Unsupported model type: ${producerVertex}`);
    }
};
exports.getModelService = getModelService;
