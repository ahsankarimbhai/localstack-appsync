"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UmbrellaCollectorServices = void 0;
const _ = __importStar(require("lodash"));
const UmbrellaRoamingComputersCollection_1 = require("./UmbrellaRoamingComputersCollection");
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const Util_1 = require("../../common/Util");
const FunctionStateServices_1 = require("../../common/FunctionStateServices");
const UmbrellaPolicyCollection_1 = require("./UmbrellaPolicyCollection");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
class UmbrellaCollectorServices extends Services_1.BaseCollectorService {
    constructor(secrets, organizationId, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.organizationId = organizationId;
        this.functionName = functionName;
    }
    async init(isV2Support) {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.UMBRELLA, this.sourceId, isV2Support);
        }
    }
    async getPolicies(timeBasedAsyncLambdaInvoker, nextUri, umbrellaV2Support) {
        const isV2Support = !!umbrellaV2Support;
        await this.init(isV2Support);
        if (!this.client.getNetworkApiAxios()) {
            return undefined;
        }
        const url = isV2Support ? '/deployments/v2/policies' : `/v1/organizations/${this.organizationId}/policies`;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.UMBRELLA));
        return new UmbrellaPolicyCollection_1.UmbrellaPolicyCollection(this.client.getNetworkApiAxios(), nextUri || url, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getRoamingComputers(timeBasedAsyncLambdaInvoker, nextUri, limit, umbrellaV2Support) {
        const isV2Support = !!umbrellaV2Support;
        await this.init(isV2Support);
        let url;
        if (isV2Support) {
            url = '/deployments/v2/roamingcomputers';
        }
        else {
            url = `/v1/organizations/${this.organizationId}/roamingcomputers`;
        }
        const bulkLength = limit || UmbrellaCollectorServices.LIMIT;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.UMBRELLA));
        nextUri = nextUri || _.get((0, Util_1.parseJSONString)(functionState.getState()), FunctionStateServices_1.FunctionState.URI_ON_FAILURE);
        const lastSuccessfulFetch = new Date(functionState.lastSuccessfulSequence).toISOString();
        return new UmbrellaRoamingComputersCollection_1.UmbrellaRoamingComputersCollection(this.client, nextUri || url.concat(`?lastSyncAfter=${lastSuccessfulFetch}&limit=${bulkLength}&page=1`), timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.UmbrellaCollectorServices = UmbrellaCollectorServices;
UmbrellaCollectorServices.LIMIT = 200;
