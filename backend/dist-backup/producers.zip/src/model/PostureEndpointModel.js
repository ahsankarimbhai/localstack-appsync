"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostureEndpointModelService = exports.PostureEndpointModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
class PostureEndpointModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.POSTURE_ENDPOINT;
    }
    getKeyProperties() {
        return [PostureEndpointModel.DIFFERENTIATOR_PROPERTY];
    }
    async initProperties(input, source, sourceConfiguration) {
        this.setProperty(PostureEndpointModel.DIFFERENTIATOR_PROPERTY, input.firstConnection);
    }
}
exports.PostureEndpointModel = PostureEndpointModel;
PostureEndpointModel.DIFFERENTIATOR_PROPERTY = 'firstConnection';
class PostureEndpointModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new PostureEndpointModel(this.partitionKey);
    }
}
exports.PostureEndpointModelService = PostureEndpointModelService;
