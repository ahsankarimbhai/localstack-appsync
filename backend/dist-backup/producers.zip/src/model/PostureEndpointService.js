"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostureEndpointService = exports.sourceToFieldsMapping = void 0;
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../common/CommonTypes");
const gremlin_1 = require("gremlin");
const PostureEntityService_1 = require("./PostureEntityService");
const PostureEndpointModel_1 = require("./PostureEndpointModel");
const AmpComputerModel_1 = require("./AmpComputerModel");
const MerakiDeviceModel_1 = require("./MerakiDeviceModel");
const JamfComputerModel_1 = require("./JamfComputerModel");
const DuoEndpointModel_1 = require("./DuoEndpointModel");
const InTuneDeviceModel_1 = require("./InTuneDeviceModel");
const OrbitalEndpointModel_1 = require("./OrbitalEndpointModel");
const Util_1 = require("../common/Util");
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const ElasticsearchServices_1 = require("../common/ElasticsearchServices");
const SharedTypesModel_1 = require("./SharedTypesModel");
const OsVersionsServices_1 = require("../common/OsVersionsServices");
const ElasticsearchFactory_1 = require("../common/ElasticsearchFactory");
const ModelServiceFactory_1 = require("./ModelServiceFactory");
const AirWatchDeviceModel_1 = require("./AirWatchDeviceModel");
const UnifiedConnectorDeviceModel_1 = require("./UnifiedConnectorDeviceModel");
const SentinelOneDeviceModel_1 = require("./SentinelOneDeviceModel");
const LabelService_1 = require("../services/common/LabelService");
const UnifiedConnectorDeploymentServices_1 = require("../services/unifiedconnector/UnifiedConnectorDeploymentServices");
const UnifiedConnectorCollectorServices_1 = require("../services/unifiedconnector/UnifiedConnectorCollectorServices");
const CyberVisionDeviceModel_1 = require("./CyberVisionDeviceModel");
const NeptuneClientManager_1 = require("../common/neptune/NeptuneClientManager");
const CrowdStrikeDeviceModel_1 = require("./CrowdStrikeDeviceModel");
const WebhookHelper_1 = require("../services/common/data-sharing/WebhookHelper");
const GenericSourceUtils_1 = require("../common/generic/GenericSourceUtils");
const TenantServices_1 = require("../common/TenantServices");
const __ = gremlin_1.process.statics;
const t = gremlin_1.process.t;
const P = gremlin_1.process.P;
const withOptions = gremlin_1.process.withOptions;
const sourceToFieldsMapping = () => {
    const propertyNames = [...Object.values(CommonTypes_1.VertexBasicProperty)];
    propertyNames.push(...Object.values(CommonTypes_1.BasicProperty));
    propertyNames.push(AmpComputerModel_1.AmpComputerStateModel.IS_COMPROMISED_KEY);
    propertyNames.push(MerakiDeviceModel_1.MerakiDeviceStateModel.AUTO_TAGS_KEY);
    return propertyNames;
};
exports.sourceToFieldsMapping = sourceToFieldsMapping;
class PostureEndpointService extends PostureEntityService_1.PostureEntityService {
    constructor(tenantUid) {
        super(tenantUid);
        this.tenantUid = tenantUid;
    }
    getComplexType() {
        return this.getLabel();
    }
    getEdgeType() {
        return CommonTypes_1.EdgeType.POSTURE_ENDPOINT;
    }
    getLabel() {
        return CommonTypes_1.VertexType.POSTURE_ENDPOINT;
    }
    getPostureModelService(tenantUid) {
        return new PostureEndpointModel_1.PostureEndpointModelService(tenantUid);
    }
    getIdentifierVertexTypes() {
        return (0, CommonTypes_1.identifierVertexTypes)();
    }
    getIdentifierEdgeTypes() {
        return (0, CommonTypes_1.identifierEdgeTypes)();
    }
    async deleteEntityFromES(currentPE) {
        await this.esServices.deleteDeviceInformation(currentPE);
    }
    async countPostureEndpoints(filter, labelsMap) {
        const countPostureEndpointsResult = await this.esServices.countPostureEndpoints(filter);
        countPostureEndpointsResult.labels = _.filter(countPostureEndpointsResult.labels, labelCount => labelsMap.has(labelCount.value));
        return countPostureEndpointsResult;
    }
    async listPostureEndpoints(filter, excludeFields) {
        return this.esServices.listPostureEndpoints(filter, excludeFields);
    }
    async exportPostureEndpointsScroll(filter, scrollId) {
        return this.esServices.pagedSearchScroll(filter, scrollId, '3m');
    }
    async getUserEndpoints(type, value) {
        const neptuneSvc = this.getNeptuneServices();
        const queryResult = await neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g)
            .hasLabel(type)
            .has(CommonTypes_1.VertexBasicProperty.EXT_ID, value).as('user')
            .in_(CommonTypes_1.EdgeType.USED_BY).not(__.inE(CommonTypes_1.EdgeType.HAS_STATE).has(CommonTypes_1.EdgeBasicProperty.UNTIL)).as('ps')
            .in_(CommonTypes_1.EdgeType.HAS_STATE).as('pv')
            .in_(CommonTypes_1.EdgeType.POSTURE_ENDPOINT).as('pe')
            .select('pe', 'pv', 'ps')
            .by(t.id)
            .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
            .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        return this.mergeToEndpoints(queryResult, []);
    }
    async getPostureEndpointMergingLogic(uid) {
        const results = await this.queryMergingLogic(uid);
        const resultSet = new gremlin_1.driver.ResultSet(results);
        const resultsAggregator = {};
        for (const result of resultSet.toArray()) {
            const pvUid = result.get('pv');
            const pvUidParts = _.split(pvUid, Util_1.SOURCE_SEPARATOR);
            const iv = result.get('iv');
            const ivUid = (0, CommonTypes_1.val)(iv.get(t.id));
            const ivMergingLogic = resultsAggregator[ivUid] || {
                unreliable: (0, CommonTypes_1.val)(iv.get(PostureEndpointService.UNRELIABLE)) || false,
                ivType: (0, Util_1.parseSimpleLabel)(iv.get(t.label)),
                value: (0, CommonTypes_1.val)(iv.get(CommonTypes_1.VertexBasicProperty.EXT_ID)),
                producers: []
            };
            resultsAggregator[ivUid] = ivMergingLogic;
            const idProperties = JSON.stringify((0, ModelServiceFactory_1.getModelService)(pvUidParts[pvUidParts.length - 4], this.tenantUid).getInputKeyProperties());
            ivMergingLogic.producers.push({
                uid: pvUid,
                type: pvUidParts[pvUidParts.length - 3],
                producerId: pvUidParts[pvUidParts.length - 2],
                properties: [{ key: 'idProperties', value: idProperties }]
            });
        }
        const identifiersWithMoreThanOnePV = _.filter(_.values(resultsAggregator), (ivMergingLogic) => ivMergingLogic.producers.length > 1);
        const identifiersSortedByIvPriority = _.sortBy(identifiersWithMoreThanOnePV, (ivMergingLogic) => (0, CommonTypes_1.identifierVertexTypes)().indexOf(ivMergingLogic.ivType));
        return { identifiers: identifiersSortedByIvPriority };
    }
    queryMergingLogic(uid) {
        const neptuneSvc = this.getNeptuneServices();
        return neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, uid)
            .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT).as('pv')
            .outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).inV()
            .out()
            .hasLabel(...(0, CommonTypes_1.identifierVertexTypes)()).as('iv')
            .select('pv', 'iv')
            .by(t.id)
            .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    async getPostureEndpoint(uid) {
        const neptuneSvc = this.getNeptuneServices();
        const results = await Promise.all([
            neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, uid).as('pe')
                .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT).as('pv')
                .outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).as('edge_pv_ps')
                .inV().as('ps')
                .select('pe', 'pv', 'ps', 'edge_pv_ps')
                .by(t.id)
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
                .toList(), NeptuneClientManager_1.NeptuneClientType.Reader),
            neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, uid).as('pe')
                .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT).as('pv')
                .outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).inV().as('ps')
                .out().dedup().as('cv')
                .select('pe', 'pv', 'cv')
                .by(t.id)
                .by(t.id)
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
                .toList(), NeptuneClientManager_1.NeptuneClientType.Reader)
        ]);
        return _.first(await this.mergeToEndpoints(results[0], results[1]));
    }
    async mergeToEndpoints(pvResults, cvResults) {
        const mergedEndpoints = {};
        const pvResultSet = new gremlin_1.driver.ResultSet(pvResults);
        for (const result of pvResultSet.toArray()) {
            const peUid = result.get('pe');
            const pe = mergedEndpoints[peUid] || { uid: peUid, propertyTimestamp: {} };
            const pv = result.get('pv');
            const ps = result.get('ps');
            const edgePvPs = result.get('edge_pv_ps');
            await this.addProducerProperties(pe, pv, ps, edgePvPs);
            mergedEndpoints[peUid] = pe;
        }
        const cvResultSet = new gremlin_1.driver.ResultSet(cvResults);
        for (const result of cvResultSet.toArray()) {
            const peUid = result.get('pe');
            const pvUid = result.get('pv');
            const pe = mergedEndpoints[peUid] || { uid: peUid, propertyTimestamp: {} };
            const cv = result.get('cv');
            this.addConnectorProperties(pe, cv, pvUid);
            mergedEndpoints[peUid] = pe;
        }
        return _.map(_.values(mergedEndpoints), mergedEndpoint => {
            mergedEndpoint.endpointType = this.extractEndpointType(mergedEndpoint);
            return mergedEndpoint;
        });
    }
    extractEndpointType(mergedEndpoint) {
        if (_.toLower(mergedEndpoint.systemModel).includes('vmware') || _.toLower(mergedEndpoint.serialNumber).includes('vmware') || _.toLower(mergedEndpoint.osVersion).includes('virtual')) {
            return CommonTypes_1.EndpointType.VIRTUAL;
        }
        switch (mergedEndpoint.osType) {
            case CommonTypes_1.OS.ANDROID:
            case CommonTypes_1.OS.IOS:
                return CommonTypes_1.EndpointType.MOBILE;
            case CommonTypes_1.OS.CENTOS:
            case CommonTypes_1.OS.RHEL:
                return CommonTypes_1.EndpointType.SERVER;
            case CommonTypes_1.OS.MAC_OS:
                return CommonTypes_1.EndpointType.DESKTOP;
            case CommonTypes_1.OS.WINDOWS:
                return _.toLower(mergedEndpoint.osVersion).includes('server') ? CommonTypes_1.EndpointType.SERVER : CommonTypes_1.EndpointType.DESKTOP;
            default:
                return undefined;
        }
    }
    async addProducerProperties(pe, pv, ps, edgePvPs) {
        var _a;
        await this.initProducerConfiguration();
        const label = (0, Util_1.parseSimpleLabel)(pv.get(t.label));
        const { source, sourceId } = this.parseSourceTypeAndId(pv.get(t.label));
        const isGenericFeatureFlagEnabled = await new TenantServices_1.TenantServices().isTenantFeatureOn(this.tenantUid, TenantServices_1.FeatureFlag.GENERIC_SOURCE);
        if (isGenericFeatureFlagEnabled && source) {
            this.sourceConfiguration = GenericSourceUtils_1.GenericSourceUtils.getSourceConfiguration(source);
        }
        const pvUid = pv.get(t.id);
        pe.producers = pe.producers || [];
        if (_.isEmpty(_.filter(this.producerConfigurations, { producerId: sourceId }))) {
            return;
        }
        const psProperties = this.toKeyValueList(ps);
        if (!_.find(pe.producers, { uid: pvUid, producerId: sourceId })) {
            pe.producers.push({
                uid: pvUid,
                producerId: sourceId,
                type: source,
                properties: psProperties,
                lastUpdated: (_a = _.find(psProperties, { key: CommonTypes_1.VertexBasicProperty.LAST_UPDATED })) === null || _a === void 0 ? void 0 : _a.value,
                since: (0, Util_1.epochToISOString)((0, CommonTypes_1.val)(edgePvPs === null || edgePvPs === void 0 ? void 0 : edgePvPs.get(CommonTypes_1.EdgeBasicProperty.SINCE))),
                until: (0, Util_1.epochToISOString)((0, CommonTypes_1.val)(edgePvPs === null || edgePvPs === void 0 ? void 0 : edgePvPs.get(CommonTypes_1.EdgeBasicProperty.UNTIL)))
            });
        }
        if (!this.osVersions) {
            this.osVersions = await new OsVersionsServices_1.OsVersionsServices().getOsVersions();
        }
        (0, CommonTypes_1.setOsProperties)(pe, ps, this.osVersions);
        pe.lastUpdated = _.toString(_.max([_.toNumber(pe.lastUpdated), (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.LAST_UPDATED))]));
        const internalIpAddresses = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexStateProperty.STATE_INTERNAL_IP_ADDRESSES));
        if (internalIpAddresses) {
            pe.internalIpAddresses = _.union(pe.internalIpAddresses, JSON.parse(internalIpAddresses)).filter(ip => ip);
            this.addProducerPropertyKvp('internalIpAddresses', internalIpAddresses, pe, pvUid);
        }
        if (isGenericFeatureFlagEnabled && this.sourceConfiguration) {
            await this.addGenericProducerProperties(pe, pv, ps);
        }
        else {
            switch (label) {
                case CommonTypes_1.VertexType.AMP_COMPUTER: {
                    pe.isCompromised = (0, CommonTypes_1.val)(ps.get(AmpComputerModel_1.AmpComputerStateModel.IS_COMPROMISED_KEY));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    const ampAvDefinitions = (0, CommonTypes_1.val)(ps.get(AmpComputerModel_1.AmpComputerStateModel.AV_UPDATE_DEFINITIONS));
                    if (ampAvDefinitions) {
                        const parsedAmpAvDefinitions = JSON.parse(ampAvDefinitions);
                        pe.avDefinitionsOutOfDate = pe.avDefinitionsOutOfDate || parsedAmpAvDefinitions.status === 'Definitions Outdated';
                    }
                    pe.ampConnectorGUID = (0, CommonTypes_1.val)(pv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                    break;
                }
                case CommonTypes_1.VertexType.MERAKI_SM_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, 'systemModel', () => pe.systemModel = (0, CommonTypes_1.val)(ps.get(MerakiDeviceModel_1.MerakiDeviceStateModel.SYSTEM_MODEL_KEY)));
                    pe.isSupervised = (0, CommonTypes_1.val)(ps.get(MerakiDeviceModel_1.MerakiDeviceStateModel.IS_SUPERVISED_KEY));
                    pe.androidSecurityPatchLevel = (0, CommonTypes_1.val)(ps.get(MerakiDeviceModel_1.MerakiDeviceStateModel.ANDROID_SECURITY_PATCH_LEVEL_KEY));
                    pe.isManaged = pe.isManaged || (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_MANAGED));
                    try {
                        const newTagsAsStrings = JSON.parse((0, CommonTypes_1.val)(ps.get(MerakiDeviceModel_1.MerakiDeviceStateModel.TAGS_KEY)) || '[]');
                        const newTags = _.map(newTagsAsStrings, (tag) => ({ name: tag, sources: [{ type: CommonTypes_1.Source.MERAKI, producerId: sourceId }] }));
                        pe.tags = this.mergeTags(pe.tags || [], newTags);
                    }
                    catch (error) {
                        this.logger.error(`Error occurred in addProducerProperties while parsing Meraki tags: ${error}`);
                    }
                    const autoTagsProp = (0, CommonTypes_1.val)(ps.get(MerakiDeviceModel_1.MerakiDeviceStateModel.AUTO_TAGS_KEY));
                    if (autoTagsProp) {
                        const autoTags = JSON.parse(autoTagsProp);
                        const compliantTags = _.filter(autoTags, tag => _.startsWith(tag, 'auto:security_policy_compliant'));
                        const violatingTags = _.filter(autoTags, tag => _.startsWith(tag, 'auto:security_policy_violating'));
                        if (violatingTags.length > 0) {
                            pe.isCompliant = false;
                        }
                        else if (compliantTags.length > 0) {
                            pe.isCompliant = true;
                        }
                    }
                    break;
                }
                case CommonTypes_1.VertexType.JAMF_COMPUTER: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, 'systemModel', () => pe.systemModel = (0, CommonTypes_1.val)(ps.get(JamfComputerModel_1.JamfComputerStateModel.MODEL_IDENTIFIER_KEY)));
                    pe.isManaged = pe.isManaged || (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_MANAGED));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    break;
                }
                case CommonTypes_1.VertexType.IN_TUNE_DEVICE: {
                    pe.isEncrypted = (0, CommonTypes_1.val)(ps.get(InTuneDeviceModel_1.InTuneDeviceStateModel.IS_ENCRYPTED_KEY));
                    pe.jailBroken = (0, CommonTypes_1.val)(ps.get(InTuneDeviceModel_1.InTuneDeviceStateModel.JAIL_BROKEN_KEY));
                    pe.isSupervised = (0, CommonTypes_1.val)(ps.get(InTuneDeviceModel_1.InTuneDeviceStateModel.IS_SUPERVISED_KEY));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, 'systemModel', () => pe.systemModel = (0, CommonTypes_1.val)(ps.get(InTuneDeviceModel_1.InTuneDeviceStateModel.MODEL_KEY)));
                    pe.androidSecurityPatchLevel = (0, CommonTypes_1.val)(ps.get(InTuneDeviceModel_1.InTuneDeviceStateModel.ANDROID_SECURITY_PATCH_LEVEL_KEY));
                    pe.isManaged = pe.isManaged || (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_MANAGED));
                    pe.isCompliant = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    break;
                }
                case CommonTypes_1.VertexType.CYBER_VISION_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    const macAddresses = (0, CommonTypes_1.val)(ps.get(CyberVisionDeviceModel_1.CyberVisionDeviceStateModel.MACS));
                    if (macAddresses) {
                        pe.macAddresses = JSON.parse(macAddresses);
                    }
                    const modelNames = (0, CommonTypes_1.val)(ps.get(CyberVisionDeviceModel_1.CyberVisionDeviceStateModel.MODEL_NAMES));
                    if (modelNames) {
                        (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, 'systemModel', () => pe.systemModel = JSON.parse(modelNames).join(','));
                    }
                    break;
                }
                case CommonTypes_1.VertexType.DEFENDER_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    break;
                }
                case CommonTypes_1.VertexType.DUO_ENDPOINT: {
                    pe.tampered = (0, CommonTypes_1.val)(ps.get(DuoEndpointModel_1.DuoEndpointStateModel.TAMPERED_KEY));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, 'systemModel', () => pe.systemModel = (0, CommonTypes_1.val)(ps.get(DuoEndpointModel_1.DuoEndpointStateModel.MODEL_KEY)));
                    if (ps.has(CommonTypes_1.VertexBasicProperty.NAME)) {
                        (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    }
                    break;
                }
                case CommonTypes_1.VertexType.ORBITAL_ENDPOINT: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    const orbitalAvDefinitions = (0, CommonTypes_1.val)(ps.get(OrbitalEndpointModel_1.OrbitalQueries.WIN_SECURITY_PRODUCTS));
                    if (orbitalAvDefinitions) {
                        const parsedOrbitalAvDefinitions = JSON.parse(orbitalAvDefinitions);
                        pe.avDefinitionsOutOfDate = pe.avDefinitionsOutOfDate || !!_.find(parsedOrbitalAvDefinitions, {
                            type: 'Antivirus',
                            signatures_up_to_date: 0
                        });
                    }
                    pe.orbitalNodeId = (0, CommonTypes_1.val)(ps.get(OrbitalEndpointModel_1.OrbitalEndpointStateModel.NODE_ID));
                    break;
                }
                case CommonTypes_1.VertexType.CUSTOM_ENDPOINT: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    break;
                }
                case CommonTypes_1.VertexType.AIR_WATCH_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    pe.isManaged = pe.isManaged || (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_MANAGED));
                    pe.isSupervised = (0, CommonTypes_1.val)(ps.get(AirWatchDeviceModel_1.AirWatchDeviceStateModel.IS_SUPERVISED_KEY));
                    pe.isCompromised = (0, CommonTypes_1.val)(ps.get(AirWatchDeviceModel_1.AirWatchDeviceStateModel.IS_COMPROMISED_KEY));
                    pe.isCompliant = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT));
                    break;
                }
                case CommonTypes_1.VertexType.CROWD_STRIKE_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    try {
                        const newTagsAsStrings = JSON.parse((0, CommonTypes_1.val)(ps.get(CrowdStrikeDeviceModel_1.CrowdStrikeDeviceStateModel.TAGS)) || '[]');
                        const newTags = _.map(newTagsAsStrings, (tag) => ({ name: tag, sources: [{ type: CommonTypes_1.Source.CROWDSTRIKE, producerId: sourceId }] }));
                        pe.tags = this.mergeTags(pe.tags || [], newTags);
                    }
                    catch (error) {
                        this.logger.error(`Error occurred in addProducerProperties while parsing CrowdStrike tags: ${error}`);
                    }
                    break;
                }
                case CommonTypes_1.VertexType.SERVICE_NOW_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    break;
                }
                case CommonTypes_1.VertexType.SENTINEL_ONE_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    pe.isManaged = pe.isManaged || (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_MANAGED));
                    pe.isCompromised = (0, CommonTypes_1.val)(ps.get(SentinelOneDeviceModel_1.SentinelOneDeviceStateModel.INFECTED)) || (0, CommonTypes_1.val)(ps.get(SentinelOneDeviceModel_1.SentinelOneDeviceStateModel.ACTIVE_THREATS)) > 0;
                    break;
                }
                case CommonTypes_1.VertexType.UMBRELLA_ROAMING_COMPUTER: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    break;
                }
                case CommonTypes_1.VertexType.UNIFIED_CONNECTOR_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_DEPLOYMENT, () => pe.deploymentId = (0, CommonTypes_1.val)(ps.get(UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_DEPLOYMENT)));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_WANTED_DEPLOYMENT, () => pe.wantedDeploymentId = (0, CommonTypes_1.val)(ps.get(UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_WANTED_DEPLOYMENT)));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_AC_UDID, () => pe.acUdId = (0, CommonTypes_1.val)(ps.get(UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_AC_UDID)));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_CSC_VERSION, () => pe.cscVersion = (0, CommonTypes_1.val)(ps.get(UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_CSC_VERSION)));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_SE_VERSION, () => pe.secureEndpointVersion = (0, CommonTypes_1.val)(ps.get(UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_SE_VERSION)));
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_CLOUD_MGMT_VER, () => pe.cloudMgmtVersion = (0, CommonTypes_1.val)(ps.get(UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_CLOUD_MGMT_VER)));
                    const softVal = (0, CommonTypes_1.val)(ps.get(UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_SOFTWARE));
                    const softArr = _.isEmpty(softVal) ? [] : JSON.parse(softVal);
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, UnifiedConnectorDeviceModel_1.UnifiedConnectorDeviceStateModel.PROP_SOFTWARE, () => pe.modules = softArr);
                    pe.ucId = (0, CommonTypes_1.val)(pv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                    break;
                }
                case CommonTypes_1.VertexType.MOBILE_IRON_DEVICE: {
                    pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME));
                    pe.isCompliant = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT));
                    pe.isManaged = pe.isManaged || (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.IS_MANAGED));
                    break;
                }
                case CommonTypes_1.VertexType.TREND_VISION_ONE_DEVICE: {
                    (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME)));
                    break;
                }
                default:
            }
        }
    }
    async addGenericProducerProperties(pe, pv, ps) {
        var _a, _b;
        if ((_b = (_a = this.sourceConfiguration) === null || _a === void 0 ? void 0 : _a.peMapping) === null || _b === void 0 ? void 0 : _b.fileName) {
            const fileName = (this.sourceConfiguration.peMapping.fileName.match(/(.ts$)|(.js$)/)) ? this.sourceConfiguration.peMapping.fileName.substring(0, this.sourceConfiguration.peMapping.fileName.length - 3) : this.sourceConfiguration.peMapping.fileName;
            const peMappingFile = await Promise.resolve().then(() => __importStar(require(`${GenericSourceUtils_1.GenericSourceUtils.configurationPath}/${fileName}`)));
            const className = this.sourceConfiguration.peMapping.className ? this.sourceConfiguration.peMapping.className : fileName;
            const peMappingClass = (peMappingFile) ? peMappingFile[className] : undefined;
            if (peMappingClass) {
                const peMappingInstance = new peMappingClass();
                peMappingInstance.handler(this.sourceConfiguration, pe, pv, ps);
            }
            else {
                this.logger.error(`Unable to import PE Mapping file "${this.sourceConfiguration.peMapping.fileName}" with className "${className}" for sourceName "${this.sourceConfiguration.sourceName}"`);
            }
        }
    }
    async getTenantTags() {
        return this.esServices.countDevicePropertyValues('tagNames.name', { tags: [] });
    }
    mergeTags(tags, newTags) {
        _.forEach(newTags, (newTag) => {
            const addedTag = _.filter(tags, (oldTag) => oldTag.name === newTag.name);
            if (addedTag.length > 0) {
                const addedTagSources = addedTag[0].sources;
                _.forEach(newTag.sources, (newSources) => {
                    const newSourcesExists = _.filter(addedTagSources, (oldSources) => oldSources.type === newSources.type && oldSources.producerId === newSources.producerId);
                    if (newSourcesExists.length === 0) {
                        addedTagSources.push({
                            type: newSources.type,
                            producerId: newSources.producerId
                        });
                    }
                });
            }
            else {
                tags.push({
                    name: newTag.name,
                    sources: [...newTag.sources]
                });
            }
        });
        return this.sortTags(tags);
    }
    sortTags(tags) {
        _.map(tags, (tag) => {
            tag.sources.sort((a, b) => {
                const sourceCompare = a.type.localeCompare(b.type);
                return (sourceCompare !== 0) ? sourceCompare : a.producerId.localeCompare(b.producerId);
            });
        });
        return tags.sort((a, b) => a.name.localeCompare(b.name));
    }
    addConnectorProperties(pe, cv, pvUid) {
        const label = (0, Util_1.parseSimpleLabel)(cv.get(t.label));
        switch (label) {
            case CommonTypes_1.VertexType.SERIAL_NUMBER: {
                pe.serialNumber = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                this.addProducerPropertyKvp('serialNumber', pe.serialNumber, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.HARDWARE_ID: {
                pe.hardwareId = _.toLower((0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID)));
                this.addProducerPropertyKvp('hardwareId', pe.hardwareId, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.COMPUTER_SID: {
                pe.computerSID = _.toLower((0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID)));
                this.addProducerPropertyKvp('computerSID', pe.computerSID, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.MAC_ADDRESS: {
                pe.macAddresses = pe.macAddresses || [];
                const macAddress = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.macAddresses, macAddress) < 0) {
                    pe.macAddresses.push(macAddress);
                }
                this.addValueToProducerProperties('macAddresses', macAddress, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS: {
                pe.externalIpAddresses = pe.externalIpAddresses || [];
                const externalIpAddress = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.externalIpAddresses, externalIpAddress) < 0) {
                    pe.externalIpAddresses.push(externalIpAddress);
                }
                this.addValueToProducerProperties('externalIpAddresses', externalIpAddress, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.INTERNAL_IP_ADDRESS: {
                pe.internalIpAddresses = pe.internalIpAddresses || [];
                const internalIpAddress = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.internalIpAddresses, internalIpAddress) < 0) {
                    pe.internalIpAddresses.push(internalIpAddress);
                }
                this.addValueToProducerProperties('internalIpAddresses', internalIpAddress, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.USER: {
                pe.users = pe.users || [];
                const user = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.users, user) < 0) {
                    pe.users.push(user);
                }
                this.addValueToProducerProperties('users', user, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.APP_USER: {
                pe.appUsers = pe.appUsers || [];
                const appUser = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.appUsers, appUser) < 0) {
                    pe.appUsers.push(appUser);
                }
                this.addValueToProducerProperties('appUsers', appUser, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.EMAIL: {
                pe.emails = pe.emails || [];
                const email = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.emails, email) < 0) {
                    pe.emails.push(email);
                }
                this.addValueToProducerProperties('emails', email, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.BROWSER: {
                this.addValueToProducerProperties('browsers', {
                    browser_family: (0, CommonTypes_1.val)(cv.get(SharedTypesModel_1.Browser.BROWSER_FAMILY)),
                    browser_version: (0, CommonTypes_1.val)(cv.get(SharedTypesModel_1.Browser.BROWSER_VERSION)),
                    flash_version: (0, CommonTypes_1.val)(cv.get(SharedTypesModel_1.Browser.FLASH_VERSION)),
                    java_version: (0, CommonTypes_1.val)(cv.get(SharedTypesModel_1.Browser.JAVA_VERSION))
                }, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.EXTERNAL_REFERENCE: {
                const externalReference = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                this.addProducerPropertyKvp('externalReference', externalReference, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.IMEI: {
                pe.imei = _.toLower((0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID)));
                this.addProducerPropertyKvp('imei', pe.imei, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.PHONE_NUMBER:
            case CommonTypes_1.VertexType.HOSTNAME:
                break;
            default: {
                this.logger.error(`unhandled connector type ${label}`);
            }
        }
    }
    async updateSearchableVertex(peUid, recalculateUnreliableIvs = false) {
        const mergedEndpoint = await this.getPostureEndpoint(peUid);
        const updateResults = await Promise.allSettled([
            this.esServices.updateMergedEndpoint(mergedEndpoint, peUid),
            this.recalculateUnreliableIdentifierVerticesIfNeeded(peUid, recalculateUnreliableIvs),
            this.incidentService.unresolvedMappingProcessing(mergedEndpoint)
        ]);
        const failedOperation = _.findLast(updateResults, res => res.status === 'rejected');
        if (failedOperation) {
            throw new Error(`failed to finish update updateSearchableVertex, reason: ${JSON.stringify(failedOperation)}`);
        }
    }
    async sendNotifications(peUid, isPEMerged = false) {
        const eventType = isPEMerged ? WebhookHelper_1.WebhookEventType.DEVICE_MERGE : WebhookHelper_1.WebhookEventType.DEVICE_UPDATE;
        try {
            await this.webhookNotificationService.sendDeviceEvent(this.tenantUid, eventType, [peUid]);
        }
        catch (err) {
            this.logger.error(`failed to send webhook notification event for type: ${eventType}, tenant: ${this.tenantUid}, peUid: ${peUid}, err: ${err.message}`);
        }
    }
    dashboardCounts() {
        return this.esServices.dashboardCounts();
    }
    async listPostureEndpointsHistoricalState(filter) {
        const pageNumber = filter.pageNumber || 0;
        const pageSize = filter.pageSize || PostureEndpointService.HISTORICAL_STATE_PAGE_SIZE;
        if (pageNumber < 0) {
            throw new Error(`pageNumber must not be negative: ${pageNumber}`);
        }
        if (pageSize <= 0) {
            throw new Error(`pageSize must be positive: ${pageSize}`);
        }
        if (pageSize > PostureEndpointService.MAX_PAGE_SIZE) {
            throw new Error(`pageSize ${pageSize} must not exceed ${PostureEndpointService.MAX_PAGE_SIZE}`);
        }
        if (filter.since === filter.until) {
            filter.until += 1000 * 60 * 10;
            this.logger.debug(`listPostureEndpointsHistoricalState filter.since === filter.until so increase filter.until by 10 minutes (from ${filter.since} to ${filter.until})`);
        }
        if (filter.since > filter.until) {
            throw new Error(`invalid time range ${filter.since} to ${filter.until}`);
        }
        if (!filter.peUid && _.isEmpty(filter.producers) && _.isEmpty(filter.searchTypes)) {
            throw new Error('Expects to receive at least 1 search type or producer');
        }
        const offset = pageNumber * pageSize;
        const filterStatesConditions = () => [
            __.has(CommonTypes_1.EdgeBasicProperty.SINCE, P.gt(filter.since)).has(CommonTypes_1.EdgeBasicProperty.SINCE, P.lt(filter.until)),
            __.has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.gt(filter.since)).has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.lt(filter.until)),
            __.has(CommonTypes_1.EdgeBasicProperty.SINCE, P.lt(filter.since)).has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.gt(filter.until)),
            __.has(CommonTypes_1.EdgeBasicProperty.SINCE, P.lt(filter.since)).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
        ];
        const psFilterQueries = [];
        const psSearchLabels = this.getPsSearchLabels(filter.searchTypes);
        if (psSearchLabels.length > 0) {
            psFilterQueries.push(__.has(t.label, gremlin_1.process.P.within(...psSearchLabels)));
        }
        const ivIds = _.map(filter.searchTypes, searchType => _.join([searchType.value, searchType.type, this.tenantUid], NeptuneServicesFactory_1.VERTEX_ID_SEPARATOR));
        if (ivIds.length > 0) {
            psFilterQueries.push(__.out().has(t.id, gremlin_1.process.P.within(...ivIds)));
        }
        const neptuneSvc = this.getNeptuneServices();
        const results = await neptuneSvc.executeTenantQuery(async (g) => {
            let query;
            if (filter.peUid) {
                query = neptuneSvc.getGraphTraversal(g, filter.peUid).as('pe');
            }
            else if (!_.isEmpty(filter.producers)) {
                if (psFilterQueries.length === 0) {
                    query = await this.getByExtIdQuery(g, filter.producers, filterStatesConditions(), offset, pageSize);
                }
                else {
                    query = await this.getByProducerQuery(g, filter.producers, filterStatesConditions(), psFilterQueries, offset, pageSize);
                }
            }
            else {
                const ivTypes = (0, CommonTypes_1.identifierVertexTypes)();
                const byIvPriority = _.maxBy(filter.searchTypes, (searchType) => ivTypes.indexOf(searchType.type));
                query = this.getByIVsQuery(g, byIvPriority || filter.searchTypes[0], filterStatesConditions(), offset, pageSize);
            }
            return query.union(__.out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
                .outE(CommonTypes_1.EdgeType.HAS_STATE)
                .or(...filterStatesConditions())
                .inV().as('ps')
                .path().from_('pe').to('ps')
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all)), __.out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
                .outE(CommonTypes_1.EdgeType.HAS_STATE)
                .or(...filterStatesConditions())
                .inV().as('ps')
                .out().as('cv')
                .path().from_('ps').to('cv')
                .by(t.id)
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))).toList();
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
        const timeTicksPerEndpoint = this.getTimeTicksPerEntity(results, filter.since, filter.until);
        const out = await this.processHistoricalStateQueryResult(results, timeTicksPerEndpoint);
        if (out.length <= pageSize) {
            return {
                hasNextPage: false,
                states: out
            };
        }
        return {
            hasNextPage: true,
            states: _.slice(out, 0, pageSize)
        };
    }
    async processHistoricalStateQueryResult(results, timeTicksPerEndpoint) {
        const resultSet = new gremlin_1.driver.ResultSet(results);
        const mergedEndpoints = {};
        const psToPe = {};
        for (const result of resultSet.toArray()) {
            const path = result.objects;
            if (path.length === 4) {
                const pe = path[0];
                const peUid = pe.get(t.id);
                const pv = path[1];
                const stateEdge = path[2];
                const until = stateEdge.get(CommonTypes_1.EdgeBasicProperty.UNTIL);
                const since = stateEdge.get(CommonTypes_1.EdgeBasicProperty.SINCE);
                const ps = path[3];
                const psUid = ps.get(t.id);
                const endpointTimeTicks = timeTicksPerEndpoint[peUid];
                const mergedEndpoint = mergedEndpoints[peUid] || PostureEntityService_1.PostureEntityService.initMergedEntity(peUid, endpointTimeTicks);
                const updatedIndices = [];
                for (let i = 0; i < endpointTimeTicks.length - 1; i += 1) {
                    const timeTickSince = endpointTimeTicks[i];
                    const timeTickUntil = endpointTimeTicks[i + 1];
                    if (since <= timeTickSince && (!until || until >= timeTickUntil)) {
                        updatedIndices.push(i);
                        await this.addProducerProperties(mergedEndpoint[i], pv, ps);
                    }
                }
                mergedEndpoints[peUid] = mergedEndpoint;
                psToPe[psUid] = { peUid, updatedIndices };
            }
            else {
                const psUid = path[0];
                const cv = path[1];
                const { peUid, updatedIndices } = psToPe[psUid];
                const mergedEndpoint = mergedEndpoints[peUid];
                for (let i = 0; i < updatedIndices.length; i += 1) {
                    this.addConnectorProperties(mergedEndpoint[updatedIndices[i]], cv);
                }
                mergedEndpoints[peUid] = mergedEndpoint;
            }
        }
        return _.values(mergedEndpoints);
    }
    async linkDirectCandidateDetailed(vertexType, savedVertexId) {
        switch (vertexType) {
            case CommonTypes_1.VertexType.ORBITAL_ENDPOINT:
                return this.connectToAnotherPE(savedVertexId, CommonTypes_1.Source.AMP);
            case CommonTypes_1.VertexType.AMP_COMPUTER: {
                return this.connectToAnotherPE(savedVertexId, CommonTypes_1.Source.ORBITAL);
            }
            default:
                return undefined;
        }
    }
    async setDevicesAssetValue(assetValue, deviceIds) {
        const failuresWithDetails = [];
        const notValidDeviceIds = [];
        if (_.isEmpty(deviceIds)) {
            this.logger.error('Incorrect input, empty device list');
            failuresWithDetails.push({ deviceId: '', failure: 'Devices are not defined' });
        }
        else if (!_.isUndefined(assetValue) && (assetValue > 10 || assetValue < 1)) {
            this.logger.error(`Incorrect input for assetValue: ${assetValue}`);
            deviceIds.forEach(deviceId => failuresWithDetails.push({ deviceId, failure: 'Incorrect value for assetValue' }));
        }
        if (_.isEmpty(failuresWithDetails)) {
            const esService = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
            const devices = await esService.getPostureEndpointsByUids(deviceIds, ['assetValue', 'rulesAssetValue', 'postureEndpointId']);
            for (const device of devices) {
                const effectedAVWithOrigin = device.effectiveAssetValueWithOrigin;
                if (effectedAVWithOrigin && assetValue && effectedAVWithOrigin.origin === CommonTypes_1.ModificationOrigin.RULES_BASED && effectedAVWithOrigin.value >= assetValue) {
                    failuresWithDetails.push({ deviceId: device.uid, failure: 'Asset value should be greater than it is on device' });
                    notValidDeviceIds.push(device.uid);
                }
            }
            const validatedIds = deviceIds.filter(id => !notValidDeviceIds.includes(id));
            const updateResponse = await esService.modifyAssetValueOnDevices(assetValue, validatedIds);
            if (updateResponse.body.total !== validatedIds.length) {
                this.logger.error(`Total of updated records is not equal to ${validatedIds} length, response: ${JSON.stringify(updateResponse)}`);
                const existing = devices.map(device => device.uid);
                _.difference(deviceIds, existing)
                    .forEach(missingId => failuresWithDetails.push({ deviceId: missingId, failure: 'Device does not found' }));
            }
        }
        return { failuresWithDetails, failure: [] };
    }
    async deleteDevicesAssetValue(deviceIds) {
        const ret = await this.setDevicesAssetValue(undefined, deviceIds);
        return ret;
    }
    async updateDevicesAssetValueMatchingFilter(assetValue, filter, exclusionList) {
        const failureArray = [];
        if ((0, Util_1.hasDuplicatesInArray)(exclusionList)) {
            failureArray.push(`exclusionList has duplicates: ${exclusionList}`);
        }
        if (assetValue && (assetValue > 10 || assetValue < 1)) {
            failureArray.push(`assetValue: ${assetValue} should be a number in the range [1-10]`);
        }
        if (_.isEmpty(failureArray)) {
            const esService = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
            try {
                const updateResponse = await esService.setDevicesAssetValueWithFilter(assetValue, filter, exclusionList);
                if (updateResponse.body.failures.length === updateResponse.body.total) {
                    this.logger.error(`Experienced an error when trying to update financial risk factor for a filter. Response: ${updateResponse}`);
                    failureArray.push('Failed to update all documents');
                }
            }
            catch (e) {
                failureArray.push('Failed to update all documents, system error');
            }
        }
        return {
            failure: failureArray
        };
    }
    async addDataFromESToMergedEP(postureEndpoint) {
        var _a;
        const esService = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        const additionalEsData = await esService.getSpecificFields([postureEndpoint.uid], ['labels', 'assetValue', 'rulesLabels', 'rulesAssetValue']);
        const currentData = additionalEsData.find(meta => meta._id === postureEndpoint.uid);
        if (currentData) {
            const dsi = { ...currentData._source };
            const labelsMetadataMap = await new LabelService_1.LabelService(this.tenantUid).getLabelsMetadataMap();
            postureEndpoint.labels = esService.getLabelMetadata(dsi, labelsMetadataMap);
            postureEndpoint.financialRiskFactor = (_a = dsi.assetValue) !== null && _a !== void 0 ? _a : ElasticsearchServices_1.ElasticsearchServices.DEFAULT_ASSET_VALUE;
            postureEndpoint.assetValue = ElasticsearchServices_1.ElasticsearchServices.getActualAssetValue(dsi).value;
            postureEndpoint.effectiveAssetValueWithOrigin = ElasticsearchServices_1.ElasticsearchServices.getActualAssetValue(dsi);
        }
        else {
            this.logger.error(`Error when trying to add labels and value data for device ${postureEndpoint.uid} of tenant ${this.tenantUid}. Device was not found.`);
            throw new Error('Device not found');
        }
    }
    async addDeploymentsToMergedEP(postureEndpoint) {
        var _a, _b;
        if (PostureEndpointService.hasProducer(postureEndpoint, CommonTypes_1.Source.UNIFIED_CONNECTOR)) {
            if ((postureEndpoint === null || postureEndpoint === void 0 ? void 0 : postureEndpoint.deploymentId) || (postureEndpoint === null || postureEndpoint === void 0 ? void 0 : postureEndpoint.wantedDeploymentId)) {
                const deploymentServices = new UnifiedConnectorDeploymentServices_1.UnifiedConnectorDeploymentServices(this.tenantUid);
                const deploymentsMap = await deploymentServices.getSourceDetails(postureEndpoint.producers.map(producer => producer.producerId))
                    .then(details => Promise.all(details.map(detail => new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(detail.secrets, detail.baseURL, detail.adminBaseUrl, this.tenantUid, detail.producerId).getDeploymentsBulk())))
                    .then(summary => deploymentServices.getFlatMapOfDeployments(summary.flat()));
                if (postureEndpoint === null || postureEndpoint === void 0 ? void 0 : postureEndpoint.deploymentId) {
                    postureEndpoint.deploymentName = (_a = deploymentsMap.get(postureEndpoint.deploymentId)) === null || _a === void 0 ? void 0 : _a.name;
                }
                if (postureEndpoint === null || postureEndpoint === void 0 ? void 0 : postureEndpoint.wantedDeploymentId) {
                    postureEndpoint.wantedDeploymentName = (_b = deploymentsMap.get(postureEndpoint.wantedDeploymentId)) === null || _b === void 0 ? void 0 : _b.name;
                }
            }
        }
    }
}
exports.PostureEndpointService = PostureEndpointService;
