"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedConnectorProcessorServices = void 0;
const lodash_1 = __importDefault(require("lodash"));
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const UnifiedConnectorEndpointService_1 = require("../../collectors/services/UnifiedConnectorEndpointService");
class UnifiedConnectorProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    getModelKeyProperties() {
        return ['originId'];
    }
    async obtainIdentifierChanges(uc, vertexState, currentTopology, changes, unchanged) {
        var _a, _b, _c, _d;
        const ucState = vertexState;
        for (const macAddress of ((_a = ucState.mergedModel) === null || _a === void 0 ? void 0 : _a.mac) || []) {
            await this.verifyChange(currentTopology, macAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        }
        const inHwid = (_b = ucState.mergedModel) === null || _b === void 0 ? void 0 : _b.hwid;
        const inHwidParts = lodash_1.default.split(inHwid, '-');
        const hwid = (lodash_1.default.size(inHwidParts[0]) < 8) ? lodash_1.default.join(lodash_1.default.tail(inHwidParts), '-') : inHwid;
        await this.verifyChange(currentTopology, hwid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        await this.verifyChange(currentTopology, (_c = ucState.mergedModel) === null || _c === void 0 ? void 0 : _c.hostname, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        await this.verifyChange(currentTopology, (_d = ucState.mergedModel) === null || _d === void 0 ? void 0 : _d.serial, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new UnifiedConnectorEndpointService_1.UnifiedConnectorEndpointService(tenantUid, sourceId);
    }
}
exports.UnifiedConnectorProcessorServices = UnifiedConnectorProcessorServices;
