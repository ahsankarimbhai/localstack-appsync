"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DataMigrationRunner = exports.DataMigrationManager = void 0;
const _ = __importStar(require("lodash"));
const BatchTaskServices_1 = require("../common/BatchTaskServices");
const LambdaLogger_1 = require("../common/LambdaLogger");
const StepFunctionService_1 = require("../common/awsclient/StepFunctionService");
const TenantServices_1 = require("../common/TenantServices");
const ScheduleServices_1 = require("../common/ScheduleServices");
const DataMigrationServices_1 = require("../common/DataMigrationServices");
class DataMigrationManager {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.dataMigrationTaskMetadataServices = new DataMigrationServices_1.DataMigrationTaskMetadataServices();
        this.dataMigrationTaskServices = new DataMigrationServices_1.DataMigrationTaskServices();
        this.tenantServices = new TenantServices_1.TenantServices();
    }
    async prepareMigrationPlan() {
        let tenants = [];
        let producers;
        const migrations = _.sortBy(await this.dataMigrationTaskMetadataServices.getAll(), ['order']);
        if (_.isEmpty(migrations)) {
            return;
        }
        if (_.some(migrations, m => m.scope === BatchTaskServices_1.TaskScope.TENANT)) {
            tenants = await this.tenantServices.getAllTenants();
        }
        for (const migration of migrations) {
            if (!Object.values(BatchTaskServices_1.TaskScope).includes(migration.scope)) {
                throw new Error(`Unsupported migration task scope ${migration.scope}`);
            }
            if (migration.scope === BatchTaskServices_1.TaskScope.GLOBAL) {
                await this.addDataMigrationTask(migration.name, BatchTaskServices_1.TaskScope.GLOBAL, migration.timeoutInterval, undefined, migration.taskParams, migration.allowParallel, migration.priorityWeight);
                continue;
            }
            for (const tenant of tenants) {
                switch (migration.scope) {
                    case BatchTaskServices_1.TaskScope.TENANT:
                        if (!migration.applyToTenants
                            || (Array.isArray(migration.applyToTenants) && migration.applyToTenants.includes(tenant.id))) {
                            await this.addDataMigrationTask(migration.name, tenant.id, migration.timeoutInterval, undefined, migration.taskParams, migration.allowParallel, migration.priorityWeight);
                        }
                        break;
                    case BatchTaskServices_1.TaskScope.PRODUCER:
                        producers = await this.tenantServices.getTenantSources(tenant.id);
                        for await (const producer of producers) {
                            if (!_.find(migration.producerTypeList, producerType => _.startsWith(producer, producerType))) {
                                continue;
                            }
                            await this.addDataMigrationTask(migration.name, tenant.id, migration.timeoutInterval, producer, migration.taskParams, migration.allowParallel, migration.priorityWeight);
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }
    async addDataMigrationTask(name, tenantUid, timeoutInterval, producer, taskParams, allowParallel, priorityWeight) {
        const existingMigration = await this.dataMigrationTaskServices.getByKey(name, tenantUid, producer);
        if (!existingMigration) {
            this.logger.debug(`Adding data migration task ${name} for tenant ${tenantUid}${producer ? ` and ${producer}` : ''}`);
            return this.dataMigrationTaskServices.save(tenantUid === BatchTaskServices_1.TaskScope.GLOBAL
                ? new DataMigrationServices_1.GlobalDataMigrationTask(name, timeoutInterval, taskParams, allowParallel, priorityWeight)
                : new DataMigrationServices_1.DataMigrationTask(name, tenantUid, timeoutInterval, producer, taskParams, allowParallel, priorityWeight));
        }
        this.logger.debug(`Data migration task ${name} for tenant ${tenantUid}${producer ? ` and ${producer}` : ''} already exists.`);
        return Promise.resolve();
    }
}
exports.DataMigrationManager = DataMigrationManager;
class DataMigrationRunner {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.dataMigrationTaskServices = new DataMigrationServices_1.DataMigrationTaskServices();
        this.stepFunctionServices = new StepFunctionService_1.StepFunctionService();
        this.scheduledTaskServices = new ScheduleServices_1.ScheduledTaskServices();
    }
    async triggerNextMigration() {
        const runningTasks = await this.dataMigrationTaskServices.getRunningTasks();
        let shouldRunAgain = false;
        if (_.isEmpty(runningTasks)) {
            const tasksToRun = await this.getTasksToRun();
            if (!_.isEmpty(tasksToRun)) {
                const maxConcurrentTasks = +(process.env.MAX_ALLOWED_CONCURRENT_MIGRATION_TASKS || 1);
                let invocations = 0;
                let prevMigration;
                for (const migration of tasksToRun) {
                    if (!prevMigration || (prevMigration.allowParallel && migration.allowParallel && invocations < maxConcurrentTasks)) {
                        const { name, tenantUid, producer } = migration;
                        this.logger.debug(`Triggering data migration task ${name} for tenant ${tenantUid}${producer ? ` and producer ${producer}` : ''}`);
                        await this.dataMigrationTaskServices.updateTaskStartTime(name, tenantUid, producer);
                        await this.stepFunctionServices.startExecution(DataMigrationRunner.getStateMachineName(name), JSON.stringify(migration));
                        prevMigration = migration;
                        invocations += 1;
                    }
                    else {
                        break;
                    }
                }
                shouldRunAgain = _.size(tasksToRun) > invocations;
            }
        }
        else {
            await Promise.all(_.map(runningTasks, (task) => this.dataMigrationTaskServices.updateTaskTimeout(task.name, task.tenantUid, task.producer)));
            shouldRunAgain = true;
        }
        if (shouldRunAgain) {
            await this.ensureNextRun();
        }
        else {
            await this.stopRunning();
        }
    }
    async getTasksToRun() {
        return _.orderBy(await this.dataMigrationTaskServices.getNotStartedTasks(), [t => t.priorityWeight || 0, 'created'], ['desc', 'asc']);
    }
    async ensureNextRun() {
        if (!(await this.isScheduled())) {
            this.logger.debug('Schedule migration task runner.');
            const runnerTask = new ScheduleServices_1.ScheduledTask(DataMigrationRunner.NAME, BatchTaskServices_1.TaskScope.GLOBAL, DataMigrationRunner.EVERY_15_MIN);
            return this.scheduledTaskServices.save(runnerTask);
        }
        return Promise.resolve();
    }
    async stopRunning() {
        if (await this.isScheduled()) {
            this.logger.debug('Un-schedule migration task runner.');
            return this.scheduledTaskServices.delete(DataMigrationRunner.NAME, BatchTaskServices_1.TaskScope.GLOBAL);
        }
        return Promise.resolve();
    }
    isScheduled() {
        return this.scheduledTaskServices.getByKey(DataMigrationRunner.NAME, BatchTaskServices_1.TaskScope.GLOBAL);
    }
    static getStateMachineName(taskName) {
        return `${process.env.STATE_MACHINE_ARN_PREFIX}${process.env.ENV_PREFIX}-${taskName}-sm`;
    }
}
exports.DataMigrationRunner = DataMigrationRunner;
DataMigrationRunner.NAME = 'trigger-data-migration';
DataMigrationRunner.EVERY_15_MIN = '0/15 * * * *';
