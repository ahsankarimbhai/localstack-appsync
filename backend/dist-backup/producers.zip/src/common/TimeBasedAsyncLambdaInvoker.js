"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeBasedAsyncLambdaInvoker = exports.BasicTimeBasedLambdaHandler = void 0;
const LambdaServices_1 = require("./LambdaServices");
const LambdaLogger_1 = require("./LambdaLogger");
const _ = __importStar(require("lodash"));
const DEFAULT_TIMEOUT_THRESHOLD = 60000;
class BasicTimeBasedLambdaHandler {
    constructor(context, timeoutThreshold = DEFAULT_TIMEOUT_THRESHOLD) {
        this.context = context;
        this.timeoutThreshold = timeoutThreshold;
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!_.get(context, 'appData.currentSequenceStart')) {
            _.set(context, 'appData.currentSequenceStart', Date.now());
        }
    }
    getRemainingTimeInMillis() {
        return this.context.getRemainingTimeInMillis();
    }
    isItTimeToStop() {
        return this.getRemainingTimeInMillis() < this.timeoutThreshold;
    }
    async handle(event) {
    }
}
exports.BasicTimeBasedLambdaHandler = BasicTimeBasedLambdaHandler;
class TimeBasedAsyncLambdaInvoker extends BasicTimeBasedLambdaHandler {
    constructor(context, timeoutThreshold = DEFAULT_TIMEOUT_THRESHOLD) {
        super(context, timeoutThreshold);
        this.lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
    }
    async handle(event) {
        await this.invokeLambda(event);
    }
    async invokeNextLambdaIfRequired(nextUri) {
        if (!nextUri) {
            return Promise.reject(new Error('nextUri is undefined'));
        }
        if (this.isItTimeToStop()) {
            this.context.appData.nextUri = nextUri;
            this.logger.info(`lambda: ${this.context.functionName} close to timeout: ${this.context.getRemainingTimeInMillis()}, invoke it again with app data: ${JSON.stringify(this.context.appData)}`);
            await this.lambdaServices.asyncInvoke(this.context.functionName, JSON.stringify(this.context.appData));
            return Promise.resolve(true);
        }
        return Promise.resolve(false);
    }
    async invokeLambda(event) {
        this.logger.info(`lambda: ${this.context.functionName} will be invoked with data: ${JSON.stringify(event)}`);
        const response = await this.lambdaServices.asyncInvoke(this.context.functionName, JSON.stringify(event));
        this.logger.debug(`Lambda invoke response: ${JSON.stringify(response)}`);
    }
}
exports.TimeBasedAsyncLambdaInvoker = TimeBasedAsyncLambdaInvoker;
