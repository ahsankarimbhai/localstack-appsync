"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedConnectorEndpointService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
class UnifiedConnectorEndpointService extends Services_1.BaseEndpointService {
    getPvType() {
        return CommonTypes_1.VertexType.UNIFIED_CONNECTOR_DEVICE;
    }
    getPsType() {
        return CommonTypes_1.VertexType.UNIFIED_CONNECTOR_DEVICE_STATE;
    }
    processNotifications(body) {
        this.logger.debug(`unifiedConnector notification ${JSON.stringify(body.data)}`);
        return [body.data];
    }
}
exports.UnifiedConnectorEndpointService = UnifiedConnectorEndpointService;
