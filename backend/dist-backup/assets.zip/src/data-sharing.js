"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dispatchWebhookNotification = exports.handleWebhook = exports.handleTenantWebhooks = exports.createWebhook = void 0;
const LambdaLogger_1 = require("./common/LambdaLogger");
const LambdaHandler_1 = require("./common/lambdahandler/LambdaHandler");
const Util_1 = require("./common/Util");
const WebhookRegistrationService_1 = require("./services/common/data-sharing/WebhookRegistrationService");
const MetricsTelemetryMiddleware_1 = require("./common/lambdahandler/MetricsTelemetryMiddleware");
const handlers_1 = require("./graphql-api/handlers");
const WebhookNotificationService_1 = require("./services/common/data-sharing/WebhookNotificationService");
const PostureEndpointService_1 = require("./model/PostureEndpointService");
const ResourcesManager_1 = require("./common/ResourcesManager");
const WebhookHelper_1 = require("./services/common/data-sharing/WebhookHelper");
const bluebird_1 = require("bluebird");
const ScheduleServices_1 = require("./common/ScheduleServices");
const DSColdStartFetchDevices_1 = require("./scheduled/tasks/DSColdStartFetchDevices");
const TenantServices_1 = require("./common/TenantServices");
const ScheduledTaskRunner_1 = require("./scheduled/ScheduledTaskRunner");
const logger = new LambdaLogger_1.LambdaLogger();
exports.createWebhook = new LambdaHandler_1.LambdaHandler(async (event) => {
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, Util_1.lambdaProxyResponse)('POST', toErrorResponseBody(['missing tenant in the request']), 401);
    }
    try {
        logger.debug(`received createWebhook request, tenantUid: ${tenantUid}, request body: ${event.body}`);
        const webhookRegistrationService = new WebhookRegistrationService_1.WebhookRegistrationService();
        if (!await webhookRegistrationService.verifyFeature(tenantUid)) {
            return (0, Util_1.lambdaProxyResponse)('POST', toErrorResponseBody(['Unauthorized to register webhook']), 401);
        }
        const reqBody = JSON.parse(event.body);
        const validationErrors = await webhookRegistrationService.validateRegisterWebhookRequest(tenantUid, reqBody);
        if (validationErrors.length > 0) {
            return (0, Util_1.lambdaProxyResponse)('POST', toErrorResponseBody(validationErrors), 400);
        }
        const webhook = await webhookRegistrationService.registerWebhook(tenantUid, reqBody);
        if (webhook.coldStart.enable) {
            await invokeColdStart(webhook);
        }
        return (0, Util_1.lambdaProxyResponse)('POST', JSON.stringify({ webhookId: webhook.webhookId }));
    }
    catch (err) {
        const errMsg = `Failed to register webhook for tenant ${tenantUid}, err: ${err.message}`;
        logger.error(errMsg);
        return (0, Util_1.lambdaProxyResponse)('POST', toErrorResponseBody([errMsg]), 500);
    }
}).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(MetricsTelemetryMiddleware_1.IntegrationType.LambdaProxy, logger)).toPipelines();
exports.handleTenantWebhooks = new LambdaHandler_1.LambdaHandler((event) => {
    switch (event.httpMethod) {
        case 'GET':
            return listTenantWebhooks(event);
        case 'DELETE':
            return deleteTenantWebhooks(event);
        default:
            throw new Error('only allow httpMethods: GET, DELETE');
    }
}).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(MetricsTelemetryMiddleware_1.IntegrationType.LambdaProxy, logger)).toPipelines();
const listTenantWebhooks = async (event) => {
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, Util_1.lambdaProxyResponse)('GET', toErrorResponseBody(['missing tenant in the request']), 401);
    }
    try {
        logger.debug(`received listWebhooks request, tenantUid: ${tenantUid}`);
        const webhookRegistrationService = new WebhookRegistrationService_1.WebhookRegistrationService();
        if (!await webhookRegistrationService.verifyFeature(tenantUid)) {
            return (0, Util_1.lambdaProxyResponse)('GET', toErrorResponseBody(['Unauthorized to get webhooks']), 401);
        }
        const webhooks = await webhookRegistrationService.listActiveWebhooks(tenantUid);
        return (0, Util_1.lambdaProxyResponse)('GET', JSON.stringify(webhooks));
    }
    catch (err) {
        const errMsg = `Failed to get webhooks for tenant ${tenantUid}, err: ${err.message}`;
        logger.error(errMsg);
        return (0, Util_1.lambdaProxyResponse)('GET', toErrorResponseBody([errMsg]), 500);
    }
};
const deleteTenantWebhooks = async (event) => {
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, Util_1.lambdaProxyResponse)('DELETE', toErrorResponseBody(['missing tenant in the request']), 401);
    }
    try {
        logger.debug(`received deleteWebhooks request, tenantUid: ${tenantUid}`);
        const webhookRegistrationService = new WebhookRegistrationService_1.WebhookRegistrationService();
        if (!await webhookRegistrationService.verifyFeature(tenantUid)) {
            return (0, Util_1.lambdaProxyResponse)('DELETE', toErrorResponseBody(['Unauthorized to get webhooks']), 401);
        }
        await webhookRegistrationService.deleteTenantWebhooks(tenantUid);
        return (0, Util_1.lambdaProxyResponse)('DELETE');
    }
    catch (err) {
        const errMsg = `Failed to delete all webhooks for tenant ${tenantUid}, err: ${err.message}`;
        logger.error(errMsg);
        return (0, Util_1.lambdaProxyResponse)('DELETE', toErrorResponseBody([errMsg]), 500);
    }
};
exports.handleWebhook = new LambdaHandler_1.LambdaHandler((event) => {
    switch (event.httpMethod) {
        case 'GET':
            return getWebhook(event);
        case 'PUT':
            return updateWebhook(event);
        case 'DELETE':
            return deleteWebhook(event);
        default:
            throw new Error('only allow httpMethods: GET, PUT, DELETE');
    }
}).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(MetricsTelemetryMiddleware_1.IntegrationType.LambdaProxy, logger)).toPipelines();
const updateWebhook = async (event) => {
    var _a;
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, Util_1.lambdaProxyResponse)('PUT', toErrorResponseBody(['missing tenant in the request']), 401);
    }
    const webhookId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.webhookId;
    if (!webhookId) {
        return (0, Util_1.lambdaProxyResponse)('PUT', toErrorResponseBody(['missing webhookId in the request']), 400);
    }
    try {
        logger.debug(`received updateWebhook request, tenantUid: ${tenantUid}, webhookId: ${webhookId}, request body: ${event.body}`);
        const webhookRegistrationService = new WebhookRegistrationService_1.WebhookRegistrationService();
        if (!await webhookRegistrationService.verifyFeature(tenantUid)) {
            return (0, Util_1.lambdaProxyResponse)('PUT', toErrorResponseBody(['Unauthorized to register webhook']), 401);
        }
        const reqBody = JSON.parse(event.body);
        const validationErrors = await webhookRegistrationService.validateUpdateWebhookRequest(webhookId, tenantUid, reqBody);
        if (validationErrors.length > 0) {
            return (0, Util_1.lambdaProxyResponse)('PUT', toErrorResponseBody(validationErrors), 400);
        }
        const { webhook, shouldInvokeColdStart } = await webhookRegistrationService.updateWebhook(webhookId, reqBody);
        if (shouldInvokeColdStart) {
            await invokeColdStart(webhook);
        }
        return (0, Util_1.lambdaProxyResponse)('PUT');
    }
    catch (err) {
        const errMsg = `Failed to update webhook ${webhookId} for tenant ${tenantUid}, err: ${err.message}`;
        logger.error(errMsg);
        return (0, Util_1.lambdaProxyResponse)('PUT', toErrorResponseBody([errMsg]), 500);
    }
};
const getWebhook = async (event) => {
    var _a;
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, Util_1.lambdaProxyResponse)('GET', toErrorResponseBody(['missing tenant in the request']), 401);
    }
    const webhookId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.webhookId;
    if (!webhookId) {
        return (0, Util_1.lambdaProxyResponse)('GET', toErrorResponseBody(['missing webhookId in the request']), 400);
    }
    try {
        logger.debug(`received getWebhook request, tenantUid: ${tenantUid}, webhookId: ${webhookId}`);
        const webhookRegistrationService = new WebhookRegistrationService_1.WebhookRegistrationService();
        if (!await webhookRegistrationService.verifyFeature(tenantUid)) {
            return (0, Util_1.lambdaProxyResponse)('GET', toErrorResponseBody(['Unauthorized to get webhook']), 401);
        }
        const webhook = await webhookRegistrationService.getWebhookById(webhookId, tenantUid);
        if (!webhook) {
            return (0, Util_1.lambdaProxyResponse)('GET', toErrorResponseBody(['webhook is not found']), 404);
        }
        return (0, Util_1.lambdaProxyResponse)('GET', JSON.stringify(webhook));
    }
    catch (err) {
        const errMsg = `Failed to get webhook ${webhookId} for tenant ${tenantUid}, err: ${err.message}`;
        logger.error(errMsg);
        return (0, Util_1.lambdaProxyResponse)('GET', toErrorResponseBody([errMsg]), 500);
    }
};
const deleteWebhook = async (event) => {
    var _a;
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        return (0, Util_1.lambdaProxyResponse)('DELETE', toErrorResponseBody(['missing tenant in the request']), 401);
    }
    const webhookId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.webhookId;
    if (!webhookId) {
        return (0, Util_1.lambdaProxyResponse)('DELETE', toErrorResponseBody(['missing webhookId in the request']), 400);
    }
    try {
        logger.debug(`received deleteWebhook request, tenantUid: ${tenantUid}, webhookId: ${webhookId}`);
        const webhookRegistrationService = new WebhookRegistrationService_1.WebhookRegistrationService();
        if (!await webhookRegistrationService.verifyFeature(tenantUid)) {
            return (0, Util_1.lambdaProxyResponse)('DELETE', toErrorResponseBody(['Unauthorized to delete webhook']), 401);
        }
        await webhookRegistrationService.deleteWebhookById(webhookId, tenantUid);
        return (0, Util_1.lambdaProxyResponse)('DELETE');
    }
    catch (err) {
        const errMsg = `Failed to delete webhook ${webhookId} for tenant ${tenantUid}, err: ${err.message}`;
        logger.error(errMsg);
        return (0, Util_1.lambdaProxyResponse)('DELETE', toErrorResponseBody([errMsg]), 500);
    }
};
const toErrorResponseBody = (errMsgs) => JSON.stringify({ errorMessage: errMsgs.join('; ') });
const invokeColdStart = async (webhook) => {
    const tenantServices = new TenantServices_1.TenantServices();
    const liveProducers = await tenantServices.getProducerConfigurations(webhook.tenantUid);
    const coldStartProducers = webhook.sourceTypes.includes(WebhookHelper_1.ALL_SOURCE_TYPES)
        ? liveProducers : liveProducers.filter(l => webhook.sourceTypes.some(s => s === l.producerType));
    if (coldStartProducers.length === 0) {
        return;
    }
    const taskParams = {
        webhookId: webhook.webhookId,
        producers: coldStartProducers.map(p => (0, Util_1.toSourceString)(p.producerType, p.producerId)),
        searchDeviceCreatedBefore: webhook.coldStart.enabledAt
    };
    await new ScheduledTaskRunner_1.ScheduledTaskRunner().triggerTask(new ScheduleServices_1.ScheduledTask(DSColdStartFetchDevices_1.DSColdStartFetchDevices.TASK_NAME, webhook.tenantUid, ScheduleServices_1.ScheduleType.NOW, undefined, taskParams));
};
const dispatchWebhookNotification = async (event) => {
    const { webhookId, tenantUid, eventType, peIds } = (0, Util_1.parseEvent)(event);
    if (!tenantUid || !Object.values(WebhookHelper_1.WebhookEventType).includes(eventType) || (peIds === null || peIds === void 0 ? void 0 : peIds.length) === 0) {
        throw new Error('must send correct arguments for tenantUid, eventType and peIds');
    }
    logger.debug(`dispatchWebhookNotification for tenant: ${tenantUid}, eventType: ${eventType}, peIds: ${peIds.join(', ')}`);
    try {
        const dedupPeIds = new Set(peIds);
        const endpoints = [];
        await bluebird_1.Promise.map(dedupPeIds, async (peId) => {
            const endpoint = await fetchPostureEndpoint(peId, tenantUid);
            if (endpoint) {
                endpoints.push(endpoint);
            }
        }, { concurrency: 10 });
        if (endpoints.length === 0) {
            logger.info(`no posture endpoint is found, won't dispatch webhook notification for tenant: ${tenantUid}, eventType: ${eventType}`);
            return;
        }
        const webhookNotificationService = new WebhookNotificationService_1.WebhookNotificationService();
        await webhookNotificationService.dispatchToWebhookTarget(tenantUid, eventType, endpoints, webhookId);
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.dispatchWebhookNotification = dispatchWebhookNotification;
const fetchPostureEndpoint = async (peId, tenantUid) => {
    try {
        const service = new PostureEndpointService_1.PostureEndpointService(tenantUid);
        const postureEndpoint = await service.getPostureEndpoint(peId);
        if (postureEndpoint) {
            await service.addDataFromESToMergedEP(postureEndpoint);
            await (0, handlers_1.augmentWithGroupDetails)(postureEndpoint, tenantUid);
            await (0, handlers_1.augmentWithPolicyDetails)(postureEndpoint, tenantUid);
        }
        return postureEndpoint;
    }
    catch (err) {
        logger.error(`failed to fetch posture endpoint for tenant: ${tenantUid}, peId: ${peId}, err: ${err.message}`);
        return undefined;
    }
};
