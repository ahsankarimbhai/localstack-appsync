"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobileIronDevicesCollection = void 0;
const MobileIronCollection_1 = require("./MobileIronCollection");
class MobileIronDevicesCollection extends MobileIronCollection_1.MobileIronCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.MobileIronDevicesCollection = MobileIronDevicesCollection;
