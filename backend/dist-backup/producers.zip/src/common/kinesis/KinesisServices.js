"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KinesisServices = void 0;
const _ = __importStar(require("lodash"));
const client_kinesis_1 = require("@aws-sdk/client-kinesis");
const LambdaLogger_1 = require("../LambdaLogger");
class KinesisServices {
    constructor(streamName, wireLogger = false) {
        this.streamName = streamName;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.encoder = new TextEncoder();
        this.kinesis = new client_kinesis_1.KinesisClient({ endpoint: `http://${process.env.LOCALSTACK_HOSTNAME}:4566`, region: process.env.AWS_REGION });
        if (wireLogger) {
            this.kinesis.config.logger = this.logger;
        }
    }
    putRecord(record) {
        return this.kinesis.send(new client_kinesis_1.PutRecordCommand(this.getPutRecord(record)));
    }
    putRecords(records) {
        return this.kinesis.send(new client_kinesis_1.PutRecordsCommand({
            Records: _.map(records, (record) => ({
                ...record,
                Data: this.encoder.encode(record.Data)
            })),
            StreamName: this.getStream()
        }));
    }
    async putRecordsWithFailedRecordCountCheck(records) {
        const result = await this.putRecords(records);
        this.logger.info(`Failed: ${result.FailedRecordCount}, time: ${Date.now()}`);
        if (result.FailedRecordCount !== 0) {
            throw new Error(`Failed to put ${result.FailedRecordCount}, stream ${this.streamName}`);
        }
        return result;
    }
    describeStream() {
        return this.kinesis.send(new client_kinesis_1.DescribeStreamCommand({
            StreamName: this.getStream()
        }));
    }
    async listAllActiveShards() {
        const allShards = await this.listAllShards();
        return allShards.filter(s => { var _a; return !((_a = s.SequenceNumberRange) === null || _a === void 0 ? void 0 : _a.EndingSequenceNumber); });
    }
    async listAllShards(nextToken) {
        let shards = [];
        const resp = await this.kinesis.send(new client_kinesis_1.ListShardsCommand({
            StreamName: this.getStream(),
            NextToken: nextToken
        })).then((data) => ({ items: data.Shards || [], nextToken: data.NextToken }));
        if (resp.nextToken) {
            shards = await this.listAllShards(resp.nextToken);
        }
        return _.concat(resp.items, shards);
    }
    getStream() {
        if (!process.env.ENV_PREFIX) {
            throw new Error('ENV_PREFIX is not set');
        }
        return `${process.env.ENV_PREFIX}-${this.streamName}`;
    }
    getPutRecord(record) {
        return {
            StreamName: this.getStream(),
            Data: this.encoder.encode(record.Data),
            PartitionKey: record.PartitionKey,
            ExplicitHashKey: record.ExplicitHashKey
        };
    }
}
exports.KinesisServices = KinesisServices;
