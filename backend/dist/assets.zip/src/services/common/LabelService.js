"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelService = exports.GlobalLabelService = void 0;
const _ = __importStar(require("lodash"));
const uuid_1 = require("uuid");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const validate_color_1 = require("validate-color");
const tinycolor2_1 = __importDefault(require("tinycolor2"));
const LabelMetadataRepo_1 = require("../../common/dynamoDBRepo/LabelMetadataRepo");
class GlobalLabelService {
    constructor() {
        this.labelMetadataRepo = new LabelMetadataRepo_1.LabelMetadataRepo();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async getAllLabelsGroupedByTenant() {
        const labels = await this.labelMetadataRepo.getAll();
        const groupedLabels = new Map();
        labels.forEach(label => {
            if (groupedLabels.has(label.tenantId)) {
                groupedLabels.get(label.tenantId).push(label.labelId);
            }
            else {
                groupedLabels.set(label.tenantId, [label.labelId]);
            }
        });
        return groupedLabels;
    }
}
exports.GlobalLabelService = GlobalLabelService;
class LabelService {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.labelMetadataRepo = new LabelMetadataRepo_1.LabelMetadataRepo();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async createLabel(labelData) {
        const toSave = this.getNewEntity(labelData);
        const isLabelWithNameAlreadyExist = await this.labelMetadataRepo.isLabelWithAttrExist(this.tenantUid, LabelMetadataRepo_1.LabelMetadataRepo.ATTR_NAME, labelData.name);
        if (isLabelWithNameAlreadyExist) {
            throw new Error(`Label with name ${labelData.name} already exists`);
        }
        await this.labelMetadataRepo.createLabel(toSave);
        return this.getMetadata(toSave);
    }
    async deleteAllLabels() {
        this.logger.info(`ALl labels for the tenant ${this.tenantUid} will be deleted`);
        const labels = await this.getAllLabels();
        await this.deleteLabels(labels.map(label => label.labelId));
    }
    async deleteLabels(labelIds) {
        const successArray = [];
        const failureArray = [];
        for (const lId of labelIds) {
            try {
                await this.labelMetadataRepo.deleteLabel(this.tenantUid, lId);
                successArray.push(lId);
            }
            catch (e) {
                this.logger.error(`Can't delete label: ${lId} for tenant: ${this.tenantUid}`, e.message);
                failureArray.push({ labelId: lId, error: 'Internal error' });
            }
        }
        return Promise.resolve({
            success: successArray,
            failure: failureArray
        });
    }
    async getLabel(labelId) {
        try {
            return this.labelMetadataRepo.getLabel(this.tenantUid, labelId);
        }
        catch (e) {
            this.logger.error(`Label ${labelId} for tenant ${this.tenantUid} can not be reached`, e.message);
            throw e;
        }
    }
    async getLabelsMetadataMap() {
        const labels = await this.getAllLabels();
        return new Map(labels.map(label => [label.labelId, this.getMetadata(label)]));
    }
    async getLabelsMetadata() {
        const labels = await this.getAllLabels();
        return labels.map(label => this.getMetadata(label));
    }
    async getLabels(labelIds) {
        const result = [];
        if ((labelIds === null || labelIds === void 0 ? void 0 : labelIds.length) === 0) {
            this.logger.error('Labels are empty');
        }
        else {
            const labelMap = await this.getLabelsMetadataMap();
            for (const labelID of labelIds) {
                const labelTemp = labelMap.get(labelID);
                if (!labelTemp) {
                    this.logger.error(`Not found label ${labelID} for tenant ${this.tenantUid}`);
                }
                else {
                    result.push(labelTemp);
                }
            }
        }
        return result;
    }
    async getAllLabels() {
        return this.labelMetadataRepo.getTenantLabels(this.tenantUid);
    }
    async updateLabels(labelsData) {
        const successArray = [];
        const failureArray = [];
        for (const labelData of labelsData) {
            if (!labelData.labelId) {
                this.logger.error(`Wrong input for label update, labelId can not be empty ${JSON.stringify(labelsData)}`);
                failureArray.push({ label: labelData, error: 'Inconsistent data' });
                continue;
            }
            try {
                this.validateNameColor(labelData);
            }
            catch (e) {
                this.logger.error(`Validation failed for label: ${JSON.stringify(labelData)} for tenant: ${this.tenantUid}, `, e.message);
                failureArray.push({ label: labelData, error: e.message });
                continue;
            }
            try {
                const toUpdate = await this.getLabel(labelData.labelId);
                if (!toUpdate) {
                    this.logger.error(`An attempt was made to update label which does not exist ${JSON.stringify(labelData)}`);
                    failureArray.push({ label: labelData, error: 'Label does not exist' });
                    continue;
                }
                else if (toUpdate.name !== labelData.name && await this.labelMetadataRepo.isLabelWithAttrExist(this.tenantUid, LabelMetadataRepo_1.LabelMetadataRepo.ATTR_NAME, labelData.name)) {
                    this.logger.error(`Can't update label: ${JSON.stringify(labelData)} for tenant: ${this.tenantUid} label with such name already exists`);
                    failureArray.push({ label: labelData, error: 'Label with such name already exists' });
                    continue;
                }
                await this.labelMetadataRepo.updateLabelMetadata({ labelId: labelData.labelId, tenantId: this.tenantUid, color: labelData.color, name: labelData.name });
                this.setTextColor(labelData);
                successArray.push({ label: labelData });
            }
            catch (e) {
                this.logger.error(`Can't update label: ${JSON.stringify(labelData)} for tenant: ${this.tenantUid}`, e.message);
                failureArray.push({ label: labelData, error: 'Internal error' });
            }
        }
        return Promise.resolve({
            success: successArray,
            failure: failureArray
        });
    }
    getNewEntity(label) {
        const { colorValue, nameValue } = this.validateNameColor(label);
        return { labelId: (0, uuid_1.v4)(), tenantId: this.tenantUid, color: colorValue, name: nameValue };
    }
    validateNameColor(label) {
        const colorValue = _.trim(label.color);
        const nameValue = _.trim(label.name);
        if (_.isEmpty(colorValue) || _.isEmpty(nameValue)) {
            this.logger.error(`Validation for name and color failed for ${JSON.stringify(label)}`);
            throw new Error('Color or name is empty');
        }
        if (nameValue.length > 50) {
            this.logger.error(`Validation for name failed for ${JSON.stringify(label)} - must be up to 50 characters`);
            throw new Error('Label name can not exceed 50 characters');
        }
        if (!(0, validate_color_1.validateHTMLColorHex)(colorValue)) {
            this.logger.error(`Validation for color failed for ${JSON.stringify(label)}`);
            throw new Error('Wrong color format');
        }
        return { colorValue, nameValue };
    }
    getMetadataWithoutId(label) {
        return { color: label.color, name: label.name };
    }
    getMetadata(label) {
        const metadata = _.merge({ labelId: label.labelId }, this.getMetadataWithoutId(label));
        this.setTextColor(metadata);
        return metadata;
    }
    setTextColor(label) {
        label.textColor = this.getTextColorByLabelColor(label.color);
    }
    getTextColorByLabelColor(labelColor) {
        const darkColors = ['#B32C20', '#F9A621', '#57886C', '#00ACC1', '#5171F1', '#355294'];
        const lightColors = ['#E1ABA6', '#FCD390', '#ABC4B6', '#99DEE6', '#A8B8F8', '#AEBAD4'];
        const white = '#FFFFFF';
        const black = '#000000';
        if (darkColors.includes(labelColor)) {
            return white;
        }
        if (lightColors.includes(labelColor)) {
            return black;
        }
        return (0, tinycolor2_1.default)(labelColor).isDark() ? white : black;
    }
}
exports.LabelService = LabelService;
