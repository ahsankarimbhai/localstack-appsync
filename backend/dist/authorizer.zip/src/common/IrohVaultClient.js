"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohVaultClient = void 0;
const IrohClient_1 = require("./IrohClient");
const axios_1 = __importDefault(require("axios"));
const LambdaLogger_1 = require("./LambdaLogger");
const Util_1 = require("./Util");
class IrohVaultClient {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!process.env.IROH_URI) {
            throw new Error('IROH_URI is not set');
        }
        this.irohUri = process.env.IROH_URI;
        this.axios = axios_1.default.create();
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'IrohVaultClient');
    }
    async getPostureConfigs() {
        try {
            const response = await this.axios.request(await this.getOptions(IrohVaultClient.IROH_VAULT_CONFIGS_URI));
            return response.data;
        }
        catch (err) {
            this.logger.error(`Failed to get posture configs: ${err.message}`);
            throw err;
        }
    }
    async getPostureConfigData(url) {
        try {
            const configDataUrl = IrohVaultClient.IROH_VAULT_CONFIGS_URI.concat(url);
            const response = await this.axios.request(await this.getOptions(configDataUrl));
            return response.data;
        }
        catch (err) {
            this.logger.error(`Failed to get posture config data: ${err.message}`);
            throw err;
        }
    }
    async getOptions(url) {
        const token = await (0, IrohClient_1.getAccessToken)(this.tenantUid);
        const method = 'get';
        return {
            method,
            baseURL: this.irohUri,
            headers: {
                Authorization: token
            },
            url
        };
    }
}
exports.IrohVaultClient = IrohVaultClient;
IrohVaultClient.IROH_VAULT_CONFIGS_URI = '/iroh/iroh-vault/configs';
