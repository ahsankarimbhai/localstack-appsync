"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericSourceUtils = void 0;
const fs_1 = __importDefault(require("fs"));
const Util_1 = require("../Util");
const IrohModuleInstanceClient_1 = require("../IrohModuleInstanceClient");
const _ = __importStar(require("lodash"));
const SourceUtils_1 = require("../SourceUtils");
const GenericSourceConfigurationValidation_1 = require("./GenericSourceConfigurationValidation");
const LambdaLogger_1 = require("../LambdaLogger");
class GenericSourceUtils {
    static init() {
        if (!GenericSourceUtils.configurations) {
            GenericSourceUtils.configurations = [];
            const filenames = fs_1.default.readdirSync(this.configurationPath);
            for (const filename of filenames) {
                if (filename.includes('.json')) {
                    const jsonStr = fs_1.default.readFileSync(`${this.configurationPath}/${filename}`, 'utf8');
                    try {
                        GenericSourceUtils.configurations.push((0, Util_1.fixAndParseJson)(jsonStr));
                    }
                    catch (e) {
                        this.logger.error(`Failed to parse configuration for fileName ${filename}: ${e.message}`);
                    }
                }
            }
        }
    }
    static clear() {
        GenericSourceUtils.configurations = undefined;
    }
    static isSourceConfiguration(sourceType) {
        this.init();
        for (const configuration of GenericSourceUtils.configurations || []) {
            if (_.get(configuration, 'sourceName') === sourceType) {
                return true;
            }
        }
        return false;
    }
    static getSourceConfiguration(sourceType, featureFlags) {
        return GenericSourceUtils.getSourceConfigurationByKeyValue('sourceName', sourceType, featureFlags);
    }
    static getSourceConfigurationByModuleType(moduleType, featureFlags) {
        const secureXClass = _.find(moduleType.external_references, { class: IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS });
        if (secureXClass && secureXClass.external_id) {
            const secureXType = secureXClass.external_id.split(':').pop();
            if (secureXType) {
                const existingModule = SourceUtils_1.moduleTypeToProducerSource[secureXType];
                if (existingModule) {
                    return GenericSourceUtils.getSourceConfiguration(existingModule, featureFlags);
                }
                return GenericSourceUtils.getSourceConfigurationByKeyValue('integrationModule.moduleTypeClass', secureXType, featureFlags);
            }
        }
        this.logger.debug(`${IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS} is missing on moduleType ${JSON.stringify(moduleType)}`);
        return undefined;
    }
    static getSourceConfigurationByKeyValue(key, value, featureFlags) {
        this.init();
        for (const configuration of GenericSourceUtils.configurations || []) {
            if (_.get(configuration, key) === value) {
                if (featureFlags && configuration.requiredFeatureFlag && !featureFlags.includes(configuration.requiredFeatureFlag)) {
                    throw new Error(`Feature source "${configuration.sourceName}" is not enabled for this tenant`);
                }
                const { errors, warnings } = GenericSourceConfigurationValidation_1.GenericSourceConfigurationValidation.validateSourceConfiguration(configuration);
                if (errors.length > 0) {
                    const errorMessage = `Invalid Source Configuration for source "${configuration.sourceName}" with ${errors.length} error(s) and ${warnings.length} warning(s).\nError(s): [${errors}]\nWarning(s): [${warnings}]`;
                    this.logger.error(errorMessage);
                    throw new Error(errorMessage);
                }
                if (warnings.length > 0) {
                    this.logger.warn(`${warnings.length} warning(s) detected in Source Configuration for source "${configuration.sourceName}". Warning(s): [${warnings}]`);
                }
                return configuration;
            }
        }
        return undefined;
    }
}
exports.GenericSourceUtils = GenericSourceUtils;
GenericSourceUtils.logger = new LambdaLogger_1.LambdaLogger();
GenericSourceUtils.configurationPath = 'src/configurations';
