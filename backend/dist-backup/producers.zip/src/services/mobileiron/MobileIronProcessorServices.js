"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobileIronProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const MobileIronEndpointService_1 = require("../../collectors/services/MobileIronEndpointService");
class MobileIronProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    getModelKeyProperties() {
        return ['guid'];
    }
    async obtainIdentifierChanges(mobileIronDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, mobileIronDevice.entityName, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        await this.verifyChange(currentTopology, mobileIronDevice.emailAddress, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
        await this.verifyChange(currentTopology, mobileIronDevice.wifiMacAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        await this.verifyChange(currentTopology, mobileIronDevice.serialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, mobileIronDevice.imei, CommonTypes_1.VertexType.IMEI, changes, unchanged);
        await this.verifyChange(currentTopology, mobileIronDevice.imei2, CommonTypes_1.VertexType.IMEI, changes, unchanged);
        await this.verifyChange(currentTopology, mobileIronDevice.phoneNumber, CommonTypes_1.VertexType.PHONE_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, mobileIronDevice.udid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new MobileIronEndpointService_1.MobileIronEndpointService(tenantUid, sourceId);
    }
}
exports.MobileIronProcessorServices = MobileIronProcessorServices;
