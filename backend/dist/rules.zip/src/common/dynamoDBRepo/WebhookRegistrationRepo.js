"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookRegistrationRepo = exports.WebhookRegistrationEntity = exports.WebhookRegistrationColdStart = exports.WebhookCompressionFormat = exports.WebhookRegistrationStatus = exports.WebhookNotificationType = void 0;
const DynamoDBServices_1 = require("../awsclient/dynamodb/DynamoDBServices");
const LambdaLogger_1 = require("../LambdaLogger");
const _ = __importStar(require("lodash"));
const uuid_1 = require("uuid");
const DynamodbServiceFactory_1 = require("../awsclient/dynamodb/DynamodbServiceFactory");
var WebhookNotificationType;
(function (WebhookNotificationType) {
    WebhookNotificationType["UPDATE"] = "UPDATE";
    WebhookNotificationType["MERGE"] = "MERGE";
    WebhookNotificationType["ALL"] = "ALL";
})(WebhookNotificationType = exports.WebhookNotificationType || (exports.WebhookNotificationType = {}));
var WebhookRegistrationStatus;
(function (WebhookRegistrationStatus) {
    WebhookRegistrationStatus["ACTIVE"] = "ACTIVE";
    WebhookRegistrationStatus["SUSPEND"] = "SUSPEND";
})(WebhookRegistrationStatus = exports.WebhookRegistrationStatus || (exports.WebhookRegistrationStatus = {}));
var WebhookCompressionFormat;
(function (WebhookCompressionFormat) {
    WebhookCompressionFormat["JSON"] = "JSON";
    WebhookCompressionFormat["GZIP"] = "GZIP";
})(WebhookCompressionFormat = exports.WebhookCompressionFormat || (exports.WebhookCompressionFormat = {}));
class WebhookRegistrationColdStart {
    constructor(enable, withHistory) {
        this.enable = enable;
        this.withHistory = withHistory;
        if (this.enable) {
            this.enabledAt = Date.now();
        }
    }
}
exports.WebhookRegistrationColdStart = WebhookRegistrationColdStart;
class WebhookRegistrationEntity {
    constructor(tenantUid, sourceTypes, notificationType, targetUrl, coldStart, compressionFormat) {
        this.webhookId = (0, uuid_1.v4)();
        this.tenantUid = tenantUid;
        this.sourceTypes = sourceTypes;
        this.targetUrl = targetUrl;
        this.notificationType = notificationType;
        this.compressionFormat = compressionFormat !== null && compressionFormat !== void 0 ? compressionFormat : WebhookCompressionFormat.GZIP;
        this.coldStart = coldStart;
        this.status = WebhookRegistrationStatus.ACTIVE;
        this.createdAt = Date.now();
        this.updatedAt = Date.now();
    }
}
exports.WebhookRegistrationEntity = WebhookRegistrationEntity;
class WebhookRegistrationRepo {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    static getDynamoDBGSIName() {
        return DynamoDBServices_1.DynamoDBServices.getTableName('wr-tenantuid-gsi');
    }
    async getByWebhookId(webhookId) {
        return this.dynamoDBServices.getByKey(WebhookRegistrationRepo.TABLE_NAME, WebhookRegistrationRepo.HASH_KEY, webhookId);
    }
    async getAllTenantWebhooks(tenantUid) {
        return this.dynamoDBServices.getItemsBySecondaryIndex(WebhookRegistrationRepo.TABLE_NAME, WebhookRegistrationRepo.getDynamoDBGSIName(), WebhookRegistrationRepo.GSI_KEY, tenantUid);
    }
    async getWebhookByTarget(tenantUid, targetUrl) {
        return (await this.dynamoDBServices.getItemsBySecondaryIndex(WebhookRegistrationRepo.TABLE_NAME, WebhookRegistrationRepo.getDynamoDBGSIName(), WebhookRegistrationRepo.GSI_KEY, tenantUid, '#targetUrl = :targetUrl', { '#targetUrl': 'targetUrl' }, { ':targetUrl': targetUrl }))[0];
    }
    async getTenantActiveWebhooks(tenantUid) {
        return this.dynamoDBServices.getItemsBySecondaryIndex(WebhookRegistrationRepo.TABLE_NAME, WebhookRegistrationRepo.getDynamoDBGSIName(), WebhookRegistrationRepo.GSI_KEY, tenantUid, '#status = :status', { '#status': 'status' }, { ':status': WebhookRegistrationStatus.ACTIVE });
    }
    async upsert(webhook) {
        webhook.updatedAt = Date.now();
        return this.dynamoDBServices.save(WebhookRegistrationRepo.TABLE_NAME, webhook);
    }
    async update(webhookId, sourceTypes, notificationType, compressionFormat, coldStart, targetUrl, status) {
        const key = { webhookId };
        const update = {};
        if (!_.isEmpty(sourceTypes)) {
            update.sourceTypes = sourceTypes;
        }
        if (!_.isNil(notificationType)) {
            update.notificationType = notificationType;
        }
        if (!_.isNil(compressionFormat)) {
            update.compressionFormat = compressionFormat;
        }
        if (!_.isNil(coldStart)) {
            update.coldStart = coldStart;
        }
        if (!_.isNil(targetUrl)) {
            update.targetUrl = targetUrl;
        }
        if (!_.isNil(status)) {
            update.status = status;
        }
        update.updatedAt = Date.now();
        return this.dynamoDBServices.update(WebhookRegistrationRepo.TABLE_NAME, key, update);
    }
    async hardDelete(webhookId) {
        return this.dynamoDBServices.delete(WebhookRegistrationRepo.TABLE_NAME, WebhookRegistrationRepo.HASH_KEY, webhookId);
    }
}
exports.WebhookRegistrationRepo = WebhookRegistrationRepo;
WebhookRegistrationRepo.TABLE_NAME = 'webhook-registration';
WebhookRegistrationRepo.HASH_KEY = 'webhookId';
WebhookRegistrationRepo.GSI_KEY = 'tenantUid';
