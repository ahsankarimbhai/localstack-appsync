"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProducerUtil = void 0;
const _ = __importStar(require("lodash"));
const uuid_1 = require("uuid");
const bluebird_1 = require("bluebird");
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const DuoProcessorServices_1 = require("../duo/DuoProcessorServices");
const DuoUsersProcessorServices_1 = require("../duo/DuoUsersProcessorServices");
const JamfProcessorServices_1 = require("../jamf/JamfProcessorServices");
const InTuneProcessorServices_1 = require("../intune/InTuneProcessorServices");
const CyberVisionProcessorServices_1 = require("../cybervision/CyberVisionProcessorServices");
const MerakiProcessorServices_1 = require("../meraki/MerakiProcessorServices");
const AmpProcessorServices_1 = require("../amp/AmpProcessorServices");
const TimestreamWriteServices_1 = require("../../common/TimestreamWriteServices");
const OrbitalProcessorServices_1 = require("../orbital/OrbitalProcessorServices");
const CustomProcessorServices_1 = require("../custom/CustomProcessorServices");
const UmbrellaProcessorServices_1 = require("../umbrella/UmbrellaProcessorServices");
const MobileIronProcessorServices_1 = require("../mobileiron/MobileIronProcessorServices");
const JamfCollectorServices_1 = require("../jamf/JamfCollectorServices");
const OrbitalCollectorServices_1 = require("../orbital/OrbitalCollectorServices");
const AmpCollectorServices_1 = require("../amp/AmpCollectorServices");
const UnifiedConnectorCollectorServices_1 = require("../unifiedconnector/UnifiedConnectorCollectorServices");
const UnifiedConnectorProcessorServices_1 = require("../unifiedconnector/UnifiedConnectorProcessorServices");
const ResourcesManager_1 = require("../../common/ResourcesManager");
const AirWatchProcessorServices_1 = require("../airwatch/AirWatchProcessorServices");
const ProcessingUtil_1 = require("../../common/ProcessingUtil");
const TimestreamRequestBuilder_1 = require("../../common/TimestreamRequestBuilder");
const GraphFactory_1 = require("../../model/GraphFactory");
const ServiceNowProcessorService_1 = require("../servicenow/ServiceNowProcessorService");
const SentinelOneProcessorServices_1 = require("../sentinelone/SentinelOneProcessorServices");
const CrowdStrikeProcessorServices_1 = require("../crowdstrike/CrowdStrikeProcessorServices");
const DefenderProcessorServices_1 = require("../defender/DefenderProcessorServices");
const AzureUsersProcessorServices_1 = require("../azure/AzureUsersProcessorServices");
const GenericSourceDeviceProcessorServices_1 = require("../generic/GenericSourceDeviceProcessorServices");
const Util_1 = require("../../common/Util");
const KinesisHelper_1 = require("../../common/kinesis/KinesisHelper");
const TrendVisionOneProcessorServices_1 = require("../trendvisionone/TrendVisionOneProcessorServices");
const TenantServices_1 = require("../../common/TenantServices");
class ProducerUtil extends ProcessingUtil_1.ProcessingUtil {
    async preProcessEventRecords(records) {
        const batches = _.chunk(records, this.bulkSize);
        try {
            for await (const batch of batches) {
                await this.preProcessRecordsBatch(batch);
            }
        }
        finally {
            await (0, ResourcesManager_1.closeConnections)();
            try {
                await this.reportCurrentMetrics();
            }
            catch (error) {
                this.logger.error('Error reporting current metrics to kinesis stream in preProcessEventRecords', error, records);
            }
        }
    }
    async preProcessRecordsBatch(records) {
        const outRecords = [];
        let recordsFailed = 0;
        let recordsSkipped = 0;
        let recordsBlocked = 0;
        let firstRecord = true;
        for (const record of records) {
            if (firstRecord) {
                this.logRecordsMetadata(record);
                firstRecord = false;
            }
            const recordData = (0, KinesisHelper_1.decodeData)(record);
            const metrics = await this.preProcessData(recordData.producer, recordData.tenantUid, recordData.data, outRecords);
            recordsSkipped += ProcessingUtil_1.ProcessingUtil.getMetricValueOrZero(metrics, TimestreamWriteServices_1.MetricName.RECORDS_SKIPPED);
            recordsFailed += ProcessingUtil_1.ProcessingUtil.getMetricValueOrZero(metrics, TimestreamWriteServices_1.MetricName.RECORDS_FAILED);
            recordsBlocked += ProcessingUtil_1.ProcessingUtil.getMetricValueOrZero(metrics, TimestreamWriteServices_1.MetricName.RECORDS_BLOCKED);
        }
        if (outRecords.length > 0) {
            try {
                await this.processingStream.putRecords(outRecords);
            }
            catch (error) {
                this.logger.error('Error putting records to processingStream in preProcessRecordsBatch', error, outRecords);
            }
        }
        this.logger.debug(`Pre-processed [${records.length - recordsFailed - recordsBlocked}] records out of [${records.length}]. Failed [${recordsFailed}]. Skipped [${recordsSkipped}]. Blocked [${recordsBlocked}]`);
    }
    async preProcessData(producer, tenantUid, data, outRecords, service) {
        let recordsSkipped = 0;
        let recordsFailed = 0;
        let recordsBlocked = 0;
        try {
            if (producer === 'JAMF__ed2f6e76-0d33-4831-b945-d47a90500cb5') {
                throw new Error('Blocked');
            }
            const isGenericFeatureFlagEnabled = await this.tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.GENERIC_SOURCE);
            const processingService = service || ProducerUtil.getProcessorServiceBySource(producer, tenantUid, isGenericFeatureFlagEnabled);
            let results;
            if (_.get(data, 'processingEventType', '') === 'delete') {
                const changes = [];
                changes.push(new Services_1.PostureTopologyChange(CommonTypes_1.ChangeType.DELETE, await (0, GraphFactory_1.createComplexVertex)(processingService.getPvType(), processingService.getPvLabel(), processingService.tenantUid, data, processingService.sourceId, processingService.getSourceConfiguration())));
                results = { changes, metrics: [new TimestreamWriteServices_1.Metric(CommonTypes_1.ChangeType.DELETE)] };
            }
            else {
                results = await processingService.obtainChanges(data);
            }
            this.addRecordMetrics(results.metrics, tenantUid, producer, CommonTypes_1.WorkFlow.PRE_PROCESSING);
            if (_.size(results.changes) === 0) {
                recordsSkipped += 1;
            }
            else {
                outRecords.push(ProducerUtil.createProcessingRecord(producer, tenantUid, results.changes));
            }
        }
        catch (err) {
            if (err.message === 'Blocked') {
                recordsBlocked += 1;
                this.logger.error(`Blocked record on pre-processing for ${producer} in ${tenantUid}`);
            }
            else {
                recordsFailed += 1;
                this.logger.error(`Failed with error [${err}] on pre-processing of ${JSON.stringify(data)} for ${producer} in ${tenantUid}`);
            }
        }
        const metrics = [
            new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL),
            new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_FAILED, recordsFailed),
            new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_SKIPPED, recordsSkipped)
        ];
        if (recordsBlocked > 0) {
            metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_BLOCKED, recordsBlocked));
        }
        this.addRecordMetrics(metrics, tenantUid, producer, CommonTypes_1.WorkFlow.PRE_PROCESSING);
        return metrics;
    }
    async processEventRecords(records, concurrency = 1) {
        let recordsFailed = 0;
        let recordsBlocked = 0;
        const allMetrics = [];
        const services = new Map();
        if (!_.isEmpty(records)) {
            this.logRecordsMetadata(_.head(records));
        }
        try {
            const res = await bluebird_1.Promise.map(records, async (record) => {
                const metrics = [];
                try {
                    const recordData = (0, KinesisHelper_1.decodeData)(record, false);
                    const tenantUid = recordData.tenantUid;
                    const producer = recordData.producer;
                    let service;
                    try {
                        if (producer === 'JAMF__ed2f6e76-0d33-4831-b945-d47a90500cb5') {
                            throw new Error('Blocked');
                        }
                        const changes = (0, KinesisHelper_1.inflateData)(recordData.data);
                        const started = Date.now();
                        const isGenericFeatureFlagEnabled = await this.tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.GENERIC_SOURCE);
                        service = ProducerUtil.getProducerService(services, producer, tenantUid, isGenericFeatureFlagEnabled);
                        const results = await service.applyChanges(changes);
                        if (results.durationMetrics.length > 0) {
                            metrics.push(...results.durationMetrics);
                        }
                        metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL));
                        metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.DURATION, Date.now() - started));
                        return { metrics, tenantUid, producer };
                    }
                    catch (err) {
                        if (err.message === 'Blocked') {
                            recordsBlocked += 1;
                            this.logger.error(`Blocked record on processing for ${producer} in ${tenantUid}`);
                            metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL));
                            metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_BLOCKED));
                        }
                        else {
                            recordsFailed += 1;
                            if (!service) {
                                this.logger.error(`Failed on processing ${JSON.stringify(record)}, no relevant service found`, err);
                                return { metrics, tenantUid, producer };
                            }
                            if (err.message
                                && (err.message.indexOf('ConcurrentModificationException') !== -1
                                    || err.message.indexOf('ConstraintViolationException') !== -1
                                    || err.message.indexOf('TimeLimitExceededException') !== -1
                                    || err.message.indexOf('MemoryLimitExceededException') !== -1)) {
                                if (recordData.retryCount && recordData.retryCount > ProducerUtil.MAX_RETRIES) {
                                    this.logger.error(`Failed on processing ${JSON.stringify(record)}`, err);
                                    return { metrics, tenantUid, producer };
                                }
                                recordData.retryCount = recordData.retryCount ? recordData.retryCount + 1 : 1;
                                this.logger.warn('Retry processing', err, JSON.stringify(recordData));
                                await this.processingStream.putRecord({
                                    Data: JSON.stringify(recordData),
                                    PartitionKey: (0, KinesisHelper_1.getPK)(producer, tenantUid, [(0, uuid_1.v4)()])
                                });
                                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RETRIES));
                            }
                            else {
                                this.logger.error(`Failed on processing ${JSON.stringify(record)}`, err);
                                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL));
                                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_FAILED));
                            }
                            return { metrics, tenantUid, producer };
                        }
                    }
                }
                catch (err) {
                    this.logger.error('Unexpected processing failure', err, record);
                }
                return { metrics };
            }, { concurrency });
            _.forEach(res, r => {
                if (r.tenantUid && r.producer) {
                    this.addRecordMetrics(r.metrics, r.tenantUid, r.producer, CommonTypes_1.WorkFlow.PROCESSING);
                }
            });
            allMetrics.push(_.flatten(_.map(res, r => r.metrics)));
        }
        finally {
            try {
                await this.reportCurrentMetrics();
            }
            catch (error) {
                this.logger.error('Error reporting current metrics to kinesis stream in processEventRecords', error, records);
            }
            this.logger.debug(`Processed [${records.length - recordsFailed - recordsBlocked}] records out of [${records.length}]. Failed [${recordsFailed}]. Blocked [${recordsBlocked}]`);
        }
        return allMetrics;
    }
    static createProcessingRecord(producer, tenantUid, changes) {
        const outData = JSON.stringify((0, KinesisHelper_1.getRecordData)(producer, tenantUid, changes));
        return {
            Data: outData,
            PartitionKey: (0, KinesisHelper_1.getPK)(producer, tenantUid, [(0, uuid_1.v4)()])
        };
    }
    static getProducerService(services, producer, tenantUid, isGenericFeatureFlagEnabled = false) {
        if (!services.has(producer)) {
            const newService = ProducerUtil.getProcessorServiceBySource(producer, tenantUid, isGenericFeatureFlagEnabled);
            services.set(producer, newService);
        }
        return services.get(producer);
    }
    logRecordsMetadata(record) {
        const sequenceNumber = record.kinesis.sequenceNumber;
        const streamPartitionKey = record.kinesis.partitionKey;
        const shardId = (0, KinesisHelper_1.getShardId)(record.eventId);
        this.logger.debug(`ShardId ${shardId}, partitionKey ${streamPartitionKey}, starting sequence number ${sequenceNumber}`);
    }
    static getProcessorServiceBySource(source, tenantUid, isGenericFeatureFlagEnabled = false) {
        switch (_.split(source, Util_1.SOURCE_SEPARATOR)[0]) {
            case CommonTypes_1.Source.DUO:
                return new DuoProcessorServices_1.DuoProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.DUO_USERS:
                return new DuoUsersProcessorServices_1.DuoUsersProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.JAMF:
                return new JamfProcessorServices_1.JamfProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.INTUNE:
                return new InTuneProcessorServices_1.InTuneProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.MERAKI:
                return new MerakiProcessorServices_1.MerakiProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.AMP:
                return new AmpProcessorServices_1.AmpProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.ORBITAL:
                return new OrbitalProcessorServices_1.OrbitalProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.UMBRELLA:
                return new UmbrellaProcessorServices_1.UmbrellaProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.MOBILEIRON:
                return new MobileIronProcessorServices_1.MobileIronProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.UNIFIED_CONNECTOR:
                return new UnifiedConnectorProcessorServices_1.UnifiedConnectorProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.AIRWATCH:
                return new AirWatchProcessorServices_1.AirWatchProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.SERVICENOW:
                if (isGenericFeatureFlagEnabled) {
                    return new GenericSourceDeviceProcessorServices_1.GenericSourceDeviceProcessorServices(tenantUid, source);
                }
                return new ServiceNowProcessorService_1.ServiceNowProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.SENTINEL_ONE:
                return new SentinelOneProcessorServices_1.SentinelOneProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.CYBERVISION:
                return new CyberVisionProcessorServices_1.CyberVisionProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.CROWDSTRIKE:
                return new CrowdStrikeProcessorServices_1.CrowdStrikeProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.DEFENDER:
                return new DefenderProcessorServices_1.DefenderProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.AZURE_USERS:
                return new AzureUsersProcessorServices_1.AzureUserProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.TREND_VISION_ONE:
                return new TrendVisionOneProcessorServices_1.TrendVisionOneProcessorServices(tenantUid, source);
            case CommonTypes_1.Source.CUSTOM:
                return new CustomProcessorServices_1.CustomProcessorServices(tenantUid, source);
            default:
                if (isGenericFeatureFlagEnabled) {
                    return new GenericSourceDeviceProcessorServices_1.GenericSourceDeviceProcessorServices(tenantUid, source);
                }
                throw new Error(`Got record data for unknown producer ${source}`);
        }
    }
    reportMetrics(metrics, tenantUid, producer, workflow) {
        const timestreamRequestBuilder = new TimestreamRequestBuilder_1.TimestreamRequestBuilder();
        timestreamRequestBuilder.add(metrics, TimestreamRequestBuilder_1.TimestreamRequestBuilder.basicDimensions(tenantUid, producer, workflow));
        return this.timestreamUtil.sendRequestsToStream(timestreamRequestBuilder.createRequestsAndReset());
    }
    static getPushCollectorService(tenantConfiguration, secrets, tenantUid, context, producerId, producerType) {
        let cfgValue;
        switch (producerType) {
            case CommonTypes_1.Source.JAMF:
                cfgValue = JSON.parse(tenantConfiguration.value);
                return new JamfCollectorServices_1.JamfCollectorServices(secrets, tenantUid, context.functionName, producerId);
            case CommonTypes_1.Source.ORBITAL:
                cfgValue = JSON.parse(tenantConfiguration.value);
                return new OrbitalCollectorServices_1.OrbitalCollectorServices(secrets, tenantUid, producerId, cfgValue.baseURL);
            case CommonTypes_1.Source.AMP:
                return new AmpCollectorServices_1.AmpCollectorServices(secrets, tenantUid, context.functionName, producerId);
            case CommonTypes_1.Source.UNIFIED_CONNECTOR:
                cfgValue = JSON.parse(tenantConfiguration.value);
                return new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(secrets, cfgValue.baseURL, cfgValue.adminBaseUrl, tenantUid, producerId);
            default:
                throw new Error(`unsupported push collector ${producerType}`);
        }
    }
}
exports.ProducerUtil = ProducerUtil;
ProducerUtil.MAX_RETRIES = 3;
