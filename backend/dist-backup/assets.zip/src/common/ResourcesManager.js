"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.closeConnections = void 0;
const ElasticsearchFactory_1 = require("./ElasticsearchFactory");
const NeptuneServicesFactory_1 = require("./neptune/NeptuneServicesFactory");
function closeConnections(shouldCloseNeptuneClient = false) {
    const resources = [(0, ElasticsearchFactory_1.closeElasticSearchClient)()];
    if (shouldCloseNeptuneClient) {
        resources.push((0, NeptuneServicesFactory_1.closeNeptuneClient)());
    }
    return Promise.all(resources);
}
exports.closeConnections = closeConnections;
