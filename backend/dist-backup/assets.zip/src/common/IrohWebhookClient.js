"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohWebhookClient = exports.WebhookType = exports.ChangeVisibilty = exports.EventType = void 0;
const lodash_1 = __importDefault(require("lodash"));
const axios_1 = __importDefault(require("axios"));
const LambdaLogger_1 = require("./LambdaLogger");
const IrohClient_1 = require("./IrohClient");
const Util_1 = require("./Util");
var EventType;
(function (EventType) {
    EventType["UPDATED"] = "module-instance/updated";
    EventType["DELETED"] = "module-instance/deleted";
    EventType["CREATED"] = "module-instance/created";
})(EventType = exports.EventType || (exports.EventType = {}));
var ChangeVisibilty;
(function (ChangeVisibilty) {
    ChangeVisibilty["ORG"] = "org";
})(ChangeVisibilty = exports.ChangeVisibilty || (exports.ChangeVisibilty = {}));
var WebhookType;
(function (WebhookType) {
    WebhookType["URL"] = "url";
})(WebhookType = exports.WebhookType || (exports.WebhookType = {}));
class IrohWebhookClient {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.clientId = undefined;
        if (!process.env.IROH_URI) {
            throw new Error('IROH_URI is not set');
        }
        this.irohUri = process.env.IROH_URI;
        if (!process.env.WEBHOOK_NOTIFICATION_BASE_URL) {
            throw new Error('WEBHOOK_NOTIFICATION_BASE_URL is not set');
        }
        this.axios = axios_1.default.create();
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'IrohWebhookClient');
    }
    async registerWebhook() {
        var _a, _b;
        try {
            this.logger.debug(`will be registered modules change notifications webhook for tenant ${this.tenantUid}`);
            const responseUrl = `${process.env.WEBHOOK_NOTIFICATION_BASE_URL}${IrohWebhookClient.DI_WEBHOOK_PATH}`;
            const clientId = await this.getClientId();
            const params = {
                url: responseUrl,
                enabled: true,
                visibility: ChangeVisibilty.ORG,
                webhook_type: WebhookType.URL,
                auth: { type: 'iroh-jwt', conf: { client_id: clientId } },
                event_type_filter: [EventType.UPDATED, EventType.CREATED, EventType.DELETED],
                event_filter_map: { module_instance_visibility: ChangeVisibilty.ORG },
                name: IrohWebhookClient.WEBHOOK_NAME,
                source: 'iroh-events'
            };
            const response = await this.axios.request(await this.getOptions(IrohWebhookClient.IROH_WEBHOOK_API_FULL_URL, params, 'post'));
            this.logger.debug(`registered modules change notifications webhook ${(_a = response.data) === null || _a === void 0 ? void 0 : _a.id} for tenant ${this.tenantUid}`);
            return response.data;
        }
        catch (err) {
            this.logger.error(`Failed to register webhook for tenant ${this.tenantUid}: ${err.message}. error data: ${JSON.stringify((_b = err.response) === null || _b === void 0 ? void 0 : _b.data)}`);
            throw err;
        }
    }
    async removeDIWebhooks() {
        var _a;
        try {
            this.logger.debug(`will be removing DI webhooks for tenant ${this.tenantUid}`);
            const diWebhook = await this.getDIWebhooks();
            if (diWebhook) {
                for (const dWh of diWebhook) {
                    const url = `${IrohWebhookClient.IROH_WEBHOOK_API_FULL_URL}/${dWh.id}`;
                    await this.axios.request(await this.getOptions(url, {}, 'delete'));
                }
            }
            this.logger.debug(`finished removing DI webhooks for tenant ${this.tenantUid}`);
        }
        catch (err) {
            this.logger.error(`Failed to remove DI Webhook: ${JSON.stringify(err.message)}. error data: ${JSON.stringify((_a = err.response) === null || _a === void 0 ? void 0 : _a.data)}`);
            throw err;
        }
    }
    async getWebhooks(webhookId) {
        var _a;
        try {
            let url = IrohWebhookClient.IROH_WEBHOOK_API_FULL_URL;
            if (!lodash_1.default.isEmpty(webhookId)) {
                url = `${url}/${webhookId}`;
            }
            const response = await this.axios.request(await this.getOptions(url));
            return response.data;
        }
        catch (err) {
            this.logger.error(`Failed to get webhooks: ${JSON.stringify(err.message)}, error data: ${JSON.stringify((_a = err.response) === null || _a === void 0 ? void 0 : _a.data)}`);
            throw err;
        }
    }
    async getDIWebhooks() {
        const webhooks = await this.getWebhooks();
        const clientId = await this.getClientId();
        return lodash_1.default.filter(webhooks, wh => wh.name === IrohWebhookClient.WEBHOOK_NAME && wh.client_id === clientId);
    }
    async isDIWebhookRegistered() {
        this.logger.debug(`checking if there is a DI Webhook registered for tenant ${this.tenantUid}`);
        const webhooks = await this.getDIWebhooks();
        const res = webhooks.length > 0;
        this.logger.debug(`result of checking if there is a DI Webhook registered for tenant ${this.tenantUid}: ${res}`);
        return res;
    }
    async getClientId() {
        if (!this.clientId) {
            const token = await (0, IrohClient_1.getAccessToken)(this.tenantUid);
            this.clientId = (0, IrohClient_1.getTokenClientId)(token);
        }
        return this.clientId || '';
    }
    async getOptions(url, data, method = 'get') {
        const token = await (0, IrohClient_1.getAccessToken)(this.tenantUid);
        return {
            method,
            baseURL: this.irohUri,
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${token}`
            },
            url,
            data
        };
    }
}
exports.IrohWebhookClient = IrohWebhookClient;
IrohWebhookClient.IROH_WEBHOOK_URI = '/iroh/iroh-webhook';
IrohWebhookClient.IROH_WEBHOOK_PATH = '/webhook';
IrohWebhookClient.IROH_WEBHOOK_API_FULL_URL = `${IrohWebhookClient.IROH_WEBHOOK_URI}${IrohWebhookClient.IROH_WEBHOOK_PATH}`;
IrohWebhookClient.DI_WEBHOOK_PATH = '/system/tenant/module-update';
IrohWebhookClient.WEBHOOK_NAME = 'DI Modules Webhook';
