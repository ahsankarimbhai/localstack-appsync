"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IncidentService = void 0;
const EventBridgeService_1 = require("../../common/awsclient/EventBridgeService");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const TenantServices_1 = require("../../common/TenantServices");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const lodash_1 = __importDefault(require("lodash"));
const IncidentTenantAgnosticService_1 = require("./IncidentTenantAgnosticService");
const uuid_1 = require("uuid");
const AssetsModel_1 = require("../../assets/AssetsModel");
const IncidentMappingRepo_1 = require("../../common/dynamoDBRepo/IncidentMappingRepo");
const CommonTypes_1 = require("../../common/CommonTypes");
const bluebird_1 = require("bluebird");
const Util_1 = require("../../common/Util");
class IncidentService {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.eventBridgeServices = new EventBridgeService_1.EventBridgeService();
        this.incidentTenantAgnosticService = new IncidentTenantAgnosticService_1.IncidentTenantAgnosticService();
        this.incidentMappingRepo = new IncidentMappingRepo_1.IncidentMappingRepo();
    }
    async saveMappingOnIdentToUnresolvedIdentity(incidentId, observables) {
        const wrongTypes = [];
        observables.forEach(observable => {
            if (!AssetsModel_1.StrongObservables.includes(observable.type)) {
                this.logger.error(`Incorrect data in observables: ${JSON.stringify(observable)}`);
                wrongTypes.push(observable.type);
            }
        });
        if (!lodash_1.default.isEmpty(wrongTypes)) {
            this.logger.error(`Wrong observableTypes: ${JSON.stringify(wrongTypes)}`);
            throw new Error(`Wrong observableTypes: ${JSON.stringify(wrongTypes)}`);
        }
        const entities = observables.map(observable => new IncidentMappingRepo_1.IncidentMappingEntity((0, uuid_1.v4)(), this.tenantUid, incidentId, IncidentService.stringifyObservable(observable.type, observable.value)));
        try {
            await this.incidentMappingRepo.create(entities);
        }
        catch (e) {
            this.logger.error('Internal error', e.message);
            throw new Error('Internal error');
        }
    }
    async publishEvents(evt, busArn, chunkSize = 50) {
        if (!evt.deviceIds || evt.deviceIds.length === 0) {
            return;
        }
        const deviceIdChunks = lodash_1.default.chunk(evt.deviceIds, chunkSize);
        await bluebird_1.Promise.map(deviceIdChunks, async (chunk) => {
            const taskName = 'incidents-notification';
            const evtReq = {
                EventBusName: busArn,
                Source: `${process.env.ENV_PREFIX}-${taskName}`,
                DetailType: 'detail',
                Detail: JSON.stringify({
                    targetTask: taskName,
                    eventBridgeData: {
                        tenantId: evt.tenantId,
                        deviceIds: chunk
                    }
                })
            };
            this.logger.debug('Publishing to incident event bridge event:', JSON.stringify(evtReq));
            await this.eventBridgeServices.publish([evtReq]);
        });
    }
    async notifyIroIfDeviceHasMappedIncident(incidentProcessingEvent) {
        const esService = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        const fields = ['labels', 'assetValue', 'rulesLabels', 'rulesAssetValue', 'incidents'];
        if (incidentProcessingEvent.deviceIds && !lodash_1.default.isEmpty(incidentProcessingEvent.deviceIds)) {
            const deviceIdsAndIncidents = await esService.getSpecificFields(incidentProcessingEvent.deviceIds, fields);
            const devicesWithIncidents = deviceIdsAndIncidents.filter(deviceWithIncident => !lodash_1.default.isUndefined(deviceWithIncident._source.incidents));
            if (!lodash_1.default.isEmpty(devicesWithIncidents)) {
                this.logger.info(`notify iroh with devices: ${JSON.stringify(devicesWithIncidents)}`);
                const message = this.convertToNotification(deviceIdsAndIncidents);
                this.incidentTenantAgnosticService.notifyIroh(message);
            }
        }
    }
    async unresolvedMappingProcessing(mergedEndpoint) {
        if (!mergedEndpoint || !(await this.isFFEnabled())) {
            return;
        }
        const observables = this.getObservables(mergedEndpoint);
        await bluebird_1.Promise.map(observables, async (observable) => {
            const mappings = await this.incidentMappingRepo.getByObservable(observable, this.tenantUid);
            if (!lodash_1.default.isEmpty(mappings)) {
                const messages = mappings.map(mapping => this.convertMergedEndpointToNotification(mergedEndpoint, mapping.incidentId));
                messages.forEach(message => this.incidentTenantAgnosticService.notifyIroh(message));
                for (const mapping of mappings) {
                    await this.incidentMappingRepo.markNotifiedAndSetExpirationTime(this.tenantUid, mapping.id);
                }
            }
        });
    }
    async getBusArnIfTenantIsSupportedIncidents() {
        if (await this.isFFEnabled()) {
            if (!process.env.DEVICE_CHANGE_NOTIFICATION_EVENT_BUS_ARN) {
                throw new Error('DEVICE_CHANGE_NOTIFICATION_EVENT_BUS_ARN is not set');
            }
            return process.env.DEVICE_CHANGE_NOTIFICATION_EVENT_BUS_ARN;
        }
        this.logger.debug(`Tenant ${this.tenantUid} does not support incidents`);
        return undefined;
    }
    async isFFEnabled() {
        return new TenantServices_1.TenantServices().isTenantFeatureOn(this.tenantUid, TenantServices_1.FeatureFlag.INCIDENTS_ENABLED);
    }
    async deleteAllMappings() {
        this.logger.info(`All incident mappings for the tenant ${this.tenantUid} will be deleted`);
        return this.incidentMappingRepo.deleteAllEntities(this.tenantUid);
    }
    convertToNotification(deviceIdsAndIncidents) {
        this.logger.debug(`convert to iroh notification: ${JSON.stringify(deviceIdsAndIncidents)}`);
        return deviceIdsAndIncidents;
    }
    convertMergedEndpointToNotification(mergedEndpoint, incidentId) {
        this.logger.debug(`convert to iroh notification: ${JSON.stringify(mergedEndpoint)}`);
        return { deviceId: mergedEndpoint.uid, incidentId };
    }
    getObservables(mergedEndpoint) {
        const observables = [];
        for (const producer of mergedEndpoint.producers) {
            const producerExtId = (0, Util_1.getProducerExtId)(producer.uid);
            if (producerExtId) {
                switch (producer.type) {
                    case CommonTypes_1.Source.UNIFIED_CONNECTOR:
                        observables.push(IncidentService.stringifyObservable(AssetsModel_1.AssetObservablesType.CISCO_UC_ID, producerExtId));
                        break;
                    case CommonTypes_1.Source.ORBITAL:
                        observables.push(IncidentService.stringifyObservable(AssetsModel_1.AssetObservablesType.ORBITAL_NODE_ID, producerExtId));
                        break;
                    case CommonTypes_1.Source.AMP:
                        observables.push(IncidentService.stringifyObservable(AssetsModel_1.AssetObservablesType.AMP_COMPUTER_GUID, producerExtId));
                        break;
                    case CommonTypes_1.Source.UMBRELLA:
                        observables.push(IncidentService.stringifyObservable(AssetsModel_1.AssetObservablesType.UMBRELLA_ODNS_IDENTITY, producerExtId));
                        break;
                    case CommonTypes_1.Source.CROWDSTRIKE:
                        observables.push(IncidentService.stringifyObservable(AssetsModel_1.AssetObservablesType.CROWDSTRIKE_ID, producerExtId));
                        break;
                    case CommonTypes_1.Source.SENTINEL_ONE:
                        observables.push(IncidentService.stringifyObservable(AssetsModel_1.AssetObservablesType.S1_AGENT_ID, producerExtId));
                        break;
                    case CommonTypes_1.Source.DEFENDER:
                        observables.push(IncidentService.stringifyObservable(AssetsModel_1.AssetObservablesType.MS_MACHINE_ID, producerExtId));
                        break;
                    default:
                }
            }
        }
        return observables;
    }
    static stringifyObservable(type, value) {
        return type.concat(IncidentService.OBSERVABLE_DELIMITER, value);
    }
}
exports.IncidentService = IncidentService;
IncidentService.OBSERVABLE_DELIMITER = '|';
