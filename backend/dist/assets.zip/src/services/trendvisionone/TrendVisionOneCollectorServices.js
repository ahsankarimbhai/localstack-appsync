"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrendVisionOneCollectorServices = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const TrendVisionOneDevicesCollection_1 = require("./TrendVisionOneDevicesCollection");
const LIMIT = 200;
const TREND_VISION_ONE_VERSION = 'v3.0';
class TrendVisionOneCollectorServices extends Services_1.BaseCollectorService {
    constructor(secrets, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.functionName = functionName;
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.TREND_VISION_ONE, this.sourceId);
        }
    }
    async getDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.TREND_VISION_ONE));
        const bulkLength = limit || LIMIT;
        const ret = new TrendVisionOneDevicesCollection_1.TrendVisionOneDevicesCollection(this.client, nextUri || `/${TREND_VISION_ONE_VERSION}/eiqs/endpoints?top=${bulkLength}`, timeBasedAsyncLambdaInvoker, functionState);
        return ret;
    }
}
exports.TrendVisionOneCollectorServices = TrendVisionOneCollectorServices;
