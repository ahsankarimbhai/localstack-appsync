"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobileIronCollectorServices = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const MobileIronDevicesCollection_1 = require("./MobileIronDevicesCollection");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const index_1 = require("../../index");
class MobileIronCollectorServices extends Services_1.BaseCollectorService {
    constructor(secrets, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.functionName = functionName;
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.MOBILEIRON, this.sourceId);
        }
    }
    async getMobileIronDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        var _a, _b, _c, _d;
        try {
            await this.init();
            let dmPartitionId;
            if (!nextUri) {
                dmPartitionId = (await this.client.get('api/v1/metadata/tenant')).data.result.defaultDmPartitionId;
            }
            const bulkLength = limit || MobileIronCollectorServices.LIMIT;
            const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.MOBILEIRON));
            return new MobileIronDevicesCollection_1.MobileIronDevicesCollection(this.client, nextUri || `api/v1/device/?dmPartitionId=${dmPartitionId}&rows=${bulkLength}&start=0`, timeBasedAsyncLambdaInvoker, functionState);
        }
        catch (err) {
            if (err.response) {
                if (typeof ((_a = err.response.data) === null || _a === void 0 ? void 0 : _a.error_description) === 'string') {
                    let message = err.response.data.error_description;
                    if (message.substring(message.length - 1).indexOf('.') === 0) {
                        message = message.substring(0, message.length - 1);
                    }
                    err.message = `${message}. `;
                }
                else if (err.response) {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                if (err.response.status === 400) {
                    err.message += 'Please verify the MobileIron module Base URL';
                }
                if (err.response.status === 401) {
                    err.message += 'Please verify the MobileIron module credentials';
                }
                index_1.logger.error(`AxiosError occurred in MobileIronCollectorServices where message='${err.message}', status=${(_b = err.response) === null || _b === void 0 ? void 0 : _b.status}, statusText=${(_c = err.response) === null || _c === void 0 ? void 0 : _c.statusText}, data=${JSON.stringify((_d = err.response) === null || _d === void 0 ? void 0 : _d.data)}`);
                throw err;
            }
            throw err;
        }
    }
}
exports.MobileIronCollectorServices = MobileIronCollectorServices;
MobileIronCollectorServices.LIMIT = 100;
