"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceNowCollection = void 0;
const Collection_1 = require("../../common/Collection");
function extractNextLink(res) {
    if (!res.headers.link) {
        return undefined;
    }
    const links = res.headers.link.split(',');
    for (const link of links) {
        if (link.indexOf('rel="next"') > -1) {
            const hostString = '://';
            const hostIndex = link.indexOf(hostString);
            const nextUriIndex = link.indexOf('/', hostIndex + hostString.length);
            const endIndex = link.indexOf('>', nextUriIndex + 1);
            if (nextUriIndex > -1 && endIndex > -1) {
                return link.substring(nextUriIndex + 1, endIndex);
            }
        }
    }
    return undefined;
}
function extractData(res) {
    return res.data.result;
}
class ServiceNowCollection extends Collection_1.Collection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, extractNextLink, extractData, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.ServiceNowCollection = ServiceNowCollection;
