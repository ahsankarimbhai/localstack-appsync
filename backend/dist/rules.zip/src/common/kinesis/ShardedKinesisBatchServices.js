"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShardedKinesisBatchServices = void 0;
const KinesisBatchServices_1 = require("./KinesisBatchServices");
const ShardingServices_1 = require("../neptune/ShardingServices");
const KinesisHelper_1 = require("./KinesisHelper");
class ShardedKinesisBatchServices {
    constructor(streams, batchSize = KinesisHelper_1.DEFAULT_BATCH_SIZE) {
        this.streams = streams;
        this.batchSize = batchSize;
        this.shardingServices = new ShardingServices_1.ShardingServices();
        this.shardKinesisBatchSvcMap = new Map();
        for (const stream of streams) {
            this.shardKinesisBatchSvcMap.set(stream.streamId, new KinesisBatchServices_1.KinesisBatchServices(stream.baseName, batchSize));
        }
    }
    async putRecord(record) {
        const shardId = await this.getShardId(record.Data);
        return this.getKinesisBatchSvc(shardId).putRecord(record);
    }
    async putRecords(records) {
        var _a;
        const shardedRecordsMap = new Map();
        for (const record of records) {
            const shardId = await this.getShardId(record.Data);
            const entries = (_a = shardedRecordsMap.get(shardId)) !== null && _a !== void 0 ? _a : [];
            entries.push(record);
            shardedRecordsMap.set(shardId, entries);
        }
        const promises = [];
        for (const [shardId, entries] of shardedRecordsMap) {
            promises.push(this.getKinesisBatchSvc(shardId).putRecords(entries));
        }
        return Promise.all(promises);
    }
    async addRecord(putRecordEntry) {
        const shardId = await this.getShardId(putRecordEntry.Data);
        await this.getKinesisBatchSvc(shardId).addRecord(putRecordEntry);
    }
    async commit() {
        let committed = 0;
        for (const kinesisBatchSvc of this.shardKinesisBatchSvcMap.values()) {
            committed += await kinesisBatchSvc.commit();
        }
        return committed;
    }
    async getShardId(data) {
        var _a;
        try {
            const tenantUid = (_a = JSON.parse(data)) === null || _a === void 0 ? void 0 : _a.tenantUid;
            if (!tenantUid) {
                throw new Error('tenantUid must be provided when sending data with ShardedKinesisBatchServices');
            }
            const tenantShard = await this.shardingServices.getCachedNeptuneCluster(tenantUid);
            return tenantShard.shardId;
        }
        catch (err) {
            throw new Error(`failed to retrieve tenant's shardId, error: ${err.message}`);
        }
    }
    getKinesisBatchSvc(shardId) {
        const kinesisBatchSvc = this.shardKinesisBatchSvcMap.get(shardId);
        if (!kinesisBatchSvc) {
            throw new Error(`KinesisBatchServices is not initialized for shardId ${shardId}`);
        }
        return kinesisBatchSvc;
    }
}
exports.ShardedKinesisBatchServices = ShardedKinesisBatchServices;
