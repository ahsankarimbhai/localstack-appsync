"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InTuneDeviceStateModelService = exports.InTuneDeviceStateModel = exports.InTuneDeviceModelService = exports.InTuneDeviceModel = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class InTuneDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.IN_TUNE_DEVICE;
    }
    async initProperties(inTuneDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, inTuneDevice.id);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.InTuneDeviceModel = InTuneDeviceModel;
class InTuneDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new InTuneDeviceModel(this.partitionKey);
    }
}
exports.InTuneDeviceModelService = InTuneDeviceModelService;
class InTuneDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.IN_TUNE_DEVICE_STATE;
    }
    async initProperties(inTuneDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(inTuneDevice, ['lastSyncDateTime'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.IS_MANAGED, true);
        _.forEach(_.toPairs(inTuneDevice), (pair) => {
            if (!InTuneDeviceStateModel.EXTERNAL_PROPERTIES.includes(pair[0])) {
                if (pair[0] === 'id') {
                    return;
                }
                switch (pair[0]) {
                    case 'deviceName':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, pair[1]);
                        break;
                    case 'operatingSystem':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(pair[1]));
                        break;
                    case 'osVersion':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, pair[1]);
                        break;
                    case 'lastSyncDateTime':
                        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(pair[1]));
                        break;
                    case 'complianceState':
                        switch (pair[1]) {
                            case 'compliant':
                                this.setProperty(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT, true);
                                break;
                            case 'noncompliant':
                            case 'inGracePeriod':
                            default:
                                this.setProperty(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT, false);
                                break;
                        }
                    default:
                        this.setProperty(_.camelCase(pair[0]), pair[1]);
                }
            }
        });
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(inTuneDevice.operatingSystem, inTuneDevice.osVersion));
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, inTuneDevice.operatingSystem, inTuneDevice.osVersion);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.InTuneDeviceStateModel = InTuneDeviceStateModel;
InTuneDeviceStateModel.EXTERNAL_PROPERTIES = [
    'userPrincipalName',
    'serialNumber',
    'wiFiMacAddress',
    'emailAddress',
    'imei'
];
InTuneDeviceStateModel.JAIL_BROKEN_KEY = 'jailBroken';
InTuneDeviceStateModel.IS_SUPERVISED_KEY = 'isSupervised';
InTuneDeviceStateModel.IS_ENCRYPTED_KEY = 'isEncrypted';
InTuneDeviceStateModel.MODEL_KEY = 'model';
InTuneDeviceStateModel.ANDROID_SECURITY_PATCH_LEVEL_KEY = 'androidSecurityPatchLevel';
class InTuneDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new InTuneDeviceStateModel(this.partitionKey);
    }
}
exports.InTuneDeviceStateModelService = InTuneDeviceStateModelService;
