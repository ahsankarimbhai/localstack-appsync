"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyWebhookToken = exports.verifyWebhookSignature = exports.isJwt = exports.extractTokenFromHeader = exports.getIssuer = exports.getUser = exports.logger = exports.AMP_FINGERPRINT_HEADER_NAME = exports.AMP_TENANT_UID_HEADER_NAME = void 0;
const _ = __importStar(require("lodash"));
const crypto_1 = require("crypto");
const LambdaLogger_1 = require("../LambdaLogger");
const EMAIL_CLAIM = 'email';
const ISSUER_CLAIM = 'iss';
const UNKNOWN = 'unknown';
const BEARER = 'Bearer';
exports.AMP_TENANT_UID_HEADER_NAME = 'X-Posture-Tenantuid';
exports.AMP_FINGERPRINT_HEADER_NAME = 'Sha256-Fingerprint';
exports.logger = new LambdaLogger_1.LambdaLogger();
const getUser = (decodedToken) => _.get(decodedToken, EMAIL_CLAIM, UNKNOWN);
exports.getUser = getUser;
const getIssuer = (decodedToken) => _.get(decodedToken, ISSUER_CLAIM, UNKNOWN);
exports.getIssuer = getIssuer;
const extractTokenFromHeader = (authorization) => (_.startsWith(authorization, BEARER) ? _.split(authorization, ' ')[1] : authorization);
exports.extractTokenFromHeader = extractTokenFromHeader;
const isJwt = (token) => (_.size(_.split(token, '.')) === 3);
exports.isJwt = isJwt;
const verifyWebhookSignature = (payload, sig, webhookSecret) => {
    const hmac = (0, crypto_1.createHmac)('sha256', webhookSecret);
    const digest = Buffer.from(hmac.update(payload).digest('hex'), 'utf8');
    const checksum = Buffer.from(sig, 'utf8');
    if (checksum.length !== digest.length || !(0, crypto_1.timingSafeEqual)(digest, checksum)) {
        exports.logger.error(`Request body digest (${digest}) did not match checksum (${checksum})`);
        return false;
    }
    return true;
};
exports.verifyWebhookSignature = verifyWebhookSignature;
const verifyWebhookToken = (headerToken, webhookAuthToken) => {
    if (headerToken !== `Token ${webhookAuthToken}`) {
        exports.logger.error(`authorization header value ${headerToken} does not match expected value`);
        return false;
    }
    return true;
};
exports.verifyWebhookToken = verifyWebhookToken;
