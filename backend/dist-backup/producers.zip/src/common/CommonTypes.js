"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sourceToFetchFunctionName = exports.sourceToVertexType = exports.vertexTypeToSource = exports.personIdentifierEdgeTypes = exports.personIdentifierVertexTypes = exports.identifierEdgeTypes = exports.identifierVertexTypes = exports.normalize = exports.valueOrJsonString = exports.empty = exports.setPropertyByTimestamp = exports.setOsProperties = exports.setOsSupport = exports.getOsSupport = exports.osVersionsToMap = exports.getNewestFamilyVersionAndNumericParts = exports.filterFamilyVersionsByParts = exports.parseVersionForOsSupport = exports.val = exports.setOsHumanReadableVersionPhrase = exports.newPhraseLowersDetailHeuristic = exports.extractNumericOsVersionFromAvailableOsDataFields = exports.isOSVersionTextOnly = exports.getOsVersion = exports.getOsType = exports.getChangeType = exports.WorkFlow = exports.ChangeType = exports.OS = exports.OsSupport = exports.VertexStateProperty = exports.VertexBasicProperty = exports.EdgeBasicProperty = exports.BasicProperty = exports.EdgeType = exports.sourceToVertexTypeMapping = exports.VertexType = exports.AccountStatus = exports.EndpointType = exports.sourceNotSupportingPull = exports.sourceWithLessSync = exports.sourceSupportsWebhooks = exports.allSources = exports.Source = exports.SUM_OF_ALL_POSSIBLE_ASSET_VALUES = exports.COUNT_ALL_POSSIBLE_ASSET_VALUES = exports.ASSET_VALUE_UPPER_BOUND = exports.ASSET_VALUE_LOWER_BOUND = exports.NUMERIC_DOTTED_PATTERN = exports.NA = void 0;
exports.isOnlySecureClientDevices = exports.getCloudMgmtVersionNumbers = exports.osToFamily = exports.OperatingSystemFamily = exports.ModificationOrigin = void 0;
const _ = __importStar(require("lodash"));
const uuid_1 = require("uuid");
const LambdaLogger_1 = require("./LambdaLogger");
exports.NA = 'na';
exports.NUMERIC_DOTTED_PATTERN = '\\d+(?:\\.\\w+)+$';
const MORE_THAN_1_DOT_VERSION_PATTERN = '\\d+\\.\\d+(?:\\.\\w+)+';
exports.ASSET_VALUE_LOWER_BOUND = 1;
exports.ASSET_VALUE_UPPER_BOUND = 10;
exports.COUNT_ALL_POSSIBLE_ASSET_VALUES = exports.ASSET_VALUE_UPPER_BOUND - exports.ASSET_VALUE_LOWER_BOUND + 1;
exports.SUM_OF_ALL_POSSIBLE_ASSET_VALUES = exports.COUNT_ALL_POSSIBLE_ASSET_VALUES * ((exports.ASSET_VALUE_UPPER_BOUND + exports.ASSET_VALUE_LOWER_BOUND) / 2);
var Source;
(function (Source) {
    Source["DUO"] = "Duo";
    Source["DUO_USERS"] = "DuoUsers";
    Source["AMP"] = "AMP";
    Source["JAMF"] = "JAMF";
    Source["INTUNE"] = "InTune";
    Source["MERAKI"] = "Meraki";
    Source["ORBITAL"] = "Orbital";
    Source["ISE"] = "ISE";
    Source["CUSTOM"] = "Custom";
    Source["UMBRELLA"] = "Umbrella";
    Source["MOBILEIRON"] = "MobileIron";
    Source["UNIFIED_CONNECTOR"] = "UnifiedConnector";
    Source["AIRWATCH"] = "AirWatch";
    Source["SERVICENOW"] = "ServiceNow";
    Source["SENTINEL_ONE"] = "SentinelOne";
    Source["CYBERVISION"] = "CyberVision";
    Source["CROWDSTRIKE"] = "CrowdStrike";
    Source["DEFENDER"] = "Defender";
    Source["AZURE_USERS"] = "AzureUsers";
    Source["TREND_VISION_ONE"] = "TrendVisionOne";
    Source["CORTEX"] = "Cortex";
})(Source = exports.Source || (exports.Source = {}));
const allSources = () => _.values(Source);
exports.allSources = allSources;
const sourceSupportsWebhooks = (src) => _.includes([Source.JAMF, Source.ORBITAL, Source.AMP, Source.UNIFIED_CONNECTOR], src);
exports.sourceSupportsWebhooks = sourceSupportsWebhooks;
const sourceWithLessSync = (src) => _.includes([Source.JAMF, Source.AMP], src);
exports.sourceWithLessSync = sourceWithLessSync;
const sourceNotSupportingPull = (src) => _.includes([Source.ORBITAL, Source.CUSTOM], src);
exports.sourceNotSupportingPull = sourceNotSupportingPull;
var EndpointType;
(function (EndpointType) {
    EndpointType["SERVER"] = "server";
    EndpointType["DESKTOP"] = "Desktop";
    EndpointType["VIRTUAL"] = "Virtual";
    EndpointType["MOBILE"] = "Mobile";
})(EndpointType = exports.EndpointType || (exports.EndpointType = {}));
var AccountStatus;
(function (AccountStatus) {
    AccountStatus["ENABLED"] = "Enabled";
    AccountStatus["DISABLED"] = "Disabled";
})(AccountStatus = exports.AccountStatus || (exports.AccountStatus = {}));
var VertexType;
(function (VertexType) {
    VertexType["AMP_COMPUTER"] = "ampComputer";
    VertexType["AMP_COMPUTER_STATE"] = "ampComputerState";
    VertexType["MERAKI_SM_DEVICE"] = "merakiSmDevice";
    VertexType["MERAKI_SM_DEVICE_STATE"] = "merakiSmDeviceState";
    VertexType["JAMF_COMPUTER"] = "jamfComputer";
    VertexType["JAMF_COMPUTER_STATE"] = "jamfComputerState";
    VertexType["IN_TUNE_DEVICE"] = "inTuneDevice";
    VertexType["IN_TUNE_DEVICE_STATE"] = "inTuneDeviceState";
    VertexType["DUO_ENDPOINT"] = "duoEndpoint";
    VertexType["DUO_ENDPOINT_STATE"] = "duoEndpointState";
    VertexType["DUO_USER"] = "duoUser";
    VertexType["DUO_USER_STATE"] = "duoUserState";
    VertexType["ORBITAL_ENDPOINT"] = "orbitalEndpoint";
    VertexType["ORBITAL_ENDPOINT_STATE"] = "orbitalEndpointState";
    VertexType["CUSTOM_ENDPOINT"] = "customEndpoint";
    VertexType["CUSTOM_ENDPOINT_STATE"] = "customEndpointState";
    VertexType["MAC_ADDRESS"] = "macAddress";
    VertexType["INTERNAL_IP_ADDRESS"] = "internalIpAddress";
    VertexType["EXTERNAL_IP_ADDRESS"] = "externalIpAddress";
    VertexType["SERIAL_NUMBER"] = "serialNumber";
    VertexType["IMEI"] = "imei";
    VertexType["HOSTNAME"] = "hostname";
    VertexType["BROWSER"] = "browser";
    VertexType["EXTERNAL_REFERENCE"] = "externalReference";
    VertexType["PHONE_NUMBER"] = "phoneNumber";
    VertexType["HARDWARE_ID"] = "hardwareId";
    VertexType["COMPUTER_SID"] = "computerSID";
    VertexType["USER"] = "user";
    VertexType["APP_USER"] = "appUser";
    VertexType["EMAIL"] = "email";
    VertexType["COOKIE"] = "cookie";
    VertexType["POSTURE_ENDPOINT"] = "postureEndpoint";
    VertexType["POSTURE_PERSON"] = "posturePerson";
    VertexType["UNDEFINED"] = "undefined";
    VertexType["VULNERABILITY"] = "vulnerability";
    VertexType["UMBRELLA_ROAMING_COMPUTER"] = "umbrellaRoamingComputer";
    VertexType["UMBRELLA_ROAMING_COMPUTER_STATE"] = "umbrellaRoamingComputerState";
    VertexType["MOBILE_IRON_DEVICE"] = "mobileIronDevice";
    VertexType["MOBILE_IRON_DEVICE_STATE"] = "mobileIronDeviceState";
    VertexType["UNIFIED_CONNECTOR_DEVICE"] = "unifiedConnectorDevice";
    VertexType["UNIFIED_CONNECTOR_DEVICE_STATE"] = "unifiedConnectorDeviceState";
    VertexType["AIR_WATCH_DEVICE"] = "airWatchDevice";
    VertexType["AIR_WATCH_DEVICE_STATE"] = "airWatchDeviceState";
    VertexType["SERVICE_NOW_DEVICE"] = "serviceNowDevice";
    VertexType["SERVICE_NOW_DEVICE_STATE"] = "serviceNowDeviceState";
    VertexType["SENTINEL_ONE_DEVICE"] = "sentinelOneDevice";
    VertexType["SENTINEL_ONE_DEVICE_STATE"] = "sentinelOneDeviceState";
    VertexType["CYBER_VISION_DEVICE"] = "cyberVisionDevice";
    VertexType["CYBER_VISION_DEVICE_STATE"] = "cyberVisionDeviceState";
    VertexType["CROWD_STRIKE_DEVICE"] = "crowdStrikeDevice";
    VertexType["CROWD_STRIKE_DEVICE_STATE"] = "crowdStrikeDeviceState";
    VertexType["DEFENDER_DEVICE"] = "defenderDevice";
    VertexType["DEFENDER_DEVICE_STATE"] = "defenderDeviceState";
    VertexType["AZURE_DEVICE"] = "azureDevice";
    VertexType["AZURE_DEVICE_STATE"] = "azureDeviceState";
    VertexType["AZURE_USER"] = "azureUser";
    VertexType["AZURE_USER_STATE"] = "azureUserState";
    VertexType["TREND_VISION_ONE_DEVICE"] = "trendVisionOneDevice";
    VertexType["TREND_VISION_ONE_DEVICE_STATE"] = "trendVisionOneDeviceState";
    VertexType["GENERIC_SOURCE_DEVICE"] = "genericSourceDevice";
    VertexType["GENERIC_SOURCE_DEVICE_STATE"] = "genericSourceDeviceState";
})(VertexType = exports.VertexType || (exports.VertexType = {}));
exports.sourceToVertexTypeMapping = {};
exports.sourceToVertexTypeMapping[Source.AMP] = VertexType.AMP_COMPUTER;
exports.sourceToVertexTypeMapping[Source.DUO] = VertexType.DUO_ENDPOINT;
exports.sourceToVertexTypeMapping[Source.DUO_USERS] = VertexType.DUO_USER;
exports.sourceToVertexTypeMapping[Source.INTUNE] = VertexType.IN_TUNE_DEVICE;
exports.sourceToVertexTypeMapping[Source.MERAKI] = VertexType.MERAKI_SM_DEVICE;
exports.sourceToVertexTypeMapping[Source.JAMF] = VertexType.JAMF_COMPUTER;
exports.sourceToVertexTypeMapping[Source.UMBRELLA] = VertexType.UMBRELLA_ROAMING_COMPUTER;
exports.sourceToVertexTypeMapping[Source.MOBILEIRON] = VertexType.MOBILE_IRON_DEVICE;
exports.sourceToVertexTypeMapping[Source.ORBITAL] = VertexType.ORBITAL_ENDPOINT;
exports.sourceToVertexTypeMapping[Source.CUSTOM] = VertexType.CUSTOM_ENDPOINT;
exports.sourceToVertexTypeMapping[Source.UNIFIED_CONNECTOR] = VertexType.UNIFIED_CONNECTOR_DEVICE;
exports.sourceToVertexTypeMapping[Source.AIRWATCH] = VertexType.AIR_WATCH_DEVICE;
exports.sourceToVertexTypeMapping[Source.SERVICENOW] = VertexType.SERVICE_NOW_DEVICE;
exports.sourceToVertexTypeMapping[Source.SENTINEL_ONE] = VertexType.SENTINEL_ONE_DEVICE;
exports.sourceToVertexTypeMapping[Source.CYBERVISION] = VertexType.CYBER_VISION_DEVICE;
exports.sourceToVertexTypeMapping[Source.CROWDSTRIKE] = VertexType.CROWD_STRIKE_DEVICE;
exports.sourceToVertexTypeMapping[Source.DEFENDER] = VertexType.DEFENDER_DEVICE;
exports.sourceToVertexTypeMapping[Source.AZURE_USERS] = VertexType.AZURE_USER;
exports.sourceToVertexTypeMapping[Source.TREND_VISION_ONE] = VertexType.TREND_VISION_ONE_DEVICE;
const vertexTypeToSourceMapping = _.invert(exports.sourceToVertexTypeMapping);
const sourceToFetchFunctionNameMapping = {};
sourceToFetchFunctionNameMapping[Source.AMP] = 'fetch-amp-computers';
sourceToFetchFunctionNameMapping[Source.DUO] = 'fetch-duo-endpoints';
sourceToFetchFunctionNameMapping[Source.DUO_USERS] = 'fetch-duo-users';
sourceToFetchFunctionNameMapping[Source.INTUNE] = 'fetch-intune-devices';
sourceToFetchFunctionNameMapping[Source.MERAKI] = 'fetch-meraki-devices';
sourceToFetchFunctionNameMapping[Source.JAMF] = 'fetch-jamf-computers';
sourceToFetchFunctionNameMapping[Source.UMBRELLA] = 'fetch-umbrella-roaming-computers';
sourceToFetchFunctionNameMapping[Source.MOBILEIRON] = 'fetch-mobileiron-devices';
sourceToFetchFunctionNameMapping[Source.UNIFIED_CONNECTOR] = 'fetch-unified-connector-computers';
sourceToFetchFunctionNameMapping[Source.AIRWATCH] = 'fetch-air-watch-devices';
sourceToFetchFunctionNameMapping[Source.SERVICENOW] = 'fetch-service-now-devices';
sourceToFetchFunctionNameMapping[Source.SENTINEL_ONE] = 'fetch-sentinel-one-devices';
sourceToFetchFunctionNameMapping[Source.CYBERVISION] = 'fetch-cyber-vision-devices';
sourceToFetchFunctionNameMapping[Source.CROWDSTRIKE] = 'fetch-crowd-strike-devices';
sourceToFetchFunctionNameMapping[Source.DEFENDER] = 'fetch-defender-devices';
sourceToFetchFunctionNameMapping[Source.AZURE_USERS] = 'fetch-azure-users';
sourceToFetchFunctionNameMapping[Source.TREND_VISION_ONE] = 'fetch-trend-vision-one-devices';
var EdgeType;
(function (EdgeType) {
    EdgeType["USES"] = "uses";
    EdgeType["USED_BY"] = "usedBy";
    EdgeType["HAS"] = "has";
    EdgeType["HAS_STATE"] = "hasState";
    EdgeType["POSTURE_ENDPOINT"] = "fromPostureEndpoint";
    EdgeType["POSTURE_PERSON"] = "fromPosturePerson";
    EdgeType["HAS_VULNERABILITY"] = "hasVulnerability";
    EdgeType["OWNED_BY"] = "ownedBy";
    EdgeType["PERSON_HAS"] = "personHas";
})(EdgeType = exports.EdgeType || (exports.EdgeType = {}));
var BasicProperty;
(function (BasicProperty) {
    BasicProperty["ID"] = "id";
    BasicProperty["LABEL"] = "label";
    BasicProperty["PARTITION_KEY"] = "_partition";
})(BasicProperty = exports.BasicProperty || (exports.BasicProperty = {}));
var EdgeBasicProperty;
(function (EdgeBasicProperty) {
    EdgeBasicProperty["CREATED"] = "created";
    EdgeBasicProperty["SINCE"] = "since";
    EdgeBasicProperty["UNTIL"] = "until";
    EdgeBasicProperty["DELETED"] = "deleted";
    EdgeBasicProperty["IS_CURRENT"] = "isCurrent";
})(EdgeBasicProperty = exports.EdgeBasicProperty || (exports.EdgeBasicProperty = {}));
var VertexBasicProperty;
(function (VertexBasicProperty) {
    VertexBasicProperty["EXT_ID"] = "extId";
    VertexBasicProperty["NAME"] = "name";
    VertexBasicProperty["LAST_UPDATED"] = "lastUpdated";
    VertexBasicProperty["OS_TYPE"] = "osType";
    VertexBasicProperty["OS_VERSION"] = "osVersion";
    VertexBasicProperty["OS_EXTRACTED_NUMERIC_VERSION"] = "osExtractedNumericVersion";
    VertexBasicProperty["OS_HUMAN_READABLE_VERSION"] = "osHumanReadableVersion";
    VertexBasicProperty["OS_BUILD"] = "osBuild";
    VertexBasicProperty["IS_MANAGED"] = "isManaged";
    VertexBasicProperty["IS_COMPLIANT"] = "isCompliant";
})(VertexBasicProperty = exports.VertexBasicProperty || (exports.VertexBasicProperty = {}));
var VertexStateProperty;
(function (VertexStateProperty) {
    VertexStateProperty["STATE_INTERNAL_IP_ADDRESSES"] = "stateInternalIpAddresses";
})(VertexStateProperty = exports.VertexStateProperty || (exports.VertexStateProperty = {}));
var OsSupport;
(function (OsSupport) {
    OsSupport["eol"] = "eol";
    OsSupport["preRelease"] = "preRelease";
    OsSupport["outOfDate"] = "outOfDate";
})(OsSupport = exports.OsSupport || (exports.OsSupport = {}));
var OS;
(function (OS) {
    OS["WINDOWS"] = "windows";
    OS["MAC_OS"] = "macOS";
    OS["ANDROID"] = "android";
    OS["IOS"] = "iOS";
    OS["IPAD_OS"] = "iPadOS";
    OS["NETWORK_GATEWAY"] = "networkGateway";
    OS["CENTOS"] = "centos";
    OS["RHEL"] = "rhel";
    OS["UBUNTU"] = "ubuntu";
    OS["ORACLE"] = "oracle";
    OS["EMAIL_SECURITY_APPLIANCE"] = "emailSecurityAppliance";
    OS["WEB_SECURITY_APPLIANCE"] = "webSecurityAppliance";
    OS["UNKNOWN"] = "unknown";
})(OS = exports.OS || (exports.OS = {}));
var ChangeType;
(function (ChangeType) {
    ChangeType["NEW"] = "new";
    ChangeType["UPDATE"] = "update";
    ChangeType["DELETE"] = "delete";
    ChangeType["STALE"] = "stale";
    ChangeType["STATE_UPDATE"] = "stateUpdate";
    ChangeType["MAC_ADDR_UPDATE"] = "macAddressUpdate";
    ChangeType["HARDWARE_ID_UPDATE"] = "hardwareIdUpdate";
    ChangeType["INTERNAL_IP_ADDR_UPDATE"] = "internalIpAddressUpdate";
    ChangeType["EXTERNAL_IP_ADDR_UPDATE"] = "externalIpAddressUpdate";
    ChangeType["USER_UPDATE"] = "userUpdate";
    ChangeType["OWNER_UPDATE"] = "ownerUpdate";
    ChangeType["PERSON_UPDATE"] = "personUpdate";
    ChangeType["EMAIL_UPDATE"] = "emailUpdate";
    ChangeType["HOSTNAME_UPDATE"] = "hostnameUpdate";
    ChangeType["APP_USER_UPDATE"] = "appUserUpdate";
    ChangeType["SERIAL_NUMBER_UPDATE"] = "serialNumberUpdate";
    ChangeType["BROWSER_UPDATE"] = "browserUpdate";
    ChangeType["COMPUTER_SID_UPDATE"] = "computerSidUpdate";
    ChangeType["EXTERNAL_REFERENCE_UPDATE"] = "externalReferenceUpdate";
    ChangeType["IMEI_UPDATE"] = "imeiUpdate";
    ChangeType["PHONE_NUMBER_UPDATE"] = "phoneNumberUpdate";
    ChangeType["LAST_UPDATED_UPDATE"] = "lastUpdatedUpdate";
})(ChangeType = exports.ChangeType || (exports.ChangeType = {}));
var WorkFlow;
(function (WorkFlow) {
    WorkFlow["NOTIFICATION_PROCESSING"] = "notificationProcessing";
    WorkFlow["COLLECTION"] = "collection";
    WorkFlow["PRE_PROCESSING"] = "preprocessing";
    WorkFlow["PROCESSING"] = "processing";
    WorkFlow["RULES_FLOW"] = "rulesFlow";
})(WorkFlow = exports.WorkFlow || (exports.WorkFlow = {}));
const getChangeType = (type) => {
    switch (type) {
        case VertexType.MAC_ADDRESS:
            return ChangeType.MAC_ADDR_UPDATE;
        case VertexType.COMPUTER_SID:
            return ChangeType.COMPUTER_SID_UPDATE;
        case VertexType.HARDWARE_ID:
            return ChangeType.HARDWARE_ID_UPDATE;
        case VertexType.EXTERNAL_IP_ADDRESS:
            return ChangeType.EXTERNAL_IP_ADDR_UPDATE;
        case VertexType.BROWSER:
            return ChangeType.BROWSER_UPDATE;
        case VertexType.EXTERNAL_REFERENCE:
            return ChangeType.EXTERNAL_REFERENCE_UPDATE;
        case VertexType.USER:
            return ChangeType.USER_UPDATE;
        case VertexType.APP_USER:
            return ChangeType.APP_USER_UPDATE;
        case VertexType.SERIAL_NUMBER:
            return ChangeType.SERIAL_NUMBER_UPDATE;
        case VertexType.IMEI:
            return ChangeType.IMEI_UPDATE;
        case VertexType.PHONE_NUMBER:
            return ChangeType.PHONE_NUMBER_UPDATE;
        case VertexType.EMAIL:
            return ChangeType.EMAIL_UPDATE;
        case VertexType.HOSTNAME:
            return ChangeType.HOSTNAME_UPDATE;
        case VertexType.AMP_COMPUTER_STATE:
        case VertexType.DUO_ENDPOINT_STATE:
        case VertexType.DUO_USER_STATE:
        case VertexType.MERAKI_SM_DEVICE_STATE:
        case VertexType.JAMF_COMPUTER_STATE:
        case VertexType.UMBRELLA_ROAMING_COMPUTER_STATE:
        case VertexType.MOBILE_IRON_DEVICE_STATE:
        case VertexType.IN_TUNE_DEVICE_STATE:
        case VertexType.ORBITAL_ENDPOINT_STATE:
        case VertexType.CUSTOM_ENDPOINT_STATE:
        case VertexType.UNIFIED_CONNECTOR_DEVICE_STATE:
        case VertexType.AIR_WATCH_DEVICE_STATE:
        case VertexType.SERVICE_NOW_DEVICE_STATE:
        case VertexType.SENTINEL_ONE_DEVICE_STATE:
        case VertexType.CYBER_VISION_DEVICE_STATE:
        case VertexType.CROWD_STRIKE_DEVICE_STATE:
        case VertexType.DEFENDER_DEVICE_STATE:
        case VertexType.AZURE_DEVICE_STATE:
        case VertexType.AZURE_USER_STATE:
        case VertexType.TREND_VISION_ONE_DEVICE_STATE:
        case VertexType.GENERIC_SOURCE_DEVICE_STATE:
            return ChangeType.STATE_UPDATE;
        default:
            throw new Error(`cannot map ChangeType to vertex type ${type}`);
    }
};
exports.getChangeType = getChangeType;
const getOsType = (osStr) => {
    if (!osStr) {
        return OS.UNKNOWN;
    }
    const os = osStr.toLowerCase();
    if (os.startsWith('os') || os.startsWith('mac os') || os.startsWith('macos') || os.startsWith('osx') || os.startsWith('macmdm')) {
        return OS.MAC_OS;
    }
    if (os.startsWith('windows') || os.startsWith('microsoft windows') || os.startsWith('winrt')) {
        return OS.WINDOWS;
    }
    if (os.startsWith('android') || os.startsWith('google android')) {
        return OS.ANDROID;
    }
    if (os.startsWith('ios') || os.startsWith('apple')) {
        return OS.IOS;
    }
    if (os.startsWith('ipad')) {
        return OS.IPAD_OS;
    }
    if (os.startsWith('network gateway')) {
        return OS.NETWORK_GATEWAY;
    }
    if (os.startsWith('centos')) {
        return OS.CENTOS;
    }
    if (os.startsWith('ubuntu')) {
        return OS.UBUNTU;
    }
    if (os.startsWith('email security appliance')) {
        return OS.EMAIL_SECURITY_APPLIANCE;
    }
    if (os.startsWith('web security appliance')) {
        return OS.WEB_SECURITY_APPLIANCE;
    }
    if (os.startsWith('red hat enterprise linux')) {
        return OS.RHEL;
    }
    if (os.startsWith('oracle linux')) {
        return OS.ORACLE;
    }
    const logger = new LambdaLogger_1.LambdaLogger();
    logger.debug(`Did not identify ${osStr}`);
    return OS.UNKNOWN;
};
exports.getOsType = getOsType;
const osPrefixes = 'macOS|Windows|Android|iOS|OS X|Mac OS|centos|red hat enterprise linux|iPadOS';
const getOsVersion = (value) => {
    const match = value && value.match(`^(${osPrefixes}) (.*)$`);
    return match ? match[2] : 'na';
};
exports.getOsVersion = getOsVersion;
const isOSVersionTextOnly = (value) => (value ? /^[a-zA-Z]+$/.test(value) : false);
exports.isOSVersionTextOnly = isOSVersionTextOnly;
const extractNumericOsVersionFromAvailableOsDataFields = (primaryOsData, secondaryOsData, osBuild) => {
    const matchKnownPhraseFollowedByAnyNumAndOrUnknownPhraseFollowedByDottedNotation = `(?:(?:Server|server|Windows Server|WindowsServer|Apple|WinRT|${osPrefixes}) *(\\d+(?:[\\.R]\\d+)*))*\\D*((?:\\d+\\.)+[A-Za-z\\d]+)*`;
    const match = primaryOsData === null || primaryOsData === void 0 ? void 0 : primaryOsData.match(matchKnownPhraseFollowedByAnyNumAndOrUnknownPhraseFollowedByDottedNotation);
    let NumericOsVersion = [match === null || match === void 0 ? void 0 : match[1], match === null || match === void 0 ? void 0 : match[2]].filter(item => item).join('.');
    const detailedMatch = secondaryOsData === null || secondaryOsData === void 0 ? void 0 : secondaryOsData.match(matchKnownPhraseFollowedByAnyNumAndOrUnknownPhraseFollowedByDottedNotation);
    const detailedVersion = (detailedMatch === null || detailedMatch === void 0 ? void 0 : detailedMatch[1]) || (detailedMatch === null || detailedMatch === void 0 ? void 0 : detailedMatch[2]);
    if (detailedVersion) {
        NumericOsVersion += detailedVersion.startsWith(NumericOsVersion) ? detailedVersion.slice(NumericOsVersion.length) : `.${detailedVersion}`;
    }
    if (NumericOsVersion) {
        if (!osBuild && secondaryOsData) {
            const buildInDetailed = secondaryOsData.match(/[Bb]uild *([A-Za-z0-9]+)/);
            NumericOsVersion += buildInDetailed ? `.${buildInDetailed[1]}` : '';
        }
        else if (osBuild) {
            NumericOsVersion += `.${osBuild}`;
        }
    }
    return NumericOsVersion || 'na';
};
exports.extractNumericOsVersionFromAvailableOsDataFields = extractNumericOsVersionFromAvailableOsDataFields;
const newPhraseLowersDetailHeuristic = (currentPhrase, newPhrase) => {
    var _a, _b, _c, _d;
    const newPhraseMatch = (_b = (_a = newPhrase === null || newPhrase === void 0 ? void 0 : newPhrase.match) === null || _a === void 0 ? void 0 : _a.call(newPhrase, MORE_THAN_1_DOT_VERSION_PATTERN)) === null || _b === void 0 ? void 0 : _b[0];
    const currentPhraseMatch = (_d = (_c = currentPhrase === null || currentPhrase === void 0 ? void 0 : currentPhrase.match) === null || _c === void 0 ? void 0 : _c.call(currentPhrase, MORE_THAN_1_DOT_VERSION_PATTERN)) === null || _d === void 0 ? void 0 : _d[0];
    if (!newPhraseMatch && currentPhraseMatch) {
        return true;
    }
    if ((newPhraseMatch && !currentPhraseMatch) || (!newPhraseMatch && !currentPhraseMatch)) {
        return false;
    }
    const same = (newPhraseMatch === null || newPhraseMatch === void 0 ? void 0 : newPhraseMatch.startsWith(currentPhraseMatch || exports.NA)) || (currentPhraseMatch === null || currentPhraseMatch === void 0 ? void 0 : currentPhraseMatch.startsWith(newPhraseMatch || exports.NA));
    return (same && currentPhrase.length > newPhrase.length);
};
exports.newPhraseLowersDetailHeuristic = newPhraseLowersDetailHeuristic;
const setOsHumanReadableVersionPhrase = (model, textual, numeric) => {
    var _a;
    const extractedNumericOsVersion = ((_a = model === null || model === void 0 ? void 0 : model.getPropertyValue) === null || _a === void 0 ? void 0 : _a.call(model, VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION)) || (model === null || model === void 0 ? void 0 : model[VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION]);
    let numericOsVersion = (extractedNumericOsVersion && extractedNumericOsVersion !== exports.NA) ? extractedNumericOsVersion : numeric;
    numericOsVersion = (textual === null || textual === void 0 ? void 0 : textual.includes(numericOsVersion)) ? undefined : numericOsVersion;
    const textualMatch = textual === null || textual === void 0 ? void 0 : textual.match(MORE_THAN_1_DOT_VERSION_PATTERN);
    textual = (numericOsVersion && textualMatch) ? textual === null || textual === void 0 ? void 0 : textual.replace(textualMatch[0], textualMatch[0].split('.').filter((item, index) => index < 2).join('.')) : textual;
    const phrase = [textual, numericOsVersion].filter(item => item).join(' ');
    if (typeof model.setProperty === 'function') {
        model.setProperty(VertexBasicProperty.OS_HUMAN_READABLE_VERSION, phrase || exports.NA);
    }
    else {
        model[VertexBasicProperty.OS_HUMAN_READABLE_VERSION] = phrase || exports.NA;
    }
};
exports.setOsHumanReadableVersionPhrase = setOsHumanReadableVersionPhrase;
const val = (inp) => {
    if (_.isArray(inp)) {
        return inp[0];
    }
    return inp;
};
exports.val = val;
const parseVersionForOsSupport = (osVersions, osType, osVersion, endpointType) => {
    if (endpointType === EndpointType.SERVER) {
        return undefined;
    }
    const familyVersions = _.find(osVersions, { osFamily: (0, exports.osToFamily)(osType) });
    if (familyVersions) {
        let result;
        const filteredFamilyVersions = _.filter(familyVersions.osVersion, (f) => osVersion.indexOf(f.baseVersion) > -1 && f.baseVersion !== '');
        if (filteredFamilyVersions.length > 0) {
            const regex = /[0-9.]+/g;
            const potentialVersions = osVersion.match(regex);
            if (!potentialVersions) {
                const familyVersion = filteredFamilyVersions[filteredFamilyVersions.length - 1];
                return { baseVersion: osVersion, version: undefined, familyVersion };
            }
            const potentialVersionsParts = [];
            for (const potentialVersion of potentialVersions) {
                const versionParts = _.split(potentialVersion, '.');
                potentialVersionsParts.push(versionParts);
            }
            const matchedVersionsAndParts = (0, exports.filterFamilyVersionsByParts)(regex, filteredFamilyVersions, potentialVersionsParts);
            const { newestFamilyVersion, newestVersionParts, matchedOsVersionParts } = (0, exports.getNewestFamilyVersionAndNumericParts)(matchedVersionsAndParts);
            if (newestFamilyVersion && newestVersionParts && matchedOsVersionParts) {
                const baseVersion = _.join(_.slice(newestVersionParts, 0, newestVersionParts.length), '.');
                const versionPartsMaxLength = Math.min(matchedOsVersionParts.length, newestVersionParts.length + 2);
                const versionStrParts = _.join(_.slice(matchedOsVersionParts, newestVersionParts.length, versionPartsMaxLength), '.');
                const version = _.isEmpty(versionStrParts) ? undefined : _.toNumber(versionStrParts);
                result = { baseVersion, version, familyVersion: newestFamilyVersion };
            }
            else {
                const familyVersion = filteredFamilyVersions[filteredFamilyVersions.length - 1];
                return { baseVersion: osVersion, version: undefined, familyVersion };
            }
            return result;
        }
    }
    return undefined;
};
exports.parseVersionForOsSupport = parseVersionForOsSupport;
const filterFamilyVersionsByParts = (regex, familyVersions, potentialVersionsParts) => {
    const result = [];
    for (const familyVersion of familyVersions) {
        let isFamilyVersionValid = false;
        const potentialFamilyVersions = familyVersion.baseVersion.match(regex);
        if (potentialFamilyVersions) {
            for (const potentialFamilyVersion of potentialFamilyVersions) {
                const familyVersionParts = _.split(potentialFamilyVersion, '.');
                for (const osVersionParts of potentialVersionsParts) {
                    for (let i = 0; i < familyVersionParts.length; i += 1) {
                        if (i >= osVersionParts.length) {
                            isFamilyVersionValid = false;
                            break;
                        }
                        if (osVersionParts[i] === familyVersionParts[i]) {
                            isFamilyVersionValid = true;
                        }
                    }
                    if (isFamilyVersionValid) {
                        result.push({ familyVersion, familyVersionParts, osVersionParts });
                        break;
                    }
                }
            }
        }
    }
    return result;
};
exports.filterFamilyVersionsByParts = filterFamilyVersionsByParts;
const getNewestFamilyVersionAndNumericParts = (matchedVersionsAndParts) => {
    let newestVersionParts = [];
    let newestMatchedVersionAndParts;
    for (const match of matchedVersionsAndParts) {
        const familyVersionParts = match.familyVersionParts;
        for (let versionPartNumber = 0; versionPartNumber < familyVersionParts.length; versionPartNumber += 1) {
            const familyVersionNumber = _.toNumber(familyVersionParts[versionPartNumber]);
            if (!Number.isNaN(familyVersionNumber) && (newestVersionParts.length === versionPartNumber
                || familyVersionNumber > newestVersionParts[versionPartNumber])) {
                newestVersionParts.splice(versionPartNumber, 1, familyVersionNumber);
                newestVersionParts = _.slice(newestVersionParts, 0, versionPartNumber + 1);
                newestMatchedVersionAndParts = match;
            }
            else if (familyVersionNumber < newestVersionParts[versionPartNumber]) {
                break;
            }
        }
    }
    return { newestFamilyVersion: newestMatchedVersionAndParts === null || newestMatchedVersionAndParts === void 0 ? void 0 : newestMatchedVersionAndParts.familyVersion, newestVersionParts, matchedOsVersionParts: newestMatchedVersionAndParts === null || newestMatchedVersionAndParts === void 0 ? void 0 : newestMatchedVersionAndParts.osVersionParts };
};
exports.getNewestFamilyVersionAndNumericParts = getNewestFamilyVersionAndNumericParts;
const osVersionsToMap = (osVersions) => {
    const osVersionsByOsFamilyDict = {};
    if (osVersions) {
        (Array.isArray(osVersions) ? osVersions : [osVersions]).forEach((item) => {
            const osVersionsByBaseVersion = {};
            item.osVersion.forEach(element => osVersionsByBaseVersion[element.baseVersion] = element);
            osVersionsByOsFamilyDict[item.osFamily] = osVersionsByBaseVersion;
        });
    }
    return osVersionsByOsFamilyDict;
};
exports.osVersionsToMap = osVersionsToMap;
const getOsSupport = (osVersions, osType, osExtractedNumericVersion, endpointType) => {
    const osSupport = {};
    if (endpointType === EndpointType.SERVER || !osExtractedNumericVersion) {
        return osSupport;
    }
    const osFamily = (0, exports.osToFamily)(osType);
    if (osFamily) {
        const osVersionsByBaseVersion = osVersions[osFamily];
        if (osVersionsByBaseVersion) {
            let currIndx = osExtractedNumericVersion.length;
            let currPhrase = '';
            let statusObj = null;
            while (currIndx) {
                currPhrase = osExtractedNumericVersion.substring(0, currIndx);
                statusObj = osVersionsByBaseVersion[currPhrase];
                if (statusObj) {
                    break;
                }
                currIndx = osExtractedNumericVersion.lastIndexOf('.', currIndx - 1);
                currIndx = currIndx === -1 ? 0 : currIndx;
            }
            if (statusObj) {
                if ('eol' in statusObj) {
                    osSupport.osSupport = OsSupport.eol;
                }
                else if ('preRelease' in statusObj) {
                    osSupport.osSupport = OsSupport.preRelease;
                }
                else if (statusObj.current !== undefined) {
                    const currentLen = statusObj.current.toString().length;
                    const hasTrailingNum = !Number.isNaN(+(osExtractedNumericVersion[currIndx + 1 + currentLen + 1]));
                    const subVersionNum = +(osExtractedNumericVersion.substring(currIndx + 1, currIndx + 1 + currentLen + (hasTrailingNum ? 1 : 0)));
                    if (subVersionNum && statusObj.current > subVersionNum) {
                        osSupport.osSupport = OsSupport.outOfDate;
                    }
                    osSupport.osStatusVersion = subVersionNum;
                }
                osSupport.osStatusBase = currPhrase;
            }
        }
    }
    return osSupport;
};
exports.getOsSupport = getOsSupport;
const setOsSupport = (osVersions, to) => {
    to.osSupport = undefined;
    const versionForOsSupport = (0, exports.parseVersionForOsSupport)(osVersions, to.osType, to.osVersion, to.endpointType);
    if (versionForOsSupport) {
        const { version, familyVersion } = versionForOsSupport;
        if (familyVersion === null || familyVersion === void 0 ? void 0 : familyVersion.eol) {
            to.osSupport = OsSupport.eol;
        }
        else if (familyVersion.current && version && version < familyVersion.current) {
            to.osSupport = OsSupport.outOfDate;
        }
    }
};
exports.setOsSupport = setOsSupport;
const setOsProperties = (to, from, osVersions) => {
    var _a, _b;
    let checkOsSupport = false;
    const fromOsType = (0, exports.val)(from.get(VertexBasicProperty.OS_TYPE));
    if (!to.osType || fromOsType !== OS.UNKNOWN) {
        if (to.osType === OS.UNKNOWN && fromOsType && fromOsType !== OS.UNKNOWN) {
            to.osType = fromOsType;
            to.propertyTimestamp[VertexBasicProperty.OS_TYPE] = (0, exports.val)(from.get(VertexBasicProperty.LAST_UPDATED));
        }
        else {
            const updated = (0, exports.setPropertyByTimestamp)(to, from, VertexBasicProperty.OS_TYPE, () => to.osType = fromOsType || OS.UNKNOWN);
            checkOsSupport || (checkOsSupport = updated);
        }
    }
    const fromOsVersion = (0, exports.val)(from.get(VertexBasicProperty.OS_VERSION));
    if (!to.osVersion || fromOsVersion !== exports.NA) {
        if (to.osVersion === exports.NA && fromOsVersion && fromOsVersion !== exports.NA) {
            to.osVersion = fromOsVersion;
            to.propertyTimestamp[VertexBasicProperty.OS_VERSION] = (0, exports.val)(from.get(VertexBasicProperty.LAST_UPDATED));
        }
        else {
            const updated = (0, exports.setPropertyByTimestamp)(to, from, VertexBasicProperty.OS_VERSION, () => to.osVersion = fromOsVersion || exports.NA);
            checkOsSupport || (checkOsSupport = updated);
        }
    }
    const fromOsExtractedNumericVersion = (0, exports.val)(from.get(VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION));
    if (!to.osExtractedNumericVersion || (fromOsExtractedNumericVersion && fromOsExtractedNumericVersion !== exports.NA)) {
        const updated = (0, exports.setPropertyByTimestamp)(to, from, VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, () => {
            const fromIsSameAsToButLessDetailed = to.osExtractedNumericVersion && fromOsExtractedNumericVersion
                && to.osExtractedNumericVersion.startsWith(fromOsExtractedNumericVersion);
            to.osExtractedNumericVersion = fromIsSameAsToButLessDetailed ? to.osExtractedNumericVersion : fromOsExtractedNumericVersion;
        });
        checkOsSupport || (checkOsSupport = updated);
    }
    const fromOsHumanReadableVersion = (0, exports.val)(from.get(VertexBasicProperty.OS_HUMAN_READABLE_VERSION));
    if (!to.osHumanReadableVersion || (fromOsHumanReadableVersion && fromOsHumanReadableVersion !== exports.NA)) {
        (0, exports.setPropertyByTimestamp)(to, from, VertexBasicProperty.OS_HUMAN_READABLE_VERSION, () => to.osHumanReadableVersion = (0, exports.newPhraseLowersDetailHeuristic)(to.osHumanReadableVersion, fromOsHumanReadableVersion)
            ? to.osHumanReadableVersion : fromOsHumanReadableVersion);
    }
    if (checkOsSupport) {
        if ((_b = (_a = to.osExtractedNumericVersion) === null || _a === void 0 ? void 0 : _a.match) === null || _b === void 0 ? void 0 : _b.call(_a, exports.NUMERIC_DOTTED_PATTERN)) {
            const osSupport = (0, exports.getOsSupport)((0, exports.osVersionsToMap)(osVersions), to.osType, to.osExtractedNumericVersion, to.endpointType);
            to.osSupport = osSupport.osSupport;
            to.osStatusBase = osSupport.osStatusBase;
            to.osStatusVersion = osSupport.osStatusVersion;
        }
        else {
            (0, exports.setOsSupport)(osVersions, to);
        }
    }
};
exports.setOsProperties = setOsProperties;
const setPropertyByTimestamp = (pe, ps, property, setValue) => {
    const psTimestamp = (0, exports.val)(ps.get(VertexBasicProperty.LAST_UPDATED));
    const existingPropertyTimestamp = pe.propertyTimestamp[property];
    if (!existingPropertyTimestamp || (psTimestamp && existingPropertyTimestamp < psTimestamp)) {
        setValue();
        pe.propertyTimestamp[property] = psTimestamp;
        return true;
    }
    return false;
};
exports.setPropertyByTimestamp = setPropertyByTimestamp;
const empty = (value) => !value || value.trim().length === 0;
exports.empty = empty;
const valueOrJsonString = (value) => ((value) ? ((typeof value === 'object') ? JSON.stringify(value) : value) : value);
exports.valueOrJsonString = valueOrJsonString;
const normalize = (value) => {
    if ((0, uuid_1.validate)(value)) {
        return _.toLower(value);
    }
    if (_.isString(value)) {
        return _.trim(value);
    }
    return value;
};
exports.normalize = normalize;
const identifierVertexTypes = () => [
    VertexType.COMPUTER_SID,
    VertexType.HARDWARE_ID,
    VertexType.SERIAL_NUMBER,
    VertexType.IMEI,
    VertexType.HOSTNAME
];
exports.identifierVertexTypes = identifierVertexTypes;
const identifierEdgeTypes = () => [
    EdgeType.HAS,
    EdgeType.USES
];
exports.identifierEdgeTypes = identifierEdgeTypes;
const personIdentifierVertexTypes = () => [
    VertexType.COMPUTER_SID,
    VertexType.USER,
    VertexType.EMAIL
];
exports.personIdentifierVertexTypes = personIdentifierVertexTypes;
const personIdentifierEdgeTypes = () => [
    EdgeType.HAS,
    EdgeType.USES,
    EdgeType.USED_BY
];
exports.personIdentifierEdgeTypes = personIdentifierEdgeTypes;
const vertexTypeToSource = (producerType) => {
    const source = vertexTypeToSourceMapping[producerType];
    if (!source) {
        throw new Error(`could not map vertexType ${producerType} to source`);
    }
    return source;
};
exports.vertexTypeToSource = vertexTypeToSource;
const sourceToVertexType = (source) => {
    const vertexType = exports.sourceToVertexTypeMapping[source];
    if (!vertexType) {
        throw new Error(`could not map source ${source} to vertexType`);
    }
    return vertexType;
};
exports.sourceToVertexType = sourceToVertexType;
const sourceToFetchFunctionName = (source) => {
    const functionName = sourceToFetchFunctionNameMapping[source];
    if (!functionName) {
        throw new Error(`could not map source ${source} to fetch function name`);
    }
    return functionName;
};
exports.sourceToFetchFunctionName = sourceToFetchFunctionName;
var ModificationOrigin;
(function (ModificationOrigin) {
    ModificationOrigin["DEFAULT"] = "default";
    ModificationOrigin["MANUAL"] = "manual";
    ModificationOrigin["RULES_BASED"] = "rules";
})(ModificationOrigin = exports.ModificationOrigin || (exports.ModificationOrigin = {}));
var OperatingSystemFamily;
(function (OperatingSystemFamily) {
    OperatingSystemFamily["MAC_OS"] = "Mac OS X";
    OperatingSystemFamily["WINDOWS"] = "Windows";
    OperatingSystemFamily["IOS"] = "iOS";
    OperatingSystemFamily["ANDROID"] = "Android";
    OperatingSystemFamily["IPAD_OS"] = "iPadOS";
})(OperatingSystemFamily = exports.OperatingSystemFamily || (exports.OperatingSystemFamily = {}));
const osToFamily = (os) => {
    switch (os) {
        case OS.ANDROID:
            return OperatingSystemFamily.ANDROID;
        case OS.IOS:
            return OperatingSystemFamily.IOS;
        case OS.WINDOWS:
            return OperatingSystemFamily.WINDOWS;
        case OS.MAC_OS:
            return OperatingSystemFamily.MAC_OS;
        case OS.IPAD_OS:
            return OperatingSystemFamily.IPAD_OS;
        default:
            return undefined;
    }
};
exports.osToFamily = osToFamily;
const getCloudMgmtVersionNumbers = (cloudMgmtVersion) => {
    let major;
    let minor;
    let patch;
    let revision;
    if (cloudMgmtVersion) {
        const numbers = cloudMgmtVersion.split('.');
        if (numbers.length > 0) {
            major = _.toInteger(numbers[0]);
        }
        if (numbers.length > 1) {
            minor = _.toInteger(numbers[1]);
        }
        if (numbers.length > 2) {
            patch = _.toInteger(numbers[2]);
        }
        if (numbers.length > 3) {
            revision = _.toInteger(numbers[3]);
        }
    }
    return { major, minor, patch, revision };
};
exports.getCloudMgmtVersionNumbers = getCloudMgmtVersionNumbers;
const isOnlySecureClientDevices = (filter) => {
    if (filter.producers && filter.producers.length > 0) {
        for (const producer of filter.producers) {
            if (producer.type !== Source.UNIFIED_CONNECTOR) {
                return false;
            }
        }
        return true;
    }
    return false;
};
exports.isOnlySecureClientDevices = isOnlySecureClientDevices;
