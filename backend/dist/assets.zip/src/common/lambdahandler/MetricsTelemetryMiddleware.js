"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.metricsTelemetryMiddleware = exports.IntegrationType = void 0;
const IrohTelemetryClient_1 = require("../IrohTelemetryClient");
const Util_1 = require("../Util");
const SERVICE_NAME = 'device_insights.api';
const SERVICE_DESCRIPTION = 'device insights api call metrics';
const HTTP_METHOD = 'httpmethod';
const API_PATH = 'path';
var IntegrationType;
(function (IntegrationType) {
    IntegrationType[IntegrationType["LambdaProxy"] = 0] = "LambdaProxy";
    IntegrationType[IntegrationType["AppSync"] = 1] = "AppSync";
})(IntegrationType = exports.IntegrationType || (exports.IntegrationType = {}));
const metricsTelemetryMiddleware = (integrationType, lambdaLogger) => (next) => async (event, context) => {
    try {
        lambdaLogger.log(`Event is, err: ${JSON.stringify(event)}`);
        lambdaLogger.log(`Context is, err: ${JSON.stringify(context)}`);
        let metrics;
        if (integrationType === IntegrationType.LambdaProxy) {
            metrics = parseLambdaProxyMetricDetails(event);
        }
        else if (integrationType === IntegrationType.AppSync) {
            metrics = parseAppSyncMetricDetails(event);
        }
        if (!metrics) {
            throw new Error('Unable to read metrics.');
        }
        const irohTelemetryClient = new IrohTelemetryClient_1.IrohTelemetryClient(metrics.tenantUid);
        await irohTelemetryClient.publishMetrics([metrics.appMetric]);
    }
    catch (err) {
        lambdaLogger.error(`Failed to process metricsTelemetryMiddleware, err: ${err}`);
    }
    const res = await next(event, context);
    return res;
};
exports.metricsTelemetryMiddleware = metricsTelemetryMiddleware;
const parseLambdaProxyMetricDetails = (event) => {
    const { tenantUid, tenantExtId, tenantName, id } = event.requestContext.authorizer;
    const appMetric = {
        service: SERVICE_NAME,
        metric: 1,
        description: SERVICE_DESCRIPTION,
        metadata: {
            user_id: id,
            tenant_ext_id: tenantExtId,
            tenant_name: (0, Util_1.decodeTenantName)(tenantName),
            time: Date.now(),
            endpoint_path: event.requestContext.path,
            action: event.requestContext.httpMethod
        }
    };
    return {
        tenantUid,
        appMetric
    };
};
const parseAppSyncMetricDetails = (event) => {
    const { tenantUid, tenantExtId, tenantName, userId } = (0, Util_1.getFromHeaders)(event);
    const appMetric = {
        service: SERVICE_NAME,
        metric: 1,
        description: SERVICE_DESCRIPTION,
        metadata: {
            user_id: userId,
            tenant_ext_id: tenantExtId,
            tenant_name: tenantName,
            time: Date.now(),
            endpoint_path: event.request.headers[API_PATH],
            action: event.request.headers[HTTP_METHOD]
        }
    };
    return {
        tenantUid,
        appMetric
    };
};
