"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.kinesisTimestream = exports.vulnerabilityKinesisProcessing = exports.kinesisProcessing = exports.kinesisPreprocessingBackup = exports.kinesisPreprocessing = exports.s3UploadFileTrigger = void 0;
const TimestreamUtil_1 = require("./common/TimestreamUtil");
const VulnerabilityUtil_1 = require("./services/common/VulnerabilityUtil");
const ProcessingUtil_1 = require("./common/ProcessingUtil");
const ProducerUtil_1 = require("./services/common/ProducerUtil");
const NeptuneClientManager_1 = require("./common/neptune/NeptuneClientManager");
const ResourcesManager_1 = require("./common/ResourcesManager");
const neptuneClientManager = NeptuneClientManager_1.NeptuneClientManager.getInstance();
const s3UploadFileTrigger = async (event) => {
    return new ProcessingUtil_1.ProcessingUtil().s3UploadFileTrigger(event.Records[0].s3);
};
exports.s3UploadFileTrigger = s3UploadFileTrigger;
const kinesisPreprocessing = (event) => {
    return new ProducerUtil_1.ProducerUtil().preProcessEventRecords(event.Records);
};
exports.kinesisPreprocessing = kinesisPreprocessing;
const kinesisPreprocessingBackup = (event) => {
    return new ProcessingUtil_1.ProcessingUtil().backupRecords(event.Records);
};
exports.kinesisPreprocessingBackup = kinesisPreprocessingBackup;
const kinesisProcessing = async (event) => {
    try {
        const parsedMultithreading = process.env.PROCESSING_INTERNAL_CONCURRENCY ? +process.env.PROCESSING_INTERNAL_CONCURRENCY : 1;
        return new ProducerUtil_1.ProducerUtil().processEventRecords(event.Records, Math.max(parsedMultithreading, 1));
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)();
    }
};
exports.kinesisProcessing = kinesisProcessing;
const vulnerabilityKinesisProcessing = async (event) => {
    const threads = process.env.VULNERABILITY_PROCESSING_INTERNAL_CONCURRENCY ? +process.env.VULNERABILITY_PROCESSING_INTERNAL_CONCURRENCY : 1;
    const concurrentUpdateComputers = process.env.VULNERABILITY_PROCESSING_CONCURRENT_UPDATE_COMPUTERS ? +process.env.VULNERABILITY_PROCESSING_CONCURRENT_UPDATE_COMPUTERS : 1;
    return new VulnerabilityUtil_1.VulnerabilityUtil().processVulnerabilityRecords(event.Records, Math.max(threads, 1), Math.max(concurrentUpdateComputers, 1));
};
exports.vulnerabilityKinesisProcessing = vulnerabilityKinesisProcessing;
const kinesisTimestream = async (event) => {
    return new TimestreamUtil_1.TimestreamUtil().sendMetricsToDatabase(event.Records);
};
exports.kinesisTimestream = kinesisTimestream;
