"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CortexPeMappingHandler = void 0;
const CommonTypes_1 = require("../common/CommonTypes");
class CortexPeMappingHandler {
    handler(sourceConfiguration, pe, pv, ps) {
        (0, CommonTypes_1.setPropertyByTimestamp)(pe, ps, CommonTypes_1.VertexBasicProperty.NAME, () => {
            pe.hostname = (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.NAME));
        });
    }
}
exports.CortexPeMappingHandler = CortexPeMappingHandler;
