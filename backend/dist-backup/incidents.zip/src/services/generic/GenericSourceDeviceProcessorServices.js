"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericSourceDeviceProcessorServices = void 0;
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const GenericSourceEndpointService_1 = require("../../collectors/services/GenericSourceEndpointService");
const GenericSourceConfiguration_1 = require("../../common/generic/GenericSourceConfiguration");
const _ = __importStar(require("lodash"));
const Util_1 = require("../../common/Util");
const GraphFactory_1 = require("../../model/GraphFactory");
const GenericSourceUtils_1 = require("../../common/generic/GenericSourceUtils");
class GenericSourceDeviceProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    initProcessorService(tenantUid, source) {
        const sourceParts = _.split(source, Util_1.SOURCE_SEPARATOR);
        const sourceType = sourceParts[0];
        this.sourceConfiguration = GenericSourceUtils_1.GenericSourceUtils.getSourceConfiguration(sourceType);
        if (!this.sourceConfiguration) {
            throw new Error(`No configuration defined for the unrecognized source "${sourceType}"`);
        }
        if (!this.sourceConfiguration.apiDetails || this.sourceConfiguration.apiDetails.length === 0) {
            throw new Error(`No apiDetails in the source configuration for source ${sourceType}`);
        }
        if (!this.sourceConfiguration.mergedModelDataMapping) {
            throw new Error(`No mergedModelDataMapping in the source configuration for source ${sourceType}`);
        }
        this.entityService = new GenericSourceEndpointService_1.GenericSourceEndpointService(tenantUid, source, this.sourceConfiguration);
    }
    getSourceConfiguration() {
        return this.sourceConfiguration;
    }
    isIdentifier(mappedType) {
        return (mappedType) ? !!GraphFactory_1.SIMPLE_MODELS[mappedType] : false;
    }
    async obtainIdentifierChanges(device, vertexState, currentTopology, changes, unchanged) {
        if (!this.sourceConfiguration) {
            throw new Error('No generic model defined for processor service');
        }
        const identifiersToVerify = Object.entries(this.sourceConfiguration.mergedModelDataMapping.storedFields)
            .filter(([, val]) => this.isIdentifier(val.mappedType) && val.mappedType !== GenericSourceConfiguration_1.StoredFieldMappedType.EXT_ID)
            .map(([, val]) => val);
        for (const identifier of identifiersToVerify) {
            if (identifier !== undefined) {
                const fieldValue = _.get(device, identifier.sourceFieldName);
                if (Array.isArray(fieldValue)) {
                    for (const element of fieldValue) {
                        await this.verifyChange(currentTopology, element, identifier.mappedType, changes, unchanged);
                    }
                }
                else {
                    await this.verifyChange(currentTopology, fieldValue, identifier.mappedType, changes, unchanged);
                }
            }
        }
    }
}
exports.GenericSourceDeviceProcessorServices = GenericSourceDeviceProcessorServices;
