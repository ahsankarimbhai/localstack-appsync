"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RefreshLoadStatusRunner = void 0;
const RebalanceNeptuneClustersBase_1 = require("./RebalanceNeptuneClustersBase");
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const bluebird_1 = require("bluebird");
class RefreshLoadStatusRunner extends RebalanceNeptuneClustersBase_1.RebalanceNeptuneClustersBase {
    async run(logsInLoading) {
        this.logger.info('Start RefreshLoadStatusRunner');
        const tenantsToBulkLoad = [];
        if (logsInLoading.length === 0) {
            this.logger.info('End RefreshLoadStatusRunner, no tenant has status LOADING');
            return tenantsToBulkLoad;
        }
        await bluebird_1.Promise.map(logsInLoading, async (migrationLog) => {
            var _a, _b;
            const tenantUid = migrationLog.tenantUid;
            this.logger.info(`refresh load status for tenant ${tenantUid}`);
            try {
                const logDetails = await this.neptuneShardMigrationLogDetailRepo.getTenantMigrationLogDetails(tenantUid);
                if (logDetails.length === 0) {
                    throw new Error('logDetails is not found');
                }
                const neptuneWriterEndpoint = this.getClusterEndpoint(migrationLog.migrateToShardId);
                const neptuneUri = `https://${neptuneWriterEndpoint.rawImportEndpoint}:${neptuneWriterEndpoint.port}`;
                const updatedLogDetails = [];
                for (const item of logDetails) {
                    if (item.loadId && (!item.loadStatus || this.LOADER_IN_PROGRESS_CODES.includes(item.loadStatus))) {
                        const res = await this.getNeptuneBulkLoadStatus(tenantUid, neptuneUri, item.loadId);
                        item.loadStatus = (_b = (_a = res.payload) === null || _a === void 0 ? void 0 : _a.overallStatus) === null || _b === void 0 ? void 0 : _b.status;
                        updatedLogDetails.push(item);
                    }
                }
                await bluebird_1.Promise.map(updatedLogDetails, async (logDetail) => {
                    await this.neptuneShardMigrationLogDetailRepo.update(logDetail.exportId, undefined, undefined, undefined, undefined, logDetail.loadStatus);
                }, { concurrency: 500 });
                if (logDetails.every(item => item.loadStatus === this.LOADER_COMPLETED_CODE)) {
                    await this.completeMigration(tenantUid, migrationLog.migrateFromShardId, migrationLog.migrateToShardId);
                }
                else if (logDetails.some(item => !item.loadId || !item.loadStatus || this.LOADER_IN_PROGRESS_CODES.includes(item.loadStatus))) {
                    await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOADING);
                    if (logDetails.some(item => !item.loadId)) {
                        tenantsToBulkLoad.push(tenantUid);
                    }
                }
                else {
                    await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOAD_FAILED);
                }
            }
            catch (err) {
                this.logger.error(`failed to refresh load status for tenant ${tenantUid}, error: ${err.message}`);
            }
        });
        this.logger.info('End RefreshLoadStatusRunner');
        return tenantsToBulkLoad;
    }
    async getNeptuneBulkLoadStatus(tenantUid, neptuneUri, loadId) {
        const res = await this.neptuneHttpClient.request({
            method: 'get',
            baseURL: neptuneUri,
            headers: {
                Accept: 'application/json'
            },
            url: `/loader/${loadId}`
        });
        this.logger.info(`Get neptune bulk load status for tenant ${tenantUid}: ${JSON.stringify(res.data)}`);
        return res.data;
    }
    async completeMigration(tenantUid, migrateFromShardId, migrateToShardId) {
        const [fromShardNeptuneEntriesCount, toShardNeptuneEntriesCount] = await bluebird_1.Promise.all([
            this.countNeptuneEntries(tenantUid, migrateFromShardId, true),
            this.countNeptuneEntries(tenantUid, migrateToShardId, true)
        ]);
        const isDone = fromShardNeptuneEntriesCount.verticesCount === toShardNeptuneEntriesCount.verticesCount
            && fromShardNeptuneEntriesCount.edgesCount === toShardNeptuneEntriesCount.edgesCount;
        await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, isDone ? NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.DONE : NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.FAILED, undefined, Date.now());
        await this.neptuneShardRepo.upsertNeptuneShard({
            tenantUid,
            shardId: isDone ? migrateToShardId : migrateFromShardId
        });
        this.logger.info(isDone
            ? `tenant ${tenantUid} is migrated successfully from neptune shard ${migrateFromShardId} to ${migrateToShardId}`
            : `tenant ${tenantUid} is migrated failed, neptune entry count is inconsistent, before: ${JSON.stringify(fromShardNeptuneEntriesCount)}, after: ${JSON.stringify(toShardNeptuneEntriesCount)}`);
    }
}
exports.RefreshLoadStatusRunner = RefreshLoadStatusRunner;
