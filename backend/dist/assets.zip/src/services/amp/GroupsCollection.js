"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupsCollection = void 0;
const AmpCollection_1 = require("./AmpCollection");
class GroupsCollection extends AmpCollection_1.AmpCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker, GroupsCollection.RETRY_CONFIG);
        this.functionState = functionState;
    }
}
exports.GroupsCollection = GroupsCollection;
GroupsCollection.INITIAL_RETRY_DELAY = 30000;
GroupsCollection.RETRY_TIMEOUT = 120000;
GroupsCollection.RETRY_CONFIG = {
    retries: 5,
    delay: 30000,
    timeout: 120000,
    backoff: 'NEXT_RETRY_DELAY'
};
