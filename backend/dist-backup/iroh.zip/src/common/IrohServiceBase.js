"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohServiceBase = void 0;
const axios_1 = __importDefault(require("axios"));
const LambdaLogger_1 = require("./LambdaLogger");
const IrohClient_1 = require("./IrohClient");
class IrohServiceBase {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!process.env.IROH_URI) {
            throw new Error('IROH_URI is not set');
        }
        this.irohUri = process.env.IROH_URI;
        this.axios = axios_1.default.create();
    }
    async getOptions(url, data, method = 'get') {
        const token = await (0, IrohClient_1.getAccessToken)(this.tenantUid);
        return {
            method,
            baseURL: this.irohUri,
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${token}`
            },
            url,
            data
        };
    }
}
exports.IrohServiceBase = IrohServiceBase;
