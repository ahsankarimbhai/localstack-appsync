"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuoUsersProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const PersonProcessorService_1 = require("../common/PersonProcessorService");
const DuoUserService_1 = require("../../collectors/services/DuoUserService");
class DuoUsersProcessorServices extends PersonProcessorService_1.PersonProcessorService {
    async obtainIdentifierChanges(duoUser, vertexState, currentTopology, changes, unchanged) {
        if (duoUser.username.includes('@')) {
            await this.verifyChange(currentTopology, duoUser.username, CommonTypes_1.VertexType.USER, changes, unchanged);
        }
        if (duoUser.email.includes('@')) {
            await this.verifyChange(currentTopology, duoUser.email, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
        }
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new DuoUserService_1.DuoUserService(tenantUid, sourceId);
    }
}
exports.DuoUsersProcessorServices = DuoUsersProcessorServices;
