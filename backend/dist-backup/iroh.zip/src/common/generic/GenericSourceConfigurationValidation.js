"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericSourceConfigurationValidation = void 0;
const GenericSourceConfiguration_1 = require("./GenericSourceConfiguration");
const fs_1 = __importDefault(require("fs"));
const GenericSourceUtils_1 = require("./GenericSourceUtils");
class GenericSourceConfigurationValidation {
    static validateSourceConfiguration(config) {
        const warnings = [];
        const errors = [];
        GenericSourceConfigurationValidation.validateRootLevel(config, errors, warnings);
        if (config.integrationModule) {
            GenericSourceConfigurationValidation.validateIntegrationModule(config, errors, warnings);
        }
        if (config.apiDetails) {
            GenericSourceConfigurationValidation.validateApiDetails(config, errors, warnings);
        }
        if (config.mergedModelDataMapping) {
            GenericSourceConfigurationValidation.validateMergedModelDataMapping(config, errors, warnings);
        }
        if (config.peMapping) {
            GenericSourceConfigurationValidation.validatePeMapping(config, errors, warnings);
        }
        if (config.uiMapping) {
            GenericSourceConfigurationValidation.validateUiMapping(config, errors, warnings);
        }
        return { errors, warnings };
    }
    static validateRootLevel(config, errors, warnings) {
        const rootLevelFields = ['sourceName', 'integrationModule', 'apiDetails', 'mergedModelDataMapping'];
        const optionalRootLevelFields = ['requiredFeatureFlag', 'peMapping', 'uiMapping'];
        const { extraFields, missingFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config, rootLevelFields, optionalRootLevelFields);
        if (extraFields.length > 0) {
            warnings.push(`Unrecognized field(s) at the root level: ${extraFields.join(', ')}`);
        }
        if (missingFields.length > 0) {
            errors.push(`Missing field(s) at the root level: ${missingFields.join(', ')}`);
        }
        const fieldsThatShouldBeStrings = ['sourceName', 'requiredFeatureFlag'];
        for (const fieldName of fieldsThatShouldBeStrings) {
            if (config[fieldName] && typeof config[fieldName] !== 'string') {
                errors.push(`Incorrect type for field ${fieldName}: should be string, not ${typeof config[fieldName]}`);
            }
        }
    }
    static validateIntegrationModule(config, errors, warnings) {
        const integrationModuleFields = ['moduleTypeClass', 'attributesToMap'];
        const { extraFields, missingFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.integrationModule, integrationModuleFields);
        if (extraFields.length > 0) {
            warnings.push(`Unrecognized field(s) within integrationModule: ${extraFields.join(', ')}`);
        }
        if (missingFields.length > 0) {
            errors.push(`Missing field(s) within integrationModule: ${missingFields.join(', ')}`);
        }
        if (missingFields.indexOf('attributesToMap') === -1) {
            if (!Array.isArray(config.integrationModule.attributesToMap) || config.integrationModule.attributesToMap.length === 0) {
                errors.push('Incorrect type or content for field attributesToMap: should be an array with at least 1 attribute object');
            }
            else {
                let isAnyBaseURL = false;
                for (let i = 0; i < config.integrationModule.attributesToMap.length; i += 1) {
                    isAnyBaseURL = isAnyBaseURL || GenericSourceConfigurationValidation.validateAttributeToMap(config, errors, warnings, i);
                }
                if (!isAnyBaseURL) {
                    errors.push('Missing attribute named "baseURL" within array integrationModule.attributesToMap: every module uses a "baseURL" value to perform queries');
                }
            }
        }
    }
    static validateAttributeToMap(config, errors, warnings, i) {
        let isAnyBaseURL = false;
        const attribute = config.integrationModule.attributesToMap[i];
        const attributesToMapFields = ['name', 'source'];
        const optionalAttributeFields = ['path', 'regex', 'captureGroupName', 'literal', 'overwrite'];
        const { extraFields: extraAttributeFields, missingFields: missingAttributeFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(attribute, attributesToMapFields, optionalAttributeFields);
        if (extraAttributeFields.length > 0) {
            warnings.push(`Unrecognized field(s) within integrationModule.attributesToMap[${i}]: ${extraAttributeFields.join(', ')}`);
        }
        if (missingAttributeFields.length > 0) {
            errors.push(`Missing field(s) within integrationModule.attributesToMap[${i}]: ${missingAttributeFields.join(', ')}`);
        }
        if (attribute.captureGroupName && !attribute.regex) {
            warnings.push(`Found field captureGroupName but no regex field within integrationModule.attributesToMap[${i}]: captureGroupName is used by the regex field`);
        }
        if (!Object.values(GenericSourceConfiguration_1.ModuleAttributeSource).includes(attribute.source)) {
            errors.push(`Invalid source value "${attribute.source}" within integrationModule.attributesToMap[${i}]: valid sources values are [${Object.values(GenericSourceConfiguration_1.ModuleAttributeSource).join(', ')}]`);
        }
        if ((attribute.source === GenericSourceConfiguration_1.ModuleAttributeSource.INSTANCE || attribute.source === GenericSourceConfiguration_1.ModuleAttributeSource.TYPE) && !attribute.path) {
            errors.push(`Missing field "path" within integrationModule.attributesToMap[${i}]: path is required when source=${attribute.source}`);
        }
        if (attribute.source === GenericSourceConfiguration_1.ModuleAttributeSource.LITERAL && !attribute.literal) {
            errors.push(`Missing field "literal" within integrationModule.attributesToMap[${i}]: literal is required when source=literal`);
        }
        if (attribute.name) {
            if (attribute.name === 'baseURL') {
                isAnyBaseURL = true;
            }
            else if (attribute.name.toLowerCase() === 'baseurl') {
                warnings.push(`Found name value "${attribute.name}", but the expected field is "baseURL" within integrationModule.attributesToMap[${i}]: check if this was a mistake`);
            }
        }
        return isAnyBaseURL;
    }
    static validateApiDetails(config, errors, warnings) {
        if (!Array.isArray(config.apiDetails) || config.apiDetails.length === 0) {
            errors.push('Incorrect type for field apiDetails: should be an array with 1 element');
        }
        else {
            for (let i = 0; i < config.apiDetails.length; i += 1) {
                const apiDetailsFields = ['fetchData'];
                const optionalApiDetailsFields = ['metaData', 'mapData'];
                const { extraFields, missingFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.apiDetails[i], apiDetailsFields, optionalApiDetailsFields);
                if (extraFields.length > 0) {
                    warnings.push(`Unrecognized field(s) within apiDetails[${i}]: ${extraFields.join(', ')}`);
                }
                if (missingFields.length > 0) {
                    errors.push(`Missing field(s) within apiDetails[${i}]: ${missingFields.join(', ')}`);
                }
                if (config.apiDetails[i].metaData) {
                    GenericSourceConfigurationValidation.validateMetaData(config, errors, warnings, i);
                }
                else if (config.apiDetails.length > 1) {
                    warnings.push(`No metaData found within apiDetails[${i}]: metaData is required to switch between multiple apiDetails instructions`);
                }
                if (config.apiDetails[i].fetchData) {
                    GenericSourceConfigurationValidation.validateFetchData(config, errors, warnings, i);
                }
            }
        }
    }
    static validateMetaData(config, errors, warnings, i) {
        var _a;
        const metaDataFields = ['referenceName'];
        const optionalMetaDataFields = ['nextReference'];
        const { extraFields: extraMetaDataFields, missingFields: missingMetaDataFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.apiDetails[i].metaData, metaDataFields, optionalMetaDataFields);
        if (extraMetaDataFields.length > 0) {
            warnings.push(`Unrecognized field(s) within apiDetails[${i}].metaData: ${extraMetaDataFields.join(', ')}`);
        }
        if (missingMetaDataFields.length > 0) {
            errors.push(`Missing field(s) within apiDetails[${i}].metaData: ${missingMetaDataFields.join(', ')}`);
        }
        if (config.apiDetails[i].metaData.nextReference) {
            let isMatchingReferenceNameFound = false;
            for (let j = 0; j < config.apiDetails.length; j += 1) {
                if (i !== j && ((_a = config.apiDetails[j].metaData) === null || _a === void 0 ? void 0 : _a.referenceName) === config.apiDetails[i].metaData.nextReference) {
                    isMatchingReferenceNameFound = true;
                }
            }
            if (!isMatchingReferenceNameFound) {
                errors.push(`No ApiDetails with a referenceName "${config.apiDetails[i].metaData.nextReference}" found to match nextReference within apiDetails[${i}] (which has referenceName "${config.apiDetails[i].metaData.referenceName}")`);
            }
        }
    }
    static validateFetchData(config, errors, warnings, i) {
        const fetchDataFields = ['relativeUrl', 'extractData', 'errorHandling'];
        const optionalFetchDataFields = ['httpMethod', 'pagingParamName', 'urlParamNamesAndValues', 'headers', 'body', 'extractNextLink', 'loopUntilEmptyResponse', 'loopUntilEmptyDataArray'];
        const { extraFields: extraFetchDataFields, missingFields: missingFetchDataFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.apiDetails[i].fetchData, fetchDataFields, optionalFetchDataFields);
        if (extraFetchDataFields.length > 0) {
            warnings.push(`Unrecognized field(s) within apiDetails[${i}].fetchData: ${extraFetchDataFields.join(', ')}`);
        }
        if (missingFetchDataFields.length > 0) {
            errors.push(`Missing field(s) within apiDetails[${i}].fetchData: ${missingFetchDataFields.join(', ')}`);
        }
        if (config.apiDetails[i].fetchData.extractNextLink) {
            const extractNextLinkFields = ['source'];
            const optionalExtractNextLinkFields = ['path', 'regex', 'captureGroupName'];
            const { extraFields: extraExtractNextLinkFields, missingFields: missingExtractNextLinkFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.apiDetails[i].fetchData.extractNextLink, extractNextLinkFields, optionalExtractNextLinkFields);
            if (extraExtractNextLinkFields.length > 0) {
                warnings.push(`Unrecognized field(s) within apiDetails[${i}].fetchData.extractNextLink: ${extraExtractNextLinkFields.join(', ')}`);
            }
            if (missingExtractNextLinkFields.length > 0) {
                errors.push(`Missing field(s) within apiDetails[${i}].fetchData.extractNextLink: ${missingExtractNextLinkFields.join(', ')}`);
            }
            if (config.apiDetails[i].fetchData.extractNextLink.source && !Object.values(GenericSourceConfiguration_1.ExtractNextLinkSource).includes(config.apiDetails[i].fetchData.extractNextLink.source)) {
                errors.push(`Invalid source value "${config.apiDetails[i].fetchData.extractNextLink.source}" within apiDetails[${i}].fetchData.extractNextLink: valid sources values are [${Object.values(GenericSourceConfiguration_1.ExtractNextLinkSource).join(', ')}]`);
            }
            if (config.apiDetails[i].fetchData.extractNextLink.source === GenericSourceConfiguration_1.ExtractNextLinkSource.RESPONSE && !config.apiDetails[i].fetchData.extractNextLink.path) {
                errors.push(`Missing field "path" within apiDetails[${i}].fetchData.extractNextLink: path is required when source=response`);
            }
        }
        if (config.apiDetails[i].fetchData.extractData) {
            const extractDataFields = ['path'];
            const optionalExtractDataFields = ['saveDataArrayName'];
            const { extraFields: extraExtractDataFields, missingFields: missingExtractDataFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.apiDetails[i].fetchData.extractData, extractDataFields, optionalExtractDataFields);
            if (extraExtractDataFields.length > 0) {
                warnings.push(`Unrecognized field(s) within apiDetails[${i}].fetchData.extractData: ${extraExtractDataFields.join(', ')}`);
            }
            if (missingExtractDataFields.length > 0) {
                errors.push(`Missing field(s) within apiDetails[${i}].fetchData.extractData: ${missingExtractDataFields.join(', ')}`);
            }
        }
        if (config.apiDetails[i].fetchData.errorHandling) {
            const errorHandlingFields = ['messagePath'];
            const optionalErrorHandlingFields = ['detailsPath', 'codePath', 'codesAndSolutions'];
            const { extraFields: extraErrorHandlingFields, missingFields: missingErrorHandlingFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.apiDetails[i].fetchData.errorHandling, errorHandlingFields, optionalErrorHandlingFields);
            if (extraErrorHandlingFields.length > 0) {
                warnings.push(`Unrecognized field(s) within apiDetails[${i}].fetchData.errorHandling: ${extraErrorHandlingFields.join(', ')}`);
            }
            if (missingErrorHandlingFields.length > 0) {
                errors.push(`Missing field(s) within apiDetails[${i}].fetchData.errorHandling: ${missingErrorHandlingFields.join(', ')}`);
            }
        }
        let numberOfLoops = 0;
        if (config.apiDetails[i].fetchData.loopUntilEmptyResponse) {
            const optionalLoopUntilEmptyResponseFields = ['path', 'iteratorStart', 'iteratorIncrement', 'iteratorValueName', 'iteratorRangeName'];
            const { extraFields: extraLoopUntilEmptyResponseFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.apiDetails[i].fetchData.loopUntilEmptyResponse, [], optionalLoopUntilEmptyResponseFields);
            if (extraLoopUntilEmptyResponseFields.length > 0) {
                warnings.push(`Unrecognized field(s) within apiDetails[${i}].fetchData.loopUntilEmptyResponse: ${extraLoopUntilEmptyResponseFields.join(', ')}`);
            }
            numberOfLoops += 1;
        }
        if (config.apiDetails[i].fetchData.loopUntilEmptyDataArray) {
            const loopUntilEmptyDataArrayFields = ['readDataArrayName'];
            const optionalLoopUntilEmptyDataArrayFields = ['batchSize', 'saveBatchName'];
            const { extraFields: extraLoopUntilEmptyDataArrayFields, missingFields: missingLoopUntilEmptyDataArrayFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.apiDetails[i].fetchData.loopUntilEmptyDataArray, loopUntilEmptyDataArrayFields, optionalLoopUntilEmptyDataArrayFields);
            if (extraLoopUntilEmptyDataArrayFields.length > 0) {
                warnings.push(`Unrecognized field(s) within apiDetails[${i}].fetchData.loopUntilEmptyDataArray: ${extraLoopUntilEmptyDataArrayFields.join(', ')}`);
            }
            if (missingLoopUntilEmptyDataArrayFields.length > 0) {
                errors.push(`Missing field(s) within apiDetails[${i}].fetchData.loopUntilEmptyDataArray: ${missingLoopUntilEmptyDataArrayFields.join(', ')}`);
            }
            numberOfLoops += 1;
        }
        if (numberOfLoops > 1) {
            warnings.push(`More than 1 loop detected within apiDetails[${i}].fetchData: Only 1 loop will be used`);
        }
    }
    static validateMergedModelDataMapping(config, errors, warnings) {
        const mergedModelDataMappingFields = ['keyProperties', 'storedFields'];
        const optionalMergedModelDataMappingFields = ['sourceFieldsToExcludeInStateHashCalculation'];
        const { extraFields, missingFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.mergedModelDataMapping, mergedModelDataMappingFields, optionalMergedModelDataMappingFields);
        if (extraFields.length > 0) {
            warnings.push(`Unrecognized field(s) within mergedModelDataMapping: ${extraFields.join(', ')}`);
        }
        if (missingFields.length > 0) {
            errors.push(`Missing field(s) within mergedModelDataMapping: ${missingFields.join(', ')}`);
        }
        const fieldsThatShouldBeArrays = ['keyProperties', 'sourceFieldsToExcludeInStateHashCalculation'];
        for (const fieldName of fieldsThatShouldBeArrays) {
            if (config.mergedModelDataMapping[fieldName] && !Array.isArray(config.mergedModelDataMapping[fieldName])) {
                errors.push(`Incorrect type for field ${fieldName}: should be array, not ${typeof config.mergedModelDataMapping[fieldName]}`);
            }
        }
        if (Array.isArray(config.mergedModelDataMapping.keyProperties) && config.mergedModelDataMapping.keyProperties.indexOf('extId') === -1) {
            errors.push('Missing value from array keyProperties: "extId" is a required key property');
        }
        if (typeof config.mergedModelDataMapping.storedFields === 'object' && !Array.isArray(config.mergedModelDataMapping.storedFields)) {
            const storedFieldNames = Object.getOwnPropertyNames(config.mergedModelDataMapping.storedFields);
            let isAnyExtId = false;
            for (const name of storedFieldNames) {
                const storedField = config.mergedModelDataMapping.storedFields[name];
                if (storedField.mappedType === 'extId') {
                    isAnyExtId = true;
                }
                else if (storedField.mappedType && !Object.values(GenericSourceConfiguration_1.StoredFieldMappedType).includes(storedField.mappedType)) {
                    errors.push(`Incorrect mappedType for storedField "${name}" within mergedModelDataMapping: mappedType "${storedField.mappedType}" is not one of the StoredFieldMappedType: [${Object.values(GenericSourceConfiguration_1.StoredFieldMappedType).sort().join(', ')}]`);
                }
            }
            if (!isAnyExtId) {
                errors.push('Missing storedField with mappedType "extId" within object mergedModelDataMapping.storedFields: every module requires 1 "extId" value to uniquely identify devices');
            }
        }
        else {
            errors.push(`Incorrect type for field storedFields: should be object, not ${Array.isArray(config.mergedModelDataMapping.storedFields) ? 'array' : typeof config.mergedModelDataMapping.storedFields}`);
        }
    }
    static validatePeMapping(config, errors, warnings) {
        const peMappingFields = ['fileName'];
        const optionalPeMappingFields = ['className'];
        const { extraFields, missingFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.peMapping, peMappingFields, optionalPeMappingFields);
        if (extraFields.length > 0) {
            warnings.push(`Unrecognized field(s) within peMapping: ${extraFields.join(', ')}`);
        }
        if (missingFields.length > 0) {
            errors.push(`Missing field(s) within peMapping: ${missingFields.join(', ')}`);
        }
        if (config.peMapping.fileName) {
            let fileName = config.peMapping.fileName;
            if (config.peMapping.fileName.match(/(.ts$)|(.js$)/g)) {
                warnings.push(`Incorrect fileName "${config.peMapping.fileName}" within peMapping: fileName should exclude the file extension like .js or .ts`);
                fileName = config.peMapping.fileName.substring(0, config.peMapping.fileName.length - 3);
            }
            const tsFileExists = fs_1.default.existsSync(`${GenericSourceUtils_1.GenericSourceUtils.configurationPath}/${fileName}.ts`);
            const jsFileExists = fs_1.default.existsSync(`${GenericSourceUtils_1.GenericSourceUtils.configurationPath}/${fileName}.js`);
            if (!tsFileExists && !jsFileExists) {
                errors.push(`Missing PE Mapping file "${config.peMapping.fileName}" referenced by sourceName "${config.sourceName}": .ts or .js file should be in the same directory as this configuration`);
            }
            else {
                const fileText = tsFileExists ? fs_1.default.readFileSync(`${GenericSourceUtils_1.GenericSourceUtils.configurationPath}/${fileName}.ts`, 'utf-8') : fs_1.default.readFileSync(`${GenericSourceUtils_1.GenericSourceUtils.configurationPath}/${fileName}.js`, 'utf-8');
                const className = config.peMapping.className ? config.peMapping.className : fileName;
                const expectedClassLine = `export class ${className} implements GenericSourceMappingHandler`;
                if (!fileText.includes(expectedClassLine)) {
                    errors.push(`Missing PE Mapping class name "${className}" or interface from PE Mapping file "${fileName}" referenced by sourceName "${config.sourceName}": the className and interface should appear in the PE Mapping file like "export class ${className} implements GenericSourceMappingHandler"`);
                }
                const expectedFunctionLine = 'handler(sourceConfiguration: GenericSourceConfiguration, pe: any, pv: any, ps: any)';
                if (!fileText.includes(expectedFunctionLine)) {
                    errors.push(`Missing PE Mapping "handler" function from PE Mapping file "${fileName}" referenced by sourceName "${config.sourceName}": the handler function should appear in the PE Mapping file like "handler(sourceConfiguration: GenericSourceConfiguration, pe: any, pv: any, ps: any)"`);
                }
            }
        }
    }
    static validateUiMapping(config, errors, warnings) {
        const uiMappingFields = ['sourceTypeDisplayName', 'displayProperties', 'icon'];
        const optionalUiMappingFields = ['iconDuskMode'];
        const { extraFields, missingFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(config.uiMapping, uiMappingFields, optionalUiMappingFields);
        if (extraFields.length > 0) {
            warnings.push(`Unrecognized field(s) within uiMapping: ${extraFields.join(', ')}`);
        }
        if (missingFields.length > 0) {
            errors.push(`Missing field(s) within uiMapping: ${missingFields.join(', ')}`);
        }
        if (config.uiMapping.displayProperties) {
            for (let i = 0; i < config.uiMapping.displayProperties.length; i += 1) {
                const displayPropertiesFields = ['sourcePropertyName', 'translationKey'];
                const optionalDisplayPropertiesFields = ['dataType'];
                const property = config.uiMapping.displayProperties[i];
                const { extraFields: displayPropertiesExtraFields, missingFields: displayPropertiesMissingFields } = GenericSourceConfigurationValidation.identifyMismatchedFieldNames(property, displayPropertiesFields, optionalDisplayPropertiesFields);
                if (displayPropertiesExtraFields.length > 0) {
                    warnings.push(`Unrecognized field(s) within uiMapping.displayProperties[${i}]: ${displayPropertiesExtraFields.join(', ')}`);
                }
                if (displayPropertiesMissingFields.length > 0) {
                    errors.push(`Missing field(s) within uiMapping.displayProperties[${i}]: ${displayPropertiesMissingFields.join(', ')}`);
                }
            }
        }
    }
    static identifyMismatchedFieldNames(objectToCheck, expectedFieldNames, optionalFieldNames = []) {
        const extraFields = [];
        let missingFields = [];
        for (const fieldName of Object.getOwnPropertyNames(objectToCheck)) {
            const indexOfFieldName = expectedFieldNames.indexOf(fieldName);
            if (indexOfFieldName > -1) {
                if (objectToCheck[fieldName]) {
                    expectedFieldNames.splice(indexOfFieldName, 1);
                }
            }
            else if (optionalFieldNames.indexOf(fieldName) === -1) {
                extraFields.push(fieldName);
            }
        }
        if (expectedFieldNames.length > 0) {
            missingFields = missingFields.concat(expectedFieldNames);
        }
        return { extraFields, missingFields };
    }
}
exports.GenericSourceConfigurationValidation = GenericSourceConfigurationValidation;
