"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Handler = exports.Notification = void 0;
class Notification {
    constructor() {
        this.timeStamp = Date.now();
    }
}
exports.Notification = Notification;
class Handler {
    constructor(callback, getIsEnabled = async () => true) {
        this.callback = callback;
        this.getIsEnabled = getIsEnabled;
        this.enabled = null;
    }
    async isEnabled() {
        if (this.enabled === null) {
            this.enabled = await this.getIsEnabled();
        }
        return this.enabled;
    }
}
exports.Handler = Handler;
