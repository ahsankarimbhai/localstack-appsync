"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQSService = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const node_http_handler_1 = require("@smithy/node-http-handler");
const LambdaLogger_1 = require("../LambdaLogger");
const RetryUtil_1 = require("../RetryUtil");
class SQSService {
    constructor(requestTimeout = 10000) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.client = new client_sqs_1.SQSClient({
            region: process.env.AWS_REGION,
            logger: this.logger,
            requestHandler: new node_http_handler_1.NodeHttpHandler({
                requestTimeout: +(process.env.SQS_REQUEST_TIMEOUT_MILLISECONDS || requestTimeout)
            })
        });
    }
    async send(request) {
        const resp = await this.client.send(new client_sqs_1.SendMessageCommand(request));
        return resp.MessageId;
    }
    async receive(request, retries = 2) {
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, {
            retries,
            backoff: 'FIXED',
            delay: 100
        });
        const emptyResponseError = 'No message is returned';
        let messages = [];
        try {
            messages = await retryUtil.executeWithRetry(async () => {
                const resp = await this.client.send(new client_sqs_1.ReceiveMessageCommand(request));
                if (!resp.Messages || resp.Messages.length === 0) {
                    throw new Error(emptyResponseError);
                }
                return resp.Messages;
            });
        }
        catch (err) {
            if (err.message !== emptyResponseError) {
                throw err;
            }
        }
        return messages;
    }
    async deleteBatch(request) {
        if (!request.Entries || request.Entries.length === 0 || request.Entries.length > 10) {
            throw new Error('Should delete 1-10 message at once.');
        }
        const resp = await this.client.send(new client_sqs_1.DeleteMessageBatchCommand(request));
        if (resp.Failed && resp.Failed.length > 0) {
            throw new Error(`Failed to delete messages: ${resp.Failed.map(f => JSON.stringify(f)).join(',')}`);
        }
    }
}
exports.SQSService = SQSService;
