"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookStatus = exports.BasePushCollectorService = exports.BaseCollectorService = exports.BasePersonService = exports.BaseEndpointService = exports.BaseEntityService = exports.PostureTopologyChange = void 0;
const _ = __importStar(require("lodash"));
const FunctionStateServices_1 = require("./FunctionStateServices");
const LambdaLogger_1 = require("./LambdaLogger");
const Util_1 = require("./Util");
const AwsSecretsService_1 = require("./AwsSecretsService");
class PostureTopologyChange {
    constructor(type, newVertex) {
        this.type = type;
        this.newVertex = newVertex;
    }
}
exports.PostureTopologyChange = PostureTopologyChange;
class BaseEntityService {
    constructor(tenantUid, sourceId) {
        this.tenantUid = tenantUid;
        this.sourceId = sourceId;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    getPvLabel() {
        return `${this.getPvType()}${Util_1.SOURCE_SEPARATOR}${this.sourceId}`;
    }
    getPsLabel() {
        return `${this.getPsType()}${Util_1.SOURCE_SEPARATOR}${this.sourceId}`;
    }
    isDeleteEvent(body) {
        return false;
    }
    getDeletedEvents(body) {
        throw new Error('method has not been implemented yet');
    }
    processNotifications(body) {
        return JSON.parse(body.data);
    }
}
exports.BaseEntityService = BaseEntityService;
class BaseEndpointService extends BaseEntityService {
}
exports.BaseEndpointService = BaseEndpointService;
class BasePersonService extends BaseEntityService {
}
exports.BasePersonService = BasePersonService;
class BaseCollectorService {
    constructor(tenantUid, sourceId) {
        this.tenantUid = tenantUid;
        this.sourceId = sourceId;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    getInitialState(functionName, source) {
        return new FunctionStateServices_1.FunctionStateServices().getByKey(this.tenantUid, functionName, source);
    }
    setFunctionStateToSuccess(collection, functionState) {
        functionState.lastSuccessfulSequence = _.get(collection, 'timeBasedAsyncLambdaInvoker.context.appData.currentSequenceStart', 0);
        const state = _.omit((0, Util_1.parseJSONString)(functionState.getState()), [FunctionStateServices_1.FunctionState.URI_ON_FAILURE, FunctionStateServices_1.FunctionState.COLLECTION_ERROR]);
        functionState.setState(JSON.stringify(state));
        return new FunctionStateServices_1.FunctionStateServices().save(functionState);
    }
    setFunctionStateToFailure(collection, functionState) {
        const state = (0, Util_1.parseJSONString)(functionState.getState());
        _.set(state, FunctionStateServices_1.FunctionState.URI_ON_FAILURE, collection.getNextUri());
        functionState.setState(JSON.stringify(state));
        return new FunctionStateServices_1.FunctionStateServices().save(functionState);
    }
    getProducer(source) {
        return this.sourceId ? `${source}${Util_1.SOURCE_SEPARATOR}${this.sourceId}` : source;
    }
    async fetchEntitiesPostProcessing(tenantUid, sourceId) {
        return Promise.resolve();
    }
    async fetchSingleEntity(deviceId) {
        return Promise.resolve(undefined);
    }
}
exports.BaseCollectorService = BaseCollectorService;
class BasePushCollectorService extends BaseCollectorService {
    async initWebhookTokenImpl(secrets, source) {
        let webhookSecret = secrets === null || secrets === void 0 ? void 0 : secrets.webhookSecret;
        if (!webhookSecret) {
            this.logger.info(`generating webhook token for tenant ${this.tenantUid} and ${source} producer ${this.sourceId}`);
            webhookSecret = (0, Util_1.generateSecret)(32);
            const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(this.tenantUid);
            await awsSecretsService.setSecretValue((0, Util_1.toSourceString)(source, this.sourceId), { ...secrets || {}, webhookSecret }, true);
        }
        return webhookSecret;
    }
    async removeWebhookSecrets(sourceString, secrets) {
        const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(this.tenantUid);
        await awsSecretsService.removeSecretValue(sourceString);
    }
    errorStatus(producer, error, errorExtraData, hasRegisteredWebhooks = true, exceptionDetail) {
        if (errorExtraData) {
            this.logger.warn(`${errorExtraData} ${exceptionDetail ? `detail: ${exceptionDetail}` : ''}`);
        }
        return new WebhookStatus(producer, undefined, undefined, error, errorExtraData, hasRegisteredWebhooks, exceptionDetail);
    }
}
exports.BasePushCollectorService = BasePushCollectorService;
class WebhookStatus {
    constructor(producer, laststatus, lastcalled, error, errorExtraData, hasRegisteredWebhooks = true, exceptionDetail) {
        this.producer = producer;
        this.laststatus = laststatus;
        this.lastcalled = lastcalled;
        this.error = error;
        this.errorExtraData = errorExtraData;
        this.hasRegisteredWebhooks = hasRegisteredWebhooks;
        this.exceptionDetail = exceptionDetail;
    }
    isSuccess() {
        if (this.laststatus && this.laststatus.toLowerCase() === 'success') {
            return true;
        }
        return false;
    }
    isErrorUnknownAPIkey() {
        var _a;
        if (this.error && ((_a = this.errorExtraData) === null || _a === void 0 ? void 0 : _a.toLowerCase().includes('unknown api key or client id'))) {
            return true;
        }
        return false;
    }
    isApiAuthError() {
        var _a;
        const exceptionDetail = (_a = this.exceptionDetail) === null || _a === void 0 ? void 0 : _a.toLowerCase();
        if (this.error
            && ((exceptionDetail === null || exceptionDetail === void 0 ? void 0 : exceptionDetail.includes('oauth2_validation_exception'))
                || (exceptionDetail === null || exceptionDetail === void 0 ? void 0 : exceptionDetail.includes('request_authentication_error')))) {
            return true;
        }
        return false;
    }
}
exports.WebhookStatus = WebhookStatus;
