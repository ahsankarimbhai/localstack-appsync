"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.incidentsNotification = exports.mapIncidentsToUnresolvedIdentity = exports.mapIncidentToIdentities = void 0;
const LambdaLogger_1 = require("./common/LambdaLogger");
const LambdaHandler_1 = require("./common/lambdahandler/LambdaHandler");
const Util_1 = require("./common/Util");
const MetricsTelemetryMiddleware_1 = require("./common/lambdahandler/MetricsTelemetryMiddleware");
const lodash_1 = __importDefault(require("lodash"));
const ElasticsearchServices_1 = require("./common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("./common/ElasticsearchFactory");
const IncidentService_1 = require("./services/common/IncidentService");
const logger = new LambdaLogger_1.LambdaLogger();
exports.mapIncidentToIdentities = new LambdaHandler_1.LambdaHandler(async (event) => {
    var _a;
    const { tenantUid } = event.requestContext.authorizer;
    const incidentId = (_a = event === null || event === void 0 ? void 0 : event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.incidentId;
    const mapIncidentToDevicesRequest = JSON.parse(event.body);
    logger.debug(`Event data: tenantId - ${tenantUid}, incidentId - ${incidentId}, devices - ${JSON.stringify(mapIncidentToDevicesRequest)}`);
    if (lodash_1.default.isEmpty(tenantUid) || lodash_1.default.isEmpty(incidentId) || lodash_1.default.isEmpty(mapIncidentToDevicesRequest)) {
        logger.error(`Missing mandatory parameter tenantUid: ${tenantUid}, incidentId: ${incidentId}`);
        return (0, Util_1.lambdaProxyResponse)('POST', 'missed mandatory parameter in request');
    }
    try {
        const connectedDevicesIds = mapIncidentToDevicesRequest.connectedInsightsIds.filter(connected => connected.identityType === 'device').map(data => data.id);
        const esService = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        await esService.addIncidentToDevices(incidentId, connectedDevicesIds);
        return (0, Util_1.lambdaProxyResponse)('POST');
    }
    catch (e) {
        logger.error('Internal error: ', e.message);
        return (0, Util_1.lambdaProxyResponse)('POST', 'internal error');
    }
}).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(MetricsTelemetryMiddleware_1.IntegrationType.LambdaProxy, logger)).toPipelines();
exports.mapIncidentsToUnresolvedIdentity = new LambdaHandler_1.LambdaHandler(async (event) => {
    var _a;
    logger.debug(`Event: ${JSON.stringify(event)}`);
    const { tenantUid } = event.requestContext.authorizer;
    const incidentId = (_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.incidentId;
    const bodyRequest = JSON.parse(event.body);
    if (lodash_1.default.isEmpty(tenantUid) || lodash_1.default.isEmpty(incidentId) || lodash_1.default.isEmpty(bodyRequest)) {
        logger.error(`Missing mandatory parameter tenantUid: ${tenantUid}, incidentId: ${incidentId}, body request: ${JSON.stringify(bodyRequest)}`);
        return (0, Util_1.lambdaProxyResponse)('POST', 'missed mandatory parameter in request', 400);
    }
    try {
        await new IncidentService_1.IncidentService(tenantUid).saveMappingOnIdentToUnresolvedIdentity(incidentId, bodyRequest.observables);
        return (0, Util_1.lambdaProxyResponse)('POST');
    }
    catch (e) {
        return (0, Util_1.lambdaProxyResponse)('POST', e.message, 400);
    }
}).withMiddlewares((0, MetricsTelemetryMiddleware_1.metricsTelemetryMiddleware)(MetricsTelemetryMiddleware_1.IntegrationType.LambdaProxy, logger)).toPipelines();
const incidentsNotification = async (event) => {
    logger.debug(`Event: ${JSON.stringify(event)}`);
    const incidentProcessingEvent = (0, Util_1.parseEvent)(event);
    if (lodash_1.default.isUndefined(incidentProcessingEvent) || lodash_1.default.isUndefined(incidentProcessingEvent.tenantId)) {
        throw new Error('Incorrect request');
    }
    const incidentService = new IncidentService_1.IncidentService(incidentProcessingEvent.tenantId);
    await incidentService.notifyIroIfDeviceHasMappedIncident(incidentProcessingEvent);
};
exports.incidentsNotification = incidentsNotification;
