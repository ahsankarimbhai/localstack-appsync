"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedConnectorComputerCollection = void 0;
const lodash_1 = __importDefault(require("lodash"));
const query_string_1 = __importDefault(require("query-string"));
const url_1 = require("url");
const Collection_1 = require("../../common/Collection");
function extractNextLink(res) {
    const reqUrl = new url_1.URL(lodash_1.default.get(res, 'config.url', ''), res.config.baseURL);
    const searchParams = reqUrl.searchParams;
    const pageSize = lodash_1.default.toNumber(searchParams.get('limit'));
    const last = res.data.last;
    if (lodash_1.default.size(res.data) < pageSize || !last) {
        return undefined;
    }
    const params = {};
    for (const [key, value] of searchParams) {
        params[key] = value;
    }
    params.last = last;
    return `${res.config.baseURL}${reqUrl.pathname}?${query_string_1.default.stringify(params)}`;
}
function extractData(res) {
    return res.data.computers;
}
class UnifiedConnectorComputerCollection extends Collection_1.Collection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, extractNextLink, extractData, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.UnifiedConnectorComputerCollection = UnifiedConnectorComputerCollection;
