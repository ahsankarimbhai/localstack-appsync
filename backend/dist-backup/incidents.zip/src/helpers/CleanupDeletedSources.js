"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CleanupDeletedSources = void 0;
const _ = __importStar(require("lodash"));
const TenantServices_1 = require("../common/TenantServices");
const ScheduleServices_1 = require("../common/ScheduleServices");
const ScheduledTaskRunner_1 = require("../scheduled/ScheduledTaskRunner");
const CloseProducerCurrentStates_1 = require("../scheduled/tasks/CloseProducerCurrentStates");
const Util_1 = require("../common/Util");
const LambdaLogger_1 = require("../common/LambdaLogger");
const CommonTypes_1 = require("../common/CommonTypes");
const ProducerUtil_1 = require("../services/common/ProducerUtil");
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const gremlin_1 = require("gremlin");
const ResourcesManager_1 = require("../common/ResourcesManager");
const NeptuneClientManager_1 = require("../common/neptune/NeptuneClientManager");
const __ = gremlin_1.process.statics;
class CleanupDeletedSources {
    constructor(whatIf = false) {
        this.whatIf = whatIf;
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!process.env.ENV_PREFIX) {
            throw new Error('ENV_PREFIX is not set');
        }
    }
    async processAllTenants() {
        var _a;
        try {
            this.logger.debug('Will be attempting to remove deleted sources for all tenants');
            const ts = new TenantServices_1.TenantServices();
            const tenants = await ts.getAllTenants();
            const safeWhatif = (_a = this.whatIf) !== null && _a !== void 0 ? _a : true;
            for (const tenant of tenants) {
                this.logger.debug(`Will be attempting to remove deleted sources for tenant ${tenant.id}, whatif=${safeWhatif}`);
                await this.processTenant(tenant.id);
                this.logger.debug(`Finished removing deleted sources for tenant ${tenant.id}`);
            }
            this.logger.debug('Finished removing deleted sources for all tenants');
        }
        catch (e) {
            this.logger.error('Failed removing deleted sources for all tenants with error ', e);
        }
        finally {
            await (0, ResourcesManager_1.closeConnections)(true);
            this.logger.debug('CleanupDeletedSourcesForAllTenants completed');
        }
    }
    async processTenant(tenantUid) {
        if (_.isEmpty(tenantUid)) {
            throw new Error('tenantUid is mandatory');
        }
        const neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(tenantUid);
        const tenantServices = new TenantServices_1.TenantServices();
        const deletedTenantProducers = await tenantServices.getDeletedProducerConfigurations(tenantUid);
        for (const deletedProducer of deletedTenantProducers) {
            const cfgKey = (0, Util_1.toSourceString)(deletedProducer.producerType, deletedProducer.producerId);
            this.logger.debug(`Checking if deleted producer ${cfgKey} of tenant ${tenantUid} has active PVs.`);
            const count = await this.countPVsOfProducer(tenantUid, deletedProducer, neptuneServices);
            if (count > 0) {
                this.logger.debug(`Deleted producer ${cfgKey} of tenant ${tenantUid} has ${count} active PVs.`);
                if (this.whatIf) {
                    this.logger.debug(`[WHATIF] - skipping - Supposed to be triggering delete task for deleted producer ${cfgKey} of tenant ${tenantUid} has ${count} active PVs.`);
                }
                else {
                    this.logger.debug(`triggering delete task for deleted producer ${cfgKey} of tenant ${tenantUid} has ${count} active PVs.`);
                    await new ScheduledTaskRunner_1.ScheduledTaskRunner().triggerTask(new ScheduleServices_1.ScheduledTask(CloseProducerCurrentStates_1.CloseProducerCurrentStates.TASK_NAME, tenantUid, ScheduleServices_1.ScheduleType.NOW, cfgKey));
                    this.logger.debug(`finished triggering delete task for deleted producer ${cfgKey} of tenant ${tenantUid} has ${count} active PVs.`);
                }
                return;
            }
        }
    }
    async countPVsOfProducer(tenantUid, deletedProducer, neptuneServices) {
        const cfgKey = (0, Util_1.toSourceString)(deletedProducer.producerType, deletedProducer.producerId);
        const isGenericFeatureFlagEnabled = await new TenantServices_1.TenantServices().isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.GENERIC_SOURCE);
        const processingService = ProducerUtil_1.ProducerUtil.getProcessorServiceBySource(cfgKey, tenantUid, isGenericFeatureFlagEnabled);
        const label = processingService.getPvLabel();
        this.logger.debug(`will be counting PVs with label ${label}`);
        const startTime = Date.now();
        try {
            const pvsCountRes = await neptuneServices.executeTenantQuery((g) => neptuneServices.getGraphTraversalBasedOnLabel(g, label)
                .hasNot(CommonTypes_1.EdgeBasicProperty.DELETED).range(0, 3000)
                .where(__.outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL))
                .count()
                .next(), NeptuneClientManager_1.NeptuneClientType.Reader);
            const endTime = Date.now();
            this.logger.debug(`counting PVs with label ${label} took ${endTime - startTime}. Result is ${pvsCountRes.value}`);
            return pvsCountRes.value;
        }
        catch (e) {
            const endTime = Date.now();
            this.logger.debug(`Failed while counting PVs with label ${label} took ${endTime - startTime}.`, e);
            throw e;
        }
    }
}
exports.CleanupDeletedSources = CleanupDeletedSources;
