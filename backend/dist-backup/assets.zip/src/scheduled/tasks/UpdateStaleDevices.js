"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateStaleDevices = void 0;
const _ = __importStar(require("lodash"));
const gremlin_1 = require("gremlin");
const CommonTypes_1 = require("../../common/CommonTypes");
const NeptuneDBScheduledTaskProcessor_1 = require("../NeptuneDBScheduledTaskProcessor");
const FunctionStateServices_1 = require("../../common/FunctionStateServices");
const TenantServices_1 = require("../../common/TenantServices");
const PostureEndpointService_1 = require("../../model/PostureEndpointService");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const Util_1 = require("../../common/Util");
const P = gremlin_1.process.P;
const t = gremlin_1.process.t;
class UpdateStaleDevices extends NeptuneDBScheduledTaskProcessor_1.NeptuneDBScheduledTaskProcessor {
    constructor(tenantUid, retentionPolicy) {
        super(tenantUid, undefined, undefined, { retentionPolicy });
        this.now = Date.now();
        this.millisAgo = this.now - retentionPolicy;
    }
    getTaskName() {
        return 'update-stale-devices';
    }
    async processRange(startRange) {
        const peUids = await this.neptuneServices.executeTenantQuery((g) => this.getRangeQuery(g, startRange)
            .property(CommonTypes_1.EdgeBasicProperty.UNTIL, this.now)
            .select('pe')
            .by(t.id)
            .toList());
        const svc = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        for (const peUid of peUids) {
            await svc.updateSearchableVertex(peUid, true);
        }
    }
    async nextRangeCount(startRange) {
        return this.neptuneServices.executeTenantQuery(async (g) => {
            const nextRangeCount = this.getRangeQuery(g, startRange).count();
            const rangeCountValue = await nextRangeCount.next();
            return rangeCountValue.value;
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    getRootTraversal(g) {
        return this.neptuneServices.getGraphTraversalBasedOnLabel(g, CommonTypes_1.VertexType.POSTURE_ENDPOINT);
    }
    getRangeQuery(g, startRange) {
        return this.getRootTraversal(g)
            .as('pe')
            .range(startRange, startRange + this.batchSize)
            .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .as('se')
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
            .inV()
            .has(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, P.lt(this.millisAgo))
            .select('se');
    }
    getNextBatchSize(currentBatchSize) {
        if (currentBatchSize <= UpdateStaleDevices.DEFAULT_MINIMUM_BATCH_SIZE) {
            return UpdateStaleDevices.DEFAULT_MINIMUM_BATCH_SIZE;
        }
        const nextBatchSize = Math.round(currentBatchSize / 2);
        return nextBatchSize <= UpdateStaleDevices.DEFAULT_MINIMUM_BATCH_SIZE ? UpdateStaleDevices.DEFAULT_MINIMUM_BATCH_SIZE : nextBatchSize;
    }
    async postProcess() {
        const sources = await new TenantServices_1.TenantServices().getTenantSources(this.tenantUid);
        return Promise.all(_.map(sources, async (source) => {
            switch (_.split(source, Util_1.SOURCE_SEPARATOR)[0]) {
                case CommonTypes_1.Source.DUO:
                    return this.updateFunctionState(`${process.env.ENV_PREFIX}-${UpdateStaleDevices.DUO_COLLECTION}`, source);
                case CommonTypes_1.Source.AMP:
                    return this.updateFunctionState(`${process.env.ENV_PREFIX}-${UpdateStaleDevices.AMP_COLLECTION}`, source);
                default:
            }
            return Promise.resolve();
        }));
    }
    async updateFunctionState(functionName, source) {
        const functionStateServices = new FunctionStateServices_1.FunctionStateServices();
        const functionState = await new FunctionStateServices_1.FunctionStateServices().getByKey(this.tenantUid, functionName, source);
        this.logger.debug(`${this.getLogPrefix()} reset function state for ${functionState.functionStateKey}`);
        functionState.lastSuccessfulSequence = 0;
        return functionStateServices.save(functionState);
    }
}
exports.UpdateStaleDevices = UpdateStaleDevices;
UpdateStaleDevices.DEFAULT_MINIMUM_BATCH_SIZE = 100;
UpdateStaleDevices.DUO_COLLECTION = 'fetch-duo-endpoints';
UpdateStaleDevices.AMP_COLLECTION = 'fetch-amp-computers';
