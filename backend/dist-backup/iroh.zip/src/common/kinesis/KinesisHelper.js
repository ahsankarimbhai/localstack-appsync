"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getShardId = exports.getRecordData = exports.inflateData = exports.decodeData = exports.getPK = exports.MAX_BATCH_SIZE = exports.DEFAULT_BATCH_SIZE = exports.RULES_EXECUTION = exports.TIMESTREAM_STREAM = exports.PRE_PROCESSING_STREAM = exports.VULNERABILITY_PROCESSING_STREAM = void 0;
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../CommonTypes");
const zlib_1 = __importDefault(require("zlib"));
exports.VULNERABILITY_PROCESSING_STREAM = 'vulnerability-processing';
exports.PRE_PROCESSING_STREAM = 'preprocessing';
exports.TIMESTREAM_STREAM = 'timestream';
exports.RULES_EXECUTION = 'rules_execution';
exports.DEFAULT_BATCH_SIZE = 100;
exports.MAX_BATCH_SIZE = 500;
const DELIMITER = ':';
function getPK(producer, tenantUid, qualifiers) {
    const groupId = _.size(qualifiers) ? _.join(qualifiers, DELIMITER) : CommonTypes_1.NA;
    return _.join([producer, tenantUid, groupId], DELIMITER);
}
exports.getPK = getPK;
function decodeData(record, inflate = true) {
    const extractedData = JSON.parse(Buffer.from(record.kinesis.data, 'base64').toString());
    return {
        producer: extractedData.producer,
        tenantUid: extractedData.tenantUid,
        tenantName: extractedData.tenantName,
        data: inflate ? inflateData(extractedData.data) : extractedData.data,
        retryCount: extractedData.retryCount
    };
}
exports.decodeData = decodeData;
function inflateData(data) {
    return JSON.parse(zlib_1.default.inflateSync(Buffer.from(data, 'base64')).toString());
}
exports.inflateData = inflateData;
function getRecordData(producer, tenantUid, data, tenantName) {
    return {
        producer,
        tenantUid,
        tenantName,
        data: zlib_1.default.deflateSync(JSON.stringify(data)).toString('base64')
    };
}
exports.getRecordData = getRecordData;
function getShardId(eventId) {
    const eventIdParts = _.split(eventId, DELIMITER);
    return eventIdParts[0];
}
exports.getShardId = getShardId;
