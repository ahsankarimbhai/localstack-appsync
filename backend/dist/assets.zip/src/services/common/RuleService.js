"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalRuleService = exports.RuleService = exports.RuleEntity = exports.SystemModifiedReason = exports.SystemModifiedLocation = exports.SystemModifiedModification = exports.SystemModifiedField = exports.RuleOrigin = exports.RuleManagementAction = void 0;
const LambdaLogger_1 = require("../../common/LambdaLogger");
const uuid_1 = require("uuid");
const _ = __importStar(require("lodash"));
const LabelService_1 = require("./LabelService");
const bluebird_1 = require("bluebird");
const DateUtils_1 = require("../../common/DateUtils");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const Util_1 = require("../../common/Util");
const DynamodbServiceFactory_1 = require("../../common/awsclient/dynamodb/DynamodbServiceFactory");
var RuleManagementAction;
(function (RuleManagementAction) {
    RuleManagementAction["CREATE"] = "create";
    RuleManagementAction["UPDATE"] = "update";
    RuleManagementAction["DELETE"] = "delete";
    RuleManagementAction["DISABLE"] = "disable";
    RuleManagementAction["ENABLE"] = "enable";
})(RuleManagementAction = exports.RuleManagementAction || (exports.RuleManagementAction = {}));
var RuleOrigin;
(function (RuleOrigin) {
    RuleOrigin["USER"] = "user";
    RuleOrigin["SYSTEM"] = "system";
})(RuleOrigin = exports.RuleOrigin || (exports.RuleOrigin = {}));
var SystemModifiedField;
(function (SystemModifiedField) {
    SystemModifiedField["LABEL"] = "label";
    SystemModifiedField["PRODUCER"] = "producer";
})(SystemModifiedField = exports.SystemModifiedField || (exports.SystemModifiedField = {}));
var SystemModifiedModification;
(function (SystemModifiedModification) {
    SystemModifiedModification["REMOVED"] = "removed";
})(SystemModifiedModification = exports.SystemModifiedModification || (exports.SystemModifiedModification = {}));
var SystemModifiedLocation;
(function (SystemModifiedLocation) {
    SystemModifiedLocation["RULE_CRITERIA"] = "rule criteria";
    SystemModifiedLocation["AUTOMATED_ASSIGNMENT"] = "automated assignment";
})(SystemModifiedLocation = exports.SystemModifiedLocation || (exports.SystemModifiedLocation = {}));
var SystemModifiedReason;
(function (SystemModifiedReason) {
    SystemModifiedReason["DELETED"] = "deleted";
})(SystemModifiedReason = exports.SystemModifiedReason || (exports.SystemModifiedReason = {}));
class RuleEntity {
    constructor(ruleId, name, tenantId, matchingCondition, actionToTake, ruleManagementAction, description, origin = RuleOrigin.USER, hidden = false, enabled = true, pendingApply = true, lastModifyTime = Date.now(), processing = false, processingStartTime = 0) {
        this.ruleId = ruleId;
        this.name = name;
        this.tenantId = tenantId;
        this.description = description;
        this.origin = origin;
        this.hidden = hidden;
        this.processing = processing;
        this.processingStartTime = processingStartTime;
        this.actionToTake = actionToTake;
        this.ruleManagementAction = ruleManagementAction;
        this.pendingApply = pendingApply;
        this.lastModifyTime = lastModifyTime;
        this.matchingCondition = matchingCondition;
        this.enabled = enabled;
    }
}
exports.RuleEntity = RuleEntity;
class RuleService {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.globalRuleService = new GlobalRuleService(this.dynamoDBServices);
    }
    async setRuleApplied(ruleId, pendingApply) {
        try {
            this.logger.debug(`To rule ${ruleId}, tenant: ${this.tenantUid} set pendingApply: ${pendingApply}`);
            await this.dynamoDBServices.update(RuleService.TABLE_NAME, this.globalRuleService.getCompositeKey(this.tenantUid, ruleId), { pendingApply });
        }
        catch (e) {
            this.logger.error(`Can not set pendingApply: ${pendingApply} to rule: ${ruleId}, ${e.message}`);
        }
    }
    async setRuleProcessing(ruleId, processing) {
        try {
            this.logger.debug(`To rule ${ruleId}, tenant: ${this.tenantUid} set processing: ${processing}`);
            await this.dynamoDBServices.update(RuleService.TABLE_NAME, this.globalRuleService.getCompositeKey(this.tenantUid, ruleId), { processing, processingStartTime: Date.now() });
        }
        catch (e) {
            this.logger.error(`Can not set processing: ${processing} to rule: ${ruleId}, ${e.message}`);
        }
    }
    async createRule(ruleData) {
        await this.validateRule(ruleData);
        const isRuleWithTheSameNameExist = await this.isRuleWithNameExist(ruleData.name);
        if (isRuleWithTheSameNameExist) {
            throw new Error(`Rule with name ${ruleData.name} already exists`);
        }
        const toSave = new RuleEntity((0, uuid_1.v4)(), ruleData.name, this.tenantUid, ruleData.matchingCondition, ruleData.actionToTake, RuleManagementAction.CREATE, ruleData.description, ruleData.origin, ruleData.hidden, ruleData.enabled);
        await this.dynamoDBServices.save(RuleService.TABLE_NAME, toSave);
        return RuleService.getRuleFromEntity(toSave);
    }
    async getRule(ruleId) {
        const ruleEntity = await this.dynamoDBServices.getByCompositeKey(RuleService.TABLE_NAME, this.globalRuleService.getCompositeKey(this.tenantUid, ruleId));
        if (ruleEntity && ruleEntity.ruleManagementAction !== RuleManagementAction.DELETE) {
            return RuleService.getRuleFromEntity(ruleEntity);
        }
        this.logger.error(`Rule ${ruleId} for tenant ${this.tenantUid} can not be reached`);
        throw new Error(`Rule ${ruleId} can not be reached`);
    }
    async getAllRules() {
        const rules = await this.getAllNotDeletedRuleEntity();
        return rules.map(rule => RuleService.getRuleFromEntity(rule));
    }
    async getAllRulesWithCount() {
        const esService = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        const [rules, counts] = await bluebird_1.Promise.all([this.getAllNotDeletedRuleEntity(), esService.countRules()]);
        return rules.map(ruleEnt => ({ rule: RuleService.getRuleFromEntity(ruleEnt), count: this.getRuleCount(ruleEnt.ruleId, counts) }));
    }
    async getAllRulesEntitiesWithCount() {
        const esService = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        const [rules, counts] = await bluebird_1.Promise.all([this.globalRuleService.getAllRuleEntity(this.tenantUid), esService.countRules()]);
        return rules.map(ruleEnt => ({ rule: ruleEnt, count: this.getRuleCount(ruleEnt.ruleId, counts) }));
    }
    async getAllRulesMap() {
        const rules = await this.getAllNotDeletedRuleEntity();
        return new Map(rules.map(rule => [rule.ruleId, RuleService.getRuleFromEntity(rule)]));
    }
    async hardDeleteRules(ruleIds) {
        for (const ruleId of ruleIds) {
            await this.dynamoDBServices.deleteByCompositeKey(RuleService.TABLE_NAME, this.globalRuleService.getCompositeKey(this.tenantUid, ruleId));
        }
    }
    async hardDeleteAllRules() {
        this.logger.info(`All rules for the tenant ${this.tenantUid} will be deleted`);
        const allRules = await this.getAllNotDeletedRuleEntity();
        await this.hardDeleteRules(allRules.map(rule => rule.ruleId));
    }
    async hardDeleteAllSoftDeletedRules() {
        this.logger.info(`All soft deleted rules for the tenant ${this.tenantUid} will be deleted`);
        const allRules = await this.getAllSoftDeletedRuleEntity();
        await this.hardDeleteRules(allRules.map(rule => rule.ruleId));
    }
    async softDeleteRule(ruleId) {
        await this.dynamoDBServices.update(RuleService.TABLE_NAME, this.globalRuleService.getCompositeKey(this.tenantUid, ruleId), { ruleManagementAction: RuleManagementAction.DELETE, pendingApply: true, lastModifyTime: Date.now() });
    }
    async deleteProducerFromRules(producerType, producerId) {
        const allTenantRules = await this.getAllNotDeletedRuleEntity();
        const toUpdate = [];
        for (const rule of allTenantRules) {
            if (this.deleteProducerFromMatchingCondition(rule, producerType, producerId)) {
                this.setRuleDisabledAndPendingApply(rule);
                toUpdate.push(rule);
                this.logger.debug(`producer deleted - rule was system modified ${JSON.stringify(rule)}`);
            }
        }
        await this.dynamoDBServices.batchUpdate(RuleService.TABLE_NAME, toUpdate);
    }
    async deleteLabelsFromRules(labelIds, labelMetadataBeforeDeletion) {
        try {
            const allTenantRules = await this.getAllNotDeletedRuleEntity();
            const toUpdate = [];
            const labelIdsSet = new Set(labelIds);
            for (const rule of allTenantRules) {
                const modifiedInAction = this.deleteLabelFromRuleAction(rule, labelIdsSet, labelMetadataBeforeDeletion);
                const modifiedInCondition = this.deleteLabelFromMatchingCondition(rule, labelIdsSet, labelMetadataBeforeDeletion);
                if (modifiedInAction || modifiedInCondition) {
                    this.setRuleDisabledAndPendingApply(rule);
                    toUpdate.push(rule);
                    this.logger.debug(`rule was system modified ${JSON.stringify(rule)}`);
                }
            }
            await this.dynamoDBServices.batchUpdate(RuleService.TABLE_NAME, toUpdate);
        }
        catch (e) {
            this.logger.error(`Failed attempt to delete labels from rules: ${e.message}`);
        }
    }
    deleteProducerFromMatchingCondition(rule, producerType, producerId) {
        var _a;
        let wasSystemModified = false;
        const ruleMatchingConditionProducersToLeave = [];
        for (const producerInMatchingCondition of ((_a = rule === null || rule === void 0 ? void 0 : rule.matchingCondition) === null || _a === void 0 ? void 0 : _a.producers) || []) {
            if (producerInMatchingCondition.type === producerType && producerInMatchingCondition.producerId === producerId) {
                RuleService.addSystemModified(rule, { field: SystemModifiedField.PRODUCER, name: (0, Util_1.toSourceString)(producerType, producerId), modification: SystemModifiedModification.REMOVED, location: SystemModifiedLocation.RULE_CRITERIA, reason: SystemModifiedReason.DELETED });
                wasSystemModified = true;
            }
            else {
                ruleMatchingConditionProducersToLeave.push(producerInMatchingCondition);
            }
        }
        rule.matchingCondition.producers = ruleMatchingConditionProducersToLeave.length ? ruleMatchingConditionProducersToLeave : undefined;
        return wasSystemModified;
    }
    deleteLabelFromMatchingCondition(rule, labelIdsSet, labelMetadataBeforeDeletion) {
        var _a, _b;
        let wasSystemModified = false;
        const ruleMatchingConditionLabelsToLeave = [];
        for (const labelInMatchingCondition of ((_a = rule === null || rule === void 0 ? void 0 : rule.matchingCondition) === null || _a === void 0 ? void 0 : _a.labels) || []) {
            if (labelIdsSet.has(labelInMatchingCondition.labelId)) {
                RuleService.addSystemModified(rule, { field: SystemModifiedField.LABEL, name: (_b = labelMetadataBeforeDeletion === null || labelMetadataBeforeDeletion === void 0 ? void 0 : labelMetadataBeforeDeletion.get(labelInMatchingCondition.labelId)) === null || _b === void 0 ? void 0 : _b.name, modification: SystemModifiedModification.REMOVED, location: SystemModifiedLocation.RULE_CRITERIA, reason: SystemModifiedReason.DELETED });
                wasSystemModified = true;
            }
            else {
                ruleMatchingConditionLabelsToLeave.push(labelInMatchingCondition);
            }
        }
        rule.matchingCondition.labels = ruleMatchingConditionLabelsToLeave.length ? ruleMatchingConditionLabelsToLeave : undefined;
        return wasSystemModified;
    }
    deleteLabelFromRuleAction(rule, labelIdsSet, labelMetadataBeforeDeletion) {
        var _a, _b;
        let wasSystemModified = false;
        const ruleActionLabelsToLeave = [];
        for (const labelInAction of ((_a = rule === null || rule === void 0 ? void 0 : rule.actionToTake) === null || _a === void 0 ? void 0 : _a.addLabels) || []) {
            if (labelIdsSet.has(labelInAction)) {
                RuleService.addSystemModified(rule, { field: SystemModifiedField.LABEL, name: (_b = labelMetadataBeforeDeletion === null || labelMetadataBeforeDeletion === void 0 ? void 0 : labelMetadataBeforeDeletion.get(labelInAction)) === null || _b === void 0 ? void 0 : _b.name, modification: SystemModifiedModification.REMOVED, location: SystemModifiedLocation.AUTOMATED_ASSIGNMENT, reason: SystemModifiedReason.DELETED });
                wasSystemModified = true;
            }
            else {
                ruleActionLabelsToLeave.push(labelInAction);
            }
        }
        rule.actionToTake.addLabels = ruleActionLabelsToLeave.length ? ruleActionLabelsToLeave : undefined;
        return wasSystemModified;
    }
    static addSystemModified(rule, systemModified) {
        rule.systemModifiedArr = [...(rule.systemModifiedArr || []), systemModified];
    }
    setRuleDisabledAndPendingApply(rule) {
        rule.enabled = false;
        rule.pendingApply = true;
        rule.ruleManagementAction = RuleManagementAction.DISABLE;
        rule.lastModifyTime = Date.now();
    }
    async updateRule(ruleData) {
        await this.validateRule(ruleData);
        if (!ruleData.ruleId) {
            this.logger.error(`Wrong input for rule update, ruleId can not be empty ${JSON.stringify(ruleData)}`);
            throw new Error(`Rule ${ruleData} can not be updated`);
        }
        const toUpdate = await this.getRule(ruleData.ruleId);
        if (!toUpdate) {
            this.logger.error(`An attempt was made to update rule which does not exist ${JSON.stringify(ruleData)}`);
            throw new Error(`Rule ${ruleData.ruleId} does not exist`);
        }
        if (toUpdate.name !== ruleData.name && await this.isRuleWithNameExist(ruleData.name)) {
            throw new Error(`Rule with name ${ruleData.name} already exists`);
        }
        const ruleWithStatusData = _.merge(ruleData, { ruleManagementAction: RuleManagementAction.UPDATE, pendingApply: true, lastModifyTime: Date.now(), systemModifiedArr: null });
        const result = await this.dynamoDBServices.update(RuleService.TABLE_NAME, this.globalRuleService.getCompositeKey(this.tenantUid, ruleData.ruleId), _.omit(ruleWithStatusData, 'ruleId'));
        if (!result.Attributes) {
            throw new Error('Error on rule update');
        }
        return RuleService.getRuleFromEntity(result.Attributes);
    }
    async getLabelsLinkedToRules() {
        var _a, _b;
        const resultMap = new Map();
        const rulesEntities = await this.getAllNotDeletedRuleEntity();
        for (const rule of rulesEntities) {
            (_a = rule.actionToTake.addLabels) === null || _a === void 0 ? void 0 : _a.forEach(labelId => this.setRuleToLabelRulesMap(resultMap, rule.ruleId, rule.name, labelId));
            (_b = rule.matchingCondition.labels) === null || _b === void 0 ? void 0 : _b.forEach(label => this.setRuleToLabelRulesMap(resultMap, rule.ruleId, rule.name, label.labelId));
        }
        return resultMap;
    }
    setRuleToLabelRulesMap(labelRulesMap, ruleId, ruleName, labelId) {
        if (labelRulesMap.has(labelId)) {
            labelRulesMap.get(labelId).push({ ruleId, ruleName });
        }
        else {
            labelRulesMap.set(labelId, [{ ruleId, ruleName }]);
        }
    }
    async getAllNotDeletedRuleEntity() {
        return this.globalRuleService.getAllNotDeletedRuleEntity(this.tenantUid);
    }
    async getAllSoftDeletedRuleEntity() {
        return this.globalRuleService.getAllSoftDeletedRuleEntity(this.tenantUid);
    }
    static generateHumanReadableSystemModified(systemModified) {
        return systemModified === null || systemModified === void 0 ? void 0 : systemModified.map(systemModifiedItem => `${systemModifiedItem.field} ${systemModifiedItem.name} was ${systemModifiedItem.modification} from this rule's ${systemModifiedItem.location} because it was externally ${systemModifiedItem.reason}.`);
    }
    static getRuleFromEntity(rule) {
        const plainRule = rule;
        plainRule.systemModified = RuleService.generateHumanReadableSystemModified(rule.systemModifiedArr);
        return { ...plainRule, tenantId: undefined, ruleManagementAction: undefined, pendingApply: undefined, lastModifyTime: undefined, processing: undefined, processingStartTime: undefined };
    }
    async validateRule(ruleData) {
        const addLabels = ruleData.actionToTake.addLabels;
        const setAssetValue = ruleData.actionToTake.setAssetValue;
        if (!ruleData.matchingCondition) {
            this.logger.error(`Validation failed for rule, matchingCondition is empty. Rule: ${ruleData}`);
            throw new Error('Matching condition can not be empty for rule');
        }
        if (this.isRuleActionInvalid(ruleData)) {
            this.logger.error(`Validation failed for rule, action is empty. Rule: ${ruleData}`);
            throw new Error('Action can not be empty for rule');
        }
        if (setAssetValue !== undefined) {
            if (setAssetValue > 10 || setAssetValue < 1) {
                this.logger.error(`Validation failed for rule, incorrect asset value. Rule: ${ruleData}`);
                throw new Error('Incorrect asset value for rule');
            }
        }
        if (addLabels) {
            if (_.isEmpty(addLabels)) {
                this.logger.error(`Validation failed for rule, labels are empty. Rule: ${ruleData}`);
                throw new Error('Labels can not be empty for rule');
            }
            const labelService = new LabelService_1.LabelService(this.tenantUid);
            const labelMap = await labelService.getLabelsMetadataMap();
            let nonExistentLabels = '';
            for (const labelId of addLabels) {
                if (!labelMap.has(labelId)) {
                    this.logger.error(`Validation failed for rule, label does not exist. Rule: ${ruleData}`);
                    nonExistentLabels = nonExistentLabels.concat(' ', labelId);
                }
            }
            if (!_.isEmpty(nonExistentLabels)) {
                throw new Error(`Labels:${nonExistentLabels} do not exist.`);
            }
        }
    }
    isRuleActionInvalid(ruleData) {
        return !ruleData.actionToTake || (_.isUndefined(ruleData.actionToTake.addLabels) && _.isUndefined(ruleData.actionToTake.setAssetValue) && _.isUndefined(ruleData.actionToTake.addLabelsFromDevice) && _.isUndefined(ruleData.actionToTake.setAssetValueFromDevice));
    }
    getRuleCount(ruleId, counts) {
        const result = counts.get(ruleId);
        return !result ? 0 : result;
    }
    async isRuleWithNameExist(name) {
        const rules = await this.getAllNotDeletedRuleEntity();
        return rules.some(rule => rule.name === name);
    }
}
exports.RuleService = RuleService;
RuleService.TABLE_NAME = 'rule';
RuleService.HASH_KEY = 'tenantId';
RuleService.CONCURRENCY = 10;
RuleService.PAGINATION_DETAILS_NAMES = ['pageSize', 'pageNumber', 'orderBy'];
class GlobalRuleService {
    constructor(dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)()) {
        this.dynamoDBServices = dynamoDBServices;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async detectRulesToApply() {
        this.logger.debug('Start searching for rules to apply');
        const result = await this.dynamoDBServices.getAllFilteredTableEntries(RuleService.TABLE_NAME, 'pendingApply = :pendingApply', { ':pendingApply': true });
        this.logger.debug(`Found ${result.length} rules to apply: ${JSON.stringify(result.map((rule) => ({ tenantId: rule.tenantId, ruleId: rule.ruleId })))}`);
        return result.filter(rule => !rule.processing || rule.processingStartTime < Date.now() - DateUtils_1.HOUR_IN_MILLIS);
    }
    groupRulesByTenant(rules) {
        const result = new Map();
        for (const rule of rules) {
            const tempRuleArr = result.get(rule.tenantId);
            if (tempRuleArr) {
                tempRuleArr.push(rule);
            }
            else {
                result.set(rule.tenantId, [rule]);
            }
        }
        return result;
    }
    async getRulesByTenants(uniqueTenants) {
        const rulesByTenants = await bluebird_1.Promise.map(uniqueTenants, (tenantId) => this.getAllEnabledRulesEntity(tenantId), { concurrency: RuleService.CONCURRENCY });
        return Object.fromEntries(rulesByTenants.map((tenantRules, i) => [uniqueTenants[i], tenantRules]));
    }
    async getAllNotDeletedRuleEntity(tenantId) {
        const result = await this.dynamoDBServices.getByPartitionKey(RuleService.TABLE_NAME, RuleService.HASH_KEY, tenantId, true);
        return result.filter(rule => rule.ruleManagementAction !== RuleManagementAction.DELETE);
    }
    async getAllRuleEntity(tenantId) {
        return this.dynamoDBServices.getByPartitionKey(RuleService.TABLE_NAME, RuleService.HASH_KEY, tenantId, true);
    }
    async getAllSoftDeletedRuleEntity(tenantId) {
        const result = await this.dynamoDBServices.getByPartitionKey(RuleService.TABLE_NAME, RuleService.HASH_KEY, tenantId, true);
        return result.filter(rule => rule.ruleManagementAction === RuleManagementAction.DELETE);
    }
    async getAllEnabledRulesEntity(tenantId) {
        const allRules = await this.getAllNotDeletedRuleEntity(tenantId);
        return allRules.filter(rule => rule.enabled);
    }
    async getAllRules() {
        return this.dynamoDBServices.getAllTableEntries(RuleService.TABLE_NAME);
    }
    async batchDelete(rules) {
        const ids = rules.map(rule => this.getCompositeKey(rule.tenantId, rule.ruleId));
        await this.dynamoDBServices.batchDelete(RuleService.TABLE_NAME, ids);
    }
    async batchUpdate(rules) {
        await this.dynamoDBServices.batchUpdate(RuleService.TABLE_NAME, rules);
    }
    static applyRuleActionOnObject(object, rule) {
        var _a, _b, _c, _d, _e, _f;
        if (!object) {
            return;
        }
        GlobalRuleService.applyRuleActionDynamicallyFromDevice(object, rule);
        object.rulesLatestProcessed = Date.now();
        object.matchedByRules = ((_a = object === null || object === void 0 ? void 0 : object.matchedByRules) === null || _a === void 0 ? void 0 : _a.length) ? [...new Set([...object.matchedByRules, rule.ruleId])] : [rule.ruleId];
        if ((_c = (_b = rule === null || rule === void 0 ? void 0 : rule.actionToTake) === null || _b === void 0 ? void 0 : _b.addLabels) === null || _c === void 0 ? void 0 : _c.length) {
            const newLabels = [...new Set([...(((_d = object === null || object === void 0 ? void 0 : object.rulesLabels) === null || _d === void 0 ? void 0 : _d.length) ? object.rulesLabels : []), ...(rule.actionToTake.addLabels)])];
            if (newLabels.length > (((_e = object === null || object === void 0 ? void 0 : object.rulesLabels) === null || _e === void 0 ? void 0 : _e.length) || 0)) {
                object.rulesLabels = newLabels;
                object.labelsUpdated = true;
            }
        }
        if ((_f = rule.actionToTake) === null || _f === void 0 ? void 0 : _f.setAssetValue) {
            if (rule.actionToTake.setAssetValue > (object.rulesAssetValue || 0)) {
                object.rulesAssetValue = rule.actionToTake.setAssetValue;
                object.assetValueUpdated = true;
            }
        }
        if (object.labelsUpdated || object.assetValueUpdated) {
            object.modifiedByRules = (object.modifiedByRules && Array.isArray(object.modifiedByRules)) ? object.modifiedByRules : [];
            object.modifiedByRules.push(rule.ruleId);
        }
    }
    static applyRuleActionDynamicallyFromDevice(object, rule) {
        var _a, _b, _c, _d, _e;
        if ((((_a = rule.actionToTake) === null || _a === void 0 ? void 0 : _a.addLabelsFromDevice) || ((_b = rule.actionToTake) === null || _b === void 0 ? void 0 : _b.setAssetValueFromDevice)) && ((_c = rule.matchingCondition) === null || _c === void 0 ? void 0 : _c.producers)) {
            const newLabels = new Set(((_d = object.rulesLabels) === null || _d === void 0 ? void 0 : _d.length) ? object.rulesLabels : []);
            for (const ruleProducer of rule.matchingCondition.producers) {
                const matchingProducers = _.filter(object.producers, (producer) => producer.type === ruleProducer.type && producer.producerId === ruleProducer.producerId && (producer.labelIds || producer.assetValue));
                for (const producer of matchingProducers) {
                    if (rule.actionToTake.addLabelsFromDevice && producer.labelIds) {
                        producer.labelIds.forEach((label) => newLabels.add(label));
                        if (newLabels.size > (((_e = object.rulesLabels) === null || _e === void 0 ? void 0 : _e.length) || 0)) {
                            object.rulesLabels = Array.from(newLabels);
                            object.labelsUpdated = true;
                        }
                    }
                    if (rule.actionToTake.setAssetValueFromDevice && producer.assetValue && parseInt(producer.assetValue, 10) > (object.rulesAssetValue || 0)) {
                        object.rulesAssetValue = producer.assetValue;
                        object.assetValueUpdated = true;
                    }
                }
            }
        }
    }
    getCompositeKey(tenantId, ruleId) {
        return { tenantId, ruleId };
    }
}
exports.GlobalRuleService = GlobalRuleService;
