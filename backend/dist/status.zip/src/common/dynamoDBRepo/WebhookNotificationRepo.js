"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookNotificationRepo = void 0;
const _ = __importStar(require("lodash"));
const DynamodbServiceFactory_1 = require("../awsclient/dynamodb/DynamodbServiceFactory");
class WebhookNotificationRepo {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    }
    async getByWebhookId(webhookId) {
        return this.dynamoDBServices.getByKey(WebhookNotificationRepo.TABLE_NAME, WebhookNotificationRepo.HASH_KEY, webhookId);
    }
    async upsert(notification) {
        notification.updatedAt = Date.now();
        return this.dynamoDBServices.save(WebhookNotificationRepo.TABLE_NAME, notification);
    }
    async update(webhookId, failedAttempts) {
        const key = { webhookId };
        const update = {};
        if (!_.isNil(failedAttempts)) {
            update.failedAttempts = failedAttempts;
        }
        update.updatedAt = Date.now();
        return this.dynamoDBServices.update(WebhookNotificationRepo.TABLE_NAME, key, update);
    }
    async hardDelete(webhookId) {
        return this.dynamoDBServices.delete(WebhookNotificationRepo.TABLE_NAME, WebhookNotificationRepo.HASH_KEY, webhookId);
    }
}
exports.WebhookNotificationRepo = WebhookNotificationRepo;
WebhookNotificationRepo.TABLE_NAME = 'webhook-notification';
WebhookNotificationRepo.HASH_KEY = 'webhookId';
