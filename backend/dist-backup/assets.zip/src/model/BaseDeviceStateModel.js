"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseDeviceStateModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const Util_1 = require("../common/Util");
const net_1 = require("net");
class BaseDeviceStateModel extends BaseGraphElement_1.BaseGraphVertex {
    setInternalIpAddresses(ipAddress) {
        const internalIps = new Set();
        if (Array.isArray(ipAddress)) {
            ipAddress.forEach(ip => {
                if (ip && (0, net_1.isIP)(ip) > 0) {
                    internalIps.add(ip);
                }
            });
        }
        else if (ipAddress && (0, net_1.isIP)(ipAddress) > 0) {
            internalIps.add(ipAddress);
        }
        if (internalIps.size > 0) {
            this.setProperty(CommonTypes_1.VertexStateProperty.STATE_INTERNAL_IP_ADDRESSES, Array.from(internalIps));
            internalIps.forEach(ip => {
                this.addSecondaryLabel(`${(0, Util_1.base64Encode)(ip)}${Util_1.SOURCE_SEPARATOR}${CommonTypes_1.VertexType.INTERNAL_IP_ADDRESS}`);
            });
        }
    }
}
exports.BaseDeviceStateModel = BaseDeviceStateModel;
