"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohProxyClient = exports.ProviderProxyClient = void 0;
const axios_1 = __importDefault(require("axios"));
const Util_1 = require("./Util");
const ProxyClientFactory_1 = require("./ProxyClientFactory");
const LambdaLogger_1 = require("./LambdaLogger");
class ProviderProxyClient {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    init() {
        this.axios = this.initClient();
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'ProviderProxyClient');
        return this.axios;
    }
    async post(url, data) {
        if (!this.axios) {
            await this.init();
        }
        return this.axios.post(url, data);
    }
    async get(url) {
        if (!this.axios) {
            await this.init();
        }
        return this.axios.get(url);
    }
    async delete(url) {
        if (!this.axios) {
            await this.init();
        }
        return this.axios.delete(url);
    }
}
exports.ProviderProxyClient = ProviderProxyClient;
class IrohProxyClient {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    getURL(url) {
        return `${process.env.IROH_URI}${ProxyClientFactory_1.ProxyClientFactory.IROH_PREF}/${url}`;
    }
    init() {
        this.axios = axios_1.default.create();
        (0, Util_1.scrubAxiosAuthHeader)(this.axios, this.logger, 'IrohProxyClient');
        return this.axios;
    }
    get(url) {
        return this.options(url, 'get');
    }
    post(url, data, configs) {
        return this.options(url, 'post', data, configs);
    }
    delete(url) {
        return this.options(url, 'delete');
    }
}
exports.IrohProxyClient = IrohProxyClient;
