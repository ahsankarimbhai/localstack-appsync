"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedConnectorDeviceStateModelService = exports.UnifiedConnectorDeviceStateModel = exports.UnifiedConnectorDeviceModelService = exports.UnifiedConnectorDeviceModel = void 0;
const lodash_1 = __importDefault(require("lodash"));
const gremlin_1 = require("gremlin");
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const UnifiedConnectorModel_1 = require("../services/unifiedconnector/UnifiedConnectorModel");
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const Util_1 = require("../common/Util");
const LambdaLogger_1 = require("../common/LambdaLogger");
const TenantServices_1 = require("../common/TenantServices");
const AwsSecretsService_1 = require("../common/AwsSecretsService");
const UnifiedConnectorCollectorServices_1 = require("../services/unifiedconnector/UnifiedConnectorCollectorServices");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
const NeptuneClientManager_1 = require("../common/neptune/NeptuneClientManager");
const withOptions = gremlin_1.process.withOptions;
const __ = gremlin_1.process.statics;
const t = gremlin_1.process.t;
class UnifiedConnectorDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.UNIFIED_CONNECTOR_DEVICE;
    }
    async initProperties(uc) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, uc.ucid);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.UnifiedConnectorDeviceModel = UnifiedConnectorDeviceModel;
class UnifiedConnectorDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new UnifiedConnectorDeviceModel(this.partitionKey);
    }
}
exports.UnifiedConnectorDeviceModelService = UnifiedConnectorDeviceModelService;
class UnifiedConnectorDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor(tenantUid) {
        super(tenantUid);
        this.tenantUid = tenantUid;
        this.type = CommonTypes_1.VertexType.UNIFIED_CONNECTOR_DEVICE_STATE;
    }
    getNeptuneServices() {
        if (!this.neptuneServices) {
            this.neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
        }
        return this.neptuneServices;
    }
    toJSON() {
        return lodash_1.default.omit(this, ['neptuneServices', 'mergedModel']);
    }
    async preProcessInitVertex(uc, tenantUid, sourceId) {
        const currentState = await this.getCurrentState(uc.ucid);
        this.mergedModel = await UnifiedConnectorDeviceStateModel.merge(currentState, uc, tenantUid, sourceId);
    }
    async initProperties(uc) {
        if (!this.mergedModel) {
            throw new Error('expected merged model to be defined');
        }
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(UnifiedConnectorDeviceStateModel.modelForHash(lodash_1.default.omit(this.mergedModel, ['timestamp', 'neptuneServices', 'mergedModel']))));
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, this.mergedModel.hostname);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, this.mergedModel.osType);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, this.mergedModel.osVersion);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, this.mergedModel.osExtractedNumericVersion);
        if (!(0, CommonTypes_1.newPhraseLowersDetailHeuristic)(this.getPropertyValue(CommonTypes_1.VertexBasicProperty.OS_HUMAN_READABLE_VERSION) || '', this.mergedModel.osHumanReadableVersion || '')) {
            this.setProperty(CommonTypes_1.VertexBasicProperty.OS_HUMAN_READABLE_VERSION, this.mergedModel.osHumanReadableVersion);
        }
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, this.mergedModel.osBuild);
        this.setProperty(CommonTypes_1.VertexType.SERIAL_NUMBER, this.mergedModel.serial);
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, this.mergedModel.timestamp);
        this.setProperty(UnifiedConnectorDeviceStateModel.PROP_SOFTWARE, this.mergedModel.software);
        this.setProperty(UnifiedConnectorDeviceStateModel.PROP_AC_UDID, this.mergedModel.acUdid);
        this.setProperty(UnifiedConnectorDeviceStateModel.PROP_DEPLOYMENT, this.mergedModel.deploymentId);
        this.setProperty(UnifiedConnectorDeviceStateModel.PROP_WANTED_DEPLOYMENT, this.mergedModel.wantedDeploymentId);
        this.setProperty(UnifiedConnectorDeviceStateModel.PROP_CSC_VERSION, this.mergedModel.cscVersion);
        this.setProperty(UnifiedConnectorDeviceStateModel.PROP_SE_VERSION, this.mergedModel.seVersion);
        this.setProperty(UnifiedConnectorDeviceStateModel.PROP_CLOUD_MGMT_VER, this.mergedModel.cloudMgmtVersion);
        this.setInternalIpAddresses(this.mergedModel.ips);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
    async getCurrentState(ucid) {
        const pvId = (0, NeptuneServicesFactory_1.getVertexId)(ucid, this.transformToPvLabel(), this.getNeptuneServices().getTenantUid());
        const neptuneSvc = this.getNeptuneServices();
        const results = await neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, pvId)
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
            .inV()
            .as('ps')
            .out()
            .as('cv')
            .path().from_('ps').to('cv')
            .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        const resultSet = new gremlin_1.driver.ResultSet(results);
        let ps;
        const cvs = [];
        for (const result of resultSet.toArray()) {
            const path = result.objects;
            ps = path[0];
            const cv = path[1];
            cvs.push(cv);
        }
        return { ps, cvs };
    }
    transformToPvLabel() {
        const labelParts = lodash_1.default.split(this.getLabel(), Util_1.SOURCE_SEPARATOR);
        return [CommonTypes_1.VertexType.UNIFIED_CONNECTOR_DEVICE, labelParts[1], labelParts[2]].join(Util_1.SOURCE_SEPARATOR);
    }
    static async merge(currentState, input, tenantUid, sourceId) {
        const ps = currentState.ps;
        if (input.created) {
            return Promise.resolve(this.mergeForRest(input));
        }
        const res = await this.mergeForWebhooks(ps, currentState, input, tenantUid, sourceId);
        const logger = new LambdaLogger_1.LambdaLogger();
        logger.debug(`Resulting merged information is ${JSON.stringify(res)}`);
        return res;
    }
    static async mergeForWebhooks(ps, currentState, input, tenantUid, sourceId) {
        const { existing, existingOsMajor, existingOsMinor } = this.getExistingModelFromNeptune(ps, currentState);
        const uc = input;
        const updated = {
            timestamp: Date.parse(uc.timestamp),
            hwid: (0, UnifiedConnectorModel_1.getAttr)(uc, 'hwid') ? (0, UnifiedConnectorModel_1.getAttr)(uc, 'hwid') : undefined,
            serial: (0, UnifiedConnectorModel_1.getAttr)(uc, 'serial') ? (0, UnifiedConnectorModel_1.getAttr)(uc, 'serial') : undefined,
            hostname: (0, UnifiedConnectorModel_1.getAttr)(uc, 'hostname') ? (0, UnifiedConnectorModel_1.getAttr)(uc, 'hostname') : undefined,
            osType: (0, UnifiedConnectorModel_1.getAttr)(uc, 'name') ? (0, CommonTypes_1.getOsType)((0, UnifiedConnectorModel_1.getAttr)(uc, 'name')) : undefined,
            osVersion: (0, UnifiedConnectorModel_1.getAttr)(uc, 'major') || (0, UnifiedConnectorModel_1.getAttr)(uc, 'minor') ? [(0, UnifiedConnectorModel_1.getAttr)(uc, 'major') || existingOsMajor, (0, UnifiedConnectorModel_1.getAttr)(uc, 'minor') || existingOsMinor].join('.') : undefined,
            osBuild: (0, UnifiedConnectorModel_1.getAttr)(uc, 'build') ? (0, UnifiedConnectorModel_1.getAttr)(uc, 'build') : undefined,
            mac: [],
            ips: [],
            software: [],
            deploymentId: (0, UnifiedConnectorModel_1.getAttr)(uc, 'deployment') ? (0, UnifiedConnectorModel_1.getAttr)(uc, 'deployment') : undefined
        };
        updated.osExtractedNumericVersion = (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)((0, UnifiedConnectorModel_1.getAttr)(uc, 'name') || '', updated.osVersion || '', updated.osBuild);
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(updated, [(0, UnifiedConnectorModel_1.getAttr)(uc, 'name'), (0, UnifiedConnectorModel_1.getAttr)(uc, 'arch')].filter(item => item).join(' '));
        const logger = new LambdaLogger_1.LambdaLogger();
        this.updateAddChangedProperties(uc, updated, existing);
        logger.debug(`Will be merging updated information=${JSON.stringify(updated)} with existing information ${JSON.stringify(existing)}`);
        const isMessageWithoutInfoInDb = !existing.hostname && !updated.hostname;
        const isFirstDeploymentUpdate = !lodash_1.default.isEmpty(updated.deploymentId) && ((0, UnifiedConnectorModel_1.getAttr)(uc, 'deployment', 'oldvalue') === UnifiedConnectorDeviceStateModel.DEFAULT_DEPLOYMENT_ID);
        const isFirstInstallUpdate = !lodash_1.default.isEmpty(lodash_1.default.filter(uc.attributes, attr => attr.action === UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeAction.added && attr.type === UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.software && lodash_1.default.includes(['cm-enterprise', 'AMP'], attr.name)));
        logger.debug(`isMessageWithoutInfoInDb=${isMessageWithoutInfoInDb}, isFirstDeploymentUpdate=${isFirstDeploymentUpdate}, isFirstInstallUpdate=${isFirstInstallUpdate}`);
        if (isMessageWithoutInfoInDb || isFirstDeploymentUpdate || isFirstInstallUpdate) {
            return this.fetchUpdatedDevice(uc, updated, tenantUid, sourceId);
        }
        this.updateDeletedProperties(uc, existing);
        return lodash_1.default.mergeWith(existing, updated, (objValue, srcValue) => {
            if (lodash_1.default.isArray(objValue)) {
                return objValue.concat(srcValue);
            }
            return undefined;
        });
    }
    static async fetchUpdatedDevice(uc, updated, tenantUid, sourceId) {
        const logger = new LambdaLogger_1.LambdaLogger();
        logger.debug(`Trigger device sync due to missing name on new vertex where notification=${JSON.stringify(updated)}`);
        const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
        await awsSecretsService.init();
        const tenantServices = new TenantServices_1.TenantServices();
        const tenantConfiguration = await tenantServices.getTenantConfiguration(tenantUid, sourceId);
        const tenantConfigurationValue = JSON.parse((tenantConfiguration === null || tenantConfiguration === void 0 ? void 0 : tenantConfiguration.value) || '{}');
        logger.debug(`The configuration for tenant=${tenantUid} and sourceId=${sourceId} is ${JSON.stringify(tenantConfiguration)}`);
        const ucCollector = new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(awsSecretsService.getSecret(sourceId), tenantConfigurationValue.baseURL, tenantConfigurationValue.adminBaseUrl, tenantUid, lodash_1.default.split(sourceId, '__')[1]);
        const device = await ucCollector.queryCscDevice(uc.ucid);
        logger.debug(`Queried CSC Device=${JSON.stringify(device)}`);
        return UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices.transformCscDeviceToMergedUnifiedConnectorDevice(device);
    }
    static updateDeletedProperties(uc, existing) {
        const logger = new LambdaLogger_1.LambdaLogger();
        for (const attr of lodash_1.default.filter(uc.attributes, { action: UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeAction.deleted })) {
            switch (attr.type) {
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.mac:
                    lodash_1.default.remove(existing.mac, v => v === attr.value);
                    break;
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.ipv4:
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.ipv6:
                    lodash_1.default.remove(existing.ips, v => v === attr.value);
                    break;
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.software:
                    lodash_1.default.remove(existing.software, v => v === `${attr.name}/${attr.value}`);
                    break;
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.deployment:
                    logger.info(`Received delete deployment notification ${attr}, on existing ${existing}`);
                    break;
                default:
                    break;
            }
        }
    }
    static updateAddChangedProperties(uc, updated, existing) {
        const logger = new LambdaLogger_1.LambdaLogger();
        for (const attr of lodash_1.default.filter(uc.attributes, attrFilter => lodash_1.default.includes([
            UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeAction.added, UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeAction.changed
        ], attrFilter.action))) {
            switch (attr.type) {
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.mac:
                    updated.mac.push(attr.value);
                    lodash_1.default.remove(existing.mac, v => v === attr.oldvalue);
                    break;
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.ipv4:
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.ipv6:
                    updated.ips.push(attr.value);
                    lodash_1.default.remove(existing.ips, v => v === attr.oldvalue);
                    break;
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.software:
                    updated.software.push(`${attr.name}/${attr.value}`);
                    lodash_1.default.remove(existing.software, v => v === `${attr.name}/${attr.oldvalue}`);
                    if (attr.name === 'AMP') {
                        updated.seVersion = attr.value;
                    }
                    else if (attr.name === 'cm-enterprise') {
                        updated.cloudMgmtVersion = attr.value;
                    }
                    else if (lodash_1.default.startsWith(attr.name, 'ac-')) {
                        updated.cscVersion = attr.value;
                    }
                    break;
                case UnifiedConnectorModel_1.UnifiedConnectorNotificationDataAttributeType.deployment:
                    updated.deploymentId = attr.value;
                    if (existing.wantedDeploymentId && existing.wantedDeploymentId !== attr.value) {
                        logger.error(`New deployment ${attr.value} is not equal to expecting ${existing.wantedDeploymentId}`);
                    }
                    break;
                default:
                    break;
            }
        }
    }
    static mergeForRest(input) {
        var _a;
        const uc = input;
        const updated = {
            timestamp: Date.parse(uc.updated),
            hwid: uc.attributes.hardware.uuid,
            serial: uc.attributes.hardware.serial_number,
            hostname: uc.attributes.os.hostname,
            osType: uc.attributes.os.name ? (0, CommonTypes_1.getOsType)(uc.attributes.os.name) : undefined,
            osVersion: uc.attributes.os.major && uc.attributes.os.minor ? [uc.attributes.os.major, uc.attributes.os.minor].join('.') : undefined,
            osBuild: uc.attributes.os.build,
            deploymentId: uc.deployment_id,
            acUdid: (_a = uc.attributes.product) === null || _a === void 0 ? void 0 : _a.anyconnect,
            mac: [],
            ips: [],
            software: []
        };
        updated.osExtractedNumericVersion = (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(uc.attributes.os.name || '', updated.osVersion || '', updated.osBuild);
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(updated, [uc.attributes.os.name, uc.attributes.os.arch].filter(item => item).join(' '));
        if (uc.wanted_deployment_id) {
            updated.wantedDeploymentId = uc.wanted_deployment_id;
        }
        lodash_1.default.each(uc.attributes.os.adapters, adapter => {
            updated.mac.push(adapter.mac);
            if (adapter.ipv4) {
                updated.ips = lodash_1.default.concat(updated.ips, adapter.ipv4);
            }
            if (adapter.ipv6) {
                updated.ips = lodash_1.default.concat(updated.ips, adapter.ipv6);
            }
        });
        lodash_1.default.each(uc.installations, software => {
            updated.software.push(`${software.package.product}/${software.package.version}`);
            if (software.package.product === 'AMP') {
                updated.seVersion = software.package.version;
            }
            else if (software.package.product === 'cm-enterprise') {
                updated.cloudMgmtVersion = software.package.version;
            }
            else if (software.package.product.startsWith('ac-')) {
                updated.cscVersion = software.package.version;
            }
        });
        return updated;
    }
    static getExistingModelFromNeptune(ps, currentState) {
        var _a, _b, _c, _d;
        const existing = {
            timestamp: ps ? lodash_1.default.get(ps.get(CommonTypes_1.VertexBasicProperty.LAST_UPDATED), '[0]') : undefined,
            hostname: ps ? lodash_1.default.get(ps.get(CommonTypes_1.VertexBasicProperty.NAME), '[0]') : undefined,
            software: ps && lodash_1.default.get(ps.get(UnifiedConnectorDeviceStateModel.PROP_SOFTWARE), '[0]') ? JSON.parse(lodash_1.default.get(ps.get(UnifiedConnectorDeviceStateModel.PROP_SOFTWARE), '[0]')) : undefined,
            osType: ps ? lodash_1.default.get(ps.get(CommonTypes_1.VertexBasicProperty.OS_TYPE), '[0]') : undefined,
            osVersion: ps ? lodash_1.default.get(ps.get(CommonTypes_1.VertexBasicProperty.OS_VERSION), '[0]') : undefined,
            osBuild: ps ? lodash_1.default.get(ps.get(CommonTypes_1.VertexBasicProperty.OS_BUILD), '[0]') : undefined,
            acUdid: ps ? lodash_1.default.get(ps.get(UnifiedConnectorDeviceStateModel.PROP_AC_UDID), '[0]') : undefined,
            deploymentId: ps ? lodash_1.default.get(ps.get(UnifiedConnectorDeviceStateModel.PROP_DEPLOYMENT), '[0]') : undefined,
            cscVersion: ps ? lodash_1.default.get(ps.get(UnifiedConnectorDeviceStateModel.PROP_CSC_VERSION), '[0]') : undefined,
            seVersion: ps ? lodash_1.default.get(ps.get(UnifiedConnectorDeviceStateModel.PROP_SE_VERSION), '[0]') : undefined,
            cloudMgmtVersion: ps ? lodash_1.default.get(ps.get(UnifiedConnectorDeviceStateModel.PROP_CLOUD_MGMT_VER), '[0]') : undefined,
            mac: [],
            ips: [],
            wantedDeploymentId: ps ? lodash_1.default.get(ps.get(UnifiedConnectorDeviceStateModel.PROP_WANTED_DEPLOYMENT), '[0]') : undefined,
            osExtractedNumericVersion: (_b = (_a = ps === null || ps === void 0 ? void 0 : ps.get) === null || _a === void 0 ? void 0 : _a.call(ps, CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION)) === null || _b === void 0 ? void 0 : _b[0],
            osHumanReadableVersion: (_d = (_c = ps === null || ps === void 0 ? void 0 : ps.get) === null || _c === void 0 ? void 0 : _c.call(ps, CommonTypes_1.VertexBasicProperty.OS_HUMAN_READABLE_VERSION)) === null || _d === void 0 ? void 0 : _d[0]
        };
        const existingOsVersion = lodash_1.default.split(existing.osVersion, '.');
        const existingOsMajor = existingOsVersion[0];
        const existingOsMinor = lodash_1.default.join(lodash_1.default.tail(existingOsVersion), '.');
        existing.ips = ps && (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexStateProperty.STATE_INTERNAL_IP_ADDRESSES)) ? JSON.parse((0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexStateProperty.STATE_INTERNAL_IP_ADDRESSES))) : [];
        for (const cv of currentState.cvs) {
            const label = (0, Util_1.parseSimpleLabel)(cv.get(t.label));
            switch (label) {
                case CommonTypes_1.VertexType.INTERNAL_IP_ADDRESS: {
                    const ip = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                    if (existing.ips.indexOf(ip) < 0) {
                        existing.ips.push(ip);
                    }
                    break;
                }
                case CommonTypes_1.VertexType.MAC_ADDRESS: {
                    existing.mac.push((0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID)));
                    break;
                }
                case CommonTypes_1.VertexType.HARDWARE_ID: {
                    existing.hwid = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                    break;
                }
                case CommonTypes_1.VertexType.SERIAL_NUMBER: {
                    existing.serial = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                    break;
                }
                default:
                    break;
            }
        }
        return { existing, existingOsMajor, existingOsMinor };
    }
    static modelForHash(mergedModel) {
        return {
            ...mergedModel,
            mac: lodash_1.default.sortBy(mergedModel.mac),
            ips: lodash_1.default.sortBy(mergedModel.ips),
            software: lodash_1.default.sortBy(mergedModel.software)
        };
    }
}
exports.UnifiedConnectorDeviceStateModel = UnifiedConnectorDeviceStateModel;
UnifiedConnectorDeviceStateModel.PROP_SOFTWARE = 'software';
UnifiedConnectorDeviceStateModel.PROP_DEPLOYMENT = 'deployment';
UnifiedConnectorDeviceStateModel.PROP_WANTED_DEPLOYMENT = 'wantedDeployment';
UnifiedConnectorDeviceStateModel.PROP_AC_UDID = 'acudid';
UnifiedConnectorDeviceStateModel.PROP_CSC_VERSION = 'cscVer';
UnifiedConnectorDeviceStateModel.PROP_SE_VERSION = 'seVer';
UnifiedConnectorDeviceStateModel.PROP_CLOUD_MGMT_VER = 'cloudMgmtVer';
UnifiedConnectorDeviceStateModel.DEFAULT_DEPLOYMENT_ID = '00000000-0000-0000-0000-000000000000';
class UnifiedConnectorDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new UnifiedConnectorDeviceStateModel(this.partitionKey);
    }
}
exports.UnifiedConnectorDeviceStateModelService = UnifiedConnectorDeviceStateModelService;
