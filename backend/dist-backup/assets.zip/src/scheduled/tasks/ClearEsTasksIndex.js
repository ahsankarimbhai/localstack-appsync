"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClearEsTasksIndex = void 0;
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const GlobalScheduledTaskProcessor_1 = require("../GlobalScheduledTaskProcessor");
class ClearEsTasksIndex extends GlobalScheduledTaskProcessor_1.GlobalScheduledTaskProcessor {
    async execute() {
        const elasticsearchServices = new ElasticsearchServices_1.ElasticsearchGlobalServices();
        await elasticsearchServices.deleteAllDocumentsInIndex(ClearEsTasksIndex.TASKS_INDEX);
        return Promise.resolve();
    }
    async process() {
        return this.execute();
    }
    getTaskName() {
        return ClearEsTasksIndex.TASK_NAME;
    }
}
exports.ClearEsTasksIndex = ClearEsTasksIndex;
ClearEsTasksIndex.TASK_NAME = 'clear-es-tasks-index';
ClearEsTasksIndex.TASKS_INDEX = '.tasks';
