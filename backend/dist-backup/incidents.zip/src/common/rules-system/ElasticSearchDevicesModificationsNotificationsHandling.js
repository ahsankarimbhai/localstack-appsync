"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ElasticSearchDevicesModificationsNotificationsHandler = void 0;
const LambdaLogger_1 = require("../LambdaLogger");
const NotificationServiceInterfaces_1 = require("../notification-service/NotificationServiceInterfaces");
const KinesisServices_1 = require("../kinesis/KinesisServices");
const Common_1 = require("./Common");
const KinesisHelper_1 = require("../kinesis/KinesisHelper");
const EventBridgeService_1 = require("../awsclient/EventBridgeService");
const TimestreamWriteServices_1 = require("../TimestreamWriteServices");
class ElasticSearchDevicesModificationsNotificationsHandler extends NotificationServiceInterfaces_1.Handler {
    constructor(tenantUid) {
        super(async (notification) => this.notifyRules(notification));
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.rulesExecutionStream = new KinesisServices_1.KinesisServices(KinesisHelper_1.RULES_EXECUTION);
        this.eventBridgeServices = new EventBridgeService_1.EventBridgeService();
        if (!process.env.EVENT_BRIDGE_BUS_ARN) {
            throw new Error('EVENT_BRIDGE_BUS_ARN is not set');
        }
        this.eventBusArn = process.env.EVENT_BRIDGE_BUS_ARN;
    }
    async notifyRules(notification) {
        const devicesModifiedNotification = notification;
        if (devicesModifiedNotification.devicesSpecifierIndirect) {
            await this.notifyRulesIndirect(devicesModifiedNotification);
            devicesModifiedNotification.metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_UPDATED_BY_FILTER_SUBMITTED));
            devicesModifiedNotification.metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_BY_FILTER_SUBMITION_DURATION, Date.now() - devicesModifiedNotification.timeStamp));
        }
        else {
            await this.notifyRulesDirect(devicesModifiedNotification);
            const { created, updated } = (0, Common_1.countCreatedUpdated)(devicesModifiedNotification);
            if (created) {
                devicesModifiedNotification.metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_CREATED_SUBMITTED, created));
            }
            if (updated) {
                devicesModifiedNotification.metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_UPDATED_SUBMITTED, updated));
            }
            devicesModifiedNotification.metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_SUBMITION_DURATION, Date.now() - devicesModifiedNotification.timeStamp));
        }
    }
    async notifyRulesDirect(notification) {
        this.logger.debug('Direct notification:', JSON.stringify(notification));
        const records = this.devicesModifiedNotificationToKinesisRecords(notification);
        await this.rulesExecutionStream.putRecords(records);
    }
    async notifyRulesIndirect(notification) {
        this.logger.debug('Indirect notification:', JSON.stringify(notification));
        const taskName = 'rules-devices-filtered-modifications';
        const evtReq = {
            EventBusName: this.eventBusArn,
            Source: `${process.env.ENV_PREFIX}-${taskName}`,
            DetailType: 'detail',
            Detail: JSON.stringify({
                targetTask: taskName,
                eventBridgeData: { ...notification, metrics: undefined, tenantId: this.tenantUid }
            })
        };
        try {
            this.logger.debug('Publishing:', JSON.stringify(evtReq));
            await this.eventBridgeServices.publish([evtReq]);
        }
        catch (e) {
            throw new Error(`Failed to publish ${JSON.stringify(evtReq)} with error: ${e.message}`);
        }
    }
    devicesModifiedNotificationToKinesisRecords(notification) {
        return notification.devicesModified.map(device => ({
            Data: JSON.stringify([device.devicesSpecifier, device.devicesModificationAction, notification.timeStamp, this.tenantUid, Common_1.NO_RULE_ID, notification.timeWhenModificationEventuallyConsistent]),
            PartitionKey: 'pk0'
        }));
    }
}
exports.ElasticSearchDevicesModificationsNotificationsHandler = ElasticSearchDevicesModificationsNotificationsHandler;
