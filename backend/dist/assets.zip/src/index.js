"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncIrohModuleInstances = exports.fetchDuoVersions = exports.liveOrbitalQuery = exports.getLiveDeviceTaskDetails = exports.triggerLiveDeviceDetails = exports.getFileUploadUrl = exports.testFetchForProducers = exports.testFetchForProducer = exports.triggerFetchForProducer = exports.vulnerabilityShaFetch = exports.triggerFetchPostureData = exports.fetchTrendVisionOneDevices = exports.fetchAzureUsers = exports.fetchSentinelOneDevices = exports.fetchMobileIronDevices = exports.fetchAirWatchDevices = exports.fetchUnifiedConnectorComputers = exports.fetchUmbrellaRoamingComputers = exports.fetchServiceNowDevices = exports.fetchJamfMobileDevices = exports.fetchJamfComputers = exports.fetchMerakiDevices = exports.fetchCyberVisionDevices = exports.fetchInTuneDevices = exports.fetchDuoUsers = exports.fetchDuoEndpoints = exports.fetchDefenderDevices = exports.fetchCrowdStrikeDevices = exports.fetchAmpComputers = exports.fetchAmpVulnerabilities = exports.fetchUmbrellaPolicies = exports.fetchAmpPolicies = exports.fetchAmpGroups = exports.fetchAzureGroups = exports.fetchGenericDevices = exports.logger = void 0;
const _ = __importStar(require("lodash"));
const AmpCollectorServices_1 = require("./services/amp/AmpCollectorServices");
const AwsSecretsService_1 = require("./common/AwsSecretsService");
const MerakiCollectorServices_1 = require("./services/meraki/MerakiCollectorServices");
const JamfCollectorServices_1 = require("./services/jamf/JamfCollectorServices");
const TimeBasedAsyncLambdaInvoker_1 = require("./common/TimeBasedAsyncLambdaInvoker");
const InTuneCollectorServices_1 = require("./services/intune/InTuneCollectorServices");
const SNSServices_1 = require("./common/SNSServices");
const CommonTypes_1 = require("./common/CommonTypes");
const TenantServices_1 = require("./common/TenantServices");
const DuoCollectorServices_1 = require("./services/duo/DuoCollectorServices");
const Util_1 = require("./common/Util");
const LambdaLogger_1 = require("./common/LambdaLogger");
const TimestreamWriteServices_1 = require("./common/TimestreamWriteServices");
const FunctionStateServices_1 = require("./common/FunctionStateServices");
const GroupServices_1 = require("./services/common/GroupServices");
const VulnerabilityUtil_1 = require("./services/common/VulnerabilityUtil");
const UmbrellaCollectorServices_1 = require("./services/umbrella/UmbrellaCollectorServices");
const MobileIronCollectorServices_1 = require("./services/mobileiron/MobileIronCollectorServices");
const DuoProcessorServices_1 = require("./services/duo/DuoProcessorServices");
const ScheduleServices_1 = require("./common/ScheduleServices");
const ScheduledTaskRunner_1 = require("./scheduled/ScheduledTaskRunner");
const OrbitalCollectorServices_1 = require("./services/orbital/OrbitalCollectorServices");
const LiveOrbitalQueryTask_1 = require("./scheduled/tasks/LiveOrbitalQueryTask");
const DuoVersionServices_1 = require("./services/duo/DuoVersionServices");
const OsVersionsServices_1 = require("./common/OsVersionsServices");
const ResourcesManager_1 = require("./common/ResourcesManager");
const UnifiedConnectorCollectorServices_1 = require("./services/unifiedconnector/UnifiedConnectorCollectorServices");
const AirWatchCollectorServices_1 = require("./services/airwatch/AirWatchCollectorServices");
const PolicyServices_1 = require("./services/common/PolicyServices");
const ProcessingUtil_1 = require("./common/ProcessingUtil");
const tenant_management_1 = require("./tenant-management");
const SourceUtils_1 = require("./common/SourceUtils");
const ElasticsearchServices_1 = require("./common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("./common/ElasticsearchFactory");
const ServiceNowCollectorServices_1 = require("./services/servicenow/ServiceNowCollectorServices");
const SentinelOneCollectorServices_1 = require("./services/sentinelone/SentinelOneCollectorServices");
const CyberVisionCollectorServices_1 = require("./services/cybervision/CyberVisionCollectorServices");
const CrowdStrikeCollectorServices_1 = require("./services/crowdstrike/CrowdStrikeCollectorServices");
const DefenderCollectorServices_1 = require("./services/defender/DefenderCollectorServices");
const AzureUsersCollectorServices_1 = require("./services/azure/AzureUsersCollectorServices");
const TrendVisionOneCollectorServices_1 = require("./services/trendvisionone/TrendVisionOneCollectorServices");
const GenericSourceCollectorServices_1 = require("./services/generic/GenericSourceCollectorServices");
const GenericSourceUtils_1 = require("./common/generic/GenericSourceUtils");
exports.logger = new LambdaLogger_1.LambdaLogger();
async function storeCollectionError(tenantUid, context, source, err) {
    var _a;
    const functionStateServices = new FunctionStateServices_1.FunctionStateServices();
    const functionState = await functionStateServices.getByKey(tenantUid, context.functionName, source);
    const state = FunctionStateServices_1.FunctionStateServices.getState(functionState);
    const response = err.response || ((_a = err.lastError) === null || _a === void 0 ? void 0 : _a.response);
    const collectionError = {
        message: err.message,
        responseBody: response === null || response === void 0 ? void 0 : response.data
    };
    _.set(state, FunctionStateServices_1.FunctionState.COLLECTION_ERROR, collectionError);
    functionState.setState(JSON.stringify(state));
    await functionStateServices.save(functionState);
}
const fetchEntitiesWrapper = async (event, context, producer, handler) => {
    const appData = (0, Util_1.getAppDataFromEvent)(event);
    const source = (0, Util_1.toSourceString)(producer || appData.tenant.source, appData.tenant.sourceId);
    const tenantUid = appData.tenant.tenantUid;
    const processingUtil = new ProcessingUtil_1.ProcessingUtil();
    let result;
    try {
        const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
        await awsSecretsService.init();
        context.appData = appData;
        if (!_.get(appData, 'nextUri')) {
            await processingUtil.reportMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.WORKFLOW_STARTED)], tenantUid, source, CommonTypes_1.WorkFlow.COLLECTION);
        }
        const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
        result = await handler(appData, awsSecretsService, timeBasedAsyncLambdaInvoker);
        const metrics = [];
        const skippedItems = result.collection.getSkippedItems();
        const notLinkableItems = result.collection.getNotLinkableItems();
        if (skippedItems > 0 || notLinkableItems > 0) {
            if (skippedItems > 0) {
                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_SKIPPED, skippedItems));
            }
            if (notLinkableItems > 0) {
                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_NOT_LINKABLE, notLinkableItems));
            }
            metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, skippedItems + notLinkableItems));
        }
        if (result.collection.isDone()) {
            await result.service.setFunctionStateToSuccess(result.collection, result.functionState);
            metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.WORKFLOW_COMPLETED));
            await result.service.fetchEntitiesPostProcessing(tenantUid, appData.tenant.sourceId);
        }
        if (metrics.length > 0) {
            await processingUtil.reportMetrics(metrics, tenantUid, source, CommonTypes_1.WorkFlow.COLLECTION);
        }
    }
    catch (err) {
        exports.logger.error(`Fetch of ${source} entities failed. ${JSON.stringify(err)}, ${err.message}, ${JSON.stringify(event)}`);
        await storeCollectionError(tenantUid, context, source, err);
        await processingUtil.reportMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.WORKFLOW_FAILED)], tenantUid, source, CommonTypes_1.WorkFlow.COLLECTION);
    }
};
const fetchGenericDevices = async (event, context) => fetchEntitiesWrapper(event, context, undefined, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const { nextUri, tenant: { tenantUid, tenantName, sourceId, source } } = (0, Util_1.getAppDataFromEvent)(event);
    exports.logger.debug(`Fetch Generic Devices called where tenant=${tenantUid}, source=${source}, and sourceId=${sourceId}`);
    const genericModel = GenericSourceUtils_1.GenericSourceUtils.getSourceConfiguration(source);
    if (!genericModel) {
        throw new Error(`No configuration defined for the unrecognized source "${source}"`);
    }
    if (!genericModel.apiDetails || genericModel.apiDetails.length === 0) {
        throw new Error(`No apiDetails in the source configuration for source ${source}`);
    }
    const service = new GenericSourceCollectorServices_1.GenericSourceCollectorServices(tenantUid, source, sourceId, genericModel.apiDetails, context.functionName);
    const collection = await service.getDevices(timeBasedAsyncLambdaInvoker, nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(source, sourceId), tenantUid, tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchGenericDevices = fetchGenericDevices;
const fetchAzureGroups = async (event, context) => {
    const { nextUri, tenant: { tenantUid, producer } } = (0, Util_1.getAppDataFromEvent)(event);
    if (!process.env.MS_GRAPH_URL) {
        throw new Error('MS_GRAPH_URL is not set');
    }
    const sourceId = _.split(producer, Util_1.SOURCE_SEPARATOR)[1];
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
    const service = new AzureUsersCollectorServices_1.AzureUserCollectorServices(awsSecretsService.getSecret(producer), tenantUid, context.functionName, sourceId);
    const collection = await service.getGroups(timeBasedAsyncLambdaInvoker, nextUri);
    const groupServices = new GroupServices_1.GroupServices(tenantUid);
    const promises = [];
    await collection.each((group) => {
        promises.push(groupServices.upsertGroup({
            sourceId,
            id: group.id,
            name: group.displayName,
            description: group.description,
            source: CommonTypes_1.Source.AZURE_USERS
        }));
    });
    await Promise.all(promises);
};
exports.fetchAzureGroups = fetchAzureGroups;
const fetchAmpGroups = async (event, context) => {
    const { nextUri, tenant: { tenantUid, producer } } = (0, Util_1.getAppDataFromEvent)(event);
    const sourceId = _.split(producer, Util_1.SOURCE_SEPARATOR)[1];
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
    const service = new AmpCollectorServices_1.AmpCollectorServices(awsSecretsService.getSecret(producer), tenantUid, context.functionName, sourceId);
    await service.init();
    const collection = await service.getGroups(timeBasedAsyncLambdaInvoker, nextUri);
    const groupServices = new GroupServices_1.GroupServices(tenantUid);
    const promises = [];
    await collection.each((group) => {
        promises.push(groupServices.upsertGroup({
            sourceId,
            id: group.guid,
            name: group.name,
            description: group.description,
            source: CommonTypes_1.Source.AMP
        }));
    });
    await Promise.all(promises);
};
exports.fetchAmpGroups = fetchAmpGroups;
const fetchAmpPolicies = async (event, context) => {
    const { nextUri, tenant: { tenantUid, producer } } = (0, Util_1.getAppDataFromEvent)(event);
    const sourceId = _.split(producer, Util_1.SOURCE_SEPARATOR)[1];
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
    const service = new AmpCollectorServices_1.AmpCollectorServices(awsSecretsService.getSecret(producer), tenantUid, context.functionName, sourceId);
    await service.init();
    const collection = await service.getPolicies(timeBasedAsyncLambdaInvoker, nextUri);
    const policyServices = new PolicyServices_1.PolicyServices(tenantUid);
    const promises = [];
    await collection.each((policy) => {
        promises.push(policyServices.upsertPolicy({
            sourceId,
            id: policy.guid,
            name: policy.name,
            description: policy.description,
            isDefault: policy.default,
            source: CommonTypes_1.Source.AMP
        }));
    });
    await Promise.all(promises);
};
exports.fetchAmpPolicies = fetchAmpPolicies;
const fetchUmbrellaPolicies = async (event, context) => {
    const appData = (0, Util_1.getAppDataFromEvent)(event);
    const tenantUid = appData.tenant.tenantUid;
    const sourceId = appData.tenant.sourceId;
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
    const tenantServices = new TenantServices_1.TenantServices();
    const source = (0, Util_1.toSourceString)(CommonTypes_1.Source.UMBRELLA, sourceId);
    const tenantConfiguration = await tenantServices.getTenantConfiguration(tenantUid, source);
    const tenantConfigurationValue = JSON.parse((tenantConfiguration === null || tenantConfiguration === void 0 ? void 0 : tenantConfiguration.value) || '{}');
    const service = new UmbrellaCollectorServices_1.UmbrellaCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UMBRELLA, sourceId)), tenantConfigurationValue.organizationId, tenantUid, context.functionName, sourceId);
    const collection = await service.getPolicies(timeBasedAsyncLambdaInvoker, appData.nextUri, tenantConfigurationValue.umbrellaV2Support);
    if (collection) {
        const policyServices = new PolicyServices_1.PolicyServices(tenantUid);
        const promises = [];
        await collection.each((group) => {
            promises.push(policyServices.upsertPolicy({
                sourceId,
                id: _.toString(group.policyId),
                name: group.name,
                source: CommonTypes_1.Source.UMBRELLA,
                priority: group.priority,
                isDefault: group.isDefault
            }));
        });
        await Promise.all(promises);
    }
};
exports.fetchUmbrellaPolicies = fetchUmbrellaPolicies;
const fetchAmpVulnerabilities = async (event, context) => {
    const { nextUri, tenant: { tenantUid, producer } } = (0, Util_1.getAppDataFromEvent)(event);
    const sourceId = _.split(producer, Util_1.SOURCE_SEPARATOR)[1];
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
    const service = new AmpCollectorServices_1.AmpCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, sourceId)), tenantUid, context.functionName, sourceId);
    await service.init();
    const collection = await service.getVulnerabilities(timeBasedAsyncLambdaInvoker, nextUri);
    return new VulnerabilityUtil_1.VulnerabilityUtil().streamVulnerabilities(collection, tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, sourceId));
};
exports.fetchAmpVulnerabilities = fetchAmpVulnerabilities;
const fetchAmpComputers = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.AMP, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new AmpCollectorServices_1.AmpCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    await service.init();
    const collection = await service.getComputers(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName, collection.updatedRecords);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchAmpComputers = fetchAmpComputers;
const fetchCrowdStrikeDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.CROWDSTRIKE, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const sourceString = (0, Util_1.toSourceString)(CommonTypes_1.Source.CROWDSTRIKE, appData.tenant.sourceId);
    const service = new CrowdStrikeCollectorServices_1.CrowdStrikeCollectorServices(appData.tenant.baseUrl, appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, sourceString, appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchCrowdStrikeDevices = fetchCrowdStrikeDevices;
const fetchDefenderDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.DEFENDER, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new DefenderCollectorServices_1.DefenderCollectorServices(appData.tenant.baseURL, appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.DEFENDER, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchDefenderDevices = fetchDefenderDevices;
const fetchDuoEndpoints = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.DUO, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new DuoCollectorServices_1.DuoCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.DUO, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getEndpoints(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.DUO, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName, undefined, DuoProcessorServices_1.DuoProcessorServices.hasPropertiesToMergeBy);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchDuoEndpoints = fetchDuoEndpoints;
const fetchDuoUsers = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.DUO_USERS, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new DuoCollectorServices_1.DuoCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.DUO_USERS, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getUsers(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.DUO_USERS, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchDuoUsers = fetchDuoUsers;
const fetchInTuneDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.INTUNE, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    if (!process.env.MS_GRAPH_URL) {
        throw new Error('MS_GRAPH_URL is not set');
    }
    const service = new InTuneCollectorServices_1.InTuneCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.INTUNE, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.INTUNE, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchInTuneDevices = fetchInTuneDevices;
const fetchCyberVisionDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.CYBERVISION, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new CyberVisionCollectorServices_1.CyberVisionCollectorServices(appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.CYBERVISION, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchCyberVisionDevices = fetchCyberVisionDevices;
const fetchMerakiDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.MERAKI, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new MerakiCollectorServices_1.MerakiCollectorServices(appData.tenant.merakiNetworkId, appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getSmDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.MERAKI, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchMerakiDevices = fetchMerakiDevices;
const fetchJamfComputers = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.JAMF, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new JamfCollectorServices_1.JamfCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.JAMF, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getComputers(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.JAMF, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchJamfComputers = fetchJamfComputers;
const fetchJamfMobileDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.JAMF, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new JamfCollectorServices_1.JamfCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.JAMF, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getMobileDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.JAMF, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchJamfMobileDevices = fetchJamfMobileDevices;
const fetchServiceNowDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.SERVICENOW, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const sourceString = (0, Util_1.toSourceString)(CommonTypes_1.Source.SERVICENOW, appData.tenant.sourceId);
    const service = new ServiceNowCollectorServices_1.ServiceNowCollectorServices(appData.tenant.baseUrl, appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, sourceString, appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchServiceNowDevices = fetchServiceNowDevices;
const fetchUmbrellaRoamingComputers = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.UMBRELLA, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new UmbrellaCollectorServices_1.UmbrellaCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UMBRELLA, appData.tenant.sourceId)), appData.tenant.organizationId, appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getRoamingComputers(timeBasedAsyncLambdaInvoker, appData.nextUri, undefined, appData.tenant.umbrellaV2Support);
    try {
        await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.UMBRELLA, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
        return {
            collection,
            service,
            functionState: collection.functionState
        };
    }
    catch (err) {
        await service.setFunctionStateToFailure(collection, collection.functionState);
        throw err;
    }
});
exports.fetchUmbrellaRoamingComputers = fetchUmbrellaRoamingComputers;
const fetchUnifiedConnectorComputers = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.UNIFIED_CONNECTOR, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, appData.tenant.sourceId)), appData.tenant.baseUrl, appData.tenant.adminBaseUrl, appData.tenant.tenantUid, appData.tenant.sourceId);
    const collection = await service.getComputersBulk(timeBasedAsyncLambdaInvoker, context.functionName, appData.nextUri);
    try {
        await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
        return {
            collection,
            service,
            functionState: collection.functionState
        };
    }
    catch (err) {
        await service.setFunctionStateToFailure(collection, collection.functionState);
        throw err;
    }
});
exports.fetchUnifiedConnectorComputers = fetchUnifiedConnectorComputers;
const fetchAirWatchDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.AIRWATCH, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new AirWatchCollectorServices_1.AirWatchCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AIRWATCH, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getAirWatchDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    try {
        await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.AIRWATCH, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
        return {
            collection,
            service,
            functionState: collection.functionState
        };
    }
    catch (err) {
        await service.setFunctionStateToFailure(collection, collection.functionState);
        throw err;
    }
});
exports.fetchAirWatchDevices = fetchAirWatchDevices;
const fetchMobileIronDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.MOBILEIRON, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new MobileIronCollectorServices_1.MobileIronCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.MOBILEIRON, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getMobileIronDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.MOBILEIRON, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchMobileIronDevices = fetchMobileIronDevices;
const fetchSentinelOneDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.SENTINEL_ONE, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new SentinelOneCollectorServices_1.SentinelOneCollectorServices(appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    try {
        await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.SENTINEL_ONE, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
        return {
            collection,
            service,
            functionState: collection.functionState
        };
    }
    catch (err) {
        await service.setFunctionStateToFailure(collection, collection.functionState);
        throw err;
    }
});
exports.fetchSentinelOneDevices = fetchSentinelOneDevices;
const fetchAzureUsers = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.AZURE_USERS, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    if (!process.env.MS_GRAPH_URL) {
        throw new Error('MS_GRAPH_URL is not set');
    }
    const service = new AzureUsersCollectorServices_1.AzureUserCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AZURE_USERS, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getUsers(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.AZURE_USERS, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchAzureUsers = fetchAzureUsers;
const fetchTrendVisionOneDevices = async (event, context) => fetchEntitiesWrapper(event, context, CommonTypes_1.Source.TREND_VISION_ONE, async (appData, awsSecretsService, timeBasedAsyncLambdaInvoker) => {
    const service = new TrendVisionOneCollectorServices_1.TrendVisionOneCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.TREND_VISION_ONE, appData.tenant.sourceId)), appData.tenant.tenantUid, context.functionName, appData.tenant.sourceId);
    const collection = await service.getDevices(timeBasedAsyncLambdaInvoker, appData.nextUri);
    await new ProcessingUtil_1.ProcessingUtil().collectionProcessing(collection, (0, Util_1.toSourceString)(CommonTypes_1.Source.TREND_VISION_ONE, appData.tenant.sourceId), appData.tenant.tenantUid, appData.tenant.tenantName);
    return {
        collection,
        service,
        functionState: collection.functionState
    };
});
exports.fetchTrendVisionOneDevices = fetchTrendVisionOneDevices;
const triggerFetchPostureData = async () => {
    const snsServices = new SNSServices_1.SNSServices();
    const tenantServices = new TenantServices_1.TenantServices();
    const tenants = await tenantServices.getAllTenants();
    for (const tenant of tenants) {
        exports.logger.info(`run fetch posture data for tenant: ${tenant.id}`);
        const producerConfigurations = await tenantServices.getPullEnabledTenantConfigurations(tenant.id);
        for (const producerConfiguration of producerConfigurations) {
            try {
                await new ProcessingUtil_1.ProcessingUtil().triggerFetchForTenantAndProducer(tenant.id, producerConfiguration.producerType, producerConfiguration.producerId, snsServices, false, TimestreamWriteServices_1.MetricName.STARTED_FETCH_SCHEDULED_TRIGGER);
            }
            catch (e) {
                exports.logger.error(e.message);
            }
        }
    }
};
exports.triggerFetchPostureData = triggerFetchPostureData;
const vulnerabilityShaFetch = async (event, context) => {
    const { nextUri, tenant: { tenantUid, producer }, sha256 } = (0, Util_1.getAppDataFromEvent)(event);
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
    const sourceId = _.split(producer, Util_1.SOURCE_SEPARATOR)[1];
    const service = new AmpCollectorServices_1.AmpCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, sourceId)), tenantUid, context.functionName, sourceId);
    await service.init();
    const collection = await service.getVulnerabilityComputers(timeBasedAsyncLambdaInvoker, nextUri, sha256);
    return new VulnerabilityUtil_1.VulnerabilityUtil().streamVulnerabilitiesSha(collection, tenantUid, (0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, sourceId), sha256);
};
exports.vulnerabilityShaFetch = vulnerabilityShaFetch;
const triggerFetchForProducer = async (event) => {
    const { tenantUid, role, userId } = (0, Util_1.getFromHeaders)(event);
    const { producerType, producerId } = event.args;
    exports.logger.info(`trigger fetch for tenant ${tenantUid} from producer ${JSON.stringify(producerType)}`);
    (0, Util_1.verifyAuthorization)(role, userId, tenantUid);
    const snsServices = new SNSServices_1.SNSServices();
    await new ProcessingUtil_1.ProcessingUtil().triggerFetchForTenantAndProducer(tenantUid, producerType, producerId, snsServices, true, TimestreamWriteServices_1.MetricName.STARTED_FETCH_MANUAL_TRIGGER);
    return true;
};
exports.triggerFetchForProducer = triggerFetchForProducer;
const testFetchForProducer = async (event, context) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { producerType, producerId } = event.args;
    exports.logger.info(`trigger test for tenant ${tenantUid} from producer ${producerType}, producerId ${producerId}`);
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const tenantServices = new TenantServices_1.TenantServices();
    const source = (0, Util_1.toSourceString)(producerType, producerId);
    const tenantConfiguration = await tenantServices.getTenantConfiguration(tenantUid, source);
    const tenantConfigurationValue = JSON.parse((tenantConfiguration === null || tenantConfiguration === void 0 ? void 0 : tenantConfiguration.value) || '{}');
    const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context, 0);
    let collection;
    switch (producerType) {
        case CommonTypes_1.Source.AMP: {
            const ampServices = new AmpCollectorServices_1.AmpCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AMP, producerId)), tenantUid, context.functionName, producerId);
            await ampServices.init();
            collection = await ampServices.getComputers(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.DUO: {
            const duoServices = new DuoCollectorServices_1.DuoCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.DUO, producerId)), tenantUid, context.functionName, producerId);
            collection = await duoServices.getEndpoints(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.DUO_USERS: {
            const duoServices = new DuoCollectorServices_1.DuoCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.DUO_USERS, producerId)), tenantUid, context.functionName, producerId);
            collection = await duoServices.getUsers(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.INTUNE: {
            if (!process.env.MS_GRAPH_URL) {
                throw new Error('MS_GRAPH_URL is not set');
            }
            const inTuneServices = new InTuneCollectorServices_1.InTuneCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.INTUNE, producerId)), tenantUid, context.functionName, producerId);
            collection = await inTuneServices.getDevices(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.CYBERVISION: {
            const cyberVisionServices = new CyberVisionCollectorServices_1.CyberVisionCollectorServices(tenantUid, context.functionName, producerId);
            collection = await cyberVisionServices.getDevices(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.JAMF: {
            const jamfServices = new JamfCollectorServices_1.JamfCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.JAMF, producerId)), tenantUid, context.functionName, producerId);
            collection = await jamfServices.getComputers(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.UNIFIED_CONNECTOR: {
            const unifiedConnectorServices = new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, producerId)), tenantConfigurationValue.baseUrl, tenantConfigurationValue.adminBaseUrl, tenantUid, producerId);
            collection = await unifiedConnectorServices.getComputersBulk(timeBasedAsyncLambdaInvoker, context.functionName, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.AIRWATCH: {
            const airWatchServices = new AirWatchCollectorServices_1.AirWatchCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AIRWATCH, producerId)), tenantUid, context.functionName, producerId);
            collection = await airWatchServices.getAirWatchDevices(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.MERAKI: {
            const merakiServices = new MerakiCollectorServices_1.MerakiCollectorServices(tenantConfigurationValue.merakiNetworkId, tenantUid, context.functionName, producerId);
            collection = await merakiServices.getSmDevices(timeBasedAsyncLambdaInvoker, undefined, 3);
            break;
        }
        case CommonTypes_1.Source.UMBRELLA: {
            const umbrellaServices = new UmbrellaCollectorServices_1.UmbrellaCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UMBRELLA, producerId)), tenantConfigurationValue.organizationId, tenantUid, context.functionName, producerId);
            collection = await umbrellaServices.getRoamingComputers(timeBasedAsyncLambdaInvoker, undefined, 1, tenantConfigurationValue.umbrellaV2Support);
            break;
        }
        case CommonTypes_1.Source.MOBILEIRON: {
            const mobileIronServices = new MobileIronCollectorServices_1.MobileIronCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.MOBILEIRON, producerId)), tenantUid, context.functionName, producerId);
            collection = await mobileIronServices.getMobileIronDevices(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.SERVICENOW: {
            const serviceNowServices = new ServiceNowCollectorServices_1.ServiceNowCollectorServices(tenantConfigurationValue.baseUrl, tenantUid, context.functionName, producerId);
            collection = await serviceNowServices.getDevices(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.SENTINEL_ONE: {
            const sentinelOneServices = new SentinelOneCollectorServices_1.SentinelOneCollectorServices(tenantUid, context.functionName, producerId);
            collection = await sentinelOneServices.getDevices(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.CROWDSTRIKE: {
            const crowdStrikeServices = new CrowdStrikeCollectorServices_1.CrowdStrikeCollectorServices(tenantConfigurationValue.baseUrl, tenantUid, context.functionName, producerId);
            collection = await crowdStrikeServices.getDevices(timeBasedAsyncLambdaInvoker, undefined, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.DEFENDER: {
            const defenderServices = new DefenderCollectorServices_1.DefenderCollectorServices(tenantConfigurationValue.baseUrl, tenantUid, context.functionName, producerId);
            collection = await defenderServices.getDevices(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.AZURE_USERS: {
            if (!process.env.MS_GRAPH_URL) {
                throw new Error('MS_GRAPH_URL is not set');
            }
            const azureUserServices = new AzureUsersCollectorServices_1.AzureUserCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.AZURE_USERS, producerId)), tenantUid, context.functionName, producerId);
            collection = await azureUserServices.getUsers(timeBasedAsyncLambdaInvoker, undefined, 1);
            break;
        }
        case CommonTypes_1.Source.TREND_VISION_ONE: {
            const trendVisionOneServices = new TrendVisionOneCollectorServices_1.TrendVisionOneCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.TREND_VISION_ONE, producerId)), tenantUid, context.functionName, producerId);
            collection = await trendVisionOneServices.getDevices(timeBasedAsyncLambdaInvoker, undefined, 50);
            break;
        }
        case CommonTypes_1.Source.ORBITAL:
            throw new Error('Scheduling Orbital webhook in progress, 0 notifications received');
        default:
            throw new Error(`Test ${producerType} is not supported yet`);
    }
    const record = await collection.next();
    exports.logger.info(`testFetchForProducer processed next record for producer type ${producerType}, producerId ${producerId}`);
    return record ? 1 : 0;
};
exports.testFetchForProducer = testFetchForProducer;
const testFetchForProducers = async (event, context) => {
    const producers = event.args.producers;
    const response = [];
    const promises = producers.map(async (producer) => {
        const fetchProducerEvent = {
            request: { headers: event.request.headers },
            args: { producerType: producer.producerType, producerId: producer.producerId }
        };
        return (0, exports.testFetchForProducer)(fetchProducerEvent, context)
            .then(result => {
            exports.logger.info(`Test fetch from producer ${producer.producerType}, producerId ${producer.producerId}, result = ${result}`);
            response.push({ producerType: producer.producerType, producerId: producer.producerId, result });
        })
            .catch(error => {
            exports.logger.error(`Test fetch from producer ${producer.producerType}, producerId ${producer.producerId}, error = ${error}`);
            response.push({ producerType: producer.producerType, producerId: producer.producerId, result: 0 });
        });
    });
    await Promise.allSettled(promises);
    exports.logger.info('testFetchForProducers completed');
    return response;
};
exports.testFetchForProducers = testFetchForProducers;
const getFileUploadUrl = async (event) => {
    const tenantUid = event.requestContext.authorizer.tenantUid;
    const role = event.requestContext.authorizer.role;
    const userId = event.requestContext.authorizer.id;
    (0, Util_1.verifyAuthorization)(role, userId, tenantUid);
    const sourceId = event.queryStringParameters.sourceId;
    const fileUploadUrl = await (new ProcessingUtil_1.ProcessingUtil()).getFileUploadUrl(tenantUid, sourceId);
    return (0, Util_1.lambdaProxyResponse)('GET', JSON.stringify({ uploadUrl: fileUploadUrl }));
};
exports.getFileUploadUrl = getFileUploadUrl;
const triggerLiveDeviceDetails = async (event) => {
    const { tenantUid } = (0, Util_1.getFromHeaders)(event);
    const { producerType, producerId, deviceId } = event.args;
    const producer = (0, Util_1.toSourceString)(producerType, producerId);
    exports.logger.info(`trigger liveOrbitalQuery for tenant ${tenantUid} from producer ${producer}, deviceId ${deviceId}`);
    const taskMessage = {
        deviceId,
        tenantUid,
        producerType,
        producerId
    };
    const scheduledTask = new LiveOrbitalQueryTask_1.LiveOrbitalQueryTask(tenantUid, deviceId, producer);
    await new ScheduleServices_1.ScheduledTaskServices().save(scheduledTask);
    await new ScheduledTaskRunner_1.ScheduledTaskRunner().triggerTask(scheduledTask, taskMessage);
    return scheduledTask.taskKey;
};
exports.triggerLiveDeviceDetails = triggerLiveDeviceDetails;
const getLiveDeviceTaskDetails = async (event) => {
    const { taskId } = event.args;
    const scheduledTask = await new ScheduleServices_1.ScheduledTaskServices().getByTaskKey(taskId);
    return {
        status: scheduledTask === null || scheduledTask === void 0 ? void 0 : scheduledTask.status,
        errorMessage: scheduledTask === null || scheduledTask === void 0 ? void 0 : scheduledTask.errorMessage
    };
};
exports.getLiveDeviceTaskDetails = getLiveDeviceTaskDetails;
async function updateLiveQueryTaskStatus(producerType, producerId, deviceId, tenantUid, status, e) {
    const producer = (0, Util_1.toSourceString)(producerType, producerId);
    const taskId = (0, Util_1.toSourceString)(LiveOrbitalQueryTask_1.LiveOrbitalQueryTask.TASK_NAME, deviceId);
    const scheduledTask = await new ScheduleServices_1.ScheduledTaskServices().getByKey(taskId, tenantUid, producer);
    scheduledTask.status = status;
    scheduledTask.errorMessage = e === null || e === void 0 ? void 0 : e.message;
    await new ScheduleServices_1.ScheduledTaskServices().save(scheduledTask);
}
const liveOrbitalQuery = async (event) => {
    const message = (0, Util_1.parseEvent)(event);
    const tenantUid = message.tenantUid;
    const { producerType, producerId, deviceId } = message;
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    await awsSecretsService.init();
    const tenantServices = new TenantServices_1.TenantServices();
    const source = (0, Util_1.toSourceString)(producerType, producerId);
    const tenantConfiguration = await tenantServices.getTenantConfiguration(tenantUid, source);
    const tenantConfigurationValue = JSON.parse((tenantConfiguration === null || tenantConfiguration === void 0 ? void 0 : tenantConfiguration.value) || '{}');
    exports.logger.info(`execute liveOrbitalQuery for tenant ${tenantUid} from producer ${producerType}, producerId ${producerId}, deviceId ${deviceId}`);
    let collectionService;
    switch (producerType) {
        case CommonTypes_1.Source.ORBITAL:
            collectionService = new OrbitalCollectorServices_1.OrbitalCollectorServices(awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.ORBITAL, producerId)), tenantUid, producerId, tenantConfigurationValue.baseURL);
            break;
        default:
            throw new Error(`On demand ${producerType} fetch is not supported yet`);
    }
    try {
        await collectionService.fetchSingleEntity(deviceId);
        await updateLiveQueryTaskStatus(producerType, producerId, deviceId, tenantUid, LiveOrbitalQueryTask_1.LiveOrbitalQueryTaskStatus.DONE);
    }
    catch (e) {
        await updateLiveQueryTaskStatus(producerType, producerId, deviceId, tenantUid, LiveOrbitalQueryTask_1.LiveOrbitalQueryTaskStatus.ERROR, e);
    }
    finally {
        await (0, ResourcesManager_1.closeConnections)(true);
    }
};
exports.liveOrbitalQuery = liveOrbitalQuery;
const fetchDuoVersions = async () => {
    const awsSecretsService = new AwsSecretsService_1.GlobalAwsSecretsService();
    await awsSecretsService.init();
    const duoSecrets = awsSecretsService.getSecret(AwsSecretsService_1.GlobalAwsSecretsService.DUO_VERSIONS);
    const duoVersionServices = new DuoVersionServices_1.DuoVersionServices(duoSecrets);
    const osVersions = await duoVersionServices.getOsVersions();
    const osVersionsServices = new OsVersionsServices_1.OsVersionsServices();
    return osVersionsServices.upsertOsVersions(osVersions);
};
exports.fetchDuoVersions = fetchDuoVersions;
const syncIrohModuleInstances = async (event, context) => {
    const appData = (0, Util_1.getAppDataFromEvent)(event);
    const tenantUid = appData.tenant.tenantUid;
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for syncIrohModuleInstances');
    }
    const tenantServices = new TenantServices_1.TenantServices();
    const featureFlags = await tenantServices.getFeatureFlags(tenantUid);
    const { setupStatus } = await tenantServices.getTenantSetupStatus(tenantUid);
    if (!setupStatus || setupStatus === TenantServices_1.TenantSetupStatus.NOT_SETUP) {
        exports.logger.debug(`Iroh module instance sync skipped, tenant is not setup: ${tenantUid}`);
        return Promise.resolve();
    }
    const instancesAndTypesToUse = await SourceUtils_1.SourceUtils.fetchIrohModulesInstancesAndTypesToUseInDi(tenantUid, featureFlags);
    const producerConfig = await tenantServices.getProducerConfigurations(tenantUid);
    const sxProducerConfig = [];
    const errors = [];
    for (const moduleInstanceAndTypePair of instancesAndTypesToUse) {
        let currentProducer = _.find(producerConfig, { irohModuleInstanceId: moduleInstanceAndTypePair.moduleInstance.id });
        try {
            if (!currentProducer) {
                currentProducer = await (0, tenant_management_1.addIrohModuleInstanceAsProducer)(tenantUid, moduleInstanceAndTypePair.moduleInstance, moduleInstanceAndTypePair.moduleType, context);
                await runSyncForANewProducerIfNeeded(currentProducer);
            }
            else {
                await (0, tenant_management_1.syncProducerWithIrohModuleInstance)(tenantUid, moduleInstanceAndTypePair.moduleInstance, moduleInstanceAndTypePair.moduleType, currentProducer);
            }
        }
        catch (ex) {
            const errorMessage = ex.message;
            errors.push(errorMessage);
            if (currentProducer) {
                exports.logger.error(`Error occurred in syncIrohModuleInstances where error=${errorMessage}, producerType=${currentProducer.producerType}, producerId=${currentProducer.producerId}, moduleInstance=${JSON.stringify(moduleInstanceAndTypePair.moduleInstance)}, tenantUid=${tenantUid}`);
            }
            else {
                exports.logger.error(`Error occurred in syncIrohModuleInstances where error=${errorMessage}, currentProducer=undefined, moduleInstance=${JSON.stringify(moduleInstanceAndTypePair.moduleInstance)}, tenantUid=${tenantUid}`);
            }
        }
        if (currentProducer) {
            sxProducerConfig.push({ producerType: currentProducer.producerType, producerId: currentProducer.producerId });
        }
    }
    const producersIrohModulesInstancesDiff = _.filter(_.map(producerConfig, producer => ({ producerType: producer.producerType, producerId: producer.producerId })), producer => !_.find(sxProducerConfig, producer));
    const producersToDelete = _.filter(producersIrohModulesInstancesDiff, producerToDelete => !_.includes(SourceUtils_1.diManagedProducers, producerToDelete.producerType));
    for (const producer of producersToDelete) {
        try {
            exports.logger.debug(`Removing producer ${JSON.stringify(producer)} for tenant ${tenantUid}`);
            const cfgKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
            const tenantConfiguration = await tenantServices.getTenantConfiguration(tenantUid, cfgKey);
            if (tenantConfiguration) {
                await (0, tenant_management_1.removeProducerConfigurationHelper)(tenantUid, tenantConfiguration, context);
            }
            exports.logger.debug(`Finished removing producer ${JSON.stringify(producer)} for tenant ${tenantUid}`);
        }
        catch (e) {
            exports.logger.error(`Failed removing producer ${JSON.stringify(producer)} for tenant ${tenantUid}. Error message: ${JSON.stringify(e.message)}`);
        }
    }
    exports.logger.debug(`Deleting irrelevant producers from ES for tenant ${tenantUid}`);
    const updatedProducerConfig = await tenantServices.getProducerConfigurations(tenantUid);
    await new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)()).deleteIrrelevantProducers(_.map(updatedProducerConfig, prod => prod.producerId));
    exports.logger.debug(`Finished syncing IROH module instances to DI producers for tenant ${tenantUid}`);
    if (errors.length > 0) {
        throw new Error(JSON.stringify({ errors }));
    }
    return Promise.resolve();
    async function runSyncForANewProducerIfNeeded(currentProducer) {
        const isReduceSchedulingOn = await tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.REDUCE_SCHEDULING);
        if (isReduceSchedulingOn && (0, CommonTypes_1.sourceWithLessSync)(currentProducer.producerType)) {
            const snsServices = new SNSServices_1.SNSServices();
            await new ProcessingUtil_1.ProcessingUtil().triggerFetchForTenantAndProducer(tenantUid, currentProducer.producerType, currentProducer.producerId, snsServices, true, TimestreamWriteServices_1.MetricName.STARTED_FETCH_NEW_PRODUCER_SCHEDULED);
        }
    }
};
exports.syncIrohModuleInstances = syncIrohModuleInstances;
