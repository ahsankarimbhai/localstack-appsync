"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneScriptClient = void 0;
const gremlin_1 = require("gremlin");
const ts_retry_promise_1 = require("ts-retry-promise");
const LambdaLogger_1 = require("../LambdaLogger");
const NeptuneClientHelper_1 = require("./NeptuneClientHelper");
class NeptuneScriptClient {
    constructor(url, options = { traversalSource: 'g', rejectUnauthorized: false }) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.url = url;
        this.clientOpts = options;
        this.client = new gremlin_1.driver.Client(url, options);
        this.client.addListener('close', (code, message) => {
            if (code === 1006) {
                this.logger.warn(`Neptune connection closed prematurely, ${message}`);
            }
        });
    }
    closeConnection() {
        return this.client.close();
    }
    async executeScript(request) {
        return (0, ts_retry_promise_1.retry)(async () => {
            try {
                const result = await this.client.submit(request);
                return result;
            }
            catch (err) {
                this.logger.error(`failed to submit query, error: ${err.message}`);
                if ((0, NeptuneClientHelper_1.isConnectionError)(err)) {
                    await this.closeConnection();
                    this.client = new gremlin_1.driver.Client(this.url, this.clientOpts);
                    this.logger.info('reopened a neptune connection.');
                }
                throw err;
            }
        }, {
            retries: 3
        });
    }
}
exports.NeptuneScriptClient = NeptuneScriptClient;
