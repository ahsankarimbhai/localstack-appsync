"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneShardMigrationLogDetailRepo = void 0;
const DynamoDBServices_1 = require("../awsclient/dynamodb/DynamoDBServices");
const _ = __importStar(require("lodash"));
const DynamodbServiceFactory_1 = require("../awsclient/dynamodb/DynamodbServiceFactory");
class NeptuneShardMigrationLogDetailRepo {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    }
    static getDynamoDBGSIName() {
        return DynamoDBServices_1.DynamoDBServices.getTableName('nsmld-tenantuid-gsi');
    }
    async getTenantMigrationLogDetails(tenantUid) {
        return this.dynamoDBServices.getItemsBySecondaryIndex(NeptuneShardMigrationLogDetailRepo.TABLE_NAME, NeptuneShardMigrationLogDetailRepo.getDynamoDBGSIName(), NeptuneShardMigrationLogDetailRepo.GSI_KEY, tenantUid);
    }
    async getAllMigrationLogDetails() {
        return this.dynamoDBServices.getAllTableEntries(NeptuneShardMigrationLogDetailRepo.TABLE_NAME);
    }
    async upsert(migrationLogDetail) {
        const item = {
            tenantUid: migrationLogDetail.tenantUid,
            exportId: migrationLogDetail.exportId,
            loadId: migrationLogDetail.loadId,
            type: migrationLogDetail.type,
            outputS3Uri: migrationLogDetail.outputS3Uri,
            exportStatus: migrationLogDetail.exportStatus,
            exportRequestPayload: migrationLogDetail.exportRequestPayload,
            loadStatus: migrationLogDetail.loadStatus,
            loadRequestPayload: migrationLogDetail.loadRequestPayload
        };
        return this.dynamoDBServices.save(NeptuneShardMigrationLogDetailRepo.TABLE_NAME, item);
    }
    async update(exportId, exportStatus, outputS3Uri, exportRequestPayload, loadId, loadStatus, loadRequestPayload) {
        const key = { exportId };
        const update = {};
        if (!_.isNil(exportStatus)) {
            update.exportStatus = exportStatus;
        }
        if (!_.isNil(outputS3Uri)) {
            update.outputS3Uri = outputS3Uri;
        }
        if (!_.isNil(exportRequestPayload)) {
            update.exportRequestPayload = exportRequestPayload;
        }
        if (!_.isNil(loadId)) {
            update.loadId = loadId;
        }
        if (!_.isNil(loadStatus)) {
            update.loadStatus = loadStatus;
        }
        if (!_.isNil(loadRequestPayload)) {
            update.loadRequestPayload = loadRequestPayload;
        }
        return this.dynamoDBServices.update(NeptuneShardMigrationLogDetailRepo.TABLE_NAME, key, update);
    }
    async delete(exportId) {
        return this.dynamoDBServices.delete(NeptuneShardMigrationLogDetailRepo.TABLE_NAME, NeptuneShardMigrationLogDetailRepo.HASH_KEY, exportId);
    }
}
exports.NeptuneShardMigrationLogDetailRepo = NeptuneShardMigrationLogDetailRepo;
NeptuneShardMigrationLogDetailRepo.TABLE_NAME = 'neptune-shard-migration-log-detail';
NeptuneShardMigrationLogDetailRepo.HASH_KEY = 'exportId';
NeptuneShardMigrationLogDetailRepo.GSI_KEY = 'tenantUid';
