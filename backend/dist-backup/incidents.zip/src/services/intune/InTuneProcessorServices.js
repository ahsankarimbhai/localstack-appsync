"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InTuneProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const InTuneEndpointService_1 = require("../../collectors/services/InTuneEndpointService");
class InTuneProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(inTuneDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, inTuneDevice.wiFiMacAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        await this.verifyChange(currentTopology, inTuneDevice.serialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        await this.verifyChange(currentTopology, inTuneDevice.imei, CommonTypes_1.VertexType.IMEI, changes, unchanged);
        await this.verifyChange(currentTopology, inTuneDevice.userPrincipalName, CommonTypes_1.VertexType.USER, changes, unchanged);
        await this.verifyChange(currentTopology, inTuneDevice.emailAddress, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
        await this.verifyChange(currentTopology, vertexState.getPropertyValue(CommonTypes_1.VertexBasicProperty.NAME), CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new InTuneEndpointService_1.InTuneEndpointService(tenantUid, sourceId);
    }
}
exports.InTuneProcessorServices = InTuneProcessorServices;
