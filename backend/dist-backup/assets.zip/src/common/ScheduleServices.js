"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScheduledTaskServices = exports.ScheduledTaskMetadataServices = exports.ScheduledTask = exports.ScheduledTaskMetadata = exports.ScheduleType = void 0;
const _ = __importStar(require("lodash"));
const Util_1 = require("./Util");
const BatchTaskServices_1 = require("./BatchTaskServices");
const DynamoDBServices_1 = require("./awsclient/dynamodb/DynamoDBServices");
const cron_time_generator_1 = require("cron-time-generator");
const MemoryCache_1 = require("./cache/MemoryCache");
var ScheduleType;
(function (ScheduleType) {
    ScheduleType["WEEKLY"] = "weekly";
    ScheduleType["DAILY"] = "daily";
    ScheduleType["HOURLY"] = "hourly";
    ScheduleType["TEN_MINUTES"] = "ten_minutes";
    ScheduleType["NOW"] = "now";
    ScheduleType["NA"] = "na";
})(ScheduleType = exports.ScheduleType || (exports.ScheduleType = {}));
class ScheduledTaskMetadata extends BatchTaskServices_1.BatchTaskMetadata {
    constructor(name, type, scope, producerTypeList, taskParams, isScalable, concurrency) {
        super(name, scope, producerTypeList, taskParams);
        this.name = name;
        this.type = type;
        this.scope = scope;
        this.taskParams = taskParams;
        this.isScalable = isScalable;
        this.concurrency = concurrency;
    }
}
exports.ScheduledTaskMetadata = ScheduledTaskMetadata;
ScheduledTaskMetadata.TABLE_NAME = `scheduled-${BatchTaskServices_1.BatchTaskMetadata.TABLE_NAME_SUFFIX}`;
class ScheduledTask extends BatchTaskServices_1.BatchTask {
    constructor(name, tenantUid, schedule = ScheduleType.DAILY, producer, taskParams) {
        super(name, tenantUid, producer, taskParams);
        this.name = name;
        this.tenantUid = tenantUid;
        this.producer = producer;
        this.taskParams = taskParams;
        switch (schedule) {
            case ScheduleType.WEEKLY: {
                this.schedule = cron_time_generator_1.CronTime.everyWeekAt(ScheduledTask.getRandomDay(), ScheduledTask.getRandomHour(), ScheduledTask.getRandomMin());
                break;
            }
            case ScheduleType.DAILY: {
                this.schedule = cron_time_generator_1.CronTime.everyDayAt(ScheduledTask.getRandomHour(), ScheduledTask.getRandomMin());
                break;
            }
            case ScheduleType.HOURLY: {
                this.schedule = cron_time_generator_1.CronTime.everyHourAt(ScheduledTask.getRandomMin());
                break;
            }
            case ScheduleType.TEN_MINUTES: {
                this.schedule = cron_time_generator_1.CronTime.every(10).minutes();
                break;
            }
            case ScheduleType.NOW: {
                this.schedule = _.toString(ScheduleType.NOW);
                break;
            }
            default:
                (0, Util_1.validateCronExpression)(schedule);
                this.schedule = schedule;
        }
    }
    static getRandomDay() {
        return ScheduledTask.getRandomNumber(6) + 1;
    }
    static getRandomHour() {
        return ScheduledTask.getRandomNumber(23);
    }
    static getRandomMin() {
        return ScheduledTask.getRandomNumber(59);
    }
    static getRandomNumber(upper) {
        return Math.floor(Math.random() * upper);
    }
    getName() {
        return this.name;
    }
}
exports.ScheduledTask = ScheduledTask;
ScheduledTask.TABLE_NAME = `scheduled-${BatchTaskServices_1.BatchTask.TABLE_NAME_SUFFIX}`;
ScheduledTask.TENANT_ID_INDEX = DynamoDBServices_1.DynamoDBServices.getTableName('tenant-id-idx');
class ScheduledTaskMetadataServices extends BatchTaskServices_1.BatchTaskMetadataServices {
    getTableName() {
        return ScheduledTaskMetadata.TABLE_NAME;
    }
    getCachedByName(name) {
        return this.getByName(name);
    }
}
__decorate([
    (0, MemoryCache_1.memCacheDecorator)(ScheduledTaskMetadata.TABLE_NAME, 600)
], ScheduledTaskMetadataServices.prototype, "getCachedByName", null);
exports.ScheduledTaskMetadataServices = ScheduledTaskMetadataServices;
class ScheduledTaskServices extends BatchTaskServices_1.BatchTaskServices {
    getTableName() {
        return ScheduledTask.TABLE_NAME;
    }
    scheduleTenantTasks(tenantUid, alreadyScheduledTasks) {
        return this.scheduleTasks(tenantUid, BatchTaskServices_1.TaskScope.TENANT, undefined, alreadyScheduledTasks);
    }
    scheduleProducerTasks(tenantUid, producer, alreadyScheduledTasks) {
        return this.scheduleTasks(tenantUid, BatchTaskServices_1.TaskScope.PRODUCER, producer, alreadyScheduledTasks);
    }
    async scheduleTasks(tenantUid, scope, producer, alreadyScheduledTasks) {
        const scheduledTasks = [];
        const metadataServices = new ScheduledTaskMetadataServices();
        const tasksMetadata = (await metadataServices.getByScope(scope)).filter(t => t.type !== ScheduleType.NA);
        const taskTypesThatMatchProducer = producer ? tasksMetadata === null || tasksMetadata === void 0 ? void 0 : tasksMetadata.filter(tmItem => { var _a; return (_a = tmItem === null || tmItem === void 0 ? void 0 : tmItem.producerTypeList) === null || _a === void 0 ? void 0 : _a.find(ptItem => producer === null || producer === void 0 ? void 0 : producer.startsWith(ptItem)); }) : tasksMetadata;
        if (!alreadyScheduledTasks) {
            alreadyScheduledTasks = new Set((await this.getScheduledTasksByTenant(tenantUid)).map((item) => item.taskKey));
        }
        const taskTypesNotAlreadyScheduled = taskTypesThatMatchProducer.filter(tmItem => !(alreadyScheduledTasks === null || alreadyScheduledTasks === void 0 ? void 0 : alreadyScheduledTasks.has(BatchTaskServices_1.BatchTask.getKey(tmItem.name, tenantUid, producer))));
        this.logger.debug(`Scheduling ${taskTypesNotAlreadyScheduled.length} tasks of ${tasksMetadata.length} for scope: ${scope}, producer: ${producer}, tenant: ${tenantUid}
    not including${producer ? ` ${tasksMetadata.length - taskTypesThatMatchProducer.length} for unmatching producer,
    and` : ''} ${taskTypesThatMatchProducer.length - taskTypesNotAlreadyScheduled.length} that are already scheduled`);
        for (const taskMetadata of taskTypesNotAlreadyScheduled) {
            scheduledTasks.push(await this.save(new ScheduledTask(taskMetadata.name, tenantUid, taskMetadata.type, producer, taskMetadata.taskParams)));
        }
        return Promise.all(scheduledTasks);
    }
    getTasksToSchedule() {
        return this.dynamoDBServices.getAllFilteredTableEntries(this.getTableName(), 'schedule <> :schedule', { ':schedule': ScheduleType.NOW });
    }
    getScheduledTasksByTenant(tenantUid) {
        return this.dynamoDBServices.getItemsBySecondaryIndex(this.getTableName(), ScheduledTask.TENANT_ID_INDEX, 'tenantUid', tenantUid);
    }
    getScheduledTask(taskName, tenantUid, producer) {
        return this.dynamoDBServices.getByKey(ScheduledTask.TABLE_NAME, ScheduledTask.TASK_KEY, BatchTaskServices_1.BatchTask.getKey(taskName, tenantUid, producer));
    }
}
exports.ScheduledTaskServices = ScheduledTaskServices;
