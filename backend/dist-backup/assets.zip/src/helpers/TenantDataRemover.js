"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantDataRemover = void 0;
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const ElasticsearchServices_1 = require("../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../common/ElasticsearchFactory");
const NeptuneClientManager_1 = require("../common/neptune/NeptuneClientManager");
class TenantDataRemover {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(tenantUid);
    }
    async dropItems(rangeQuery, itemLabel, batchSize) {
        let numItems = 0;
        let nextCount;
        do {
            const start = Date.now();
            await this.neptuneServices.executeTenantQuery((g) => rangeQuery(g).drop().iterate());
            console.log('time to drop', Date.now() - start);
            numItems += batchSize;
            console.log(`${itemLabel} deleted`, numItems);
            nextCount = await this.neptuneServices.executeTenantQuery((g) => rangeQuery(g).count().next(), NeptuneClientManager_1.NeptuneClientType.Reader);
        } while (nextCount.value > 0);
    }
    async dropTenantNeptuneData() {
        const edgeRange = (g) => this.neptuneServices.getEdgeTraversal(g).range(0, TenantDataRemover.EDGE_BATCH_SIZE);
        await this.dropItems(edgeRange, 'edges', TenantDataRemover.EDGE_BATCH_SIZE);
        const graphTraversal = (g) => this.neptuneServices.getGraphTraversal(g).range(0, TenantDataRemover.VERTEX_BATCH_SIZE);
        await this.dropItems(graphTraversal, 'vertices', TenantDataRemover.VERTEX_BATCH_SIZE);
        await (0, NeptuneServicesFactory_1.closeNeptuneClient)();
    }
    dropTenantElasticSearchData() {
        const esServices = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        return esServices.deleteTenant();
    }
}
exports.TenantDataRemover = TenantDataRemover;
TenantDataRemover.EDGE_BATCH_SIZE = 100000;
TenantDataRemover.VERTEX_BATCH_SIZE = 10000;
