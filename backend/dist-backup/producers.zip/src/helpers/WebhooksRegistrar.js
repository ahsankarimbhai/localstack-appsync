"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhooksRegistrar = void 0;
const Util_1 = require("../common/Util");
const AwsSecretsService_1 = require("../common/AwsSecretsService");
const TenantServices_1 = require("../common/TenantServices");
const ProducerUtil_1 = require("../services/common/ProducerUtil");
class WebhooksRegistrar {
    constructor(tenantUid, producerType, producerId) {
        this.tenantUid = tenantUid;
        this.producerType = producerType;
        this.producerId = producerId;
    }
    async getSvc(context) {
        const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(this.tenantUid);
        await awsSecretsService.init();
        const secrets = awsSecretsService.getSecret((0, Util_1.toSourceString)(this.producerType, this.producerId));
        const tenantConfiguration = await (new TenantServices_1.TenantServices()).getTenantConfigurationOrFail(this.tenantUid, this.producerType, this.producerId);
        const svc = ProducerUtil_1.ProducerUtil.getPushCollectorService(tenantConfiguration, secrets, this.tenantUid, context, this.producerId, this.producerType);
        await svc.initWebhookToken(secrets);
        return svc;
    }
    async hasRegisteredWebhooks(context) {
        const svc = await this.getSvc(context);
        return svc.hasRegisteredWebhooks();
    }
    async getWebhookStatus(context) {
        const svc = await this.getSvc(context);
        return svc.getWebhookStatus();
    }
    async registerWebhooks(context) {
        const svc = await this.getSvc(context);
        await svc.registerWebhooks();
    }
    async deleteWebhooks(context) {
        const svc = await this.getSvc(context);
        await svc.removeWebhooks();
    }
}
exports.WebhooksRegistrar = WebhooksRegistrar;
