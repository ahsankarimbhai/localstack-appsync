"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SentinelOneDeviceStateModelService = exports.SentinelOneDeviceStateModel = exports.SentinelOneDeviceModelService = exports.SentinelOneDeviceModel = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class SentinelOneDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.SENTINEL_ONE_DEVICE;
    }
    async initProperties(sentinelOneDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, sentinelOneDevice.id);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.SentinelOneDeviceModel = SentinelOneDeviceModel;
class SentinelOneDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new SentinelOneDeviceModel(this.partitionKey);
    }
}
exports.SentinelOneDeviceModelService = SentinelOneDeviceModelService;
class SentinelOneDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.SENTINEL_ONE_DEVICE_STATE;
    }
    async initProperties(sentinelOneDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(sentinelOneDevice, [SentinelOneDeviceStateModel.LAST_ACTIVE_DATE])));
        const internalIps = [];
        if (sentinelOneDevice.lastIpToMgmt) {
            internalIps.push(sentinelOneDevice.lastIpToMgmt);
        }
        sentinelOneDevice.networkInterfaces.forEach((networkInterface) => {
            networkInterface.inet.forEach((ip) => {
                internalIps.push(ip);
            });
        });
        this.setInternalIpAddresses(internalIps);
        _.forEach(_.toPairs(sentinelOneDevice), (pair) => {
            if (!SentinelOneDeviceStateModel.SKIP_PROPERTIES.includes(pair[0])) {
                if (pair[0] === SentinelOneDeviceStateModel.ID) {
                    return;
                }
                this.setProperty(_.camelCase(pair[0]), pair[1]);
                switch (pair[0]) {
                    case SentinelOneDeviceStateModel.COMPUTER_NAME:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, pair[1]);
                        break;
                    case SentinelOneDeviceStateModel.OS_TYPE:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(pair[1]));
                        break;
                    case SentinelOneDeviceStateModel.OS_REVISION:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, pair[1]);
                        break;
                    case SentinelOneDeviceStateModel.OS_NAME:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_HUMAN_READABLE_VERSION, pair[1]);
                        break;
                    case SentinelOneDeviceStateModel.LAST_ACTIVE_DATE:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(pair[1]));
                        break;
                    case SentinelOneDeviceStateModel.IS_ACTIVE:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.IS_MANAGED, true);
                        break;
                    case SentinelOneDeviceStateModel.IS_DECOMMISSIONED:
                        this.setProperty(CommonTypes_1.VertexBasicProperty.IS_MANAGED, false);
                        break;
                    case SentinelOneDeviceStateModel.INFECTED:
                        if (pair[1]) {
                            this.setProperty(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT, false);
                        }
                        break;
                    case SentinelOneDeviceStateModel.ACTIVE_THREATS:
                        if (pair[1] > 0) {
                            this.setProperty(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT, false);
                        }
                        else {
                            this.setProperty(CommonTypes_1.VertexBasicProperty.IS_COMPLIANT, true);
                        }
                        break;
                    default:
                }
            }
        });
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.SentinelOneDeviceStateModel = SentinelOneDeviceStateModel;
SentinelOneDeviceStateModel.ID = 'id';
SentinelOneDeviceStateModel.ACCOUNT_ID = 'accountId';
SentinelOneDeviceStateModel.ACCOUNT_NAME = 'accountName';
SentinelOneDeviceStateModel.ACTIVE_THREATS = 'activeThreats';
SentinelOneDeviceStateModel.COMPUTER_NAME = 'computerName';
SentinelOneDeviceStateModel.EXTERNAL_IP = 'externalIp';
SentinelOneDeviceStateModel.INFECTED = 'infected';
SentinelOneDeviceStateModel.IS_ACTIVE = 'isActive';
SentinelOneDeviceStateModel.IS_DECOMMISSIONED = 'isDecommissioned';
SentinelOneDeviceStateModel.IS_PENDING_UNINSTALL = 'isPendingUninstall';
SentinelOneDeviceStateModel.IS_UNINSTALLED = 'isUninstalled';
SentinelOneDeviceStateModel.IS_UP_TO_DATE = 'isUpToDate';
SentinelOneDeviceStateModel.LAST_ACTIVE_DATE = 'lastActiveDate';
SentinelOneDeviceStateModel.LAST_IP_TO_MGMT = 'lastIpToMgmt';
SentinelOneDeviceStateModel.LAST_LOGGED_IN_USER_NAME = 'lastLoggedInUserName';
SentinelOneDeviceStateModel.MODEL_NAME = 'modelName';
SentinelOneDeviceStateModel.OS_NAME = 'osName';
SentinelOneDeviceStateModel.OS_TYPE = 'osType';
SentinelOneDeviceStateModel.OS_REVISION = 'osRevision';
SentinelOneDeviceStateModel.SERIAL_NUMBER = 'serialNumber';
SentinelOneDeviceStateModel.TAGS = 'tags';
SentinelOneDeviceStateModel.USER_ACTIONS_NEEDED = 'userActionsNeeded';
SentinelOneDeviceStateModel.UUID = 'uuid';
SentinelOneDeviceStateModel.SKIP_PROPERTIES = [
    'chmurray-place-holder'
];
class SentinelOneDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new SentinelOneDeviceStateModel(this.partitionKey);
    }
}
exports.SentinelOneDeviceStateModelService = SentinelOneDeviceStateModelService;
