"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CloseProducerCurrentStates = void 0;
const _ = __importStar(require("lodash"));
const gremlin_1 = require("gremlin");
const CommonTypes_1 = require("../../common/CommonTypes");
const NeptuneDBScheduledTaskProcessor_1 = require("../NeptuneDBScheduledTaskProcessor");
const Util_1 = require("../../common/Util");
const PostureEndpointService_1 = require("../../model/PostureEndpointService");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const t = gremlin_1.process.t;
class CloseProducerCurrentStates extends NeptuneDBScheduledTaskProcessor_1.NeptuneDBScheduledTaskProcessor {
    constructor(tenantUid, source) {
        super(tenantUid, 10, source);
        this.source = source;
        this.now = Date.now();
    }
    getTaskName() {
        return CloseProducerCurrentStates.TASK_NAME;
    }
    async processRange(startRange) {
        const peUids = await this.neptuneServices.executeTenantQuery((g) => this.getRangeQuery(g, startRange)
            .property(CommonTypes_1.EdgeBasicProperty.UNTIL, this.now)
            .select('pe')
            .by(t.id)
            .toList());
        const svc = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        for (const peUid of peUids) {
            try {
                await svc.updateSearchableVertex(peUid, true);
            }
            catch (e) {
                this.logger.error(`${this.getLogPrefix()} - failed to perform an update of information for PE ${peUid} with error`, e);
            }
        }
    }
    async nextRangeCount(startRange) {
        return this.neptuneServices.executeTenantQuery(async (g) => {
            const nextRangeCount = this.getRangeQuery(g, startRange).count();
            const rangeCountValue = await nextRangeCount.next();
            return rangeCountValue.value;
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    getRootTraversal(g) {
        return this.neptuneServices.getGraphTraversalBasedOnLabel(g, CommonTypes_1.VertexType.POSTURE_ENDPOINT);
    }
    getRangeQuery(g, startRange) {
        return this.getRootTraversal(g)
            .as('pe')
            .range(startRange, startRange + this.batchSize)
            .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .hasLabel(`${(0, CommonTypes_1.sourceToVertexType)(_.split(this.source, Util_1.SOURCE_SEPARATOR)[0])}__${this.source}__${this.tenantUid}`)
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL);
    }
}
exports.CloseProducerCurrentStates = CloseProducerCurrentStates;
CloseProducerCurrentStates.TASK_NAME = 'close-producer-current-states';
