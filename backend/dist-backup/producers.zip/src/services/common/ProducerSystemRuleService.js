"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProducerSystemRuleService = void 0;
const RuleService_1 = require("./RuleService");
const uuid_1 = require("uuid");
const lodash_1 = __importDefault(require("lodash"));
class ProducerSystemRuleService {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
    }
    async createSystemRules(sourceId, sourceName) {
        const newRules = this.getSystemRules(sourceId);
        const createdRules = [];
        const rulesService = new RuleService_1.RuleService(this.tenantUid);
        for (const rule of newRules) {
            const ruleName = `${rule.name} for ${sourceName}`;
            createdRules.push(await rulesService.createRule(new RuleService_1.RuleEntity(rule.ruleId || (0, uuid_1.v4)(), ruleName, this.tenantUid, rule.matchingCondition, rule.actionToTake, RuleService_1.RuleManagementAction.CREATE, rule.description, rule.origin, rule.hidden)));
        }
        return createdRules;
    }
    async deleteSystemRules(sourceId, rules) {
        const rulesService = new RuleService_1.RuleService(this.tenantUid);
        if (!rules || rules.length === 0) {
            rules = await rulesService.getAllRules();
        }
        const rulesIdsToDelete = [];
        for (const rule of rules) {
            if (rule.ruleId && rule.origin === RuleService_1.RuleOrigin.SYSTEM && lodash_1.default.some(rule.matchingCondition.producers, (producer) => producer.producerId === sourceId)) {
                rulesIdsToDelete.push(rule.ruleId);
            }
        }
        if (rulesIdsToDelete.length > 0) {
            await rulesService.hardDeleteRules(rulesIdsToDelete);
        }
    }
}
exports.ProducerSystemRuleService = ProducerSystemRuleService;
