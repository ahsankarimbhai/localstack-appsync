"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UmbrellaRoamingComputerStateModelService = exports.UmbrellaRoamingComputerStateModel = exports.UmbrellaRoamingComputerModelService = exports.UmbrellaRoamingComputerModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const _ = __importStar(require("lodash"));
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class UmbrellaRoamingComputerModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.UMBRELLA_ROAMING_COMPUTER;
    }
    async initProperties(umbrellaRoamingComputer) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, umbrellaRoamingComputer.originId);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.UmbrellaRoamingComputerModel = UmbrellaRoamingComputerModel;
class UmbrellaRoamingComputerModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new UmbrellaRoamingComputerModel(this.partitionKey);
    }
}
exports.UmbrellaRoamingComputerModelService = UmbrellaRoamingComputerModelService;
class UmbrellaRoamingComputerStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.UMBRELLA_ROAMING_COMPUTER_STATE;
    }
    async initProperties(umbrellaRoamingComputer) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(umbrellaRoamingComputer, ['lastSync'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, umbrellaRoamingComputer.name);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(umbrellaRoamingComputer.osVersionName));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, (0, CommonTypes_1.getOsVersion)(umbrellaRoamingComputer.osVersionName));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_EXTRACTED_NUMERIC_VERSION, (0, CommonTypes_1.extractNumericOsVersionFromAvailableOsDataFields)(umbrellaRoamingComputer.osVersionName, umbrellaRoamingComputer.osVersion));
        (0, CommonTypes_1.setOsHumanReadableVersionPhrase)(this, [umbrellaRoamingComputer.osVersionName.split(' ').some(token => umbrellaRoamingComputer.osVersion.includes(token)) ? undefined : umbrellaRoamingComputer.osVersionName, umbrellaRoamingComputer.osVersion].filter(item => item).join(' '));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, umbrellaRoamingComputer.osVersion);
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.parse(umbrellaRoamingComputer.lastSync));
        this.setProperty(UmbrellaRoamingComputerStateModel.TYPE, umbrellaRoamingComputer.type);
        this.setProperty(UmbrellaRoamingComputerStateModel.STATUS, umbrellaRoamingComputer.status);
        this.setProperty(UmbrellaRoamingComputerStateModel.LAST_SYNC_STATUS, umbrellaRoamingComputer.lastSyncStatus);
        this.setProperty(UmbrellaRoamingComputerStateModel.HAS_IP_BLOCKING, umbrellaRoamingComputer.hasIpBlocking);
        this.setProperty(UmbrellaRoamingComputerStateModel.DEVICE_ID, umbrellaRoamingComputer.deviceId);
        this.setProperty(UmbrellaRoamingComputerStateModel.APPLIED_BUNDLE, umbrellaRoamingComputer.appliedBundle);
        this.setProperty(UmbrellaRoamingComputerStateModel.VERSION, umbrellaRoamingComputer.version);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.UmbrellaRoamingComputerStateModel = UmbrellaRoamingComputerStateModel;
UmbrellaRoamingComputerStateModel.TYPE = 'type';
UmbrellaRoamingComputerStateModel.STATUS = 'status';
UmbrellaRoamingComputerStateModel.LAST_SYNC_STATUS = 'lastSyncStatus';
UmbrellaRoamingComputerStateModel.HAS_IP_BLOCKING = 'hasIpBlocking';
UmbrellaRoamingComputerStateModel.DEVICE_ID = 'deviceId';
UmbrellaRoamingComputerStateModel.APPLIED_BUNDLE = 'appliedBundle';
UmbrellaRoamingComputerStateModel.VERSION = 'version';
class UmbrellaRoamingComputerStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new UmbrellaRoamingComputerStateModel(this.partitionKey);
    }
}
exports.UmbrellaRoamingComputerStateModelService = UmbrellaRoamingComputerStateModelService;
