"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.refreshOrbitalWebhookCredential = exports.truncateTenantNeptuneData = exports.restartFailedMigrationTask = exports.extendMigrationTaskTTL = exports.retrofitNeptunePsCvEdgeProperty = exports.rollbackRebalanceTask = exports.balanceTenantShardTask = exports.cleanupScheduleTasks = exports.initializeNeptuneShardTableMigration = exports.reregisterWebhooksTask = exports.retrofitTenantConfigScheduleTask = exports.populateTenantUidTask = exports.registerDIModuleInstance = exports.irohSyncScheduleTimeMigration = exports.unknownDuoHostnameMigration = exports.triggerDataMigration = void 0;
const DataMigrationOrchestrator_1 = require("./migration/DataMigrationOrchestrator");
const IrohModulesSyncScheduleTimeMigration_1 = require("./migration/tasks/IrohModulesSyncScheduleTimeMigration");
const UnknownDuoHostnameMigration_1 = require("./migration/tasks/UnknownDuoHostnameMigration");
const RegisterTenantAsDIModuleMigration_1 = require("./migration/tasks/RegisterTenantAsDIModuleMigration");
const PopulateTenantUidTask_1 = require("./migration/tasks/PopulateTenantUidTask");
const Util_1 = require("./common/Util");
const RetrofitTenantConfigScheduleTask_1 = require("./migration/tasks/RetrofitTenantConfigScheduleTask");
const ReregisterWebhooksTask_1 = require("./migration/tasks/ReregisterWebhooksTask");
const InitializeNeptuneShardTableMigration_1 = require("./migration/tasks/InitializeNeptuneShardTableMigration");
const CleanupScheduleTasks_1 = require("./migration/tasks/CleanupScheduleTasks");
const BalanceTenantShardTask_1 = require("./migration/tasks/BalanceTenantShardTask");
const RollbackRebalanceTask_1 = require("./migration/tasks/RollbackRebalanceTask");
const RetrofitNeptunePsCvEdgeProperty_1 = require("./migration/tasks/RetrofitNeptunePsCvEdgeProperty");
const TimeBasedAsyncLambdaInvoker_1 = require("./common/TimeBasedAsyncLambdaInvoker");
const ExtendMigrationTaskTTL_1 = require("./migration/tasks/ExtendMigrationTaskTTL");
const RestartFailedMigrationTask_1 = require("./migration/tasks/RestartFailedMigrationTask");
const BatchTaskServices_1 = require("./common/BatchTaskServices");
const TruncateTenantNeptuneData_1 = require("./migration/tasks/TruncateTenantNeptuneData");
const RefreshOrbitalWebhookCredential_1 = require("./migration/tasks/RefreshOrbitalWebhookCredential");
function getAppDataFromEvent(event) {
    const message = (0, Util_1.parseEvent)(event);
    return {
        startRangeInput: message.startRangeInput,
        tenantUid: message.tenantUid,
        producer: message.producer,
        taskParams: message.taskParams
    };
}
const triggerDataMigration = async () => {
    await new DataMigrationOrchestrator_1.DataMigrationManager().prepareMigrationPlan();
    return new DataMigrationOrchestrator_1.DataMigrationRunner().triggerNextMigration();
};
exports.triggerDataMigration = triggerDataMigration;
const unknownDuoHostnameMigration = async (event) => {
    const { tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for unknownDuoHostnameMigration');
    }
    const migration = new UnknownDuoHostnameMigration_1.UnknownDuoHostnameMigration(tenantUid);
    return migration.processTask();
};
exports.unknownDuoHostnameMigration = unknownDuoHostnameMigration;
const irohSyncScheduleTimeMigration = async (event) => {
    const { tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for irohSyncScheduleTimeMigration');
    }
    const migration = new IrohModulesSyncScheduleTimeMigration_1.IrohModulesSyncScheduleTimeMigration(tenantUid);
    return migration.processTask();
};
exports.irohSyncScheduleTimeMigration = irohSyncScheduleTimeMigration;
const registerDIModuleInstance = async (event) => {
    const { tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for registerDIModuleInstance');
    }
    const migration = new RegisterTenantAsDIModuleMigration_1.RegisterTenantAsDIModuleMigration(tenantUid);
    return migration.processTask();
};
exports.registerDIModuleInstance = registerDIModuleInstance;
const populateTenantUidTask = async (event) => {
    const { taskParams } = getAppDataFromEvent(event);
    const migration = new PopulateTenantUidTask_1.PopulateTenantUidTask(taskParams);
    return migration.processTask();
};
exports.populateTenantUidTask = populateTenantUidTask;
const retrofitTenantConfigScheduleTask = async () => {
    const migration = new RetrofitTenantConfigScheduleTask_1.RetrofitTenantConfigScheduleTask();
    return migration.processTask();
};
exports.retrofitTenantConfigScheduleTask = retrofitTenantConfigScheduleTask;
const reregisterWebhooksTask = async (event) => {
    const { taskParams } = getAppDataFromEvent(event);
    const migration = new ReregisterWebhooksTask_1.ReregisterWebhooksTask(taskParams);
    return migration.processTask();
};
exports.reregisterWebhooksTask = reregisterWebhooksTask;
const initializeNeptuneShardTableMigration = async () => {
    const migration = new InitializeNeptuneShardTableMigration_1.InitializeNeptuneShardTableMigration();
    return migration.processTask();
};
exports.initializeNeptuneShardTableMigration = initializeNeptuneShardTableMigration;
const cleanupScheduleTasks = async () => {
    const migration = new CleanupScheduleTasks_1.CleanupScheduleTasks();
    return migration.processTask();
};
exports.cleanupScheduleTasks = cleanupScheduleTasks;
const balanceTenantShardTask = async (event) => {
    const { taskParams } = getAppDataFromEvent(event);
    const migration = new BalanceTenantShardTask_1.BalanceTenantShardTask(taskParams);
    return migration.processTask();
};
exports.balanceTenantShardTask = balanceTenantShardTask;
const rollbackRebalanceTask = async (event) => {
    const { taskParams } = getAppDataFromEvent(event);
    const migration = new RollbackRebalanceTask_1.RollbackRebalanceTask(taskParams);
    return migration.processTask();
};
exports.rollbackRebalanceTask = rollbackRebalanceTask;
const retrofitNeptunePsCvEdgeProperty = async (event, context) => {
    const { tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for retrofitNeptunePsCvEdgeProperty');
    }
    const migration = new RetrofitNeptunePsCvEdgeProperty_1.RetrofitNeptunePsCvEdgeProperty(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 450000), tenantUid);
    return migration.processTask();
};
exports.retrofitNeptunePsCvEdgeProperty = retrofitNeptunePsCvEdgeProperty;
const extendMigrationTaskTTL = async (event) => {
    const { taskParams } = getAppDataFromEvent(event);
    const migration = new ExtendMigrationTaskTTL_1.ExtendMigrationTaskTTL(BatchTaskServices_1.TaskScope.GLOBAL, undefined, taskParams);
    return migration.processTask();
};
exports.extendMigrationTaskTTL = extendMigrationTaskTTL;
const restartFailedMigrationTask = async (event) => {
    const { taskParams } = getAppDataFromEvent(event);
    const migration = new RestartFailedMigrationTask_1.RestartFailedMigrationTask(taskParams);
    return migration.processTask();
};
exports.restartFailedMigrationTask = restartFailedMigrationTask;
const truncateTenantNeptuneData = async (event, context) => {
    const { tenantUid, taskParams } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for truncateTenantNeptuneData');
    }
    const migration = new TruncateTenantNeptuneData_1.TruncateTenantNeptuneData(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 360000), tenantUid, taskParams, +(process.env.BATCH_SIZE || 10000));
    return migration.processTask();
};
exports.truncateTenantNeptuneData = truncateTenantNeptuneData;
const refreshOrbitalWebhookCredential = async (event, context) => {
    const { taskParams } = getAppDataFromEvent(event);
    const migration = new RefreshOrbitalWebhookCredential_1.RefreshOrbitalWebhookCredential(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 30000), taskParams || { processedCount: 0 });
    return migration.processTask();
};
exports.refreshOrbitalWebhookCredential = refreshOrbitalWebhookCredential;
