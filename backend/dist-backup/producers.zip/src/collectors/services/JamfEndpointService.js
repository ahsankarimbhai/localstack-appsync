"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JamfEndpointService = exports.JamfWebhookEvent = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
var JamfWebhookEvent;
(function (JamfWebhookEvent) {
    JamfWebhookEvent["ComputerInventoryCompleted"] = "ComputerInventoryCompleted";
    JamfWebhookEvent["MobileDeviceCheckIn"] = "MobileDeviceCheckIn";
    JamfWebhookEvent["MobileDeviceUnEnrolled"] = "MobileDeviceUnEnrolled";
})(JamfWebhookEvent = exports.JamfWebhookEvent || (exports.JamfWebhookEvent = {}));
class JamfEndpointService extends Services_1.BaseEndpointService {
    getPvType() {
        return CommonTypes_1.VertexType.JAMF_COMPUTER;
    }
    getPsType() {
        return CommonTypes_1.VertexType.JAMF_COMPUTER_STATE;
    }
    processNotifications(body) {
        let record;
        this.logger.debug(`JAMF notification, event: ${body.webhook.webhookEvent}`);
        let computer;
        let device;
        switch (body.webhook.webhookEvent) {
            case JamfWebhookEvent.ComputerInventoryCompleted:
                computer = body.event;
                record = {
                    id: computer.jssID,
                    location: {
                        username: computer.username,
                        position: computer.position,
                        room: computer.room
                    },
                    name: computer.deviceName,
                    udid: computer.udid,
                    serialNumber: computer.serialNumber,
                    lastContactDate: JamfEndpointService.toIsoString(body.webhook.eventTimestamp),
                    operatingSystemVersion: computer.osVersion,
                    operatingSystemBuild: computer.osBuild,
                    ipAddress: computer.ipAddress,
                    reportedIpAddress: computer.reportedIpAddress,
                    macAddress: computer.macAddress,
                    alternateMacAddress: computer.alternateMacAddress,
                    modelIdentifier: computer.model,
                    isManaged: true,
                    isMobile: false,
                    username: computer.username,
                    emailAddress: computer.emailAddress
                };
                break;
            case JamfWebhookEvent.MobileDeviceCheckIn:
                device = body.event;
                record = {
                    id: device.jssID,
                    location: {
                        username: device.username,
                        position: 'NA',
                        room: device.room
                    },
                    name: device.deviceName,
                    udid: device.udid,
                    serialNumber: device.serialNumber,
                    lastContactDate: JamfEndpointService.toIsoString(body.webhook.eventTimestamp),
                    operatingSystemVersion: device.osVersion,
                    operatingSystemBuild: device.osBuild,
                    macAddress: device.bluetoothMacAddress,
                    alternateMacAddress: device.wifiMacAddress,
                    modelIdentifier: device.model,
                    isManaged: true,
                    isMobile: true,
                    username: device.username,
                    imei: device.imei
                };
                break;
            case JamfWebhookEvent.MobileDeviceUnEnrolled:
                break;
        }
        return record ? [record] : [];
    }
    static toIsoString(eventTimestamp) {
        return new Date(eventTimestamp).toISOString();
    }
}
exports.JamfEndpointService = JamfEndpointService;
