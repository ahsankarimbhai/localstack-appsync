"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RetrofitNeptunePsCvEdgeProperty = void 0;
const gremlin_1 = require("gremlin");
const CommonTypes_1 = require("../../common/CommonTypes");
const RetryUtil_1 = require("../../common/RetryUtil");
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const NeptuneServicesFactory_1 = require("../../common/neptune/NeptuneServicesFactory");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const __ = gremlin_1.process.statics;
class RetrofitNeptunePsCvEdgeProperty extends DataMigrationTaskProcessor_1.DataMigrationTaskProcessor {
    constructor(timeBasedLambdaHandler, tenantUid, batchSize = 10) {
        super(tenantUid);
        this.timeBasedLambdaHandler = timeBasedLambdaHandler;
        this.batchSize = batchSize;
        this.retryUtil = new RetryUtil_1.RetryUtil(undefined, {
            retries: 5,
            backoff: 'LINEAR',
            delay: 100
        });
        this.neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(tenantUid);
    }
    getTaskName() {
        return RetrofitNeptunePsCvEdgeProperty.TASK_NAME;
    }
    async execute() {
        let totalProcessed = 0;
        try {
            while (await this.neptuneServices.executeTenantQuery((g) => this.findPsNeedUpdate(g).hasNext(), NeptuneClientManager_1.NeptuneClientType.Reader)) {
                this.logger.debug(`${this.getLogPrefix()} remaining time in millis: ${this.timeBasedLambdaHandler.getRemainingTimeInMillis()}, threshold: ${this.timeBasedLambdaHandler.timeoutThreshold}`);
                if (this.timeBasedLambdaHandler.isItTimeToStop()) {
                    return { shouldContinue: true };
                }
                const currentPsIds = await this.neptuneServices.executeTenantQuery((g) => this.findPsNeedUpdate(g).toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
                for (const psId of currentPsIds) {
                    this.logger.debug(`${this.getLogPrefix()} - start updating for PS ${psId}`);
                    await this.setProperty(psId);
                    totalProcessed += 1;
                }
            }
            return { shouldContinue: false };
        }
        catch (err) {
            this.logger.error(`${this.getLogPrefix()} - error occurred when updating edge properties. err: ${err.message}`, err);
            throw err;
        }
        finally {
            this.logger.info(`${this.getLogPrefix()} - updated ${totalProcessed} current PS`);
        }
    }
    findPsNeedUpdate(g) {
        return this.neptuneServices.getGraphTraversalBasedOnLabel(g, CommonTypes_1.VertexType.POSTURE_ENDPOINT)
            .outE(CommonTypes_1.EdgeType.POSTURE_ENDPOINT).inV()
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
            .inV()
            .where(__.outE().not(__.has(CommonTypes_1.EdgeBasicProperty.IS_CURRENT, true)))
            .range(0, this.batchSize);
    }
    async setProperty(psId) {
        await this.retryUtil.executeWithRetry(() => this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, psId)
            .where(__.outE().not(__.has(CommonTypes_1.EdgeBasicProperty.IS_CURRENT, true)))
            .outE()
            .property(CommonTypes_1.EdgeBasicProperty.IS_CURRENT, true)
            .iterate()));
    }
}
exports.RetrofitNeptunePsCvEdgeProperty = RetrofitNeptunePsCvEdgeProperty;
RetrofitNeptunePsCvEdgeProperty.TASK_NAME = 'retrofit-neptune-ps-cv-edge-property';
