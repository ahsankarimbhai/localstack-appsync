"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SentinelOneProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const SentinelOneEndpointService_1 = require("../../collectors/services/SentinelOneEndpointService");
class SentinelOneProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async verifyChangeIfNotNull(currentTopology, identifier, vertexType, changes, unchanged) {
        if (identifier) {
            await this.verifyChange(currentTopology, identifier, vertexType, changes, unchanged);
        }
    }
    async obtainIdentifierChanges(sentinelOneDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChangeIfNotNull(currentTopology, sentinelOneDevice.serialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        await this.verifyChangeIfNotNull(currentTopology, sentinelOneDevice.externalIp, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
        await this.verifyChangeIfNotNull(currentTopology, sentinelOneDevice.lastLoggedInUserName, CommonTypes_1.VertexType.USER, changes, unchanged);
        await this.verifyChange(currentTopology, vertexState.getPropertyValue(CommonTypes_1.VertexBasicProperty.NAME), CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        for (const networkInterface of sentinelOneDevice.networkInterfaces) {
            await this.verifyChange(currentTopology, networkInterface.physical, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        }
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new SentinelOneEndpointService_1.SentinelOneEndpointService(tenantUid, sourceId);
    }
}
exports.SentinelOneProcessorServices = SentinelOneProcessorServices;
