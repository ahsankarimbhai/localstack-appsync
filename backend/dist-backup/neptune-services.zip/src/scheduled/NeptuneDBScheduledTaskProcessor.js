"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneDBScheduledTaskProcessor = void 0;
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const TimestreamWriteServices_1 = require("../common/TimestreamWriteServices");
const BasicScheduledTaskProcessor_1 = require("./BasicScheduledTaskProcessor");
const ResourcesManager_1 = require("../common/ResourcesManager");
const NeptuneClientManager_1 = require("../common/neptune/NeptuneClientManager");
class NeptuneDBScheduledTaskProcessor extends BasicScheduledTaskProcessor_1.BasicScheduledTaskProcessor {
    constructor(tenantUid, batchSize = NeptuneDBScheduledTaskProcessor.DEFAULT_BATCH_SIZE, producer, taskParams) {
        super(tenantUid, producer, taskParams);
        this.tenantUid = tenantUid;
        this.producer = producer;
        if (!process.env.ENV_PREFIX) {
            throw new Error('ENV_PREFIX is not set');
        }
        this.neptuneServices = (0, NeptuneServicesFactory_1.getNeptuneServices)(tenantUid);
        this.batchSize = batchSize;
    }
    execute() {
        throw new Error('Unsupported. Invoke process instead');
    }
    async process(timeBasedLambdaHandler, startRangeInput = 0) {
        if (startRangeInput === 0) {
            this.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.WORKFLOW_STARTED)]);
        }
        let startRange = startRangeInput;
        const start = Date.now();
        let totalCount = 0;
        this.logger.debug(`${this.getLogPrefix()} startRange [${startRange}]`);
        try {
            while (await this.hasNext(startRange)) {
                this.logger.debug(`${this.getLogPrefix()} remaining time in millis: ${timeBasedLambdaHandler.getRemainingTimeInMillis()}, threshold: ${timeBasedLambdaHandler.timeoutThreshold}`);
                if (timeBasedLambdaHandler.isItTimeToStop()) {
                    const event = {
                        startRangeInput: startRange,
                        tenantUid: this.tenantUid,
                        producer: this.producer,
                        taskParams: this.taskParams,
                        isEnded: false
                    };
                    await timeBasedLambdaHandler.handle(event);
                    return event;
                }
                await this.processRange(startRange);
                totalCount += await this.nextRangeCount(startRange);
                startRange += this.batchSize;
                this.logger.debug(`${this.getLogPrefix()} elements updated so far [${totalCount}] out of [${startRange}]`);
                this.batchSize = this.getNextBatchSize(this.batchSize);
            }
            await this.handleSuccess();
        }
        catch (err) {
            await this.handleFailure(err);
        }
        finally {
            await (0, ResourcesManager_1.closeConnections)();
            this.logger.debug(`${this.getLogPrefix()} completed, records affected: ${totalCount}, runtime:`, Date.now() - start);
            this.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, totalCount)]);
            await this.timestreamUtil.sendRequestsToStream(this.timestreamRequestBuilder.createRequestsAndReset());
        }
        return {
            startRangeInput,
            tenantUid: this.tenantUid,
            producer: this.producer,
            taskParams: this.taskParams,
            isEnded: true
        };
    }
    hasNext(startRange) {
        return this.neptuneServices.executeTenantQuery((g) => this.getRootTraversal(g).range(startRange, startRange + this.batchSize).hasNext(), NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    async nextRangeCount(startRange) {
        return this.neptuneServices.executeTenantQuery(async (g) => {
            const nextRangeCount = this.getRangeQuery(g, startRange).count();
            const rangeCountValue = await nextRangeCount.next();
            return rangeCountValue.value;
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    getRangeQuery(g, startRange) {
        return this.getRootTraversal(g).range(startRange, startRange + this.batchSize);
    }
    getNextBatchSize(currentBatchSize) {
        return currentBatchSize;
    }
    postProcess() {
        return Promise.resolve();
    }
}
exports.NeptuneDBScheduledTaskProcessor = NeptuneDBScheduledTaskProcessor;
NeptuneDBScheduledTaskProcessor.DEFAULT_BATCH_SIZE = 1000;
