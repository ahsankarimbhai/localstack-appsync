"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneClientManager = exports.NeptuneClientType = void 0;
const NeptuneClient_1 = require("./NeptuneClient");
const LambdaLogger_1 = require("../LambdaLogger");
const ts_retry_promise_1 = require("ts-retry-promise");
const NeptuneClientHelper_1 = require("./NeptuneClientHelper");
const Util_1 = require("../Util");
var NeptuneClientType;
(function (NeptuneClientType) {
    NeptuneClientType["Reader"] = "Reader";
    NeptuneClientType["Writer"] = "Writer";
})(NeptuneClientType = exports.NeptuneClientType || (exports.NeptuneClientType = {}));
class NeptuneCluster {
    constructor(shardId) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.clients = new Map();
        this.clientReconnectTime = new Map();
        this.shardId = shardId;
    }
    init(clientType) {
        let client = this.clients.get(clientType);
        if (!client) {
            const url = (0, NeptuneClientHelper_1.getNeptuneShardUrl)(this.shardId, clientType === NeptuneClientType.Reader);
            client = new NeptuneClient_1.NeptuneClient(url, { rejectUnauthorized: false, pingEnabled: false }, process.env.REPEAT_MODE, +(process.env.NEPTUNE_QUERY_TIMEOUT || 60000));
            this.clients.set(clientType, client);
        }
        return client;
    }
    async close(clientType) {
        if (clientType) {
            const client = this.clients.get(clientType);
            if (client) {
                await client.closeConnection().catch((err) => this.logger.error(`failed to close ${clientType}'s connection to shard ${this.shardId}`, err));
                this.clients.delete(clientType);
            }
        }
        else {
            for (const [type, client] of this.clients) {
                await client.closeConnection().catch((err) => this.logger.error(`failed to close ${type}'s connection to shard ${this.shardId}`, err));
            }
            this.clients.clear();
        }
    }
    getLatestReconnectTime(clientType) {
        return this.clientReconnectTime.get(clientType) || 0;
    }
    async reconnect(clientType) {
        this.clientReconnectTime.set(clientType, Date.now());
        await this.close(clientType);
        return this.init(clientType);
    }
}
class NeptuneClientManager {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.shardClusterMap = new Map();
        this.shardLastWriteTimeMap = new Map();
    }
    static getInstance() {
        if (!NeptuneClientManager.neptuneClientManager) {
            this.neptuneClientManager = new NeptuneClientManager();
        }
        return this.neptuneClientManager;
    }
    init(shardId, clientType) {
        let cluster = this.shardClusterMap.get(shardId);
        if (!cluster) {
            cluster = new NeptuneCluster(shardId);
            this.shardClusterMap.set(shardId, cluster);
        }
        return cluster.init(clientType);
    }
    async closeNeptuneClient(shardId) {
        if (!shardId) {
            for (const cluster of this.shardClusterMap.values()) {
                await cluster.close();
            }
        }
        else {
            const cluster = this.shardClusterMap.get(shardId);
            if (cluster) {
                await cluster.close();
            }
        }
        return Promise.resolve();
    }
    async executeQueryScope(shardId, clientType, queryFunc, strongConsistentReadDelay) {
        await this.waitForStrongConsistentRead(shardId, clientType, +(process.env.NEPTUNE_STRONG_CONSISTENT_READ_DELAY || strongConsistentReadDelay || 0));
        return this.retryIfWebSocketClosed(shardId, clientType, queryFunc);
    }
    async waitForStrongConsistentRead(shardId, clientType, strongConsistentReadDelay) {
        if (clientType !== NeptuneClientType.Reader || !strongConsistentReadDelay) {
            return;
        }
        if ((this.shardLastWriteTimeMap.get(shardId) || 0) > (Date.now() - strongConsistentReadDelay)) {
            await (0, Util_1.delay)(strongConsistentReadDelay);
        }
    }
    getLatestReconnectTime(shardId, clientType) {
        var _a;
        return ((_a = this.shardClusterMap.get(shardId)) === null || _a === void 0 ? void 0 : _a.getLatestReconnectTime(clientType)) || 0;
    }
    retryIfWebSocketClosed(shardId, clientType, func) {
        return (0, ts_retry_promise_1.retry)(async () => {
            const startTime = Date.now();
            try {
                const res = await func(this.init(shardId, clientType).getGraphTraversalSource());
                if (clientType === NeptuneClientType.Writer) {
                    this.shardLastWriteTimeMap.set(shardId, Date.now());
                }
                return res;
            }
            catch (err) {
                this.logger.error(`failed to submit query to ${clientType} in shard ${shardId}, error: ${err.message}`);
                if ((0, NeptuneClientHelper_1.isConnectionError)(err)) {
                    if (startTime <= this.getLatestReconnectTime(shardId, clientType)) {
                        this.logger.debug(`client for ${clientType} in shard ${shardId} was reconnected by other process, won't reopen a neptune connection`);
                    }
                    else {
                        const cluster = this.shardClusterMap.get(shardId);
                        if (cluster) {
                            await cluster.reconnect(clientType);
                            this.logger.info(`reopened a neptune connection for ${clientType} in shard ${shardId}.`);
                        }
                    }
                }
                throw err;
            }
        }, {
            timeout: +(process.env.NEPTUNE_QUERY_TIMEOUT || 60000),
            retries: 3,
            retryIf: (err) => (0, NeptuneClientHelper_1.isConnectionError)(err)
        });
    }
}
exports.NeptuneClientManager = NeptuneClientManager;
