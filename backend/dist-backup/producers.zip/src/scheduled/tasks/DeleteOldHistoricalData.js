"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteOldHistoricalData = void 0;
const ts_retry_promise_1 = require("ts-retry-promise");
const gremlin_1 = require("gremlin");
const CommonTypes_1 = require("../../common/CommonTypes");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const DateUtils_1 = require("../../common/DateUtils");
const NeptuneDBScheduledTaskProcessor_1 = require("../NeptuneDBScheduledTaskProcessor");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const __ = gremlin_1.process.statics;
const P = gremlin_1.process.P;
class DeleteOldHistoricalData extends NeptuneDBScheduledTaskProcessor_1.NeptuneDBScheduledTaskProcessor {
    constructor(tenantUid) {
        super(tenantUid, 10);
        this.esServices = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        this.oldestAllowedTime = new Date().getTime() - DeleteOldHistoricalData.DAYS_TO_KEEP * DateUtils_1.DAY_MILLIS;
    }
    getTaskName() {
        return DeleteOldHistoricalData.TASK_NAME;
    }
    getRootTraversal(g) {
        return this.neptuneServices.getGraphTraversalBasedOnLabel(g, CommonTypes_1.VertexType.POSTURE_ENDPOINT).hasNot(CommonTypes_1.EdgeBasicProperty.DELETED);
    }
    async processRange(startRange) {
        const peUids = await this.neptuneServices.executeTenantQuery((g) => this.getRangeQuery(g, startRange).toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        this.logger.debug(`${this.getLogPrefix()} - Deleting old data for PEs ${JSON.stringify(peUids)}, oldestAllowedTime: ${this.oldestAllowedTime}`);
        for (const peUid of peUids) {
            try {
                await this.processPE(peUid);
            }
            catch (e) {
                this.logger.error(`${this.getLogPrefix()} - failed to process PE ${peUid}. Continuing to other records.`, e);
            }
        }
    }
    async processPE(peUid) {
        let attempt = 1;
        await (0, ts_retry_promise_1.retry)(async () => {
            try {
                const connectorVertices = await this.getConnectorVerticesOfOutDatedPVs(peUid, this.oldestAllowedTime);
                await this.deleteOutdatedPSs(peUid, this.oldestAllowedTime);
                for (const cv of connectorVertices) {
                    await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, cv).where(__.inE(CommonTypes_1.EdgeType.HAS, CommonTypes_1.EdgeType.USES, CommonTypes_1.EdgeType.USED_BY).count().is(P.eq(0))).drop().iterate());
                }
                await this.deletePVsWithoutPSs(peUid);
                await this.deletePeIfNoPVs(peUid);
            }
            catch (e) {
                this.logger.error(`${this.getLogPrefix()} - Failed attempt ${attempt} to process PE ${peUid}`, e);
                attempt += 1;
                throw e;
            }
        }, DeleteOldHistoricalData.DEFAULT_RETRY_CONFIG);
    }
    async getConnectorVerticesOfOutDatedPVs(peUid, oldestAllowedTime) {
        const ivsResults = await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, peUid)
            .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .outE(CommonTypes_1.EdgeType.HAS_STATE).has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.lt(oldestAllowedTime))
            .inV()
            .out()
            .dedup()
            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        const resultSet = new gremlin_1.driver.ResultSet(ivsResults);
        return resultSet.toArray();
    }
    async deleteOutdatedPSs(peUid, oldestAllowedTime) {
        await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, peUid)
            .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .outE(CommonTypes_1.EdgeType.HAS_STATE).has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.lt(oldestAllowedTime))
            .inV()
            .and(__.inE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).count().is(P.eq(0)), __.inE(CommonTypes_1.EdgeType.HAS_STATE).has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.gte(oldestAllowedTime)).count().is(P.eq(0)))
            .drop()
            .iterate());
    }
    async deletePVsWithoutPSs(peUid) {
        await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, peUid)
            .out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .where(__.outE(CommonTypes_1.EdgeType.HAS_STATE).count().is(P.eq(0)))
            .drop()
            .iterate());
    }
    async deletePeIfNoPVs(peUid) {
        const countRes = await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, peUid).out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT).count().next(), NeptuneClientManager_1.NeptuneClientType.Reader);
        if (countRes.value === 0) {
            this.logger.debug(`${this.getLogPrefix()} - deleting PE ${peUid} since it has no states connected to it`);
            await this.neptuneServices.executeTenantQuery((g) => this.neptuneServices.getGraphTraversal(g, peUid).drop().iterate());
            await this.esServices.deleteDeviceInformation(peUid);
            this.logger.debug(`${this.getLogPrefix()} - Finished deleting PE ${peUid} since it has no states connected to it`);
        }
    }
}
exports.DeleteOldHistoricalData = DeleteOldHistoricalData;
DeleteOldHistoricalData.DEFAULT_RETRY_CONFIG = {
    retries: 5,
    delay: 100,
    backoff: 'LINEAR',
    timeout: 60000
};
DeleteOldHistoricalData.TASK_NAME = 'delete-old-data';
DeleteOldHistoricalData.DAYS_TO_KEEP = 21;
