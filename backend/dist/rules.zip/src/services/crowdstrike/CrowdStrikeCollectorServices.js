"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrowdStrikeCollectorServices = exports.CrowdStrikeFetcher = exports.CrowdStrikePolicyTypes = void 0;
const Services_1 = require("../../common/Services");
const CrowdStrikeCollection_1 = require("./CrowdStrikeCollection");
const CommonTypes_1 = require("../../common/CommonTypes");
const query_string_1 = __importDefault(require("query-string"));
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const _ = __importStar(require("lodash"));
const LambdaLogger_1 = require("../../common/LambdaLogger");
const GroupServices_1 = require("../common/GroupServices");
const PolicyServices_1 = require("../common/PolicyServices");
var CrowdStrikePolicyTypes;
(function (CrowdStrikePolicyTypes) {
    CrowdStrikePolicyTypes["DEVICE_CONTROL"] = "device-control";
    CrowdStrikePolicyTypes["FIREWALL"] = "firewall";
    CrowdStrikePolicyTypes["PREVENTION"] = "prevention";
    CrowdStrikePolicyTypes["REMOTE_RESPONSE"] = "remote-response";
    CrowdStrikePolicyTypes["SENSOR_UPDATE"] = "sensor-update";
    CrowdStrikePolicyTypes["GLOBAL_CONFIG"] = "globalconfig";
})(CrowdStrikePolicyTypes = exports.CrowdStrikePolicyTypes || (exports.CrowdStrikePolicyTypes = {}));
class CrowdStrikeFetcher {
    constructor(client, tenantUid, sourceId, limit, listUrl, devicesUrl, groupMap = new Map(), policyMap = new Map()) {
        this.client = client;
        this.tenantUid = tenantUid;
        this.sourceId = sourceId;
        this.limit = limit;
        this.listUrl = listUrl;
        this.devicesUrl = devicesUrl;
        this.groupMap = groupMap;
        this.policyMap = policyMap;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.queryListOfIds = (uri) => this.client.get(uri)
            .then((listResult) => {
            var _a, _b;
            const listOfIds = listResult.data.resources;
            if (listOfIds.length > 0) {
                if ((_b = (_a = listResult.data.meta) === null || _a === void 0 ? void 0 : _a.pagination) === null || _b === void 0 ? void 0 : _b.offset) {
                    this.nextUri = `${this.listUrl}&offset=${listResult.data.meta.pagination.offset}`;
                }
                const ids = `ids=${_.join(listOfIds, '&ids=')}`;
                return `${this.devicesUrl}?${ids}`;
            }
            this.nextUri = undefined;
            return false;
        });
        this.queryDevices = (devicesUrlWithIds) => this.client.get(devicesUrlWithIds)
            .then((deviceResult) => deviceResult.data.resources);
        this.processDevices = async (devices, resolve, reject) => {
            try {
                if (devices) {
                    await this.processGroups(devices);
                    await this.processPolicies(devices);
                }
                resolve(devices);
            }
            catch (ex) {
                this.logger.error(`Failed to process devices for tenant ${this.tenantUid} and sourceId ${this.sourceId} where error="${ex}"`);
                reject(ex);
            }
        };
        this.processGroups = async (devices) => {
            const groupSet = new Set();
            for (const device of devices) {
                if (device.groups === undefined) {
                    continue;
                }
                for (const groupId of device.groups) {
                    if (!this.groupMap.has(groupId)) {
                        groupSet.add(groupId);
                    }
                }
            }
            if (groupSet.size === 0) {
                return;
            }
            const groups = await this.groupServices.getGroups(this.sourceId);
            for (const group of groups) {
                this.groupMap.set(group.id, group);
            }
            const unsavedGroupIds = [];
            for (const groupId of groupSet) {
                if (!this.groupMap.has(groupId)) {
                    unsavedGroupIds.push(groupId);
                }
            }
            const queryPromises = [];
            const queryUrl = CrowdStrikeFetcher.queryGroupsUrl;
            let queryUrlParams = new URLSearchParams();
            for (let i = 0; i < unsavedGroupIds.length; i += 1) {
                queryUrlParams.append('ids', unsavedGroupIds[i]);
                if (i === unsavedGroupIds.length - 1 || (i + 1) % this.limit === 0) {
                    queryPromises.push(this.client.get(`${queryUrl}?${queryUrlParams.toString()}`));
                    queryUrlParams = new URLSearchParams();
                }
            }
            if (queryPromises.length > 0) {
                let groupResults = [];
                try {
                    groupResults = await Promise.all(queryPromises);
                }
                catch (e) {
                    this.logger.error(`Failed to query groups for tenant ${this.tenantUid} and sourceId ${this.sourceId} where error=${e}`);
                }
                const groupUpsertPromises = [];
                for (const result of groupResults) {
                    for (const group of result.data.resources) {
                        const newGroup = {
                            id: group.id,
                            name: group.name,
                            description: group.description,
                            source: CommonTypes_1.Source.CROWDSTRIKE,
                            sourceId: this.sourceId
                        };
                        this.groupMap.set(newGroup.id, newGroup);
                        groupUpsertPromises.push(this.groupServices.upsertGroup(newGroup));
                    }
                }
                await Promise.all(groupUpsertPromises);
            }
        };
        this.processPolicies = async (devices) => {
            var _a;
            const policySetMap = new Map();
            for (const device of devices) {
                for (const policy of device.policies || []) {
                    if (!this.policyMap.has(policy.policy_id)) {
                        policySetMap.set(policy.policy_id, { policy_id: policy.policy_id, policy_type: policy.policy_type });
                    }
                }
                if (device.device_policies) {
                    const policyTypesOnDevice = Object.getOwnPropertyNames(device.device_policies);
                    for (const policyType of policyTypesOnDevice) {
                        const policy = device.device_policies[policyType];
                        if (!this.policyMap.has(policy.policy_id)) {
                            policySetMap.set(policy.policy_id, { policy_id: policy.policy_id, policy_type: policy.policy_type });
                        }
                    }
                }
            }
            if (policySetMap.size === 0) {
                return;
            }
            const policies = await this.policyServices.getPolicies(this.sourceId);
            for (const policy of policies) {
                this.policyMap.set(policy.id, policy);
            }
            const unsavedPolicies = [];
            for (const policy of policySetMap.values()) {
                if (!this.policyMap.has(policy.policy_id)) {
                    unsavedPolicies.push(policy);
                }
            }
            unsavedPolicies.sort((a, b) => a.policy_type.localeCompare(b.policy_type));
            const queryPromises = [];
            const queryPromiseTypes = [];
            let queryUrl;
            let queryUrlParams = new URLSearchParams();
            let queryUrlParamsCount = 0;
            for (let i = 0; i < unsavedPolicies.length; i += 1) {
                if (!queryUrl) {
                    queryUrl = this.getPolicyQueryUrlFromPolicyType(unsavedPolicies[i].policy_type);
                    if (!queryUrl) {
                        continue;
                    }
                }
                queryUrlParams.append('ids', unsavedPolicies[i].policy_id);
                queryUrlParamsCount += 1;
                if (i === unsavedPolicies.length - 1 || queryUrlParamsCount >= this.limit || unsavedPolicies[i].policy_type !== unsavedPolicies[i + 1].policy_type) {
                    queryPromises.push(this.client.get(`${queryUrl}?${queryUrlParams.toString()}`));
                    queryPromiseTypes.push(unsavedPolicies[i].policy_type);
                    queryUrl = undefined;
                    queryUrlParams = new URLSearchParams();
                    queryUrlParamsCount = 0;
                }
            }
            if (queryPromises.length > 0) {
                const policyResults = [];
                const policyErrors = [];
                await Promise.allSettled(queryPromises)
                    .then(results => results.map((result, index) => ((result.status === 'fulfilled') ? policyResults.push(result.value) : policyErrors.push({ type: queryPromiseTypes[index], error: result.reason }))));
                if (policyErrors.length > 0) {
                    const failedTypes = _.map(policyErrors, (policy) => policy.type);
                    this.logger.error(`Failed to query policy types [${failedTypes.join(', ')}] for tenant ${this.tenantUid} and sourceId ${this.sourceId} where errors=${JSON.stringify(policyErrors)}`);
                }
                const policyUpsertPromises = [];
                for (const result of policyResults) {
                    for (const policy of result.data.resources) {
                        const policyType = (_a = policySetMap.get(policy.id)) === null || _a === void 0 ? void 0 : _a.policy_type;
                        const newPolicy = {
                            id: policy.id,
                            name: policy.name,
                            description: policy.description,
                            type: policyType,
                            source: CommonTypes_1.Source.CROWDSTRIKE,
                            sourceId: this.sourceId
                        };
                        this.policyMap.set(newPolicy.id, newPolicy);
                        policyUpsertPromises.push(await this.policyServices.upsertPolicy(newPolicy));
                    }
                }
                await Promise.all(policyUpsertPromises);
            }
        };
        this.shouldAbortRetry = (err) => {
            var _a, _b, _c;
            if (err.response && (err.response.status === 400 || err.response.status === 401 || err.response.status === 403 || err.response.status === 404)) {
                if (((_b = (_a = err.response.data) === null || _a === void 0 ? void 0 : _a.errors) === null || _b === void 0 ? void 0 : _b.length) > 0 && err.response.data.errors[0].message && err.response.data.errors[0].code) {
                    err.message = `${err.response.data.errors[0].message} (${err.response.data.errors[0].code}). `;
                }
                else {
                    err.message = `${err.response.statusText} (${err.response.status}). `;
                }
                err.message += 'Please verify the CrowdStrike module configuration';
                this.logger.error(`CrowdStrike query cannot be resolved (aborting retry) because status=${err.response.status}, statusText=${err.response.statusText}, url=${(_c = err.config) === null || _c === void 0 ? void 0 : _c.baseURL}, and data=${JSON.stringify(err.response.data)}`);
                return true;
            }
            return false;
        };
        this.groupServices = new GroupServices_1.GroupServices(this.tenantUid);
        this.policyServices = new PolicyServices_1.PolicyServices(this.tenantUid);
    }
    async fetchNextPage(uri, retryUtil) {
        return new Promise((resolve, reject) => {
            retryUtil.executeWithRetry(() => this.queryListOfIds(uri), (err) => this.shouldAbortRetry(err), (err) => this.handleFailure(err, reject)).then((devicesUrlWithIds) => {
                if (devicesUrlWithIds) {
                    retryUtil.executeWithRetry(() => this.queryDevices(devicesUrlWithIds), (err) => this.shouldAbortRetry(err), (err) => this.handleFailure(err, reject)).then(async (devices) => {
                        await this.processDevices(devices, resolve, reject);
                    });
                }
                else {
                    resolve([]);
                }
            });
        });
    }
    getPolicyQueryUrlFromPolicyType(policyType) {
        switch (policyType) {
            case CrowdStrikePolicyTypes.DEVICE_CONTROL:
                return CrowdStrikeFetcher.queryPolicyDeviceControl;
            case CrowdStrikePolicyTypes.FIREWALL:
                return CrowdStrikeFetcher.queryPolicyFirewall;
            case CrowdStrikePolicyTypes.PREVENTION:
                return CrowdStrikeFetcher.queryPolicyPrevention;
            case CrowdStrikePolicyTypes.REMOTE_RESPONSE:
                return CrowdStrikeFetcher.queryPolicyRemoteResponse;
            case CrowdStrikePolicyTypes.SENSOR_UPDATE:
                return CrowdStrikeFetcher.queryPolicySensorUpdate;
            default:
                this.logger.info(`No query available for CrowdStrike Policy Type: ${policyType}`);
                return undefined;
        }
    }
    handleFailure(err, reject) {
        this.logger.error(`CrowdStrike query failed all retries where error message=${err.message}`);
        if (err.lastError && err.lastError.response) {
            this.logger.error(`lastError status=${err.lastError.response.status}, statusText=${err.lastError.response.statusText}, url=${err.lastError.config.baseURL}, and data=${JSON.stringify(err.lastError.response.data)}`);
        }
        reject(err);
    }
    provideNextUri() {
        return this.nextUri;
    }
}
exports.CrowdStrikeFetcher = CrowdStrikeFetcher;
CrowdStrikeFetcher.queryGroupsUrl = 'devices/entities/host-groups/v1';
CrowdStrikeFetcher.queryPolicyDeviceControl = 'policy/entities/device-control/v1';
CrowdStrikeFetcher.queryPolicyFirewall = 'policy/entities/firewall/v1';
CrowdStrikeFetcher.queryPolicyPrevention = 'policy/entities/prevention/v1';
CrowdStrikeFetcher.queryPolicyRemoteResponse = 'policy/entities/response/v1';
CrowdStrikeFetcher.queryPolicySensorUpdate = 'policy/entities/sensor-update/v1';
class CrowdStrikeCollectorServices extends Services_1.BaseCollectorService {
    constructor(baseUrl, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.baseUrl = baseUrl;
        this.functionName = functionName;
    }
    async getDevices(timeBasedAsyncLambdaInvoker, listUrl, devicesUrl, limit, sort) {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.CROWDSTRIKE, this.sourceId);
        }
        const params = {
            limit: (limit && limit <= CrowdStrikeCollectorServices.LIMIT ? limit : CrowdStrikeCollectorServices.LIMIT),
            sort: sort || 'hostname.asc'
        };
        let listUrlWithParams = listUrl || '';
        if (!listUrl) {
            listUrlWithParams = `${CrowdStrikeCollectorServices.defaultListUrl}?${query_string_1.default.stringify(params)}`;
        }
        else if (listUrl.indexOf('?') === -1) {
            listUrlWithParams = `${listUrl}?${query_string_1.default.stringify(params)}`;
        }
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.CROWDSTRIKE));
        const customPageFetcher = new CrowdStrikeFetcher(this.client, this.tenantUid, this.sourceId, params.limit, listUrlWithParams, devicesUrl || CrowdStrikeCollectorServices.defaultDevicesUrl);
        return new CrowdStrikeCollection_1.CrowdStrikeCollection(customPageFetcher, listUrlWithParams, timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.CrowdStrikeCollectorServices = CrowdStrikeCollectorServices;
CrowdStrikeCollectorServices.LIMIT = 100;
CrowdStrikeCollectorServices.defaultListUrl = 'devices/queries/devices-scroll/v1';
CrowdStrikeCollectorServices.defaultDevicesUrl = 'devices/entities/devices/v2';
