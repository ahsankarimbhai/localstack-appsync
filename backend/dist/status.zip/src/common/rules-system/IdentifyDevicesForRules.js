"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdentifyDevicesForRules = void 0;
const bluebird_1 = require("bluebird");
const RuleService_1 = require("../../services/common/RuleService");
const ElasticsearchServices_1 = require("../ElasticsearchServices");
const ElasticsearchFactory_1 = require("../ElasticsearchFactory");
const LambdaLogger_1 = require("../LambdaLogger");
const lodash_1 = __importDefault(require("lodash"));
const Common_1 = require("./Common");
const TimeBasedAsyncLambdaInvoker_1 = require("../TimeBasedAsyncLambdaInvoker");
const KinesisHelper_1 = require("../kinesis/KinesisHelper");
const TimestreamWriteServices_1 = require("../TimestreamWriteServices");
const KinesisBatchServices_1 = require("../kinesis/KinesisBatchServices");
const fields = ['postureEndpointId'];
class IdentifyDevicesForRules {
    constructor(context) {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.gRuleService = new RuleService_1.GlobalRuleService();
        this.concurrency = process.env.RULES_EVENTS_HANDLING_CONCURRENCY ? +process.env.RULES_EVENTS_HANDLING_CONCURRENCY : 1;
        this.kinesisBatchServices = new KinesisBatchServices_1.KinesisBatchServices(KinesisHelper_1.RULES_EXECUTION, KinesisHelper_1.MAX_BATCH_SIZE);
        this.rulesMetrics = new Common_1.RulesMetrics();
        this.timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
    }
    async identifyForFilterEvent(event) {
        const metrics = [];
        const tenantId = event.tenantId;
        await this.validateFilterEvent(event.devicesModified, event.devicesSpecifierIndirect);
        metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_UPDATED_BY_FILTER_RECEIVED));
        const esService = new ElasticsearchServices_1.ElasticsearchServices(tenantId, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        const queryParsed = JSON.parse(event.devicesModified[0].devicesSpecifier);
        let shouldStopProcessing = false;
        let scrollId;
        const now = Date.now();
        do {
            const results = await esService.getSpecificFieldsWithScrollWithBody({ query: queryParsed }, fields, scrollId);
            scrollId = results.scrollId;
            shouldStopProcessing = lodash_1.default.isEmpty(results.hits);
            if (!shouldStopProcessing) {
                await this.addEventToKinesisRecords(results.hits, Common_1.EventType.UPDATED, event.timeStamp, tenantId, Common_1.NO_RULE_ID);
                await this.kinesisBatchServices.commit();
            }
        } while (!shouldStopProcessing);
        metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_IDENTIFICATION_DURATION, Date.now() - now));
        await (0, ElasticsearchFactory_1.closeElasticSearchClient)();
        this.rulesMetrics.addRecordMetrics(metrics, event.tenantId);
        await this.rulesMetrics.reportCurrentMetrics();
        this.logger.info(`Finished identify devices that belongs to tenant: ${tenantId}, for rules by filter`);
    }
    async identifyForRuleEvent(event) {
        this.logger.debug('Start identify devises for rules that was modified');
        let rulesProcessingMetadata;
        if (event.processingMeta) {
            rulesProcessingMetadata = event.rulesProcessingMetadata;
        }
        else {
            rulesProcessingMetadata = await this.fetchProcessingMeta();
        }
        const notProcessedData = new Map(JSON.parse(JSON.stringify([...rulesProcessingMetadata])));
        const now = Date.now();
        await bluebird_1.Promise.map(Array.from(rulesProcessingMetadata), async ([ruleId, ruleProcessingMeta]) => {
            try {
                const tenantId = ruleProcessingMeta[0].tenantId;
                for (const ruleMeta of ruleProcessingMeta) {
                    const stoppedByTime = await this.fetchAndProcessDevices(ruleMeta);
                    if (!stoppedByTime) {
                        await this.rulePostProcessing(ruleMeta, notProcessedData);
                    }
                }
                if (lodash_1.default.isEmpty(notProcessedData.get(ruleId))) {
                    await this.markRuleAsApplied(tenantId, ruleId);
                }
            }
            catch (e) {
                this.logger.error(`Failed to process ${JSON.stringify(ruleProcessingMeta)}, error: ${JSON.stringify(e.message)}`);
            }
        }, { concurrency: this.concurrency });
        this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_IDENTIFICATION_DURATION, Date.now() - now)], 'global');
        if (!lodash_1.default.isEmpty(notProcessedData)) {
            this.logger.info(`Ttl of function is going to end => will be restarted with state: ${JSON.stringify(notProcessedData)}`);
            await this.timeBasedAsyncLambdaInvoker.invokeLambda({ rulesProcessingMetadata: notProcessedData });
        }
        await (0, ElasticsearchFactory_1.closeElasticSearchClient)();
        await this.rulesMetrics.reportCurrentMetrics();
        this.logger.debug('Finished matching devices for rules.');
    }
    async validateFilterEvent(devicesModified, devicesSpecifierIndirect) {
        if (!devicesSpecifierIndirect) {
            throw new Error('Not indirect notification');
        }
        if (lodash_1.default.isEmpty(devicesModified) || devicesModified.length !== 1) {
            throw new Error('Should be only one device modified');
        }
    }
    async rulePostProcessing(ruleMeta, notProcessedData) {
        const notProcessedRuleMetadata = notProcessedData.get(ruleMeta.ruleId);
        if (notProcessedRuleMetadata) {
            const indexToDelete = notProcessedRuleMetadata.findIndex(meta => meta.ruleId === ruleMeta.ruleId && meta.eventType === ruleMeta.eventType);
            if (indexToDelete !== -1) {
                notProcessedRuleMetadata.splice(indexToDelete, 1);
            }
        }
        if (lodash_1.default.isEmpty(notProcessedData.get(ruleMeta.ruleId))) {
            notProcessedData.delete(ruleMeta.ruleId);
            await new RuleService_1.RuleService(ruleMeta.tenantId).setRuleProcessing(ruleMeta.ruleId, false);
        }
    }
    async fetchProcessingMeta() {
        const rulesMap = this.gRuleService.groupRulesByTenant(await this.gRuleService.detectRulesToApply());
        const rulesProcessingMetadata = new Map();
        if (lodash_1.default.isEmpty(rulesMap)) {
            this.logger.debug('There is no logs to process');
            return rulesProcessingMetadata;
        }
        this.logger.debug(`Found ${JSON.stringify(rulesMap)} rules to process, and FF is turned on for them`);
        for (const [tenantId, rulesPerTenant] of rulesMap) {
            const metricCounts = { create: 0, update: 0, delete: 0, time: Infinity };
            const timestamp = Date.now();
            const esService = new ElasticsearchServices_1.ElasticsearchServices(tenantId, (0, ElasticsearchFactory_1.getElasticSearchClient)());
            for (const rule of rulesPerTenant) {
                switch (rule.ruleManagementAction) {
                    case RuleService_1.RuleManagementAction.ENABLE:
                    case RuleService_1.RuleManagementAction.CREATE:
                        rulesProcessingMetadata.set(rule.ruleId, [{
                                tenantId: rule.tenantId,
                                ruleId: rule.ruleId,
                                query: await esService.buildSearchQuery(rule.matchingCondition),
                                eventType: Common_1.EventType.APPLY,
                                timestamp
                            }]);
                        metricCounts.create += 1;
                        break;
                    case RuleService_1.RuleManagementAction.UPDATE:
                        rulesProcessingMetadata.set(rule.ruleId, [{
                                tenantId: rule.tenantId,
                                ruleId: rule.ruleId,
                                query: esService.buildRulesContainsQuery(rule.ruleId),
                                eventType: Common_1.EventType.UPDATED,
                                timestamp
                            }, {
                                tenantId: rule.tenantId,
                                ruleId: rule.ruleId,
                                query: await esService.buildSearchQuery(rule.matchingCondition),
                                eventType: Common_1.EventType.UPDATED,
                                timestamp
                            }]);
                        metricCounts.update += 1;
                        break;
                    case RuleService_1.RuleManagementAction.DISABLE:
                    case RuleService_1.RuleManagementAction.DELETE:
                        rulesProcessingMetadata.set(rule.ruleId, [{
                                tenantId: rule.tenantId,
                                ruleId: rule.ruleId,
                                query: esService.buildRulesContainsQuery(rule.ruleId),
                                eventType: Common_1.EventType.UPDATED,
                                timestamp
                            }]);
                        metricCounts.delete += 1;
                        break;
                    default:
                        this.logger.error(`Invalid rule, ruleManagement is incorrect, ${JSON.stringify(rule)}`);
                }
                metricCounts.time = metricCounts.time > rule.lastModifyTime ? rule.lastModifyTime : metricCounts.time;
            }
            this.rulesMetrics.addRecordMetrics([metricCounts.create ? new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_CREATED, metricCounts.create) : null,
                metricCounts.update ? new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_UPDATED, metricCounts.update) : null,
                metricCounts.delete ? new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DELETED, metricCounts.delete) : null,
                new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_CHANGES_EFFECT_DURATION, timestamp - metricCounts.time)].filter((item) => item), tenantId);
        }
        return rulesProcessingMetadata;
    }
    async fetchAndProcessDevices(ruleMetadata) {
        const esService = new ElasticsearchServices_1.ElasticsearchServices(ruleMetadata.tenantId, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        let shouldStop = false;
        let stoppedByTime = false;
        if (!this.timeBasedAsyncLambdaInvoker.isItTimeToStop()) {
            do {
                const results = await esService.getSpecificFieldsWithScroll(ruleMetadata.query, fields, ruleMetadata.scrollId);
                ruleMetadata.scrollId = results.scrollId;
                if (!lodash_1.default.isEmpty(results.hits)) {
                    await this.addRuleMetadataEventToKinesisRecords(ruleMetadata, results.hits);
                    await this.kinesisBatchServices.commit();
                }
                stoppedByTime = this.timeBasedAsyncLambdaInvoker.isItTimeToStop();
                shouldStop = stoppedByTime || lodash_1.default.isEmpty(results.hits);
            } while (!shouldStop);
        }
        return stoppedByTime;
    }
    async markRuleAsApplied(tenantID, ruleId) {
        const ruleService = new RuleService_1.RuleService(tenantID);
        await ruleService.setRuleApplied(ruleId, false);
    }
    doThemMetricz(devices, eventType, tenantId, ruleId) {
        let metricName;
        if (eventType === Common_1.EventType.APPLY) {
            metricName = TimestreamWriteServices_1.MetricName.RULES_DEVICES_IDENTIFIED_APPLY_SUBMITTED;
        }
        else if (eventType === Common_1.EventType.UPDATED) {
            if (ruleId === Common_1.NO_RULE_ID) {
                metricName = TimestreamWriteServices_1.MetricName.RULES_DEVICES_IDENTIFIED_UPDATED_BY_FILTER_SUBMITTED;
            }
            else {
                metricName = TimestreamWriteServices_1.MetricName.RULES_DEVICES_IDENTIFIED_UPDATE_SUBMITTED;
            }
        }
        if (metricName) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(metricName, devices.length)], tenantId);
        }
    }
    async addRuleMetadataEventToKinesisRecords(ruleMetadata, devices) {
        await this.addEventToKinesisRecords(devices, ruleMetadata.eventType, ruleMetadata.timestamp, ruleMetadata.tenantId, ruleMetadata.ruleId);
    }
    async addEventToKinesisRecords(devices, eventType, timestamp, tenantId, ruleId) {
        this.doThemMetricz(devices, eventType, tenantId, ruleId);
        for (const device of devices) {
            const event = {
                Data: JSON.stringify([device._id, eventType, timestamp, tenantId, eventType === Common_1.EventType.APPLY ? ruleId : Common_1.NO_RULE_ID]),
                PartitionKey: 'pk0'
            };
            await this.kinesisBatchServices.addRecord(event);
        }
    }
}
exports.IdentifyDevicesForRules = IdentifyDevicesForRules;
