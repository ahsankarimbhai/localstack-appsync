"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailService = exports.Email = exports.AppUserService = exports.AppUser = exports.UserService = exports.User = exports.ExternalReferenceService = exports.ExternalReference = exports.BrowserService = exports.Browser = exports.CookieService = exports.Cookie = exports.ComputerSIDService = exports.HardwareIdService = exports.ComputerSID = exports.HardwareId = exports.HostnameService = exports.Hostname = exports.PhoneNumberService = exports.PhoneNumber = exports.ImeiService = exports.Imei = exports.SerialNumberService = exports.SerialNumber = exports.MacAddressService = exports.MacAddress = exports.ExternalIpAddressService = exports.ExternalIpAddress = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
const _ = __importStar(require("lodash"));
const util = __importStar(require("../common/Util"));
class ExternalIpAddress extends BaseGraphElement_1.SimpleVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS;
    }
}
exports.ExternalIpAddress = ExternalIpAddress;
class ExternalIpAddressService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new ExternalIpAddress(this.partitionKey);
    }
}
exports.ExternalIpAddressService = ExternalIpAddressService;
class MacAddress extends BaseGraphElement_1.SimpleNormalizedVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.MAC_ADDRESS;
    }
    normalizeValue(value) {
        return _.replace(super.normalizeValue(value), /-/g, ':');
    }
}
exports.MacAddress = MacAddress;
MacAddress.MAC_EXCLUSION_LIST = [
    '00:05:9A:3C:78:00',
    '00:05:9A:3C:7A:00',
    '00:05:9A:3C:79:00',
    '00:FF:08:30:26:82',
    '54:25:6D:74:E1:0F',
    '00:FF:68:7D:FD:81',
    '00:FF:68:BD:D3:81',
    '00:53:45:00:00:00',
    '00:50:56:C0:00:01',
    '00:50:56:C0:00:02',
    '00:50:56:C0:00:03',
    '00:50:56:C0:00:04',
    '00:50:56:C0:00:05',
    '00:50:56:C0:00:06',
    '00:50:56:C0:00:07',
    '00:50:56:C0:00:08',
    '00:50:56:C0:00:09',
    '00:01:23:45:67:89',
    '00:10:32:54:76:98',
    '00:1C:42:00:00:00',
    '00:1C:42:00:00:01',
    '00:1C:42:00:00:02',
    '00:1C:42:00:00:03',
    '00:1C:42:00:00:04',
    '00:1C:42:00:00:05',
    '00:1C:42:00:00:06',
    '00:1C:42:00:00:07',
    '00:1C:42:00:00:08',
    '00:1C:42:00:00:09',
    '7A:79:05:A8:B9:90',
    '00:00:00:00:00:00',
    '00:A0:D5:FF:FF:85',
    '00:09:0F:FE:00:01',
    '44:45:53:54:42:00',
    '00:FF:08:30:56:89',
    '00:53:45:00:00:00',
    '00:A0:C6:00:00:00',
    '00:80:98:EB:96:56',
    '00:26:37:BD:39:42',
    '00:00:00:00:00:01'
];
class MacAddressService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new MacAddress(this.partitionKey);
    }
    skipUpdate(object) {
        const macAddress = object.getProperty(CommonTypes_1.VertexBasicProperty.EXT_ID);
        return _.includes(MacAddress.MAC_EXCLUSION_LIST, macAddress.value.toUpperCase());
    }
}
exports.MacAddressService = MacAddressService;
class SerialNumber extends BaseGraphElement_1.SimpleNormalizedVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.SERIAL_NUMBER;
    }
}
exports.SerialNumber = SerialNumber;
SerialNumber.SERIAL_NO_EXCLUSION_LIST = [
    '-1',
    '0'
];
class SerialNumberService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new SerialNumber(this.partitionKey);
    }
    skipUpdate(object) {
        var _a;
        const serial = object.getProperty(CommonTypes_1.VertexBasicProperty.EXT_ID);
        return _.includes(SerialNumber.SERIAL_NO_EXCLUSION_LIST, (_a = serial.value) === null || _a === void 0 ? void 0 : _a.trim());
    }
}
exports.SerialNumberService = SerialNumberService;
class Imei extends BaseGraphElement_1.SimpleNormalizedVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.IMEI;
    }
}
exports.Imei = Imei;
class ImeiService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new Imei(this.partitionKey);
    }
}
exports.ImeiService = ImeiService;
class PhoneNumber extends BaseGraphElement_1.SimpleVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.PHONE_NUMBER;
    }
}
exports.PhoneNumber = PhoneNumber;
class PhoneNumberService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new PhoneNumber(this.partitionKey);
    }
}
exports.PhoneNumberService = PhoneNumberService;
class Hostname extends BaseGraphElement_1.SimpleNormalizedVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.HOSTNAME;
    }
    normalizeValue(value) {
        return super.normalizeValue(util.processHostNameToNotBeFqdn(value));
    }
}
exports.Hostname = Hostname;
class HostnameService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new Hostname(this.partitionKey);
    }
}
exports.HostnameService = HostnameService;
class HardwareId extends BaseGraphElement_1.SimpleNormalizedVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.HARDWARE_ID;
    }
}
exports.HardwareId = HardwareId;
class ComputerSID extends BaseGraphElement_1.SimpleNormalizedVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.COMPUTER_SID;
    }
}
exports.ComputerSID = ComputerSID;
class HardwareIdService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new HardwareId(this.partitionKey);
    }
}
exports.HardwareIdService = HardwareIdService;
class ComputerSIDService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new ComputerSID(this.partitionKey);
    }
}
exports.ComputerSIDService = ComputerSIDService;
class Cookie extends BaseGraphElement_1.SimpleVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.COOKIE;
    }
}
exports.Cookie = Cookie;
class CookieService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new Cookie(this.partitionKey);
    }
}
exports.CookieService = CookieService;
class Browser extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.BROWSER;
    }
    async initProperties(browser) {
        this.setProperty(Browser.BROWSER_FAMILY, browser.browserFamily);
        this.setProperty(Browser.BROWSER_VERSION, browser.browserVersion);
        this.setProperty(Browser.FLASH_VERSION, browser.flashVersion);
        this.setProperty(Browser.JAVA_VERSION, browser.javaVersion);
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(browser, ['lastUsed'])));
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.Browser = Browser;
Browser.BROWSER_FAMILY = 'browserFamily';
Browser.BROWSER_VERSION = 'browserVersion';
Browser.FLASH_VERSION = 'flashVersion';
Browser.JAVA_VERSION = 'javaVersion';
class BrowserService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new Browser(this.partitionKey);
    }
}
exports.BrowserService = BrowserService;
class ExternalReference extends BaseGraphElement_1.SimpleVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.EXTERNAL_REFERENCE;
    }
}
exports.ExternalReference = ExternalReference;
class ExternalReferenceService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new ExternalReference(this.partitionKey);
    }
}
exports.ExternalReferenceService = ExternalReferenceService;
class User extends BaseGraphElement_1.SimpleVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.USER;
    }
    async initProperties(user) {
        this.setProperty('position', user.position);
    }
}
exports.User = User;
class UserService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new User(this.partitionKey);
    }
}
exports.UserService = UserService;
class AppUser extends BaseGraphElement_1.SimpleVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.APP_USER;
    }
}
exports.AppUser = AppUser;
class AppUserService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new AppUser(this.partitionKey);
    }
}
exports.AppUserService = AppUserService;
class Email extends BaseGraphElement_1.SimpleVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.EMAIL;
    }
    normalizeValue(value) {
        return _.replace(super.normalizeValue(value), /\+.*@/g, '@');
    }
}
exports.Email = Email;
class EmailService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new Email(this.partitionKey);
    }
}
exports.EmailService = EmailService;
