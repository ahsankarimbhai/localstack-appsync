"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDynamoDBService = void 0;
const DynamoDBServices_1 = require("./DynamoDBServices");
let dynamodbService;
function getDynamoDBService() {
    if (!dynamodbService) {
        dynamodbService = new DynamoDBServices_1.DynamoDBServices();
    }
    return dynamodbService;
}
exports.getDynamoDBService = getDynamoDBService;
