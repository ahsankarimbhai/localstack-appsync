"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrowdStrikeDeviceStateModelService = exports.CrowdStrikeDeviceStateModel = exports.CrowdStrikeDeviceModelService = exports.CrowdStrikeDeviceModel = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphService_1 = require("./BaseGraphService");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphElement_1 = require("./BaseGraphElement");
const BaseDeviceStateModel_1 = require("./BaseDeviceStateModel");
class CrowdStrikeDeviceModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.CROWD_STRIKE_DEVICE;
    }
    async initProperties(crowdStrikeDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, crowdStrikeDevice.device_id);
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, crowdStrikeDevice.hostname);
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, crowdStrikeDevice.last_seen);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.CrowdStrikeDeviceModel = CrowdStrikeDeviceModel;
class CrowdStrikeDeviceModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new CrowdStrikeDeviceModel(this.partitionKey);
    }
}
exports.CrowdStrikeDeviceModelService = CrowdStrikeDeviceModelService;
class CrowdStrikeDeviceStateModel extends BaseDeviceStateModel_1.BaseDeviceStateModel {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.CROWD_STRIKE_DEVICE_STATE;
    }
    async initProperties(crowdStrikeDevice) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(crowdStrikeDevice, ['last_seen'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, crowdStrikeDevice.hostname);
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_TYPE, (0, CommonTypes_1.getOsType)(crowdStrikeDevice.os_version));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_VERSION, (0, CommonTypes_1.getOsVersion)(crowdStrikeDevice.os_version));
        this.setProperty(CommonTypes_1.VertexBasicProperty.OS_BUILD, crowdStrikeDevice.os_build);
        this.setProperty(CrowdStrikeDeviceStateModel.CONNECTION_IP, crowdStrikeDevice.connection_ip);
        this.setProperty(CrowdStrikeDeviceStateModel.CONNECTION_MAC_ADDRESS, crowdStrikeDevice.connection_mac_address);
        this.setProperty(CrowdStrikeDeviceStateModel.AGENT_VERSION, crowdStrikeDevice.agent_version);
        this.setProperty(CrowdStrikeDeviceStateModel.MAJOR_VERSION, crowdStrikeDevice.major_version);
        this.setProperty(CrowdStrikeDeviceStateModel.MINOR_VERSION, crowdStrikeDevice.minor_version);
        this.setProperty(CrowdStrikeDeviceStateModel.PLATFORM_ID, crowdStrikeDevice.platform_id);
        this.setProperty(CrowdStrikeDeviceStateModel.PLATFORM_NAME, crowdStrikeDevice.platform_name);
        this.setProperty(CrowdStrikeDeviceStateModel.CREATED_AT, this.convertToMilliseconds(crowdStrikeDevice.first_seen));
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, this.convertToMilliseconds(crowdStrikeDevice.last_seen));
        this.setInternalIpAddresses(crowdStrikeDevice.local_ip);
        this.setPolicyIds(crowdStrikeDevice);
        if (crowdStrikeDevice.groups && crowdStrikeDevice.groups.length > 0) {
            this.setProperty(CrowdStrikeDeviceStateModel.GROUP_IDS, crowdStrikeDevice.groups);
        }
        if (crowdStrikeDevice.tags && crowdStrikeDevice.tags.length > 0) {
            this.setProperty(CrowdStrikeDeviceStateModel.TAGS, crowdStrikeDevice.tags);
        }
    }
    setPolicyIds(crowdStrikeDevice) {
        const policyIds = [];
        for (const policy of (crowdStrikeDevice.policies || [])) {
            policyIds.push(policy.policy_id);
        }
        if (crowdStrikeDevice.device_policies) {
            const policyTypesOnDevice = Object.getOwnPropertyNames(crowdStrikeDevice.device_policies);
            for (const policyType of policyTypesOnDevice) {
                const policy = crowdStrikeDevice.device_policies[policyType];
                policyIds.push(policy.policy_id);
            }
        }
        if (policyIds.length > 0) {
            this.setProperty(CrowdStrikeDeviceStateModel.POLICY_IDS, policyIds);
        }
    }
    convertToMilliseconds(stringValue) {
        return new Date(stringValue).getTime();
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.CrowdStrikeDeviceStateModel = CrowdStrikeDeviceStateModel;
CrowdStrikeDeviceStateModel.CREATED_AT = 'createdAt';
CrowdStrikeDeviceStateModel.CONNECTION_IP = 'connectionIp';
CrowdStrikeDeviceStateModel.CONNECTION_MAC_ADDRESS = 'connectionMacAddress';
CrowdStrikeDeviceStateModel.AGENT_VERSION = 'agentVersion';
CrowdStrikeDeviceStateModel.MAJOR_VERSION = 'majorVersion';
CrowdStrikeDeviceStateModel.MINOR_VERSION = 'minorVersion';
CrowdStrikeDeviceStateModel.PLATFORM_ID = 'platformId';
CrowdStrikeDeviceStateModel.PLATFORM_NAME = 'platformName';
CrowdStrikeDeviceStateModel.POLICY_IDS = 'policyIds';
CrowdStrikeDeviceStateModel.GROUP_IDS = 'groupIds';
CrowdStrikeDeviceStateModel.TAGS = 'tags';
class CrowdStrikeDeviceStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new CrowdStrikeDeviceStateModel(this.partitionKey);
    }
}
exports.CrowdStrikeDeviceStateModelService = CrowdStrikeDeviceStateModelService;
