"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseGraphEdge = exports.SimpleNormalizedVertex = exports.SimpleVertex = exports.BaseGraphVertex = exports.BaseGraphElement = void 0;
const _ = __importStar(require("lodash"));
const uuid_1 = require("uuid");
const CommonTypes_1 = require("../common/CommonTypes");
const crypto_1 = require("crypto");
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const Util_1 = require("../common/Util");
class BaseGraphElement {
    constructor(partitionKey) {
        this.type = CommonTypes_1.VertexType.UNDEFINED;
        this.properties = [];
        this.secondaryLabels = undefined;
        this.id = (0, uuid_1.v4)();
        this.setProperty(CommonTypes_1.BasicProperty.PARTITION_KEY, partitionKey);
    }
    setProperty(key, value) {
        if (!_.isNil(value) && !_.isNaN(value) && value !== '') {
            const isKey = this.isKey(key);
            this.properties.push({ key, isKey, value: (0, CommonTypes_1.normalize)(value) });
        }
    }
    setPropertyIfNotSet(key, value) {
        if (_.isNil(this.getPropertyValue(key))) {
            this.setProperty(key, value);
        }
    }
    async setPropertyWithCompressedValue(key, value) {
        if (value) {
            this.setProperty(key, {
                compressedValue: await (0, Util_1.stringToGzip)(value)
            });
        }
    }
    addSecondaryLabel(value) {
        if (value) {
            if (!this.secondaryLabels) {
                this.secondaryLabels = [];
            }
            this.secondaryLabels.push(value);
        }
    }
    getProperty(key) {
        return _.find(this.properties, { key });
    }
    getPropertyValueOrThrow(key) {
        const property = this.getProperty(key);
        if (_.isNil(property)) {
            throw new Error(`Property ${key} is missing`);
        }
        return property.value;
    }
    getPropertyValue(key, defaultValue = undefined) {
        const property = this.getProperty(key);
        return property ? property.value : defaultValue;
    }
    static getPropertyValue(vertex, key, defaultValue = undefined) {
        const property = _.find(vertex.properties, { key });
        return property ? property.value : defaultValue;
    }
    isKey(key) {
        return false;
    }
    getId() {
        return this.id;
    }
}
exports.BaseGraphElement = BaseGraphElement;
class BaseGraphVertex extends BaseGraphElement {
    constructor() {
        super(...arguments);
        this.label = this.type;
    }
    getLabel() {
        return this.label && this.label !== CommonTypes_1.VertexType.UNDEFINED ? this.label : this.type;
    }
    setLabel(label) {
        this.label = label;
    }
    getKey() {
        return _.filter(this.properties, { isKey: true });
    }
    isKey(key) {
        return _.includes(this.getKeyProperties(), key);
    }
    preProcessInitVertex(input, partitionKey, sourceId) {
        return Promise.resolve();
    }
    async initVertex(input, source, sourceConfiguration) {
        await this.initProperties(input, source, sourceConfiguration);
        this.updateId();
    }
    calculateHash(model) {
        const data = JSON.stringify(model);
        return (0, crypto_1.createHash)('md5').update(data).digest('hex');
    }
    updateId(vertexId = undefined) {
        const extId = _.get(_.find(this.properties, { key: CommonTypes_1.VertexBasicProperty.EXT_ID }), 'value');
        const partition = _.get(_.find(this.properties, { key: CommonTypes_1.BasicProperty.PARTITION_KEY }), 'value');
        if (extId && partition) {
            this.id = (0, NeptuneServicesFactory_1.getVertexId)(extId, this.getLabel(), partition);
        }
        else if (vertexId) {
            this.id = vertexId;
        }
    }
    equals(that, excludes = []) {
        if (!that) {
            return false;
        }
        const thisProps = _.omitBy(this.properties, p => excludes.includes(p.key));
        const thatProps = _.omitBy(that.properties, p => excludes.includes(p.key));
        return _.isEqual(thisProps, thatProps);
    }
}
exports.BaseGraphVertex = BaseGraphVertex;
class SimpleVertex extends BaseGraphVertex {
    constructor(partitionKey, value) {
        super(partitionKey);
        this.setValue(value);
        this.setLabel(this.type);
    }
    setValue(value) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.normalizeValue(value));
    }
    normalizeValue(value) {
        return value;
    }
    async initProperties(input) {
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.SimpleVertex = SimpleVertex;
class SimpleNormalizedVertex extends SimpleVertex {
    normalizeValue(value) {
        return _.isString(value) ? _.toLower(value) : value;
    }
}
exports.SimpleNormalizedVertex = SimpleNormalizedVertex;
class BaseGraphEdge extends BaseGraphElement {
    constructor(sourceId, targetId, partitionKey, type, edgeProperties) {
        super(partitionKey);
        this.sourceId = sourceId;
        this.targetId = targetId;
        this.type = type;
        this.created = Date.now();
        this.setProperty(CommonTypes_1.EdgeBasicProperty.CREATED, this.created);
        _.each(_.toPairs(edgeProperties), pair => this.setProperty(pair[0], pair[1]));
    }
}
exports.BaseGraphEdge = BaseGraphEdge;
