"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const _ = __importStar(require("lodash"));
const JwtHelper_1 = require("../common/tokenhelper/JwtHelper");
const CommonTypes_1 = require("../common/CommonTypes");
const TenantServices_1 = require("../common/TenantServices");
const Util_1 = require("../common/Util");
const LambdaLogger_1 = require("../common/LambdaLogger");
const AwsSecretsService_1 = require("../common/AwsSecretsService");
const AuthorizerHelper_1 = require("./AuthorizerHelper");
const MemoryCache_1 = require("../common/cache/MemoryCache");
const cacheManager = MemoryCache_1.MemoryCacheManager.getInstance();
const logger = new LambdaLogger_1.LambdaLogger();
const validateApiToken = async (token, resource, callback) => {
    const tokenStruct = _.split(token, Util_1.TOKEN_SEPARATOR);
    if (!tokenStruct || _.size(tokenStruct) !== 3) {
        logger.error('Wrong token structure');
        return callback('Unauthorized');
    }
    const tenantUid = tokenStruct[0];
    const idParts = _.split(tokenStruct[1], Util_1.SOURCE_SEPARATOR);
    const source = idParts[0];
    const sourceId = idParts[1];
    if (!tenantUid) {
        logger.error('Tenant uid is missing in webhook request');
        return callback('Unauthorized');
    }
    if (!source) {
        logger.error(`Source is missing in webhook request ${JSON.stringify(idParts)}`);
        return callback('Unauthorized');
    }
    if (!sourceId) {
        logger.error(`Source id is missing in webhook request ${JSON.stringify(idParts)}`);
        return callback('Unauthorized');
    }
    if ((0, AuthorizerHelper_1.shouldBlockTenantAndSource)(tenantUid, source, sourceId)) {
        const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
        return callback(null, { policyDocument, context: { tenantUid, source: tokenStruct[1] } });
    }
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    try {
        await awsSecretsService.init();
    }
    catch (e) {
        const tenantServices = new TenantServices_1.TenantServices();
        const tenant = await tenantServices.getTenantById(tenantUid);
        if (!tenant) {
            const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
            return callback(null, { policyDocument, context: { tenantUid, source: tokenStruct[1] } });
        }
        logger.error(`Failed to init awsSecretService while validating API token tenantUid=${tenantUid}, source=${source}, sourceId=${sourceId}, error=${e.message}`);
        return callback('Unauthorized');
    }
    let producersWebhookToken;
    try {
        producersWebhookToken = await verifySecretTokenExists(awsSecretsService, tenantUid, (0, Util_1.toSourceString)(source, sourceId), 'webhookToken');
    }
    catch (e) {
        if (e.message === 'Gone') {
            const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
            return callback(null, { policyDocument, context: { tenantUid, source: tokenStruct[1] } });
        }
        return callback(e.message);
    }
    if (producersWebhookToken === tokenStruct[2]) {
        const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.ALLOW, resource);
        return callback(null, { policyDocument, context: { tenantUid, source: tokenStruct[1] } });
    }
    logger.error(`Producers Webhook Token failed to match secret token while validating API token tenantUid=${tenantUid}, source=${source}, sourceId=${sourceId}`);
    return callback('Unauthorized');
};
function extractId(event) {
    return event.headers[JwtHelper_1.AMP_TENANT_UID_HEADER_NAME];
}
async function verifyAmpAuthentication(event, resource, callback) {
    var _a, _b;
    const idParts = _.split(extractId(event), Util_1.SOURCE_SEPARATOR);
    const tenantUid = idParts[0];
    const source = `${idParts[1]}${Util_1.SOURCE_SEPARATOR}${idParts[2]}`;
    if (!tenantUid) {
        logger.error(`missing tenantUid in header ${JwtHelper_1.AMP_TENANT_UID_HEADER_NAME}`);
        return callback('Unauthorized');
    }
    if (!idParts[1] || !idParts[2]) {
        logger.error(`missing source in header ${JwtHelper_1.AMP_TENANT_UID_HEADER_NAME}`);
        return callback('Unauthorized');
    }
    if ((0, AuthorizerHelper_1.shouldBlockTenantAndSource)(tenantUid, idParts[1], idParts[2])) {
        const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
        return callback(null, { policyDocument, context: { tenantUid, source } });
    }
    const fpHeader = event.headers[JwtHelper_1.AMP_FINGERPRINT_HEADER_NAME];
    if (!fpHeader) {
        logger.error(`missing hmac in header ${JwtHelper_1.AMP_FINGERPRINT_HEADER_NAME}`);
        return callback('Unauthorized');
    }
    const authorizationHeader = (_a = event.headers) === null || _a === void 0 ? void 0 : _a.Authorization;
    if (!authorizationHeader) {
        logger.error('missing Authorization header');
        return callback('Unauthorized');
    }
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    try {
        await awsSecretsService.init();
    }
    catch (e) {
        const tenantServices = new TenantServices_1.TenantServices();
        const tenant = await tenantServices.getTenantById(tenantUid);
        if (!tenant) {
            const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
            return callback(null, { policyDocument, context: { tenantUid, source } });
        }
        logger.error(`Failed to init awsSecretService while verifying AMP header tenantUid=${tenantUid}, source=${source}, error=${e.message}`);
        return callback('Unauthorized');
    }
    let webhookAuthToken;
    try {
        webhookAuthToken = await verifySecretTokenExists(awsSecretsService, tenantUid, source, 'webhookAuthToken');
    }
    catch (e) {
        if (e.message === 'Gone') {
            const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
            return callback(null, { policyDocument, context: { tenantUid, source } });
        }
        return callback(e.message);
    }
    if (!(0, JwtHelper_1.verifyWebhookToken)((_b = event.headers) === null || _b === void 0 ? void 0 : _b.Authorization, webhookAuthToken)) {
        logger.error(`authorization failed where tenantUid=${tenantUid}, source=${source}`);
        return callback('Unauthorized');
    }
    const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.ALLOW, resource);
    return callback(null, { policyDocument, context: { tenantUid, source } });
}
async function authorizeBasicAuthentication(event, resource, callback, tokenName) {
    var _a, _b;
    const basicAuthHeader = Buffer.from(_.split((_a = event.headers) === null || _a === void 0 ? void 0 : _a.Authorization, ' ')[1], 'base64').toString('ascii');
    const username = _.split(basicAuthHeader, ':')[0];
    const tokenStruct = _.split(username, Util_1.SOURCE_SEPARATOR);
    if (!tokenStruct || tokenStruct.length < 2) {
        logger.error('wrong tenant structure', JSON.stringify(tokenStruct));
        return callback('Unauthorized');
    }
    const tenantUid = tokenStruct[0];
    const sourceId = tokenStruct[2];
    const source = (0, Util_1.toSourceString)(tokenStruct[1], sourceId);
    if ((0, AuthorizerHelper_1.shouldBlockTenantAndSource)(tenantUid, tokenStruct[1], sourceId)) {
        const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
        return callback(null, { policyDocument, context: { tenantUid, source } });
    }
    const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
    try {
        await awsSecretsService.init();
    }
    catch (e) {
        const tenantServices = new TenantServices_1.TenantServices();
        const tenant = await tenantServices.getTenantById(tenantUid);
        if (!tenant) {
            const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
            return callback(null, { policyDocument, context: { tenantUid, source } });
        }
        logger.error(`invalid tenant uid ${username}, source=${source}, error=${e.message}`);
        return callback('Unauthorized');
    }
    let password;
    try {
        password = await verifySecretTokenExists(awsSecretsService, tenantUid, source, tokenName);
    }
    catch (e) {
        if (e.message === 'Gone') {
            const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.DENY, resource);
            return callback(null, { policyDocument, context: { tenantUid, source } });
        }
        return callback(e.message);
    }
    if (!verifyAuthorization((_b = event.headers) === null || _b === void 0 ? void 0 : _b.Authorization, username, password)) {
        logger.error(`invalid authorization ${username}, tenantUid=${tenantUid}, source=${source}`);
        return callback('Unauthorized');
    }
    const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.ALLOW, resource);
    return callback(null, { policyDocument, context: { tenantUid, source } });
}
async function verifySecretTokenExists(secretService, tenantUid, source, tokenName) {
    const tenantServices = new TenantServices_1.TenantServices();
    if (!await tenantServices.verifyWebhookConfigExistence(tenantUid, source)) {
        logger.info(`Receiving webhook call for tenantUid=${tenantUid}, source=${source} but source was deleted`);
        return Promise.reject(new Error('Gone'));
    }
    const secretToken = await getSecretToken(secretService, source, tokenName, 3);
    if (secretToken) {
        return Promise.resolve(secretToken);
    }
    logger.error(`No secret parameter for tenantUid=${tenantUid}, source=${source}, tokenName=${tokenName}`);
    return Promise.reject(Util_1.UNAUTHORIZED);
}
async function getSecretToken(secretService, source, tokenName, retryAttempts) {
    const secret = await secretService.getSecretWithReloadingOnRetry(source, retryAttempts);
    if (secret) {
        return secret[tokenName];
    }
    return undefined;
}
function verifyAuthorization(authorization, username, password) {
    return authorization === `Basic ${(0, Util_1.basicAuthenticationEncode)(username, password)}`;
}
async function verifyISEAuthentication(event, resource, callback) {
    var _a, _b;
    if (((_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.ise_api_version) !== '3') {
        logger.error(`invalid ise_api_version ${(_b = event.queryStringParameters) === null || _b === void 0 ? void 0 : _b.ise_api_version}`);
        return callback('Unauthorized');
    }
    return authorizeBasicAuthentication(event, resource, callback, 'iseMdmPassword');
}
const handler = async (event, context, callback) => {
    var _a, _b;
    if (context) {
        context.callbackWaitsForEmptyEventLoop = false;
    }
    if (!event.methodArn) {
        logger.error('methodArn is mandatory');
        return callback('Unauthorized');
    }
    if (event.methodArn.includes('ciscoise')) {
        return verifyISEAuthentication(event, event.methodArn, callback);
    }
    if (event.headers[JwtHelper_1.AMP_TENANT_UID_HEADER_NAME]) {
        return verifyAmpAuthentication(event, event.methodArn, callback);
    }
    if (_.startsWith(_.toLower((_a = event.headers) === null || _a === void 0 ? void 0 : _a.Authorization), 'basic')) {
        return authorizeBasicAuthentication(event, event.methodArn, callback, 'webhookSecret');
    }
    const token = (0, JwtHelper_1.extractTokenFromHeader)((_b = event.headers) === null || _b === void 0 ? void 0 : _b.Authorization) || '';
    if ((0, CommonTypes_1.empty)(token)) {
        logger.error(`Token must be specified in authorization header: ${event}`);
        return callback('Unauthorized');
    }
    return validateApiToken(token, event.methodArn, callback);
};
exports.handler = handler;
