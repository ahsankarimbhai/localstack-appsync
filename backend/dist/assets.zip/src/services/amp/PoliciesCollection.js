"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PoliciesCollection = void 0;
const AmpCollection_1 = require("./AmpCollection");
class PoliciesCollection extends AmpCollection_1.AmpCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker, PoliciesCollection.RETRY_CONFIG);
        this.functionState = functionState;
    }
}
exports.PoliciesCollection = PoliciesCollection;
PoliciesCollection.RETRY_CONFIG = {
    retries: 5,
    delay: 30000,
    timeout: 120000,
    backoff: 'NEXT_RETRY_DELAY'
};
