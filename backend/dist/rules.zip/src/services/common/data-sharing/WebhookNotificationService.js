"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookNotificationService = void 0;
const axios_1 = __importDefault(require("axios"));
const LambdaLogger_1 = require("../../../common/LambdaLogger");
const TenantServices_1 = require("../../../common/TenantServices");
const WebhookRegistrationRepo_1 = require("../../../common/dynamoDBRepo/WebhookRegistrationRepo");
const EventBridgeService_1 = require("../../../common/awsclient/EventBridgeService");
const Util_1 = require("../../../common/Util");
const AwsSecretsService_1 = require("../../../common/AwsSecretsService");
const WebhookHelper_1 = require("./WebhookHelper");
const RetryUtil_1 = require("../../../common/RetryUtil");
const WebhookResiliencyHandler_1 = require("./WebhookResiliencyHandler");
const bluebird_1 = require("bluebird");
const lodash_1 = __importDefault(require("lodash"));
class WebhookNotificationService {
    constructor() {
        this.webhookRegistrationRepo = new WebhookRegistrationRepo_1.WebhookRegistrationRepo();
        this.tenantServices = new TenantServices_1.TenantServices();
        this.eventBridgeServices = new EventBridgeService_1.EventBridgeService();
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.webhookNotificationApiClient = axios_1.default.create();
        this.webhookResiliencyHandler = new WebhookResiliencyHandler_1.WebhookResiliencyHandler();
    }
    async sendDeviceEvent(tenantUid, eventType, peIds, webhookId, chunkSize = 50) {
        if (peIds.length === 0) {
            return;
        }
        const webhooks = await this.getWebhooks(tenantUid);
        if (webhooks.length === 0) {
            return;
        }
        const peIdChunks = lodash_1.default.chunk(peIds, chunkSize);
        await bluebird_1.Promise.map(peIdChunks, async (chunk) => {
            const evtReq = {
                EventBusName: this.getEventBusArn(),
                Source: `${process.env.ENV_PREFIX}-ds-webhook-event`,
                DetailType: 'detail',
                Detail: JSON.stringify({
                    targetTask: 'dispatch-webhook-notification',
                    eventBridgeData: {
                        webhookId,
                        tenantUid,
                        eventType,
                        peIds: chunk
                    }
                })
            };
            await this.eventBridgeServices.publish([evtReq]);
        });
    }
    async dispatchToWebhookTarget(tenantUid, eventType, postureEndpoints, webhookId) {
        let webhooks = await this.getWebhooks(tenantUid);
        if (webhookId) {
            webhooks = webhooks.filter(w => w.webhookId === webhookId);
        }
        if (webhooks.length === 0) {
            throw new Error(`failed to fetch webhooks for tenant ${tenantUid}${webhookId ? `, webhook: ${webhookId}` : ''}`);
        }
        const tenant = await this.tenantServices.getTenantById(tenantUid);
        if (!tenant || !tenant.extId) {
            throw new Error(`cannot retrieve organizationId for tenant ${tenantUid}`);
        }
        const secretsService = new AwsSecretsService_1.AwsSecretsService(tenantUid);
        await secretsService.init();
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, {
            retries: 2,
            backoff: 'LINEAR',
            delay: 2000,
            timeout: 100000
        });
        await bluebird_1.Promise.map(webhooks, async (webhook) => {
            const webhookDataList = [];
            for (const endpoint of postureEndpoints) {
                const webhookData = await this.prepareWebhookData(webhook, eventType, JSON.stringify(endpoint));
                if (webhookData) {
                    webhookDataList.push(webhookData);
                }
            }
            if (webhookDataList.length === 0) {
                return;
            }
            const compressedNotification = await this.toCompressedData(webhookDataList, webhook.compressionFormat);
            try {
                this.logger.debug(`post to target url for webhook: ${webhook.webhookId}, tenant: ${tenantUid}, eventType: ${eventType}, peIds: ${webhookDataList.map(d => d.uid).join(', ')}`);
                await retryUtil.executeWithRetry(async () => this.postToTargetUrl(secretsService, webhook, {
                    metadata: {
                        webhookId: webhook.webhookId,
                        notificationType: eventType,
                        organizationId: tenant.extId
                    },
                    data: compressedNotification
                }), undefined, undefined, 30000);
                await this.webhookResiliencyHandler.resetFailedAttempt(webhook.webhookId);
            }
            catch (err) {
                this.logger.error(`failed to post webhook notification, webhook ${webhook.webhookId}, tenant: ${tenantUid}, eventType: ${eventType}, err: ${err.message}`);
                await this.webhookResiliencyHandler.handleFailure(webhook.webhookId);
            }
        }, { concurrency: 10 });
    }
    getEventBusArn() {
        if (!process.env.DEVICE_CHANGE_NOTIFICATION_EVENT_BUS_ARN) {
            throw new Error('DEVICE_CHANGE_NOTIFICATION_EVENT_BUS_ARN is not set');
        }
        return process.env.DEVICE_CHANGE_NOTIFICATION_EVENT_BUS_ARN;
    }
    async getWebhooks(tenantUid) {
        if (await this.tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.DATA_SHARING_WEBHOOKS)) {
            return this.webhookRegistrationRepo.getTenantActiveWebhooks(tenantUid);
        }
        return [];
    }
    async prepareWebhookData(webhook, eventType, endpointStr) {
        const endpoint = JSON.parse(endpointStr);
        const matchUpdateNotification = eventType === WebhookHelper_1.WebhookEventType.DEVICE_UPDATE && [WebhookRegistrationRepo_1.WebhookNotificationType.UPDATE, WebhookRegistrationRepo_1.WebhookNotificationType.ALL].includes(webhook.notificationType);
        const matchMergeNotification = eventType === WebhookHelper_1.WebhookEventType.DEVICE_MERGE && [WebhookRegistrationRepo_1.WebhookNotificationType.UPDATE, WebhookRegistrationRepo_1.WebhookNotificationType.MERGE, WebhookRegistrationRepo_1.WebhookNotificationType.ALL].includes(webhook.notificationType);
        const matchColdStartNotification = eventType === WebhookHelper_1.WebhookEventType.DEVICE_COLD_START && webhook.coldStart.enable;
        if (!matchUpdateNotification && !matchMergeNotification && !matchColdStartNotification) {
            this.logger.debug(`device (${endpoint.uid})'s eventType ${eventType} does not match the webhook (${webhook.webhookId})'s notification type ${webhook.notificationType}`);
            return undefined;
        }
        let doesEndpointContainWebhookSources = webhook.sourceTypes.includes(WebhookHelper_1.ALL_SOURCE_TYPES);
        if (!doesEndpointContainWebhookSources) {
            for (const producer of endpoint.producers) {
                if (webhook.sourceTypes.includes(producer.type)) {
                    doesEndpointContainWebhookSources = true;
                    continue;
                }
                producer.properties = [];
            }
        }
        if (!doesEndpointContainWebhookSources) {
            this.logger.debug(`device (${endpoint.uid}) does not contain webhook (${webhook.webhookId})'s sourceTypes ${JSON.stringify(webhook.sourceTypes)}`);
            return undefined;
        }
        return endpoint;
    }
    async toCompressedData(data, compressionFormat) {
        switch (compressionFormat) {
            case WebhookRegistrationRepo_1.WebhookCompressionFormat.JSON:
                return JSON.stringify(data);
            case WebhookRegistrationRepo_1.WebhookCompressionFormat.GZIP:
                return (0, Util_1.stringToGzip)(JSON.stringify(data));
            default:
                throw new Error(`compressionFormat ${compressionFormat} is not supported`);
        }
    }
    async postToTargetUrl(secretsService, webhook, notification) {
        const webhookSecret = await secretsService.getSecret(`${WebhookHelper_1.WEBHOOK_SECRET_KEY_PREFIX}${webhook.webhookId}`);
        if (!webhookSecret) {
            throw new Error('webhook secret is not found');
        }
        await this.webhookNotificationApiClient.request({
            method: 'post',
            baseURL: webhook.targetUrl,
            headers: {
                Secret: webhookSecret === null || webhookSecret === void 0 ? void 0 : webhookSecret.secret
            },
            data: notification
        });
    }
}
exports.WebhookNotificationService = WebhookNotificationService;
