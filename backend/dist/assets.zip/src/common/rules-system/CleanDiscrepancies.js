"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CleanDiscrepancies = void 0;
const RuleService_1 = require("../../services/common/RuleService");
const LambdaLogger_1 = require("../LambdaLogger");
const DateUtils_1 = require("../DateUtils");
const ElasticsearchServices_1 = require("../ElasticsearchServices");
const OsVersionsServices_1 = require("../OsVersionsServices");
const elastic_builder_1 = __importDefault(require("elastic-builder"));
const Common_1 = require("./Common");
const KinesisServices_1 = require("../kinesis/KinesisServices");
const KinesisHelper_1 = require("../kinesis/KinesisHelper");
const TimeBasedAsyncLambdaInvoker_1 = require("../TimeBasedAsyncLambdaInvoker");
const TimestreamWriteServices_1 = require("../TimestreamWriteServices");
const LabelService_1 = require("../../services/common/LabelService");
const lodash_1 = __importDefault(require("lodash"));
const FAILED_DEVICES_THRESHOLD = 5;
const FAILED_RULES_THRESHOLD = 1;
class CleanDiscrepancies {
    constructor(rulesMetrics = new Common_1.RulesMetrics()) {
        this.rulesMetrics = rulesMetrics;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.gRuleService = new RuleService_1.GlobalRuleService();
        this.evaluateAndRaiseAlert = (metricName, value, dimensions) => {
            if (metricName === TimestreamWriteServices_1.MetricName.RULES_DISCR_Q_AND_R_MATCHING_DEVICES && value >= FAILED_DEVICES_THRESHOLD) {
                this.rulesMetrics.setRaisedAlert();
                this.logger.error(`Raised alert: metric ${metricName} with dimensions ${JSON.stringify(dimensions)} count ${value} exceeded FAILED_DEVICES_THRESHOLD ${FAILED_DEVICES_THRESHOLD}`);
            }
        };
        this.evaluateAndRaiseAlertRulesManagement = (metricName, value, dimensions) => {
            if ([TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_RULES_FOR_NEW_PROCESSING, TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_DELETED_RULES_ENABLED, TimestreamWriteServices_1.MetricName.RULES_DISCR_NOT_EXISTING_LABEL_PART_OF_THE_RULE].includes(metricName)
                && value >= FAILED_RULES_THRESHOLD) {
                this.rulesMetrics.setRaisedAlert();
                this.logger.error(`Raised alert: metric ${metricName} with dimensions ${JSON.stringify(dimensions)} count ${value} exceeded FAILED_RULES_THRESHOLD ${FAILED_RULES_THRESHOLD}`);
            }
        };
    }
    async rulesDiscrepancies(tenantUid) {
        this.logger.info(`Start looking for for RulesDiscrepancies for tenant ${tenantUid}`);
        const ruleService = new RuleService_1.RuleService(tenantUid);
        const labelService = new LabelService_1.LabelService(tenantUid);
        const rulesForHardDelete = [];
        const rulesToBeDisabled = [];
        const rulesForNewProcessing = [];
        const allTenantRulesWithCount = await ruleService.getAllRulesEntitiesWithCount();
        await this.deleteDiscrepancies(allTenantRulesWithCount, rulesToBeDisabled, rulesForHardDelete, rulesForNewProcessing);
        await this.labelDiscrepancies(allTenantRulesWithCount, rulesToBeDisabled, labelService);
        await this.batchUpdate(rulesForNewProcessing, rulesToBeDisabled, rulesForHardDelete);
        await this.rulesMetrics.reportCurrentMetrics();
        if (this.rulesMetrics.isAlertRaised()) {
            throw new Error(`Rules system coherence impaired. Alert raised for metric ${TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_RULES_FOR_NEW_PROCESSING} exceeding threshold ${FAILED_RULES_THRESHOLD}`);
        }
        this.logger.info(`Finished looking for RulesDiscrepancies for tenant ${tenantUid}`);
    }
    async devicesDiscrepancies(event, context) {
        var _a, _b;
        this.logger.debug('devicesDiscrepancies invoked. event:', JSON.stringify([(_a = event === null || event === void 0 ? void 0 : event.remainingWork) === null || _a === void 0 ? void 0 : _a.length, event]));
        const esService = new ElasticsearchServices_1.ElasticsearchGlobalServices();
        const rulesExecutionStream = new KinesisServices_1.KinesisServices(KinesisHelper_1.RULES_EXECUTION);
        const timeBasedAsyncLambdaInvoker = new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context);
        let rulesMetadata;
        if ((_b = event === null || event === void 0 ? void 0 : event.remainingWork) === null || _b === void 0 ? void 0 : _b.length) {
            rulesMetadata = event.remainingWork;
            for (const ruleMetaTuple of rulesMetadata) {
                this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_REMAINING_INPUT)], ruleMetaTuple[0].tenantId);
            }
        }
        else {
            const allRules = await this.gRuleService.getAllRules();
            this.logger.debug('allRules:', JSON.stringify([allRules.length, allRules]));
            for (const ruleItem of allRules) {
                this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_FROM_DB)], ruleItem.tenantId);
            }
            const now = Date.now();
            rulesMetadata = await Promise.all(allRules.filter(rule => (rule.lastModifyTime || Infinity) < now - DateUtils_1.HOUR_IN_MILLIS).map(async (rule) => {
                const queries = [elastic_builder_1.default.matchQuery('tenantUid.keyword', rule.tenantId)];
                queries.push(elastic_builder_1.default.boolQuery().should([
                    elastic_builder_1.default.rangeQuery('rulesLatestProcessed').lte(rule.lastModifyTime),
                    elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.existsQuery('rulesLatestProcessed')),
                    (rule.ruleManagementAction === RuleService_1.RuleManagementAction.DELETE || !rule.enabled) ? elastic_builder_1.default.termQuery('matchedByRules.keyword', rule.ruleId) : elastic_builder_1.default.boolQuery().mustNot(elastic_builder_1.default.termQuery('matchedByRules.keyword', rule.ruleId))
                ]));
                const searchQuery = await ElasticsearchServices_1.ElasticsearchGlobalServices.buildSearchQuery(rule.matchingCondition, () => new OsVersionsServices_1.OsVersionsServices().getOsVersions(), undefined, queries);
                return [rule, searchQuery];
            }));
        }
        for (const ruleMetaTuple of rulesMetadata) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IN_GRACE)], ruleMetaTuple[0].tenantId);
        }
        this.logger.debug('rulesMetadata:', JSON.stringify([rulesMetadata.length, rulesMetadata]));
        for (const ruleMetaTuple of rulesMetadata) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IN_FF)], ruleMetaTuple[0].tenantId);
        }
        this.logger.debug('rulesMetadata only if FF enabled for tenant:', JSON.stringify([rulesMetadata.length, rulesMetadata]));
        const allSettledResults = await Promise.allSettled(rulesMetadata.map((ruleMetadata) => { var _a, _b; return this.queryAndRemediate(ruleMetadata[0], esService, rulesExecutionStream, timeBasedAsyncLambdaInvoker, !((_a = event === null || event === void 0 ? void 0 : event.remainingWork) === null || _a === void 0 ? void 0 : _a.length) ? ruleMetadata[1] : undefined, ((_b = event === null || event === void 0 ? void 0 : event.remainingWork) === null || _b === void 0 ? void 0 : _b.length) ? ruleMetadata[1] : undefined); }));
        this.logger.debug('allSettledResults:', JSON.stringify([allSettledResults.length, allSettledResults]));
        const remainingWork = allSettledResults.filter(item => item.status === 'fulfilled').map(item => item.value).filter(val => val);
        this.logger.debug('remainingWork:', JSON.stringify([remainingWork === null || remainingWork === void 0 ? void 0 : remainingWork.length, remainingWork]));
        if (remainingWork === null || remainingWork === void 0 ? void 0 : remainingWork.length) {
            for (const ruleMetaTuple of remainingWork) {
                this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_REMAINING_OUTPUT)], ruleMetaTuple[0].tenantId);
            }
            this.logger.debug('re-invoking lambda to finish remaining work: ', JSON.stringify(remainingWork.length));
            await timeBasedAsyncLambdaInvoker.invokeLambda({ remainingWork, metricsState: this.rulesMetrics.timestreamRequestBuilder });
        }
        await this.rulesMetrics.reportCurrentMetrics();
        if (this.rulesMetrics.isAlertRaised()) {
            throw new Error(`Rules system coherence impaired. Alert raised for metric ${TimestreamWriteServices_1.MetricName.RULES_DISCR_Q_AND_R_MATCHING_DEVICES} exceeding threshold ${FAILED_DEVICES_THRESHOLD}`);
        }
    }
    async queryAndRemediate(rule, esService, rulesExecutionStream, timeBasedAsyncLambdaInvoker, query, scrollId = '') {
        var _a, _b;
        this.logger.debug('queryAndRemediate invoked. [rule, query, scroll]:', JSON.stringify([rule, query, scrollId]));
        let lastScrollId = scrollId;
        let result;
        try {
            for await (result of await esService.scrollGenerator(query, false, 500, scrollId)) {
                this.logger.debug('devices query results: ', JSON.stringify([(_a = result === null || result === void 0 ? void 0 : result[0]) === null || _a === void 0 ? void 0 : _a.length, result]));
                const events = (_b = result === null || result === void 0 ? void 0 : result[0]) === null || _b === void 0 ? void 0 : _b.map((device) => ({
                    Data: JSON.stringify([device._id, Common_1.EventType.UPDATED, Date.now(), rule.tenantId, Common_1.NO_RULE_ID]),
                    PartitionKey: 'pk0'
                }));
                this.logger.debug('events: ', JSON.stringify(events));
                if (events === null || events === void 0 ? void 0 : events.length) {
                    try {
                        this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_Q_AND_R_MATCHING_DEVICES, events.length)], rule.tenantId, undefined, undefined, this.evaluateAndRaiseAlert);
                        await rulesExecutionStream.putRecords(events);
                        this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_Q_AND_R_SENT_EVENTS, events.length)], rule.tenantId);
                        this.logger.debug('finished putting events on rules execution kinesis');
                        if (timeBasedAsyncLambdaInvoker.isItTimeToStop()) {
                            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_Q_AND_R_STOPPED_BY_TIME)], rule.tenantId);
                            this.logger.debug('Time to stop lambda. returning: ', JSON.stringify([rule, result[1]]));
                            return [rule, result[1]];
                        }
                    }
                    catch (error) {
                        this.logger.error('Error queryAndRemediate putting records on rules execution stream. ', error);
                    }
                }
                lastScrollId = result === null || result === void 0 ? void 0 : result[1];
            }
        }
        catch (error) {
            this.logger.error('Error queryAndRemediate', error);
        }
        if (lastScrollId) {
            await esService.clearScroll(lastScrollId);
        }
        this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_Q_AND_R_COMPLETED_SUCCESSFULLY)], rule.tenantId);
        this.logger.debug('queryAndRemediate ending successfuly. returning null');
        return null;
    }
    async deleteDiscrepancies(allTenantRulesWithCount, rulesToBeDisabled, rulesForHardDelete, rulesForNewProcessing) {
        for (const ruleCount of allTenantRulesWithCount) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_ALL_RULES), new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_ACCUMULATED_DEVICES_COUNT, ruleCount.count)], ruleCount.rule.tenantId);
        }
        const deletedRules = allTenantRulesWithCount.filter(ruleWithCount => ruleWithCount.rule.ruleManagementAction === RuleService_1.RuleManagementAction.DELETE);
        if (deletedRules === null || deletedRules === void 0 ? void 0 : deletedRules.length) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_DELETED_RULES, deletedRules.length)], deletedRules[0].rule.tenantId);
        }
        for (const ruleWithCount of deletedRules) {
            const rule = ruleWithCount.rule;
            if (ruleWithCount.count > 0) {
                this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_DELETED_RULES_WITH_ADHERING_DEVICES)], ruleWithCount.rule.tenantId);
                this.logger.error(`Rule inconsistency error, rule can not be deleted and have assigned devices: ${JSON.stringify(rule)}`);
                rulesForNewProcessing.push(rule);
            }
            else if (rule.enabled) {
                this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_DELETED_RULES_ENABLED)], ruleWithCount.rule.tenantId, undefined, undefined, this.evaluateAndRaiseAlertRulesManagement);
                this.logger.error(`Rule inconsistency error, rule can not be deleted and enabled: ${JSON.stringify(rule)}`);
                rulesToBeDisabled.push(rule);
            }
            else if (!rule.pendingApply && rule.processing) {
                this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_NOT_PENDING_APPLY_PROCESSING)], ruleWithCount.rule.tenantId);
                this.logger.error(`Rule inconsistency error, rule can not be !rule.pendingApply && rule.processing: ${JSON.stringify(rule)}`);
                rulesForNewProcessing.push(rule);
            }
            else if (!rule.pendingApply && (Date.now() - DateUtils_1.WEEK_MILLIS > rule.lastModifyTime)) {
                this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_NOT_PENDING_APPLY_TO_HARD_DELETE)], ruleWithCount.rule.tenantId);
                rulesForHardDelete.push(rule);
            }
        }
        if (rulesForNewProcessing === null || rulesForNewProcessing === void 0 ? void 0 : rulesForNewProcessing.length) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_RULES_IMPAIRED_RULES_FOR_NEW_PROCESSING, rulesForNewProcessing.length)], rulesForNewProcessing[0].tenantId, undefined, undefined, this.evaluateAndRaiseAlertRulesManagement);
        }
    }
    async labelDiscrepancies(allTenantRulesWithCount, rulesToBeDisabled, labelService) {
        var _a, _b;
        const rules = allTenantRulesWithCount
            .filter(rwc => rwc.rule.ruleManagementAction !== RuleService_1.RuleManagementAction.DELETE)
            .map(rwc => rwc.rule);
        if (lodash_1.default.isEmpty(rules)) {
            return;
        }
        const labelMap = await labelService.getLabelsMetadataMap();
        for (const rule of rules) {
            const actionLabels = [];
            let actionModified = false;
            const matchingLabels = [];
            let matchingModified = false;
            const errorLabelIds = [];
            (_a = rule.actionToTake.addLabels) === null || _a === void 0 ? void 0 : _a.forEach(labelId => {
                if (!labelMap.has(labelId)) {
                    this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_NOT_EXISTING_LABEL_PART_OF_THE_RULE)], rule.tenantId, undefined, undefined, this.evaluateAndRaiseAlertRulesManagement);
                    this.logger.error(`Rule inconsistency error, rule: ${JSON.stringify(rule)} actionToTake contain invalid label: ${labelId}`);
                    errorLabelIds.push(labelId);
                    actionModified = true;
                }
                else {
                    actionLabels.push(labelId);
                }
            });
            (_b = rule.matchingCondition.labels) === null || _b === void 0 ? void 0 : _b.forEach(labelInfo => {
                if (!labelMap.has(labelInfo.labelId)) {
                    this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DISCR_NOT_EXISTING_LABEL_PART_OF_THE_RULE)], rule.tenantId, undefined, undefined, this.evaluateAndRaiseAlertRulesManagement);
                    this.logger.error(`Rule inconsistency error, rule: ${JSON.stringify(rule)} matchingCondition contain invalid label: ${JSON.stringify(labelInfo)}`);
                    errorLabelIds.push(labelInfo.labelId);
                    matchingModified = true;
                }
                else {
                    matchingLabels.push(labelInfo);
                }
            });
            if (!lodash_1.default.isEmpty(errorLabelIds)) {
                if (actionModified) {
                    rule.actionToTake.addLabels = lodash_1.default.isEmpty(actionLabels) ? undefined : actionLabels;
                }
                if (matchingModified) {
                    rule.matchingCondition.labels = lodash_1.default.isEmpty(matchingLabels) ? undefined : matchingLabels;
                }
                errorLabelIds.forEach(eLablId => {
                    var _a;
                    RuleService_1.RuleService.addSystemModified(rule, { field: RuleService_1.SystemModifiedField.LABEL,
                        name: (_a = labelMap.get(eLablId)) === null || _a === void 0 ? void 0 : _a.name,
                        modification: RuleService_1.SystemModifiedModification.REMOVED,
                        location: RuleService_1.SystemModifiedLocation.AUTOMATED_ASSIGNMENT,
                        reason: RuleService_1.SystemModifiedReason.DELETED });
                });
                rulesToBeDisabled.push(rule);
            }
        }
    }
    async batchUpdate(rulesForNewProcessing, rulesToBeDisabled, rulesForHardDelete) {
        const toNewProcessing = rulesForNewProcessing.map(rule => new RuleService_1.RuleEntity(rule.ruleId, rule.name, rule.tenantId, rule.matchingCondition, rule.actionToTake, rule.ruleManagementAction, rule.description, rule.origin, rule.hidden, rule.enabled, true, Date.now(), false, 0));
        const toBeDisabled = rulesToBeDisabled.map(rule => new RuleService_1.RuleEntity(rule.ruleId, rule.name, rule.tenantId, rule.matchingCondition, rule.actionToTake, rule.ruleManagementAction, rule.description, rule.origin, rule.hidden, false, true, Date.now(), false, 0));
        await Promise.all([this.gRuleService.batchUpdate(toBeDisabled.concat(toNewProcessing)), this.gRuleService.batchDelete(rulesForHardDelete)]);
    }
}
exports.CleanDiscrepancies = CleanDiscrepancies;
