"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CloudWatchService = void 0;
const client_cloudwatch_1 = require("@aws-sdk/client-cloudwatch");
const LambdaLogger_1 = require("../LambdaLogger");
class CloudWatchService {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.client = new client_cloudwatch_1.CloudWatchClient({ logger: this.logger });
    }
    getMetricStatistics(metricReq) {
        return this.client.send(new client_cloudwatch_1.GetMetricStatisticsCommand(metricReq)).then((resp) => resp.Datapoints).catch((err) => {
            this.logger.error(`Error occurred during fetch metric statistics, err: ${err.message}`);
            throw err;
        });
    }
}
exports.CloudWatchService = CloudWatchService;
