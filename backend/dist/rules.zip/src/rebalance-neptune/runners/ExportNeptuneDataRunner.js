"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExportNeptuneDataRunner = void 0;
const RebalanceNeptuneClustersBase_1 = require("./RebalanceNeptuneClustersBase");
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const bluebird_1 = require("bluebird");
const lodash_1 = __importDefault(require("lodash"));
const async_lock_1 = __importDefault(require("async-lock"));
class ExportNeptuneDataRunner extends RebalanceNeptuneClustersBase_1.RebalanceNeptuneClustersBase {
    constructor() {
        super();
        this.exportLock = new async_lock_1.default({ timeout: 180000, maxOccupationTime: 300000 });
        this.maxExportVerticesChunkSize = +(process.env.MAX_EXPORT_VERTICES_CHUNK_SIZE || 500000);
        this.approxTotalDBEdgeCount = +(process.env.APPROX_TOTAL_DB_EDGE_COUNT || 0);
    }
    async run(tenants) {
        this.logger.info('Start ExportNeptuneDataRunner');
        if (tenants.length === 0) {
            this.logger.info('End ExportNeptuneDataRunner, no tenant needs to be exported');
            return;
        }
        await bluebird_1.Promise.map(tenants, async (tenantUid) => {
            const migrationLog = await this.neptuneShardMigrationLogRepo.getTenantMigrationLog(tenantUid);
            if (!migrationLog) {
                return;
            }
            try {
                this.logger.info(`start exporting for tenant ${tenantUid}`);
                if (await this.terminateNotThrottledTenant(tenantUid)) {
                    return;
                }
                const logDetails = await this.neptuneShardMigrationLogDetailRepo.getTenantMigrationLogDetails(tenantUid);
                if (logDetails.length === 0) {
                    await this.processLog(migrationLog);
                }
                else {
                    await this.reprocessFailedLog(logDetails);
                }
            }
            catch (err) {
                this.logger.error(`failed to export neptune data for tenant ${tenantUid}, error: ${err.message}`);
                await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORT_FAILED);
            }
        });
        this.logger.info('End ExportNeptuneDataRunner');
    }
    async processLog(migrationLog) {
        const tenantUid = migrationLog.tenantUid;
        this.logger.info(`start processLog for tenant ${tenantUid}`);
        const { verticesCount } = await this.countNeptuneEntries(tenantUid, migrationLog.migrateFromShardId);
        if (verticesCount === 0) {
            this.logger.info(`tenant ${tenantUid} has no neptune data, will switch from shard ${migrationLog.migrateFromShardId} to ${migrationLog.migrateToShardId} and complete migration`);
            await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(migrationLog.tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.DONE, undefined, Date.now());
            await this.neptuneShardRepo.upsertNeptuneShard({
                tenantUid: migrationLog.tenantUid,
                shardId: migrationLog.migrateToShardId
            });
            return;
        }
        const endpoint = this.getClusterEndpoint(migrationLog.migrateFromShardId).rawExportEndpoint;
        const { concurrency, jobSize } = this.estimateJobSize(verticesCount);
        const chunks = lodash_1.default.range(Math.ceil(verticesCount / this.maxExportVerticesChunkSize));
        const logDetails = [];
        for (const chunk of chunks) {
            const rangeStart = chunk * this.maxExportVerticesChunkSize;
            const rangeEnd = Math.min((chunk + 1) * this.maxExportVerticesChunkSize, verticesCount);
            const gremlinFilter = `has("_partition", "${tenantUid}").range(${rangeStart}, ${rangeEnd})`;
            logDetails.push(await this.exportChunk(tenantUid, endpoint, RebalanceNeptuneClustersBase_1.ExportDataType.NODES, concurrency, jobSize, gremlinFilter));
        }
        logDetails.push(await this.exportChunk(tenantUid, endpoint, RebalanceNeptuneClustersBase_1.ExportDataType.EDGES, 25, 'xlarge', `has("_partition", "${tenantUid}")`));
        await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORTING);
        await bluebird_1.Promise.map(logDetails, async (logDetail) => {
            await this.neptuneShardMigrationLogDetailRepo.upsert(logDetail);
        }, { concurrency: 500 });
    }
    async exportChunk(tenantUid, endpoint, scope, concurrency, jobSize, gremlinFilter) {
        const requestPayload = {
            command: 'export-pg',
            outputS3Path: `s3://${this.migrationS3Bucket}/export_files/${tenantUid}/${scope}/`,
            params: {
                endpoint,
                gremlinFilter,
                scope,
                concurrency,
                mergeFiles: true
            },
            jobSize
        };
        if (scope === RebalanceNeptuneClustersBase_1.ExportDataType.EDGES) {
            if (this.approxTotalDBEdgeCount > 0) {
                requestPayload.params.approxEdgeCount = this.approxTotalDBEdgeCount;
            }
            requestPayload.params.filterEdgesEarly = true;
        }
        const requestPayloadStr = JSON.stringify(requestPayload);
        const exportId = await this.triggerNeptuneExportService(tenantUid, requestPayloadStr);
        return {
            tenantUid,
            exportId,
            type: scope,
            exportRequestPayload: requestPayloadStr
        };
    }
    async reprocessFailedLog(logDetails) {
        const tenantUid = logDetails[0].tenantUid;
        this.logger.info(`reprocess exporting for tenant ${tenantUid}`);
        const refreshedLogDetails = [];
        for (const logDetail of logDetails) {
            if (logDetail.exportStatus === 'failed') {
                const failedExportId = logDetail.exportId;
                logDetail.exportId = await this.triggerNeptuneExportService(tenantUid, logDetail.exportRequestPayload);
                logDetail.exportStatus = undefined;
                refreshedLogDetails.push({ failedExportId, refreshedLogDetail: logDetail });
            }
        }
        await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORTING);
        await bluebird_1.Promise.map(refreshedLogDetails, async (detail) => {
            await this.neptuneShardMigrationLogDetailRepo.delete(detail.failedExportId);
            await this.neptuneShardMigrationLogDetailRepo.upsert(detail.refreshedLogDetail);
        }, { concurrency: 500 });
    }
    estimateJobSize(verticesCount) {
        const concurrencySetting = JSON.parse(process.env.NEPTUNE_EXPORT_SERVICE_CONCURRENCY_SETTING || '{}');
        switch (true) {
            case (verticesCount >= 1000000):
                return {
                    concurrency: Math.min((concurrencySetting.xlargeJob || 96), 96),
                    jobSize: 'xlarge'
                };
            case (verticesCount >= 500000):
                return {
                    concurrency: Math.min((concurrencySetting.largeJob || 64), 64),
                    jobSize: 'large'
                };
            case (verticesCount >= 50000):
                return {
                    concurrency: Math.min((concurrencySetting.mediumJob || 32), 32),
                    jobSize: 'large'
                };
            default:
                return {
                    concurrency: Math.min((concurrencySetting.smallJob || 8), 8),
                    jobSize: 'large'
                };
        }
    }
    async triggerNeptuneExportService(tenantUid, requestPayload) {
        return this.exportLock.acquire(this.triggerNeptuneExportService.name, async () => {
            const resp = await this.lambdaServices.syncInvoke(process.env.NEPTUNE_EXPORT_SERVICE_LAMBDA_NAME, requestPayload);
            const payload = JSON.parse(resp.Payload);
            const jobId = JSON.parse((payload === null || payload === void 0 ? void 0 : payload.body) || '{}').jobId;
            if (!jobId) {
                throw new Error(`Failed to trigger Neptune Export Service for tenant ${tenantUid} with request ${requestPayload}, response payload: ${resp.Payload}`);
            }
            this.logger.info(`Neptune Export Service job ${jobId} is triggered for tenant ${tenantUid} with request ${requestPayload}`);
            return jobId;
        });
    }
}
exports.ExportNeptuneDataRunner = ExportNeptuneDataRunner;
