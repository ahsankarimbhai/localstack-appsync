"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegularMonitoring = void 0;
const TenantServices_1 = require("../common/TenantServices");
const _ = __importStar(require("lodash"));
const TimestreamQueryServices_1 = require("../common/TimestreamQueryServices");
const util_1 = __importDefault(require("util"));
const TimestreamWriteServices_1 = require("../common/TimestreamWriteServices");
const CommonTypes_1 = require("../common/CommonTypes");
const Util_1 = require("../common/Util");
const LambdaLogger_1 = require("../common/LambdaLogger");
const CronParser = __importStar(require("cron-parser"));
const DateUtils_1 = require("../common/DateUtils");
const logger = new LambdaLogger_1.LambdaLogger();
class RegularMonitoring {
    constructor(interval = DateUtils_1.DAY_MILLIS / 2) {
        this.interval = interval;
    }
    async identifyUnsuccessfulTenantConfigurationSyncs() {
        const { tasks, stats } = await this.getTenantConfigs();
        const { metricsStarted, metricsFinished } = await this.getTimestreamMetrics(stats);
        const { tasksInterrupted, tasksFailed, tasksNeverStarted } = this.getUnfinishedTenantConfigurationsUsingMetrics(tasks, metricsStarted, metricsFinished, stats);
        const failedTasks = this.getListOfFailedTasks(tasksInterrupted, tasksFailed, tasksNeverStarted, stats);
        this.logFailedTasks(failedTasks, stats);
        this.logStats(failedTasks, stats);
        return failedTasks;
    }
    async getTenantConfigs() {
        const tenantServices = new TenantServices_1.TenantServices();
        const tenantConfigs = await tenantServices.getTenantConfigurationsForAllTenantsAtTime(Date.now() - this.interval);
        const tenantConfigsFiltered = _.filter(tenantConfigs, record => typeof record.value === 'string' && record.value.indexOf('schedule') > -1);
        _.map(tenantConfigsFiltered, record => this.processTenantConfiguration(record));
        const tenantConfigsGrouped = _.groupBy(tenantConfigsFiltered, record => record.scheduledToRun);
        const tenantConfigsScheduled = tenantConfigsGrouped.true || [];
        const tenantConfigsNotScheduled = tenantConfigsGrouped.false || [];
        const tenantConfigsScheduledSorted = _.sortBy(tenantConfigsScheduled, record => record.tenantKey, record => record.createdAt);
        const tenantConfigsScheduledGroupedBySchedule = _.groupBy(tenantConfigsScheduledSorted, record => record.scheduledFrequency);
        const tenantConfigsScheduledGroupedByProducerType = _.groupBy(tenantConfigsScheduledSorted, record => record.producerType);
        const tenantConfigsScheduledDeleted = _.filter(tenantConfigsScheduledSorted, record => record.deletedAt);
        const tenantConfigsScheduledDeletedGroupedBySchedule = _.groupBy(tenantConfigsScheduledDeleted, record => record.scheduledFrequency);
        const tenantConfigsScheduledDeletedGroupedByProducerType = _.groupBy(tenantConfigsScheduledDeleted, record => record.producerType);
        const tenantConfigsNotScheduledGroupedBySchedule = _.groupBy(tenantConfigsNotScheduled, record => record.scheduledFrequency);
        const tenantConfigsNotScheduledGroupedByProducerType = _.groupBy(tenantConfigsNotScheduled, record => record.producerType);
        const stats = {};
        stats.tasks = tenantConfigs.length;
        stats.tasksScheduled = tenantConfigsScheduled.length;
        stats.tasksScheduledGroupedBySchedule = tenantConfigsScheduledGroupedBySchedule;
        stats.tasksScheduledGroupedByProducerType = tenantConfigsScheduledGroupedByProducerType;
        stats.tasksScheduledDeleted = tenantConfigsScheduledDeleted.length;
        stats.tasksScheduledDeletedGroupedBySchedule = tenantConfigsScheduledDeletedGroupedBySchedule;
        stats.tasksScheduledDeletedGroupedByProducerType = tenantConfigsScheduledDeletedGroupedByProducerType;
        stats.tasksNotScheduled = tenantConfigsNotScheduled.length;
        stats.tasksNotScheduledGroupedBySchedule = tenantConfigsNotScheduledGroupedBySchedule;
        stats.tasksNotScheduledGroupedByProducerType = tenantConfigsNotScheduledGroupedByProducerType;
        return { tasks: tenantConfigsScheduledSorted, stats };
    }
    processTenantConfiguration(record) {
        const tenantKeyParts = _.split(record.tenantKey, Util_1.SOURCE_SEPARATOR);
        if (tenantKeyParts.length === 3) {
            record.tenant = tenantKeyParts[0];
            record.producerType = tenantKeyParts[1];
            record.producer = `${tenantKeyParts[1]}${Util_1.SOURCE_SEPARATOR}${tenantKeyParts[2]}`;
        }
        else {
            logger.debug(`Tenant Config Key is not in 3 parts: ${record.tenantKey}`);
        }
        if (typeof record.value === 'string' && record.value.indexOf('schedule') > -1) {
            try {
                const value = JSON.parse(record.value);
                record.schedule = value.schedule;
                this.processSchedule(record);
            }
            catch (ex) {
                logger.error(`Error occurred while parsing this tenant config's value and schedule: ${JSON.stringify(record)}`, ex);
                record.scheduledFrequency = 'Error';
                record.scheduledToRun = false;
            }
        }
        return record;
    }
    processSchedule(record) {
        if (record.schedule === '') {
            record.scheduledToRun = false;
            record.scheduledFrequency = '(Blank)';
            return;
        }
        const schedule = CronParser.parseExpression(record.schedule, { currentDate: Date.now() });
        const lastRun = schedule.prev().getTime();
        const age = Date.now() - lastRun;
        record.scheduledToRun = (age < this.interval);
        if (age < 15 * DateUtils_1.MINUTE_IN_MILLIS) {
            record.potentiallyRunning = true;
        }
        const parts = _.split(record.schedule, ' ');
        if (parts.length === 6) {
            parts.shift();
        }
        if (parts.length === 5) {
            if (parts[3] !== '*') {
                record.scheduledFrequency = 'Annually';
            }
            else if (parts[2] !== '*') {
                record.scheduledFrequency = 'Monthly';
            }
            else if (parts[4] !== '*') {
                record.scheduledFrequency = 'Weekly';
            }
            else if (parts[1] !== '*') {
                record.scheduledFrequency = 'Daily';
            }
            else if (parts[0] !== '*') {
                record.scheduledFrequency = 'Hourly';
            }
            else {
                record.scheduledFrequency = 'Minutely';
            }
        }
        else {
            record.scheduledFrequency = 'Invalid';
            logger.error(`Invalid schedule '${record.schedule}' for this record: ${JSON.stringify(record)}`);
            record.scheduledToRun = false;
        }
    }
    async getTimestreamMetrics(stats) {
        let intervalInHours = this.interval / DateUtils_1.HOUR_IN_MILLIS;
        if (intervalInHours < 1) {
            intervalInHours = 1;
        }
        const timestreamQueryServices = new TimestreamQueryServices_1.TimestreamQueryServices();
        const timestreamQuery = util_1.default.format(TimestreamQueryServices_1.WORKFLOW_EXECUTED_QUERY_TEMPLATE, TimestreamWriteServices_1.TimestreamWriteServices.getDatabaseName(), TimestreamWriteServices_1.TimestreamWriteServices.TABLE_NAME, intervalInHours, CommonTypes_1.WorkFlow.COLLECTION);
        const timestreamResults = await timestreamQueryServices.getQueryResults(timestreamQuery, undefined);
        const timestreamResultsProcessed = _.map(timestreamResults, metricArray => {
            const object = {};
            for (const element of metricArray) {
                object[element.key] = element.value;
                if (element.key === 'producer') {
                    const parts = _.split(element.value, Util_1.SOURCE_SEPARATOR);
                    if (parts.length > 0) {
                        object.producerType = parts[0];
                    }
                }
            }
            return object;
        });
        const [metricsStarted, metricsFinished] = timestreamResultsProcessed.reduce(([started, ended], record) => ((record.measure_name === 'started') ? [[...started, record], ended] : [started, [...ended, record]]), [[], []]);
        const metricsStartedDuplicates = this.removeOrderedDuplicates(metricsStarted, (a, b) => a.tenant === b.tenant && a.producer === b.producer);
        const metricsFinishedDuplicates = this.removeOrderedDuplicates(metricsFinished, (a, b) => a.tenant === b.tenant && a.producer === b.producer);
        stats.metricsStarted = metricsStarted.length;
        stats.metricsStartedDuplicates = metricsStartedDuplicates.length;
        stats.metricsFinished = metricsFinished.length;
        stats.metricsFinishedDuplicates = metricsFinishedDuplicates.length;
        return { metricsStarted, metricsFinished };
    }
    removeOrderedDuplicates(array, conditional) {
        const duplicates = [];
        for (let i = 0; i < array.length - 1; i += 1) {
            const a = array[i];
            const b = array[i + 1];
            if (conditional(a, b)) {
                duplicates.push({ original: a, duplicate: b });
                array.splice(i + 1, 1);
                i -= 1;
            }
        }
        return duplicates;
    }
    getUnfinishedTenantConfigurationsUsingMetrics(tasks, metricsStarted, metricsFinished, stats) {
        const [metricsStartedAndFinished, metricsStartedButNotFinished] = this.getMatches(metricsStarted, metricsFinished, (a, b) => a.tenant === b.tenant && a.producer === b.producer, (a, b) => ({ started: a, finished: b }));
        const [matchedTasksAndMetrics, unmatchedTasksToMetrics] = this.getMatches(tasks, metricsStartedAndFinished, (a, b) => a.tenant === b.started.tenant && a.producer === b.started.producer, (a, b) => ({ config: a, started: b.started, finished: b.finished }));
        const [matchedTasksAndMetricsCompleted, matchedTasksAndMetricsFailed] = matchedTasksAndMetrics.reduce(([completed, failed], record) => ((record.finished.measure_name === 'completed') ? [[...completed, record], failed] : [completed, [...failed, record]]), [[], []]);
        const matchedTasksAndMetricsCompletedGroupedBySchedule = _.groupBy(matchedTasksAndMetricsCompleted, record => record.config.scheduledFrequency);
        const matchedTasksAndMetricsCompletedGroupedByProducerType = _.groupBy(matchedTasksAndMetricsCompleted, record => record.config.producerType);
        const matchedTasksAndMetricsFailedGroupedBySchedule = _.groupBy(matchedTasksAndMetricsFailed, record => record.config.scheduledFrequency);
        const matchedTasksAndMetricsFailedGroupedByProducerType = _.groupBy(matchedTasksAndMetricsFailed, record => record.config.producerType);
        const [matchedTasksStartedButNotFinished, unmatchedTasksNeverStarted] = this.getMatches(unmatchedTasksToMetrics, metricsStartedButNotFinished, (a, b) => a.tenant === b.tenant && a.producer === b.producer, (a, b) => ({ config: a, started: b }));
        const matchedTasksStartedButNotFinishedGroupedBySchedule = _.groupBy(matchedTasksStartedButNotFinished, record => record.config.scheduledFrequency);
        const matchedTasksStartedButNotFinishedGroupedByProducerType = _.groupBy(matchedTasksStartedButNotFinished, record => record.config.producerType);
        const matchedTasksPotentiallyStillRunning = _.filter(matchedTasksStartedButNotFinished, (record) => record.config.potentiallyRunning);
        const matchedTasksPotentiallyStillRunningGroupedBySchedule = _.groupBy(matchedTasksPotentiallyStillRunning, record => record.config.scheduledFrequency);
        const matchedTasksPotentiallyStillRunningGroupedByProducerType = _.groupBy(matchedTasksPotentiallyStillRunning, record => record.config.producerType);
        const [unmatchedTasksNeverStartedNotDeleted, unmatchedTasksNeverStartedDeleted] = unmatchedTasksNeverStarted.reduce(([notDeleted, deleted], record) => ((!record.deletedAt) ? [[...notDeleted, record], deleted] : [notDeleted, [...deleted, record]]), [[], []]);
        const unmatchedTasksNeverStartedNotDeletedGroupedBySchedule = _.groupBy(unmatchedTasksNeverStartedNotDeleted, record => record.scheduledFrequency);
        const unmatchedTasksNeverStartedNotDeletedGroupedByProducerType = _.groupBy(unmatchedTasksNeverStartedNotDeleted, record => record.producerType);
        const unmatchedTasksNeverStartedDeletedGroupedBySchedule = _.groupBy(unmatchedTasksNeverStartedDeleted, record => record.scheduledFrequency);
        const unmatchedTasksNeverStartedDeletedGroupedByProducerType = _.groupBy(unmatchedTasksNeverStartedDeleted, record => record.producerType);
        stats.metricsStartedAndFinished = metricsStartedAndFinished.length;
        stats.metricsStartedButNotFinished = metricsStartedButNotFinished.length;
        stats.matchedTasksAndMetrics = matchedTasksAndMetrics.length;
        stats.unmatchedTasksToMetrics = unmatchedTasksToMetrics.length;
        stats.matchedTasksAndMetricsCompleted = matchedTasksAndMetricsCompleted.length;
        stats.matchedTasksAndMetricsCompletedGroupedBySchedule = matchedTasksAndMetricsCompletedGroupedBySchedule;
        stats.matchedTasksAndMetricsCompletedGroupedByProducerType = matchedTasksAndMetricsCompletedGroupedByProducerType;
        stats.matchedTasksAndMetricsFailed = matchedTasksAndMetricsFailed.length;
        stats.matchedTasksAndMetricsFailedGroupedBySchedule = matchedTasksAndMetricsFailedGroupedBySchedule;
        stats.matchedTasksAndMetricsFailedGroupedByProducerType = matchedTasksAndMetricsFailedGroupedByProducerType;
        stats.matchedTasksStartedButNotFinished = matchedTasksStartedButNotFinished.length;
        stats.matchedTasksStartedButNotFinishedGroupedBySchedule = matchedTasksStartedButNotFinishedGroupedBySchedule;
        stats.matchedTasksStartedButNotFinishedGroupedByProducerType = matchedTasksStartedButNotFinishedGroupedByProducerType;
        stats.unmatchedTasksNeverStarted = unmatchedTasksNeverStarted.length;
        stats.matchedTasksPotentiallyStillRunning = matchedTasksPotentiallyStillRunning.length;
        stats.matchedTasksPotentiallyStillRunningGroupedBySchedule = matchedTasksPotentiallyStillRunningGroupedBySchedule;
        stats.matchedTasksPotentiallyStillRunningGroupedByProducerType = matchedTasksPotentiallyStillRunningGroupedByProducerType;
        stats.unmatchedTasksNeverStartedNotDeleted = unmatchedTasksNeverStartedNotDeleted.length;
        stats.unmatchedTasksNeverStartedNotDeletedGroupedBySchedule = unmatchedTasksNeverStartedNotDeletedGroupedBySchedule;
        stats.unmatchedTasksNeverStartedNotDeletedGroupedByProducerType = unmatchedTasksNeverStartedNotDeletedGroupedByProducerType;
        stats.unmatchedTasksNeverStartedDeleted = unmatchedTasksNeverStartedDeleted.length;
        stats.unmatchedTasksNeverStartedDeletedGroupedBySchedule = unmatchedTasksNeverStartedDeletedGroupedBySchedule;
        stats.unmatchedTasksNeverStartedDeletedGroupedByProducerType = unmatchedTasksNeverStartedDeletedGroupedByProducerType;
        return { tasksInterrupted: matchedTasksStartedButNotFinished, tasksFailed: matchedTasksAndMetricsFailed, tasksNeverStarted: unmatchedTasksNeverStartedNotDeleted };
    }
    getMatches(arrayA, arrayB, conditional, matchedResult) {
        const matched = [];
        const unmatched = [];
        for (const a of arrayA) {
            let isMatched = false;
            for (const b of arrayB) {
                if (conditional(a, b)) {
                    matched.push(matchedResult(a, b));
                    isMatched = true;
                    break;
                }
            }
            if (!isMatched) {
                unmatched.push(a);
            }
        }
        return [matched, unmatched];
    }
    getListOfFailedTasks(tasksInterrupted, tasksFailed, tasksNeverStarted, stats) {
        stats.failedTasksIndexForInterrupted = 0;
        let failedTasks = _.map(tasksInterrupted, record => `${record.started.tenant}${Util_1.SOURCE_SEPARATOR}${record.started.producer}`);
        stats.failedTasksIndexForFailed = failedTasks.length;
        failedTasks = failedTasks.concat(_.map(tasksFailed, record => `${record.started.tenant}${Util_1.SOURCE_SEPARATOR}${record.started.producer}`));
        stats.failedTasksIndexForNeverRun = failedTasks.length;
        failedTasks = failedTasks.concat(_.map(tasksNeverStarted, record => record.tenantKey));
        const failedTasksDuplicate = [];
        for (let i = 0; i < failedTasks.length - 1; i += 1) {
            for (let j = i + 1; j < failedTasks.length; j += 1) {
                if (failedTasks[i] === failedTasks[j]) {
                    failedTasksDuplicate.push(failedTasks[j]);
                }
            }
        }
        stats.failedTasksDuplicate = failedTasksDuplicate.length;
        return failedTasks;
    }
    logFailedTasks(failedTasks, stats) {
        if (failedTasks.length === 0) {
            logger.info('All tasks have run successfully');
        }
        for (let i = 0; i < failedTasks.length; i += 1) {
            let cause;
            if (i >= stats.failedTasksIndexForNeverRun) {
                cause = 'never ran';
            }
            else if (i >= stats.failedTasksIndexForFailed) {
                cause = 'failed';
            }
            else if (i >= stats.failedTasksIndexForInterrupted) {
                cause = 'was interrupted';
            }
            logger.info(`${i + 1}/${failedTasks.length}) Task ${cause}: ${failedTasks[i]}`);
        }
    }
    logStats(failedTasks, stats) {
        const separator = '-';
        let results = 'Unsuccessful Tenant Configuration Sync Result Counts\n';
        results += `Interval = ${this.getIntervalAsString()}\n`;
        results += '\n';
        results += 'Executive Summary:\n';
        if (failedTasks.length === 0) {
            results += 'All tasks have run successfully';
        }
        else {
            results += `Successful tasks within interval = ${stats.tasksScheduled - failedTasks.length}\n`;
            results += `Unsuccessful tasks within interval = ${failedTasks.length}\n`;
            results += `  Interrupted/timed out = ${stats.matchedTasksStartedButNotFinished}\n`;
            results += this.getLengthsOfEachNestedArrayInEachObject([stats.matchedTasksStartedButNotFinishedGroupedBySchedule, stats.matchedTasksStartedButNotFinishedGroupedByProducerType], (element, length) => `    ${element} tasks = ${length}\n`, `    ${separator.repeat(10)}\n`);
            if (stats.matchedTasksPotentiallyStillRunning > 0) {
                results += `  (Potentially still running = ${stats.matchedTasksPotentiallyStillRunning})\n`;
                results += this.getLengthsOfEachNestedArrayInEachObject([stats.matchedTasksPotentiallyStillRunningGroupedBySchedule, stats.matchedTasksPotentiallyStillRunningGroupedByProducerType], (element, length) => `      ${element} tasks = ${length}\n`, `      ${separator.repeat(8)}\n`);
            }
            results += `  ${separator.repeat(12)}\n`;
            results += `  Failed = ${stats.matchedTasksAndMetricsFailed}\n`;
            results += this.getLengthsOfEachNestedArrayInEachObject([stats.matchedTasksAndMetricsFailedGroupedBySchedule, stats.matchedTasksAndMetricsFailedGroupedByProducerType], (element, length) => `    ${element} tasks = ${length}\n`, `    ${separator.repeat(10)}\n`);
            results += `  ${separator.repeat(12)}\n`;
            results += `  Never ran = ${stats.unmatchedTasksNeverStartedNotDeleted}\n`;
            results += this.getLengthsOfEachNestedArrayInEachObject([stats.unmatchedTasksNeverStartedNotDeletedGroupedBySchedule, stats.unmatchedTasksNeverStartedNotDeletedGroupedByProducerType], (element, length) => `    ${element} tasks = ${length}\n`, `    ${separator.repeat(10)}\n`);
            results += `  ${separator.repeat(12)}\n`;
            results += `  Verify no duplicates identified in results = ${stats.failedTasksDuplicate === 0} (count = ${stats.failedTasksDuplicate})\n`;
        }
        results += '\n';
        results += 'Summary of Tasks:\n';
        results += `All tasks, including recently-deleted = ${stats.tasks}\n`;
        results += `Scheduled only, including recently-deleted = ${stats.tasksScheduled + stats.tasksNotScheduled}\n`;
        results += `  Scheduled but out of interval window = ${stats.tasksNotScheduled}\n`;
        results += this.getLengthsOfEachNestedArrayInEachObject([stats.tasksNotScheduledGroupedBySchedule, stats.tasksNotScheduledGroupedByProducerType], (element, length) => `    ${element} tasks = ${length}\n`, `    ${separator.repeat(10)}\n`);
        results += `  Scheduled to run within interval = ${stats.tasksScheduled}\n`;
        results += this.getLengthsOfEachNestedArrayInEachObject([stats.tasksScheduledGroupedBySchedule, stats.tasksScheduledGroupedByProducerType], (element, length) => `    ${element} tasks = ${length}\n`, `    ${separator.repeat(10)}\n`);
        if (stats.tasksScheduledDeleted) {
            results += `Scheduled to run and was recently-deleted = ${stats.tasksScheduledDeleted}\n`;
            results += this.getLengthsOfEachNestedArrayInEachObject([stats.tasksScheduledDeletedGroupedBySchedule, stats.tasksScheduledDeletedGroupedByProducerType], (element, length) => `  ${element} tasks = ${length}\n`, `  ${separator.repeat(12)}\n`);
        }
        results += '\n';
        results += 'Summary of Metrics:\n';
        results += `Metrics started = ${(stats.metricsStarted + stats.metricsStartedDuplicates)}\n`;
        results += `  First occurrence = ${stats.metricsStarted}\n`;
        results += `  Duplicate occurrence = ${stats.metricsStartedDuplicates}\n`;
        results += `Metrics finished = ${(stats.metricsFinished + stats.metricsFinishedDuplicates)}\n`;
        results += `  First occurrence = ${stats.metricsFinished}\n`;
        results += `  Duplicate occurrence = ${stats.metricsFinishedDuplicates}\n`;
        results += `Started and finished (no duplicates) = ${stats.metricsStartedAndFinished}\n`;
        results += `Started but not finished (no duplicates) = ${stats.metricsStartedButNotFinished}\n`;
        results += '\n';
        results += 'Summary of Tasks matched to Metrics (no duplicates):\n';
        results += `Matched tasks to metrics = ${stats.matchedTasksAndMetrics + stats.matchedTasksStartedButNotFinished}\n`;
        results += `  Sync started and finished = ${stats.matchedTasksAndMetrics}\n`;
        results += `    Completed = ${stats.matchedTasksAndMetricsCompleted}\n`;
        results += this.getLengthsOfEachNestedArrayInEachObject([stats.matchedTasksAndMetricsCompletedGroupedBySchedule, stats.matchedTasksAndMetricsCompletedGroupedByProducerType], (element, length) => `      ${element} tasks = ${length}\n`, `      ${separator.repeat(8)}\n`);
        results += `    Failed = ${stats.matchedTasksAndMetricsFailed}\n`;
        results += this.getLengthsOfEachNestedArrayInEachObject([stats.matchedTasksAndMetricsFailedGroupedBySchedule, stats.matchedTasksAndMetricsFailedGroupedByProducerType], (element, length) => `      ${element} tasks = ${length}\n`, `      ${separator.repeat(8)}\n`);
        results += `  Sync started but not finished = ${stats.matchedTasksStartedButNotFinished}\n`;
        results += this.getLengthsOfEachNestedArrayInEachObject([stats.matchedTasksStartedButNotFinishedGroupedBySchedule, stats.matchedTasksStartedButNotFinishedGroupedByProducerType], (element, length) => `    ${element} tasks = ${length}\n`, `    ${separator.repeat(10)}\n`);
        results += `Unfinished tasks = ${stats.unmatchedTasksToMetrics}\n`;
        results += `  Started but unfinished tasks = ${stats.unmatchedTasksToMetrics - stats.unmatchedTasksNeverStarted}\n`;
        results += `    Potentially still running = ${stats.matchedTasksPotentiallyStillRunning}\n`;
        results += this.getLengthsOfEachNestedArrayInEachObject([stats.matchedTasksPotentiallyStillRunningGroupedBySchedule, stats.matchedTasksPotentiallyStillRunningGroupedByProducerType], (element, length) => `      ${element} tasks = ${length}\n`, `      ${separator.repeat(8)}\n`);
        results += `  Unstarted tasks = ${stats.unmatchedTasksNeverStarted}\n`;
        if (stats.unmatchedTasksNeverStartedDeleted) {
            results += `    Active tasks = ${stats.unmatchedTasksNeverStartedNotDeleted}\n`;
            results += this.getLengthsOfEachNestedArrayInEachObject([stats.unmatchedTasksNeverStartedNotDeletedGroupedBySchedule, stats.unmatchedTasksNeverStartedNotDeletedGroupedByProducerType], (element, length) => `      ${element} tasks = ${length}\n`, `      ${separator.repeat(8)}\n`);
            results += `    Deleted tasks = ${stats.unmatchedTasksNeverStartedDeleted}\n`;
            results += this.getLengthsOfEachNestedArrayInEachObject([stats.unmatchedTasksNeverStartedDeletedGroupedBySchedule, stats.unmatchedTasksNeverStartedDeletedGroupedByProducerType], (element, length) => `      ${element} tasks = ${length}\n`, `      ${separator.repeat(8)}\n`);
        }
        else if (stats.unmatchedTasksNeverStartedNotDeleted > 0) {
            results += this.getLengthsOfEachNestedArrayInEachObject([stats.unmatchedTasksNeverStartedNotDeletedGroupedBySchedule, stats.unmatchedTasksNeverStartedNotDeletedGroupedByProducerType], (element, length) => `    ${element} tasks = ${length}\n`, `    ${separator.repeat(10)}\n`);
        }
        logger.info(results);
    }
    getIntervalAsString() {
        const days = this.interval / DateUtils_1.DAY_MILLIS;
        const daysInt = Math.floor(days);
        const hours = ((days - daysInt) * DateUtils_1.DAY_MILLIS) / DateUtils_1.HOUR_IN_MILLIS;
        const hoursInt = Math.floor(hours);
        const minutes = ((hours - hoursInt) * DateUtils_1.HOUR_IN_MILLIS) / DateUtils_1.MINUTE_IN_MILLIS;
        const minutesInt = Math.floor(minutes);
        const seconds = ((minutes - minutesInt) * DateUtils_1.MINUTE_IN_MILLIS) / 1000;
        const secondsInt = Math.round(seconds);
        const output = [];
        if (daysInt > 0) {
            output.push(this.pluralize(daysInt, 'day'));
        }
        if (hoursInt > 0) {
            output.push(this.pluralize(hoursInt, 'hour'));
        }
        if (minutesInt > 0) {
            output.push(this.pluralize(minutesInt, 'minute'));
        }
        if (secondsInt > 0) {
            output.push(this.pluralize(secondsInt, 'second'));
        }
        return output.join(', ');
    }
    pluralize(value, word, plural = `${word}s`) {
        return `${value} ${[1, -1].includes(value) ? word : plural}`;
    }
    getLengthsOfEachNestedArrayInEachObject(objects, result, separator) {
        let results = '';
        for (let i = 0; i < objects.length; i += 1) {
            const object = objects[i];
            const properties = _.sortBy(Object.getOwnPropertyNames(object));
            for (const element of properties) {
                if (object[element].length) {
                    results += result(element, object[element].length);
                }
            }
            if (properties.length > 0 && i < objects.length - 1) {
                results += separator;
            }
        }
        return results;
    }
}
exports.RegularMonitoring = RegularMonitoring;
