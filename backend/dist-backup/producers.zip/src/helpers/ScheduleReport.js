"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScheduleReport = void 0;
const lodash_1 = __importDefault(require("lodash"));
const parser = __importStar(require("cron-parser"));
const TenantServices_1 = require("../common/TenantServices");
const Util_1 = require("../common/Util");
const DateUtils_1 = require("../common/DateUtils");
const ScheduleServices_1 = require("../common/ScheduleServices");
class ScheduleReport {
    constructor() {
        this.tenantServices = new TenantServices_1.TenantServices();
        this.scheduleServices = new ScheduleServices_1.ScheduledTaskServices();
    }
    async report(from = 24, to = 24) {
        const results = [];
        const tenants = await this.tenantServices.getAllTenants();
        const now = Date.now();
        const options = {
            currentDate: now - DateUtils_1.HOUR_IN_MILLIS * from,
            endDate: Date.now() + DateUtils_1.HOUR_IN_MILLIS * to
        };
        for (const tenant of tenants) {
            const producers = await this.tenantServices.getTenantConfigurations(tenant.id);
            const tenantTasks = await this.scheduleServices.getAllTenantTasks(tenant.id);
            let taskSchedules = lodash_1.default.map(tenantTasks, task => ScheduleReport.getTaskSchedule(task.name, task.schedule, options));
            for (const producer of producers) {
                try {
                    const value = JSON.parse(producer.value);
                    const producerType = value.source;
                    const producerId = value.sourceId;
                    const cfgKey = (0, Util_1.toSourceString)(producerType, producerId);
                    const producerTasks = await this.scheduleServices.getAllProducerTasks(tenant.id, cfgKey);
                    taskSchedules = lodash_1.default.concat(taskSchedules, lodash_1.default.map(producerTasks, task => ScheduleReport.getTaskSchedule(task.name, task.schedule, options, cfgKey)));
                    const cronExpression = value.schedule;
                    if (!cronExpression) {
                        continue;
                    }
                    taskSchedules = lodash_1.default.concat(taskSchedules, ScheduleReport.getTaskSchedule('collection', cronExpression, options, cfgKey));
                }
                catch (err) {
                }
            }
            results.push({
                tenantId: tenant.id,
                taskSchedules
            });
        }
        return results;
    }
    static getTaskSchedule(taskName, cronExpression, options, producer) {
        const interval = parser.parseExpression(cronExpression, options);
        let nextRunInRange;
        try {
            nextRunInRange = interval.next().toString();
        }
        catch (err) {
        }
        return {
            taskName,
            producer,
            cronSchedule: {
                cronExpression,
                nextRun: nextRunInRange || 'next run is out of time range'
            }
        };
    }
}
exports.ScheduleReport = ScheduleReport;
const scheduleReport = new ScheduleReport();
const from = Number(process.argv[2]);
const to = Number(process.argv[3]);
console.log(`Creating Schedule Report for [${process.env.ENV}] env in the time range [ now - ${from} hour(s), now + ${to} hour(s) ] ...`);
scheduleReport.report(from, to)
    .then((result) => {
    console.log(JSON.stringify(result, null, '\t'));
})
    .catch(console.error);
