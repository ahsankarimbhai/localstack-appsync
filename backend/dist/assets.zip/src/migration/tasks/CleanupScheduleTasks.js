"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CleanupScheduleTasks = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const TenantServices_1 = require("../../common/TenantServices");
const BatchTaskServices_1 = require("../../common/BatchTaskServices");
const ScheduleServices_1 = require("../../common/ScheduleServices");
const bluebird_1 = require("bluebird");
const DataMigrationOrchestrator_1 = require("../DataMigrationOrchestrator");
class CleanupScheduleTasks extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor() {
        super(...arguments);
        this.tenantServices = new TenantServices_1.TenantServices();
        this.scheduledTaskServices = new ScheduleServices_1.ScheduledTaskServices();
        this.scheduledTaskMetadataServices = new ScheduleServices_1.ScheduledTaskMetadataServices();
    }
    async execute() {
        const tasks = await this.scheduledTaskServices.getAll();
        const metadataNames = await this.getAllMetadataNames();
        const tenants = await this.tenantServices.getAllTenants();
        const tenantUidSet = new Set(tenants.map(t => t.id));
        const cleanupTasks = tasks.filter(t => (t.tenantUid !== BatchTaskServices_1.TaskScope.GLOBAL && !tenantUidSet.has(t.tenantUid))
            || (!metadataNames.has(t.name) && t.name !== DataMigrationOrchestrator_1.DataMigrationRunner.NAME));
        this.logger.info(`${cleanupTasks.length} tasks will be deleted`);
        const hasErr = await this.deleteTasks(cleanupTasks);
        if (hasErr) {
            throw new Error('Error occurred when clean up schedule tasks for not existed tenant');
        }
        return bluebird_1.Promise.resolve();
    }
    async deleteTasks(cleanupTasks) {
        let hasErr = false;
        await bluebird_1.Promise.map(cleanupTasks, async (task) => {
            try {
                await this.scheduledTaskServices.deleteByKey(task.taskKey);
                this.logger.info(`task ${task.taskKey} is deleted successfully`);
            }
            catch (err) {
                hasErr = true;
                this.logger.error(`failed to delete task ${task.taskKey}, error: ${err.message}`);
            }
        }, { concurrency: 500 });
        return hasErr;
    }
    async getAllMetadataNames() {
        const tasksMetadata = await this.scheduledTaskMetadataServices.getAll();
        return new Set(tasksMetadata.map(item => item.name));
    }
    getTaskName() {
        return CleanupScheduleTasks.TASK_NAME;
    }
}
exports.CleanupScheduleTasks = CleanupScheduleTasks;
CleanupScheduleTasks.TASK_NAME = 'cleanup-schedule-tasks';
