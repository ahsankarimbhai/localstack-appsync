"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScheduledTaskRunner = void 0;
const LambdaLogger_1 = require("../common/LambdaLogger");
const EventBridgeService_1 = require("../common/awsclient/EventBridgeService");
const SQSService_1 = require("../common/awsclient/SQSService");
const DateUtils_1 = require("../common/DateUtils");
const _ = __importStar(require("lodash"));
const Util_1 = require("../common/Util");
const LambdaServices_1 = require("../common/LambdaServices");
const TenantServices_1 = require("../common/TenantServices");
const ScheduleServices_1 = require("../common/ScheduleServices");
class ScheduledTaskRunner {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.scheduledTaskServices = new ScheduleServices_1.ScheduledTaskServices();
        this.scheduledTaskMetadataServices = new ScheduleServices_1.ScheduledTaskMetadataServices();
        this.eventBridgeServices = new EventBridgeService_1.EventBridgeService();
        this.sqsServices = new SQSService_1.SQSService();
        if (!process.env.SCHEDULED_EVENTBUS_ARN) {
            throw new Error('SCHEDULED_EVENTBUS_ARN is not set');
        }
        this.eventBusArn = process.env.SCHEDULED_EVENTBUS_ARN;
    }
    async triggerTasks() {
        this.logger.debug(`Start triggering scheduled tasks scheduled to the next ${ScheduledTaskRunner.SCHEDULE_WINDOW_IN_MILLISECONDS} window...`);
        const scheduledTasks = await this.scheduledTaskServices.getTasksToSchedule();
        for await (const task of scheduledTasks) {
            try {
                await this.triggerTask(_.assign(new ScheduleServices_1.ScheduledTask(task.name, task.tenantUid, task.schedule), task));
            }
            catch (err) {
                this.logger.error(err);
            }
        }
        this.logger.debug(`Finished triggering scheduled tasks scheduled to the next ${ScheduledTaskRunner.SCHEDULE_WINDOW_IN_MILLISECONDS} window...`);
    }
    async triggerTask(task, additionalMessageProps) {
        if (task.schedule !== _.toString(ScheduleServices_1.ScheduleType.NOW) && !(0, Util_1.isScheduledForNextWindow)(task.schedule, ScheduledTaskRunner.SCHEDULE_WINDOW_IN_MILLISECONDS)) {
            this.logger.debug(`Not triggering scheduled task: ${JSON.stringify(task)}, it is not its time`);
            return;
        }
        try {
            const taskMetadata = await this.scheduledTaskMetadataServices.getCachedByName(task.getName());
            const taskMessage = JSON.stringify({
                targetTask: task.getName(),
                eventBridgeData: _.merge({
                    tenantUid: task.tenantUid,
                    producer: task.producer,
                    taskParams: task.taskParams
                }, additionalMessageProps)
            });
            this.logger.debug(`Trigger scheduled task: ${taskMessage}`);
            if (taskMetadata === null || taskMetadata === void 0 ? void 0 : taskMetadata.isScalable) {
                await this.triggerScalableTask(task.getName(), taskMessage);
            }
            else {
                await this.triggerNonScalableTask(taskMessage);
            }
        }
        catch (err) {
            throw new Error(`Failed to trigger scheduled task ${JSON.stringify(task)} with error: ${err.message}`);
        }
    }
    async triggerNonScalableTask(taskMessage) {
        const evtReq = {
            EventBusName: this.eventBusArn,
            Source: `${process.env.ENV_PREFIX}-scheduled_task_runner`,
            DetailType: 'detail',
            Detail: taskMessage
        };
        await this.eventBridgeServices.publish([evtReq]);
    }
    async triggerScalableTask(taskName, taskMessage) {
        const msgReq = {
            QueueUrl: `${process.env.ENV_PREFIX}-${taskName}.fifo`,
            MessageBody: taskMessage,
            MessageGroupId: taskName
        };
        await this.sqsServices.send(msgReq);
    }
    async scheduleMissingTasks(shard) {
        const MAX_CONCURRENT_FOR_LAMBDA = +(process.env.MAX_CONCURRENT_FOR_LAMBDA || 8);
        this.logger.debug(`Scheduling missing tasks. shard: ${shard} MAX_CONCURRENT_FOR_LAMBDA: ${MAX_CONCURRENT_FOR_LAMBDA}`);
        if (undefined === shard) {
            const lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
            const functionName = `${process.env.ENV_PREFIX}-schedule-missing-tasks`;
            for (const currentShard of Array(MAX_CONCURRENT_FOR_LAMBDA).keys()) {
                const invokeParams = { shard: currentShard };
                this.logger.debug(`Invoking lambda: ${functionName} with: ${JSON.stringify(invokeParams)}`);
                await lambdaServices.asyncInvoke(functionName, JSON.stringify(invokeParams));
            }
        }
        else {
            const scheduledTaskServices = new ScheduleServices_1.ScheduledTaskServices();
            const tenantService = new TenantServices_1.TenantServices();
            const tenants = await tenantService.getAllTenants();
            const tenantsOfShard = tenants.filter(currentTenant => currentTenant.id.charCodeAt(0) % MAX_CONCURRENT_FOR_LAMBDA === shard);
            this.logger.debug(`Scheduling tasks for ${tenantsOfShard.length} tenants of shard: ${shard}`);
            for (const tenant of tenantsOfShard) {
                let alreadyScheduledTasks;
                try {
                    alreadyScheduledTasks = new Set((await this.scheduledTaskServices.getScheduledTasksByTenant(tenant.id)).map((item) => item.taskKey));
                    this.logger.debug(`Scheduling tasks for tenant ${tenant.id} shard: ${shard}`);
                    await scheduledTaskServices.scheduleTenantTasks(tenant.id, alreadyScheduledTasks);
                    this.logger.debug(`Successfully scheduled tasks for tenant ${tenant.id}`);
                }
                catch (e) {
                    this.logger.error(`Failed to schedule tasks for tenant ${tenant.id}, ${JSON.stringify(e)}`);
                }
                const producers = await tenantService.getProducerConfigurations(tenant.id);
                for (const producer of producers) {
                    try {
                        await scheduledTaskServices.scheduleProducerTasks(tenant.id, (0, Util_1.toSourceString)(producer.producerType, producer.producerId), alreadyScheduledTasks);
                    }
                    catch (e) {
                        this.logger.error(`Failed to schedule tasks of tenant ${tenant.id} and producer ${producer.producerId}, ${e}`);
                    }
                }
                this.logger.debug(`Finished scheduling tasks that are missing for tenant: ${tenant.id}`);
            }
        }
    }
}
exports.ScheduledTaskRunner = ScheduledTaskRunner;
ScheduledTaskRunner.SCHEDULE_WINDOW_IN_MILLISECONDS = DateUtils_1.MINUTE_IN_MILLIS * 10;
