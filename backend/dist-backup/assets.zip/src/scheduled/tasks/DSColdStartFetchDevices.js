"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DSColdStartFetchDevices = void 0;
const _ = __importStar(require("lodash"));
const gremlin_1 = require("gremlin");
const CommonTypes_1 = require("../../common/CommonTypes");
const NeptuneDBScheduledTaskProcessor_1 = require("../NeptuneDBScheduledTaskProcessor");
const Util_1 = require("../../common/Util");
const WebhookNotificationService_1 = require("../../services/common/data-sharing/WebhookNotificationService");
const WebhookHelper_1 = require("../../services/common/data-sharing/WebhookHelper");
const WebhookRegistrationRepo_1 = require("../../common/dynamoDBRepo/WebhookRegistrationRepo");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const __ = gremlin_1.process.statics;
const P = gremlin_1.process.P;
const t = gremlin_1.process.t;
class DSColdStartFetchDevices extends NeptuneDBScheduledTaskProcessor_1.NeptuneDBScheduledTaskProcessor {
    constructor(tenantUid, taskParams) {
        var _a;
        super(tenantUid, 20, undefined, taskParams);
        this.processRangeCount = 0;
        if (!taskParams || !this.taskParams.webhookId || !this.taskParams.producers
            || this.taskParams.producers.length === 0 || !this.taskParams.searchDeviceCreatedBefore) {
            throw new Error('webhookId, producers and searchDeviceCreatedBefore must be set in taskParams');
        }
        this.webhookNotificationService = new WebhookNotificationService_1.WebhookNotificationService();
        this.webhookRegistrationRepo = new WebhookRegistrationRepo_1.WebhookRegistrationRepo();
        this.webhookId = this.taskParams.webhookId;
        this.producers = this.taskParams.producers;
        this.searchDeviceCreatedBefore = (_a = this.taskParams) === null || _a === void 0 ? void 0 : _a.searchDeviceCreatedBefore;
    }
    getTaskName() {
        return DSColdStartFetchDevices.TASK_NAME;
    }
    async processRange(startRange) {
        var _a;
        const webhook = await this.webhookRegistrationRepo.getByWebhookId(this.webhookId);
        if (!((_a = webhook === null || webhook === void 0 ? void 0 : webhook.coldStart) === null || _a === void 0 ? void 0 : _a.enable) || webhook.coldStart.enabledAt !== this.searchDeviceCreatedBefore) {
            throw new Error(`webhook ${this.webhookId} is changed, stop fetching devices for cold start`);
        }
        const peIds = await this.neptuneServices.executeTenantQuery((g) => this.getRangeQuery(g, startRange)
            .select('pe')
            .by(t.id)
            .toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        this.processRangeCount = peIds.length;
        if (peIds.length > 0) {
            await this.webhookNotificationService.sendDeviceEvent(this.tenantUid, WebhookHelper_1.WebhookEventType.DEVICE_COLD_START, peIds);
        }
    }
    async nextRangeCount(startRange) {
        return this.processRangeCount;
    }
    getRootTraversal(g) {
        return this.neptuneServices.getGraphTraversalBasedOnLabel(g, CommonTypes_1.VertexType.POSTURE_ENDPOINT);
    }
    getRangeQuery(g, startRange) {
        return this.getRootTraversal(g)
            .as('pe')
            .range(startRange, startRange + this.batchSize)
            .where(__.out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .hasLabel(...this.producers.map(producer => `${(0, CommonTypes_1.sourceToVertexType)(_.split(producer, Util_1.SOURCE_SEPARATOR)[0])}__${producer}__${this.tenantUid}`))
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
            .has(CommonTypes_1.EdgeBasicProperty.SINCE, P.lte(this.searchDeviceCreatedBefore)));
    }
}
exports.DSColdStartFetchDevices = DSColdStartFetchDevices;
DSColdStartFetchDevices.TASK_NAME = 'ds-cold-start-fetch-devices';
