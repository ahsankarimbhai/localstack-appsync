"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RebalanceNeptuneClustersBase = exports.ExportDataType = void 0;
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const NeptuneShardRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardRepo");
const NeptuneClient_1 = require("../../common/neptune/NeptuneClient");
const LambdaServices_1 = require("../../common/LambdaServices");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const CommonTypes_1 = require("../../common/CommonTypes");
const https_1 = __importDefault(require("https"));
const axios_1 = __importDefault(require("axios"));
const NeptuneShardMigrationLogDetailRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogDetailRepo");
var ExportDataType;
(function (ExportDataType) {
    ExportDataType["NODES"] = "nodes";
    ExportDataType["EDGES"] = "edges";
})(ExportDataType = exports.ExportDataType || (exports.ExportDataType = {}));
class RebalanceNeptuneClustersBase {
    constructor() {
        this.LOADER_COMPLETED_CODE = 'LOAD_COMPLETED';
        this.LOADER_IN_PROGRESS_CODES = ['LOAD_NOT_STARTED', 'LOAD_IN_PROGRESS', 'LOAD_IN_QUEUE'];
        this.neptuneShardMigrationLogRepo = new NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationLogRepo();
        this.neptuneShardMigrationLogDetailRepo = new NeptuneShardMigrationLogDetailRepo_1.NeptuneShardMigrationLogDetailRepo();
        this.neptuneShardRepo = new NeptuneShardRepo_1.NeptuneShardRepo();
        this.lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
        const agent = new https_1.default.Agent({
            rejectUnauthorized: false
        });
        this.neptuneHttpClient = axios_1.default.create({ httpsAgent: agent });
        this.logger = new LambdaLogger_1.LambdaLogger();
        const neptuneRebalanceSettings = JSON.parse(process.env.NEPTUNE_REBALANCE_SETTINGS || '{}');
        this.migrationS3Bucket = neptuneRebalanceSettings.s3Bucket;
        this.loaderS3AccessRoleArn = neptuneRebalanceSettings.s3AccessRoleArn;
        this.clusterEndpoints = neptuneRebalanceSettings.clusterEndpoints;
    }
    async terminateNotThrottledTenant(tenantUid) {
        const tenantShard = await this.neptuneShardRepo.getNeptuneShard(tenantUid);
        if (!(tenantShard === null || tenantShard === void 0 ? void 0 : tenantShard.isThrottled)) {
            this.logger.error(`Failed to migrate tenant ${tenantUid}, tenant is not throttled`);
            await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.FAILED, undefined, Date.now());
            return true;
        }
        return false;
    }
    async countNeptuneEntries(tenantUid, shardId, countEdges = false) {
        const endpointSetting = this.getClusterEndpoint(shardId);
        const client = new NeptuneClient_1.NeptuneClient(`wss://${endpointSetting.rawExportEndpoint}:${endpointSetting.port}/gremlin`, { rejectUnauthorized: false }, undefined, +(process.env.NEPTUNE_QUERY_TIMEOUT || 300000));
        try {
            const requests = [];
            requests.push(client.getGraphTraversalSource().V().has(CommonTypes_1.BasicProperty.PARTITION_KEY, tenantUid).count()
                .next());
            if (countEdges) {
                requests.push(client.getGraphTraversalSource().E().has(CommonTypes_1.BasicProperty.PARTITION_KEY, tenantUid).count()
                    .next());
            }
            const [verticesCount, edgesCount] = await Promise.all(requests);
            this.logger.info(`tenant ${tenantUid} has ${verticesCount.value} vertices ${countEdges ? `and ${edgesCount.value} edges ` : ''}in shard ${shardId}`);
            return {
                verticesCount: verticesCount.value,
                edgesCount: edgesCount === null || edgesCount === void 0 ? void 0 : edgesCount.value
            };
        }
        finally {
            await client.closeConnection();
        }
    }
    getClusterEndpoint(shardId) {
        const clusterEndpoint = this.clusterEndpoints.find(item => item.shardId === shardId);
        if (!clusterEndpoint) {
            throw new Error(`Environment variable NEPTUNE_REBALANCE_SETTINGS is not set correctly for shardId ${shardId}`);
        }
        return clusterEndpoint;
    }
}
exports.RebalanceNeptuneClustersBase = RebalanceNeptuneClustersBase;
