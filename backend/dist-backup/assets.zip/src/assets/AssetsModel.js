"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postureAssetModel = exports.postureAssetMapping = exports.postureAssetProperties = exports.AssetConfidence = exports.AssetSpecificity = exports.AssetType = exports.AssetPropertyKey = exports.StrongObservables = exports.AssetObservablesType = exports.AssetsErrorType = exports.AssetsErrorCode = void 0;
const IrohModuleInstanceClient_1 = require("../common/IrohModuleInstanceClient");
var AssetsErrorCode;
(function (AssetsErrorCode) {
    AssetsErrorCode["MISSING_TENANT"] = "1000";
    AssetsErrorCode["GENERIC_ERROR"] = "5000";
})(AssetsErrorCode = exports.AssetsErrorCode || (exports.AssetsErrorCode = {}));
var AssetsErrorType;
(function (AssetsErrorType) {
    AssetsErrorType["FATAL"] = "fatal";
    AssetsErrorType["ERROR"] = "error";
    AssetsErrorType["WARNING"] = "warning";
})(AssetsErrorType = exports.AssetsErrorType || (exports.AssetsErrorType = {}));
var AssetObservablesType;
(function (AssetObservablesType) {
    AssetObservablesType["MAC_ADDRESS"] = "mac_address";
    AssetObservablesType["HOSTNAME"] = "hostname";
    AssetObservablesType["ORBITAL_NODE_ID"] = "orbital_node_id";
    AssetObservablesType["USER"] = "user";
    AssetObservablesType["EMAIL"] = "email";
    AssetObservablesType["IP"] = "ip";
    AssetObservablesType["IPV6"] = "ipv6";
    AssetObservablesType["IMEI"] = "imei";
    AssetObservablesType["AMP_COMPUTER_GUID"] = "amp_computer_guid";
    AssetObservablesType["CISCO_UC_ID"] = "cisco_uc_id";
    AssetObservablesType["SERIAL_NUMBER"] = "serial_number";
    AssetObservablesType["UMBRELLA_ODNS_IDENTITY"] = "odns_identity";
    AssetObservablesType["CROWDSTRIKE_ID"] = "crowdstrike_id";
    AssetObservablesType["S1_AGENT_ID"] = "s1_agent_id";
    AssetObservablesType["MS_MACHINE_ID"] = "ms_machine_id";
    AssetObservablesType["TREND_MICRO_ID"] = "trend_micro_id";
})(AssetObservablesType = exports.AssetObservablesType || (exports.AssetObservablesType = {}));
exports.StrongObservables = [AssetObservablesType.CISCO_UC_ID, AssetObservablesType.ORBITAL_NODE_ID, AssetObservablesType.AMP_COMPUTER_GUID, AssetObservablesType.UMBRELLA_ODNS_IDENTITY, AssetObservablesType.CROWDSTRIKE_ID, AssetObservablesType.S1_AGENT_ID, AssetObservablesType.MS_MACHINE_ID, AssetObservablesType.TREND_MICRO_ID];
var AssetPropertyKey;
(function (AssetPropertyKey) {
    AssetPropertyKey["DEVICE_ID"] = "cisco:ctr:device:id";
    AssetPropertyKey["DEVICE_NAME"] = "cisco:ctr:device:name";
    AssetPropertyKey["DEVICE_TYPE"] = "cisco:ctr:device:type";
    AssetPropertyKey["DEVICE_ADMINISTRATORS"] = "cisco:ctr:device:administrators";
    AssetPropertyKey["DEVICE_MODEL"] = "cisco:ctr:device:model";
    AssetPropertyKey["DEVICE_HARDWARE_ID"] = "cisco:ctr:device:hardware_id";
    AssetPropertyKey["DEVICE_COMPUTER_SID"] = "cisco:ctr:device:computer_sid";
    AssetPropertyKey["DEVICE_OS_VERSION"] = "cisco:ctr:device:os_version";
    AssetPropertyKey["DEVICE_OS_EXTRACTED_NUMERIC_VERSION"] = "cisco:ctr:device:OS_EXTRACTED_NUMERIC_VERSION";
    AssetPropertyKey["DEVICE_OS_VERSION_NAME"] = "cisco:ctr:device:os_version_name";
    AssetPropertyKey["DEVICE_OS_SUPPORT"] = "cisco:ctr:device:os_support";
    AssetPropertyKey["DEVICE_IS_COMPROMISED"] = "cisco:ctr:device:iscompromised";
    AssetPropertyKey["DEVICE_IS_MANAGED"] = "cisco:ctr:device:ismanaged";
    AssetPropertyKey["DEVICE_IS_ENCRYPTED"] = "cisco:ctr:device:isencrypted";
    AssetPropertyKey["DEVICE_IS_SUPERVISED"] = "cisco:ctr:device:issupervised";
    AssetPropertyKey["DEVICE_MDM_COMPLIANT"] = "cisco:ctr:device:mdm_compliant";
    AssetPropertyKey["DEVICE_MDM_JAIL_BROKEN"] = "cisco:ctr:device:mdm_jail_broken";
    AssetPropertyKey["DEVICE_MDM_ANDROID_SECURITY"] = "cisco:ctr:device:mdm_android_security";
    AssetPropertyKey["DEVICE_MDM_TAMPERED"] = "cisco:ctr:device:mdm_tampered";
    AssetPropertyKey["DEVICE_LAST_SYNC_TIME"] = "cisco:ctr:device:last_sync_time";
    AssetPropertyKey["DEVICE_HAS_FAULTS"] = "cisco:ctr:device:hasfaults";
    AssetPropertyKey["DEVICE_AV_DEFINITION_OUT_OF_DATE"] = "cisco:ctr:device:av_definitions_out_of_date";
    AssetPropertyKey["ASSET_VALUE"] = "cisco:ctr:assetValue";
    AssetPropertyKey["ASSET_LABELS"] = "cisco:ctr:labels";
})(AssetPropertyKey = exports.AssetPropertyKey || (exports.AssetPropertyKey = {}));
var AssetType;
(function (AssetType) {
    AssetType["DEVICE"] = "device";
})(AssetType = exports.AssetType || (exports.AssetType = {}));
var AssetSpecificity;
(function (AssetSpecificity) {
    AssetSpecificity["MEDIUM"] = "Medium";
    AssetSpecificity["UNIQUE"] = "Unique";
    AssetSpecificity["LOW"] = "Low";
})(AssetSpecificity = exports.AssetSpecificity || (exports.AssetSpecificity = {}));
var AssetConfidence;
(function (AssetConfidence) {
    AssetConfidence["MEDIUM"] = "Medium";
    AssetConfidence["INFO"] = "Info";
    AssetConfidence["UNKNOWN"] = "Unknown";
    AssetConfidence["NONE"] = "None";
    AssetConfidence["HIGH"] = "High";
    AssetConfidence["LOW"] = "Low";
})(AssetConfidence = exports.AssetConfidence || (exports.AssetConfidence = {}));
const ASSET_SOURCE = `cisco:${IrohModuleInstanceClient_1.DEVICE_INSIGHTS}`;
const ASSET_SCHEMA_VERSION = '1.0.19';
const PLACEHOLDER_REF = 'placeholder';
exports.postureAssetProperties = {
    asset_ref: PLACEHOLDER_REF,
    id: PLACEHOLDER_REF,
    source: ASSET_SOURCE,
    schema_version: ASSET_SCHEMA_VERSION,
    type: 'asset-properties',
    source_uri: process.env.POSTURE_URL
};
exports.postureAssetMapping = {
    type: 'asset-mapping',
    source: ASSET_SOURCE,
    asset_ref: PLACEHOLDER_REF,
    id: PLACEHOLDER_REF,
    schema_version: ASSET_SCHEMA_VERSION,
    asset_type: AssetType.DEVICE,
    stability: 'Managed',
    specificity: AssetSpecificity.UNIQUE,
    confidence: AssetConfidence.UNKNOWN,
    source_uri: process.env.POSTURE_URL
};
exports.postureAssetModel = {
    type: 'asset',
    id: PLACEHOLDER_REF,
    asset_type: AssetType.DEVICE,
    source: ASSET_SOURCE,
    schema_version: ASSET_SCHEMA_VERSION,
    source_uri: process.env.POSTURE_URL
};
