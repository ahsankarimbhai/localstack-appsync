import { GenericSourceConfiguration } from '@common/generic/GenericSourceConfiguration';
import { GenericSourceMappingHandler } from '@common/generic/GenericSourceMappingHandler';
import {
  setPropertyByTimestamp,
  val,
  VertexBasicProperty
} from '@common/CommonTypes';

export class CortexPeMappingHandler implements GenericSourceMappingHandler {
  // pe is a MergedEndpoint but that would cause a circular reference since that interface is defined in PostureEndpointService
  handler(sourceConfiguration: GenericSourceConfiguration, pe: any, pv: any, ps: any): void {
    setPropertyByTimestamp(pe, ps, VertexBasicProperty.NAME, () => {
      pe.hostname = val(ps.get(VertexBasicProperty.NAME));
    });
  }
}
