"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IrohKeyClient = void 0;
const _ = __importStar(require("lodash"));
const IdpKeyClient_1 = require("./IdpKeyClient");
const Util_1 = require("../Util");
const CommonTypes_1 = require("../CommonTypes");
const TenantServices_1 = require("../TenantServices");
const AuthorizerHelper_1 = require("../../authorizer/AuthorizerHelper");
class IrohKeyClient extends IdpKeyClient_1.IdpKeyClient {
    async getExistingTenant(decodedToken) {
        const extId = _.get(decodedToken, IrohKeyClient.ORG_ID_CLAIM);
        const tenantServices = new TenantServices_1.TenantServices();
        return await tenantServices.getTenantByExtId(extId) || await tenantServices.getTenantById(extId);
    }
    async getTenantDataFromToken(decodedToken) {
        const extId = _.get(decodedToken, IrohKeyClient.ORG_ID_CLAIM);
        const name = _.get(decodedToken, IrohKeyClient.ORG_NAME_CLAIM, CommonTypes_1.NA);
        const role = this.getPostureRole(decodedToken);
        const tenant = await this.getExistingTenant(decodedToken);
        this.logger.info(`Tenant is: ${JSON.stringify(tenant)}`);
        if (tenant) {
            return { uid: tenant.id, tenantExtId: extId, name, role };
        }
        return { tenantExtId: extId, name, role };
    }
    verifyAudience(decodedToken, resource) {
        const ifSystemApi = (0, AuthorizerHelper_1.isSystemApi)(resource);
        if (ifSystemApi && !this.isAdmin(decodedToken)) {
            throw new Error('System API is restricted to administrators');
        }
        const ifDataSharingWebhooksApi = (0, AuthorizerHelper_1.isDataSharingWebhooksApi)(resource);
        if (ifDataSharingWebhooksApi && !this.isAdmin(decodedToken)) {
            throw new Error('DataSharing Webhooks API is restricted to administrators');
        }
        const ifIncidentApi = (0, AuthorizerHelper_1.isIncidentApi)(resource);
        const isAllowedAudience = (IdpKeyClient_1.IdpKeyClient.valueIncluded(decodedToken, IdpKeyClient_1.IdpKeyClient.AUDIENCE_CLAIM, IrohKeyClient.POSTURE_AUD, IrohKeyClient.IROH_UI_AUD)
            || (ifSystemApi && IdpKeyClient_1.IdpKeyClient.valueIncluded(decodedToken, IdpKeyClient_1.IdpKeyClient.AUDIENCE_CLAIM, IrohKeyClient.POSTURE_AUD))
            || (ifIncidentApi && IdpKeyClient_1.IdpKeyClient.valueIncluded(decodedToken, IrohKeyClient.SCOPES_CLAIM, IrohKeyClient.ASSET_SCOPE, IrohKeyClient.INTEGRATION_ASSET_WRITE_SCOPE))
            || (IdpKeyClient_1.IdpKeyClient.valueIncluded(decodedToken, IrohKeyClient.SCOPES_CLAIM, IrohKeyClient.INSIGHTS_SCOPE, IrohKeyClient.INSIGHTS_READ_SCOPE)));
        if (!isAllowedAudience) {
            if (!this.isAuthorizedClientApiUsage(decodedToken)) {
                throw new Error(`wrong audience. received audience was ${_.get(decodedToken, IdpKeyClient_1.IdpKeyClient.AUDIENCE_CLAIM)}`);
            }
        }
    }
    getPostureRole(decodedToken) {
        return _.isEqual(this.getRole(decodedToken), 'admin') ? Util_1.ROLE_ADMIN : IdpKeyClient_1.IdpKeyClient.DEFAULT_ROLE;
    }
    getJwksUri() {
        if (!process.env.IROH_JWKS_URI) {
            throw new Error('IROH_JWKS_URI env variable is missing');
        }
        return process.env.IROH_JWKS_URI;
    }
    getRole(decodedToken) {
        return _.get(decodedToken, IrohKeyClient.ROLE_CLAIM);
    }
    isAdminScope(decodedToken) {
        return IdpKeyClient_1.IdpKeyClient.valueIncluded(decodedToken, IrohKeyClient.SCOPES_CLAIM, IrohKeyClient.INSIGHTS_SCOPE);
    }
    isAuthorizedClientApiUsage(decodedToken) {
        if (!process.env.API_ALLOWED_CLIENT_IDS) {
            return false;
        }
        const clientIds = _.split(process.env.API_ALLOWED_CLIENT_IDS, ',');
        const clientIdClaim = _.get(decodedToken, 'https://schemas.cisco.com/iroh/identity/claims/oauth/client/id');
        return (_.indexOf(clientIds, clientIdClaim) !== -1) && IdpKeyClient_1.IdpKeyClient.valueIncluded(decodedToken, IdpKeyClient_1.IdpKeyClient.AUDIENCE_CLAIM, clientIdClaim);
    }
}
exports.IrohKeyClient = IrohKeyClient;
IrohKeyClient.ORG_NAME_CLAIM = 'https://schemas.cisco.com/iroh/identity/claims/org/name';
IrohKeyClient.ORG_ID_CLAIM = 'https://schemas.cisco.com/iroh/identity/claims/org/id';
IrohKeyClient.ROLE_CLAIM = 'https://schemas.cisco.com/iroh/identity/claims/user/role';
IrohKeyClient.SCOPES_CLAIM = 'https://schemas.cisco.com/iroh/identity/claims/scopes';
IrohKeyClient.POSTURE_AUD = 'POSTURE';
IrohKeyClient.IROH_UI_AUD = 'iroh-ui';
IrohKeyClient.INTEGRATION_ASSET_WRITE_SCOPE = 'integration/asset:write';
IrohKeyClient.ASSET_SCOPE = 'asset';
IrohKeyClient.INSIGHTS_READ_SCOPE = 'insights:read';
IrohKeyClient.INSIGHTS_SCOPE = 'insights';
