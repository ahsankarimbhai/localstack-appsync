"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PosturePersonModelService = exports.PosturePersonModel = void 0;
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
class PosturePersonModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.POSTURE_PERSON;
    }
    getKeyProperties() {
        return [PosturePersonModel.DIFFERENTIATOR_PROPERTY];
    }
    async initProperties(input, source, sourceConfiguration) {
        this.setProperty(PosturePersonModel.DIFFERENTIATOR_PROPERTY, input.firstConnection);
    }
}
exports.PosturePersonModel = PosturePersonModel;
PosturePersonModel.DIFFERENTIATOR_PROPERTY = 'firstConnection';
class PosturePersonModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new PosturePersonModel(this.partitionKey);
    }
}
exports.PosturePersonModelService = PosturePersonModelService;
