"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.closeElasticSearchClient = exports.getElasticSearchClient = void 0;
const elasticsearch_1 = require("@elastic/elasticsearch");
const ElasticsearchServices_1 = require("./ElasticsearchServices");
const LambdaLogger_1 = require("./LambdaLogger");
let elasticSearchClient;
const logger = new LambdaLogger_1.LambdaLogger();
function getElasticSearchClient() {
    if (!elasticSearchClient) {
        elasticSearchClient = new elasticsearch_1.Client({
            node: process.env.LOCAL_ENV ? 'http://localhost:8157' : ElasticsearchServices_1.ElasticsearchServices.ES_ADDRESS,
            requestTimeout: 120000,
            ssl: {
                rejectUnauthorized: false
            }
        });
    }
    return elasticSearchClient;
}
exports.getElasticSearchClient = getElasticSearchClient;
function closeElasticSearchClient() {
    if (elasticSearchClient) {
        return elasticSearchClient.close().catch((err) => logger.error('failed to close connection', err)).finally(() => elasticSearchClient = undefined);
    }
    return Promise.resolve();
}
exports.closeElasticSearchClient = closeElasticSearchClient;
