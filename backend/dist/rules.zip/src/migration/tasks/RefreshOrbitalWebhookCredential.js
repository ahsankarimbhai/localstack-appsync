"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RefreshOrbitalWebhookCredential = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const lodash_1 = __importDefault(require("lodash"));
const TenantServices_1 = require("../../common/TenantServices");
const DynamoDBServices_1 = require("../../common/awsclient/dynamodb/DynamoDBServices");
const OrbitalCollectorServices_1 = require("../../services/orbital/OrbitalCollectorServices");
class RefreshOrbitalWebhookCredential extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor(timeBasedLambdaHandler, taskParams) {
        super(taskParams);
        this.timeBasedLambdaHandler = timeBasedLambdaHandler;
        this.processedCount = taskParams.processedCount;
        this.dynamoDBServices = new DynamoDBServices_1.DynamoDBServices();
    }
    getTaskName() {
        return RefreshOrbitalWebhookCredential.TASK_NAME;
    }
    async execute() {
        var _a;
        try {
            const orbitalWebhooks = lodash_1.default.sortBy(await this.dynamoDBServices.getAllFilteredTableEntries(TenantServices_1.TenantConfiguration.TABLE_NAME, 'contains(tenantKey, :orbital) and attribute_not_exists(deletedAt)', { ':orbital': 'Orbital' }), item => item.createdAt);
            while (this.processedCount < orbitalWebhooks.length) {
                if (this.timeBasedLambdaHandler.isItTimeToStop()) {
                    this.taskParams.processedCount = this.processedCount;
                    return { shouldContinue: true };
                }
                const tenantKey = orbitalWebhooks[this.processedCount].tenantKey;
                try {
                    const tenantUid = orbitalWebhooks[this.processedCount].tenantUid;
                    const webhookConfig = JSON.parse(orbitalWebhooks[this.processedCount].value || '{}');
                    if (webhookConfig.webhookId) {
                        const orbitalService = new OrbitalCollectorServices_1.OrbitalCollectorServices({}, tenantUid, webhookConfig.sourceId, webhookConfig.baseURL);
                        await orbitalService.updateS3Webhook();
                    }
                }
                catch (err) {
                    this.logger.error(`error when updating Orbital webhook for tenant ${tenantKey}, err: ${err.message}, http response err: ${JSON.stringify(((_a = err.response) === null || _a === void 0 ? void 0 : _a.data) || '{}')}`);
                }
                this.processedCount += 1;
            }
            this.taskParams.processedCount = this.processedCount;
            return { shouldContinue: false };
        }
        catch (err) {
            this.logger.error(`${this.getLogPrefix()} - error occurred when executing task. err: ${err.message}`, err);
            throw err;
        }
    }
}
exports.RefreshOrbitalWebhookCredential = RefreshOrbitalWebhookCredential;
RefreshOrbitalWebhookCredential.TASK_NAME = 'refresh-orbital-webhook-credential';
