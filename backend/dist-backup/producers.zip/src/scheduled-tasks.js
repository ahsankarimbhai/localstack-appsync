"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dsColdStartFetchDevices = exports.updateTenantWebhooks = exports.cleanLabelsOnAllDevicesFromNoLongerExisting = exports.updateAllRelevantScheduling = exports.performRegularMonitoring = exports.deleteScheduledTask = exports.saveScheduledTask = exports.cleanupDeletedSourcesForAllTenants = exports.deleteEmptyStaleTenants = exports.triggerDeleteStaleTenantData = exports.cleanupRedundanciesFromES = exports.deleteTenantData = exports.closeProducerCurrentStates = exports.deleteOldHistoricalData = exports.clearEsTasksIndex = exports.cleanupShadowSources = exports.syncNeptuneToEsDifference = exports.updateStaleDevices = exports.scheduleMissingTasks = exports.distributeScalableTasks = exports.triggerScheduledTasks = void 0;
const _ = __importStar(require("lodash"));
const UpdateStaleDevices_1 = require("./scheduled/tasks/UpdateStaleDevices");
const UpdateStaleDevicesUsingES_1 = require("./scheduled/tasks/UpdateStaleDevicesUsingES");
const TimeBasedAsyncLambdaInvoker_1 = require("./common/TimeBasedAsyncLambdaInvoker");
const ScheduleServices_1 = require("./common/ScheduleServices");
const ScheduledTaskRunner_1 = require("./scheduled/ScheduledTaskRunner");
const CloseProducerCurrentStates_1 = require("./scheduled/tasks/CloseProducerCurrentStates");
const BatchTaskServices_1 = require("./common/BatchTaskServices");
const NeptuneToEsDiffSyncTask_1 = require("./scheduled/tasks/NeptuneToEsDiffSyncTask");
const DeleteTenantData_1 = require("./scheduled/tasks/DeleteTenantData");
const TenantServices_1 = require("./common/TenantServices");
const DateUtils_1 = require("./common/DateUtils");
const LambdaLogger_1 = require("./common/LambdaLogger");
const tenant_management_1 = require("./tenant-management");
const CleanupShadowSources_1 = require("./scheduled/tasks/CleanupShadowSources");
const CleanupDeletedSources_1 = require("./helpers/CleanupDeletedSources");
const DeleteOldHistoricalData_1 = require("./scheduled/tasks/DeleteOldHistoricalData");
const RegularMonitoring_1 = require("./scheduled/RegularMonitoring");
const CommonTypes_1 = require("./common/CommonTypes");
const Util_1 = require("./common/Util");
const CleanupRedundanciesFromES_1 = require("./scheduled/tasks/CleanupRedundanciesFromES");
const LabelService_1 = require("./services/common/LabelService");
const ElasticsearchServices_1 = require("./common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("./common/ElasticsearchFactory");
const NeptuneClientManager_1 = require("./common/neptune/NeptuneClientManager");
const ScalableTaskDispatcher_1 = require("./scheduled/ScalableTaskDispatcher");
const ClearEsTasksIndex_1 = require("./scheduled/tasks/ClearEsTasksIndex");
const bluebird_1 = require("bluebird");
const IrohEntitlementSummaryClient_1 = require("./common/IrohEntitlementSummaryClient");
const DSColdStartFetchDevices_1 = require("./scheduled/tasks/DSColdStartFetchDevices");
const logger = new LambdaLogger_1.LambdaLogger();
const INACTIVE_TENANT_RETENTION_PERIOD = 90 * DateUtils_1.DAY_MILLIS;
const neptuneClientManager = NeptuneClientManager_1.NeptuneClientManager.getInstance();
const triggerScheduledTasks = async () => {
    await new ScheduledTaskRunner_1.ScheduledTaskRunner().triggerTasks();
};
exports.triggerScheduledTasks = triggerScheduledTasks;
const distributeScalableTasks = async () => {
    await new ScalableTaskDispatcher_1.ScalableTaskDispatcher(process.env.TASK_NAME, process.env.TASK_QUEUE_URL, process.env.TASK_STATE_MACHINE_ARN, process.env.SCHEDULED_EVENTBUS_ARN).dispatchTasks();
};
exports.distributeScalableTasks = distributeScalableTasks;
const scheduleMissingTasks = async (event) => {
    await new ScheduledTaskRunner_1.ScheduledTaskRunner().scheduleMissingTasks(event.shard);
};
exports.scheduleMissingTasks = scheduleMissingTasks;
const updateStaleDevices = async (event, context) => {
    const { startRangeInput, tenantUid, taskParams, scrollId, cumulativeTotal } = getAppDataFromEvent(event);
    let actualRetentionPolicy;
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for updateStaleDevices');
    }
    const tenantServices = new TenantServices_1.TenantServices();
    if (!await tenantServices.getTenantById(tenantUid, true)) {
        throw new Error(`tenant with uid ${tenantUid} does not exist`);
    }
    if (_.isUndefined(taskParams === null || taskParams === void 0 ? void 0 : taskParams.retentionPolicy)) {
        actualRetentionPolicy = await new IrohEntitlementSummaryClient_1.IrohEntitlementSummaryClient(tenantUid).getRetentionPolicy();
    }
    else {
        actualRetentionPolicy = taskParams.retentionPolicy;
    }
    if (await tenantServices.isTenantFeatureOn(tenantUid, TenantServices_1.FeatureFlag.ES_BASED_SEARCH)) {
        logger.debug('Update Stale Devices V2 is in use');
        const task = new UpdateStaleDevicesUsingES_1.UpdateStaleDevicesUsingES(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 450000), tenantUid, actualRetentionPolicy, scrollId, cumulativeTotal);
        return task.processTask();
    }
    const task = new UpdateStaleDevices_1.UpdateStaleDevices(tenantUid, actualRetentionPolicy);
    return task.process(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 450000), startRangeInput || 0);
};
exports.updateStaleDevices = updateStaleDevices;
const syncNeptuneToEsDifference = async (event, context) => {
    const { startRangeInput, tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for syncNeptuneToEsDifference');
    }
    const task = new NeptuneToEsDiffSyncTask_1.NeptuneToEsDiffSyncTask(tenantUid);
    await task.process(new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context, 450000), startRangeInput || 0);
};
exports.syncNeptuneToEsDifference = syncNeptuneToEsDifference;
const cleanupShadowSources = async (event, context) => {
    const { startRangeInput, tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for CleanupShadowSources');
    }
    const scheduledTask = new CleanupShadowSources_1.CleanupShadowSources(tenantUid);
    return scheduledTask.process(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 660000), startRangeInput || 0);
};
exports.cleanupShadowSources = cleanupShadowSources;
const clearEsTasksIndex = async () => {
    const scheduledTask = new ClearEsTasksIndex_1.ClearEsTasksIndex(undefined);
    return scheduledTask.process();
};
exports.clearEsTasksIndex = clearEsTasksIndex;
const deleteOldHistoricalData = async (event, context) => {
    const { startRangeInput, tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for DeleteOldHistoricalData');
    }
    const scheduledTask = new DeleteOldHistoricalData_1.DeleteOldHistoricalData(tenantUid);
    return scheduledTask.process(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 450000), startRangeInput || 0);
};
exports.deleteOldHistoricalData = deleteOldHistoricalData;
const closeProducerCurrentStates = async (event, context) => {
    const { startRangeInput, tenantUid, producer } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for closeProducerCurrentStates');
    }
    if (!producer) {
        throw new Error('missing [producer] value, which is mandatory for closeProducerCurrentStates');
    }
    const task = new CloseProducerCurrentStates_1.CloseProducerCurrentStates(tenantUid, producer);
    return task.process(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 660000), startRangeInput || 0);
};
exports.closeProducerCurrentStates = closeProducerCurrentStates;
const deleteTenantData = async (event, context) => {
    const { tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error(`missing [tenantUid] value, which is mandatory for ${context.functionName}`);
    }
    const tenantServices = new TenantServices_1.TenantServices();
    const tenant = await tenantServices.getTenantById(tenantUid, true);
    if (!tenant) {
        throw new Error(`tenant with uid ${tenantUid} does not exist`);
    }
    if (!tenant.deletedAt) {
        throw new Error('cannot delete data for active tenant');
    }
    if (tenant.deletedAt > Date.now() - INACTIVE_TENANT_RETENTION_PERIOD) {
        throw new Error('cannot delete tenant data that must be retained for 90 days');
    }
    const task = new DeleteTenantData_1.DeleteTenantData(tenantUid);
    await task.process(new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context, 450000), 0);
};
exports.deleteTenantData = deleteTenantData;
const cleanupRedundanciesFromES = async (event, context) => {
    const { scrollId, cumulativeTotal, tenantUid } = getAppDataFromEvent(event);
    if (!tenantUid) {
        throw new Error(`missing [tenantUid] value, which is mandatory for ${context.functionName}`);
    }
    const tenantServices = new TenantServices_1.TenantServices();
    const tenant = await tenantServices.getTenantById(tenantUid, true);
    if (!tenant) {
        throw new Error(`tenant with uid ${tenantUid} does not exist`);
    }
    const task = new CleanupRedundanciesFromES_1.CleanupRedundanciesFromES(new TimeBasedAsyncLambdaInvoker_1.TimeBasedAsyncLambdaInvoker(context, 450000), tenantUid, scrollId, cumulativeTotal);
    await task.processTask();
};
exports.cleanupRedundanciesFromES = cleanupRedundanciesFromES;
const triggerDeleteStaleTenantData = async () => {
    const tenantServices = new TenantServices_1.TenantServices();
    const tenants = await tenantServices.getInactiveTenants();
    const staleTenants = _.filter(tenants, tenant => !_.isNil(tenant.deletedAt) && tenant.deletedAt <= Date.now() - INACTIVE_TENANT_RETENTION_PERIOD);
    const scheduledTaskRunner = new ScheduledTaskRunner_1.ScheduledTaskRunner();
    const firstTenant = _.first(staleTenants);
    if (firstTenant) {
        logger.info(`Trigger data deletion for tenant ${firstTenant.id}`);
        return scheduledTaskRunner.triggerTask(new ScheduleServices_1.ScheduledTask(DeleteTenantData_1.DeleteTenantData.TASK_NAME, firstTenant.id, ScheduleServices_1.ScheduleType.NOW));
    }
    return Promise.resolve();
};
exports.triggerDeleteStaleTenantData = triggerDeleteStaleTenantData;
const deleteEmptyStaleTenants = async () => {
    logger.debug('Identifying the tenants that have been created for some time but are not used - should be deleted');
    const emptyTenantRetention = 30 * DateUtils_1.DAY_MILLIS;
    const batchSize = 10;
    let tenantsToDelete = [];
    const tenantServices = new TenantServices_1.TenantServices();
    const tenants = await tenantServices.getAllTenants();
    let totalTenantsToDelete = 0;
    logger.debug(`There are total of ${tenants.length} tenants`);
    for (const tenant of tenants) {
        const tenantProducers = await tenantServices.getProducerConfigurations(tenant.id);
        const deletedTenantProducers = await tenantServices.getDeletedProducerConfigurations(tenant.id);
        if (tenantProducers.length === 0 && deletedTenantProducers.length === 0) {
            const tenantCreatedDate = new Date(tenant.createdAt).getTime();
            const maxRetentionDate = new Date().getTime() - emptyTenantRetention;
            if (tenantCreatedDate < maxRetentionDate) {
                logger.debug(`Tenant ${tenant.id} created at ${tenant.createdAt} should be deleted`);
                totalTenantsToDelete += 1;
                tenantsToDelete.push(tenant);
                if (tenantsToDelete.length >= batchSize) {
                    await deleteTenantsBatch(tenantsToDelete);
                    tenantsToDelete = [];
                }
            }
            else {
                logger.debug(`Tenant ${tenant.id} created at ${tenant.createdAt} is an empty tenant, but still hasn't reached the deletion age for empty tenants`);
            }
        }
        else {
            logger.debug(`Tenant ${tenant.id} created at ${tenant.createdAt} has ${tenantProducers.length} producers, isn't a candidate for deletion`);
        }
    }
    logger.debug(`A total number of ${totalTenantsToDelete} out of ${tenants.length} tenants should be deleted`);
    await deleteTenantsBatch(tenantsToDelete);
};
exports.deleteEmptyStaleTenants = deleteEmptyStaleTenants;
async function deleteTenantsBatch(tenantsBatch) {
    for (const tenant of tenantsBatch) {
        try {
            logger.debug(`will be deleting tenant ${tenant.id}, extId: ${tenant.extId}`);
            await (0, tenant_management_1.deleteTenant)({ tenantUid: tenant.id }, { functionName: 'deleteEmptyStaleTenants' });
            logger.debug(`finished deleting tenant ${tenant.id}, extId: ${tenant.extId}`);
        }
        catch (e) {
            logger.error(`failed to delete tenant ${tenant.id}, extId: ${tenant.extId}. Message: ${e.message}`);
        }
    }
}
const cleanupDeletedSourcesForAllTenants = async (event) => {
    const { whatif } = event;
    const safeWhatif = whatif !== null && whatif !== void 0 ? whatif : false;
    const cds = new CleanupDeletedSources_1.CleanupDeletedSources(safeWhatif);
    await cds.processAllTenants();
};
exports.cleanupDeletedSourcesForAllTenants = cleanupDeletedSourcesForAllTenants;
function getAppDataFromEvent(event) {
    const message = (0, Util_1.parseEvent)(event);
    return {
        startRangeInput: message.startRangeInput,
        scrollId: message.scrollId,
        cumulativeTotal: message.cumulativeTotal,
        tenantUid: message.tenantUid,
        producer: message.producer,
        taskParams: message.taskParams
    };
}
const saveScheduledTask = async (event) => {
    const { name, schedule, tenantUid, producer, overwrite = false } = event;
    validateManagementEvent(name, tenantUid);
    const metadata = await new ScheduleServices_1.ScheduledTaskMetadataServices().getByName(name);
    if (!metadata) {
        throw new Error(`cannot find scheduled task metadata for [${name}]`);
    }
    if (metadata.type === ScheduleServices_1.ScheduleType.NA) {
        throw new Error('cannot save a non-schedule task');
    }
    if (metadata.scope === BatchTaskServices_1.TaskScope.PRODUCER && !producer) {
        throw new Error('missing [producer] value, which is mandatory for [name]');
    }
    if (producer && !_.find(metadata.producerTypeList, producerType => _.startsWith(producer, producerType))) {
        return Promise.resolve();
    }
    const scheduledTask = new ScheduleServices_1.ScheduledTask(name, tenantUid, schedule || metadata.type, producer, metadata.taskParams);
    const scheduleServices = new ScheduleServices_1.ScheduledTaskServices();
    const existingTask = await scheduleServices.getByKey(name, tenantUid, producer);
    if (!existingTask || overwrite) {
        return scheduleServices.save(scheduledTask);
    }
    return Promise.resolve(existingTask);
};
exports.saveScheduledTask = saveScheduledTask;
const deleteScheduledTask = async (event) => {
    const { name, tenantUid, producer } = event;
    validateManagementEvent(name, tenantUid);
    return new ScheduleServices_1.ScheduledTaskServices().delete(name, tenantUid, producer);
};
exports.deleteScheduledTask = deleteScheduledTask;
const validateManagementEvent = (name, tenantUid) => {
    if (!name) {
        throw new Error('missing [name] value, which is mandatory');
    }
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory');
    }
};
const performRegularMonitoring = async (event) => {
    var _a;
    const interval = (_a = event === null || event === void 0 ? void 0 : event.args) === null || _a === void 0 ? void 0 : _a.interval;
    const monitoring = new RegularMonitoring_1.RegularMonitoring(interval);
    const promises = [];
    promises.push(monitoring.identifyUnsuccessfulTenantConfigurationSyncs());
    await Promise.all(promises);
};
exports.performRegularMonitoring = performRegularMonitoring;
const updateAllRelevantScheduling = async () => {
    logger.info('Starting processing all tenants');
    const tenantServices = new TenantServices_1.TenantServices();
    const tenants = await tenantServices.getAllTenants();
    for (const tenant of tenants) {
        logger.info(`Starting process for tenant ${tenant.id}`);
        const isFfOn = await tenantServices.isTenantFeatureOn(tenant.id, TenantServices_1.FeatureFlag.REDUCE_SCHEDULING);
        if (!isFfOn) {
            logger.info(`Tenant ${tenant.id} have no active FF REDUCE_SCHEDULING and will be skipped`);
            continue;
        }
        const producerConfig = await tenantServices.getProducerConfigurations(tenant.id);
        const filteredProducers = _.filter(producerConfig, config => (0, CommonTypes_1.sourceWithLessSync)(config.producerType));
        for (const producer of filteredProducers) {
            logger.info(`Starting process for tenant ${tenant.id} with type ${producer.producerType} and producerId ${producer.producerId}`);
            try {
                if (!(0, Util_1.validateCronIsLessOftenThanExpected)(producer.cronSchedule, DateUtils_1.WEEK_MILLIS)) {
                    const cfgKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
                    const updatedSchedule = (0, Util_1.changeCronFromDailyToWeekly)(producer.cronSchedule);
                    logger.info(`Updating value config of ${cfgKey} on tenant ${tenant.id} cron changed from ${producer.cronSchedule} to ${updatedSchedule}`);
                    const existingProducerConfig = await tenantServices.getTenantConfiguration(tenant.id, cfgKey);
                    const updatedValue = _.merge(JSON.parse((existingProducerConfig === null || existingProducerConfig === void 0 ? void 0 : existingProducerConfig.value) || '{}'), { schedule: updatedSchedule });
                    const cfgVal = JSON.stringify(updatedValue);
                    logger.info(`Updating value config of ${cfgKey} on tenant ${tenant.id} to value: ${cfgVal}`);
                    const updatedConfig = await tenantServices.updateProducerConfiguration(tenant.id, cfgKey, undefined, undefined, cfgVal);
                    logger.info(`Updated value config of ${cfgKey} on tenant ${tenant.id} to value: ${cfgVal}, full config ${updatedConfig}`);
                }
            }
            catch (e) {
                logger.warn(`Update for tenant ${tenant.id}, source ${producer.producerType} ${producer.producerId} was failed `, e);
            }
        }
        logger.info(`Finishing process for tenant ${tenant.id}`);
    }
    logger.info('Finished processing all tenants');
};
exports.updateAllRelevantScheduling = updateAllRelevantScheduling;
const cleanLabelsOnAllDevicesFromNoLongerExisting = async (event) => {
    var _a, _b;
    const { tenantUid } = getAppDataFromEvent(event);
    logger.info(`Starting removing labels from all devices for tenant ${tenantUid} that are not exist more`);
    const labelService = new LabelService_1.LabelService(tenantUid);
    const labels = await labelService.getAllLabels();
    try {
        const esService = new ElasticsearchServices_1.ElasticsearchServices(tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        const countedLabels = await esService.countLabelsAndRuleLabels();
        const existingLabelIds = labels.map(label => label.labelId);
        let toRunLabelCleaning = false;
        let toRunRulesLabelCleaning = false;
        (_a = countedLabels.get('labels')) === null || _a === void 0 ? void 0 : _a.forEach(labelData => {
            if (!existingLabelIds.includes(labelData.key)) {
                logger.info(`Will be deleted label ${labelData.key}, which occurs on ${labelData.doc_count} devices, that does not exist for the tenant: ${tenantUid}`);
                toRunLabelCleaning = true;
            }
        });
        (_b = countedLabels.get('rulesLabels')) === null || _b === void 0 ? void 0 : _b.forEach(labelData => {
            if (!existingLabelIds.includes(labelData.key)) {
                logger.info(`Will be deleted rule based label ${labelData.key}, which occurs on ${labelData.doc_count} devices, that does not exist for the tenant: ${tenantUid}`);
                toRunRulesLabelCleaning = true;
            }
        });
        if (toRunLabelCleaning) {
            await esService.cleanLabelsOnDevicesFromNoLongerExisting(existingLabelIds);
            await (0, bluebird_1.delay)(1000);
        }
        if (toRunRulesLabelCleaning) {
            await esService.cleanRulesLabelsOnDevicesFromNoLongerExisting(existingLabelIds);
        }
    }
    catch (e) {
        logger.error(`Failed to clean labels for tenant: ${tenantUid}, `, e.message());
    }
    logger.info('Finished removing labels from all devices that are not exist more');
};
exports.cleanLabelsOnAllDevicesFromNoLongerExisting = cleanLabelsOnAllDevicesFromNoLongerExisting;
const updateTenantWebhooks = async (event) => {
    const { tenantUid } = (0, Util_1.parseEvent)(event);
    if (!tenantUid) {
        throw new Error('missing [tenantUid] value, which is mandatory for updateTenantWebhooks');
    }
    const sourceOptions = process.env.SOURCE_OPTIONS ? JSON.parse(process.env.SOURCE_OPTIONS) : [];
    for (const sourceOption of sourceOptions) {
        logger.info(`update webhooks for tenant ${tenantUid} with source options ${JSON.stringify(sourceOption)}`);
        await (0, tenant_management_1.updateWebhookForAllTenants)({
            tenantUid,
            source: sourceOption.source,
            forceRefreshWebhooks: sourceOption.forceRefreshWebhooks,
            registerAll: sourceOption.registerAll,
            refreshSecrets: sourceOption.refreshSecrets
        });
    }
};
exports.updateTenantWebhooks = updateTenantWebhooks;
const dsColdStartFetchDevices = async (event, context) => {
    const { startRangeInput, tenantUid, taskParams } = (0, Util_1.parseEvent)(event);
    if (!tenantUid || !taskParams) {
        throw new Error('tenantUid and taskParams are mandatory for dsColdStartFetchDevices');
    }
    const task = new DSColdStartFetchDevices_1.DSColdStartFetchDevices(tenantUid, taskParams);
    return task.process(new TimeBasedAsyncLambdaInvoker_1.BasicTimeBasedLambdaHandler(context, 180000), startRangeInput || 0);
};
exports.dsColdStartFetchDevices = dsColdStartFetchDevices;
