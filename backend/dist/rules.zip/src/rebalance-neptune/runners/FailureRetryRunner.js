"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FailureRetryRunner = void 0;
const RebalanceNeptuneClustersBase_1 = require("./RebalanceNeptuneClustersBase");
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const bluebird_1 = require("bluebird");
class FailureRetryRunner extends RebalanceNeptuneClustersBase_1.RebalanceNeptuneClustersBase {
    async run(logsInFailure) {
        this.logger.info('Start FailureRetryRunner');
        if (logsInFailure.length === 0) {
            this.logger.info('End FailureRetryRunner, no tenant has status EXPORT_FAILED or LOAD_FAILED');
            return;
        }
        await bluebird_1.Promise.map(logsInFailure, async (migrationLog) => {
            const tenantUid = migrationLog.tenantUid;
            try {
                const failedAttempts = migrationLog.failedAttempts || 0;
                if (failedAttempts >= 3) {
                    await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(migrationLog.tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.FAILED, undefined, Date.now());
                    await this.neptuneShardRepo.upsertNeptuneShard({
                        tenantUid: migrationLog.tenantUid,
                        shardId: migrationLog.migrateFromShardId
                    });
                    return;
                }
                if (migrationLog.migrationStatus === NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORT_FAILED) {
                    await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.START, undefined, undefined, failedAttempts + 1);
                    return;
                }
                if (migrationLog.migrationStatus === NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOAD_FAILED) {
                    const logDetails = await this.neptuneShardMigrationLogDetailRepo.getTenantMigrationLogDetails(tenantUid);
                    await bluebird_1.Promise.map(logDetails.filter(l => l.loadStatus !== this.LOADER_COMPLETED_CODE), async (logDetail) => {
                        logDetail.loadId = undefined;
                        logDetail.loadStatus = undefined;
                        logDetail.loadRequestPayload = undefined;
                        await this.neptuneShardMigrationLogDetailRepo.upsert(logDetail);
                    }, { concurrency: 500 });
                    await this.neptuneShardMigrationLogRepo.updateTenantMigrationLog(tenantUid, NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOADING, undefined, undefined, failedAttempts + 1);
                }
            }
            catch (err) {
                this.logger.error(`failed to retry failed steps for tenant ${tenantUid}, error: ${err.message}`);
            }
        });
        this.logger.info('End FailureRetryRunner');
    }
}
exports.FailureRetryRunner = FailureRetryRunner;
