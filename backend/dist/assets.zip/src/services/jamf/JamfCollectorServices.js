"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JamfCollectorServices = void 0;
const _ = __importStar(require("lodash"));
const fast_xml_parser_1 = require("fast-xml-parser");
const Util_1 = require("../../common/Util");
const ComputersCollection_1 = require("./ComputersCollection");
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const TenantServices_1 = require("../../common/TenantServices");
const query_string_1 = __importDefault(require("query-string"));
const JamfMobileDevicesCollection_1 = require("./JamfMobileDevicesCollection");
const JamfEndpointService_1 = require("../../collectors/services/JamfEndpointService");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const AwsSecretsService_1 = require("../../common/AwsSecretsService");
const LIMIT = 200;
class JamfCollectorServices extends Services_1.BasePushCollectorService {
    constructor(secrets, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.functionName = functionName;
        this.webhookSecret = secrets === null || secrets === void 0 ? void 0 : secrets.webhookSecret;
        this.cfgKey = (0, Util_1.toSourceString)('jamf_webhooks_ids', sourceId);
        this.webhookSource = (0, Util_1.toSourceString)(CommonTypes_1.Source.JAMF, sourceId);
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.JAMF, this.sourceId);
        }
    }
    async getComputers(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const bulkLength = limit || LIMIT;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.JAMF));
        const params = {
            'page-size': bulkLength,
            section: ['GENERAL', 'USER_AND_LOCATION', 'HARDWARE', 'OPERATING_SYSTEM', 'DISK_ENCRYPTION', 'SECURITY']
        };
        return new ComputersCollection_1.ComputersCollection(this.client, nextUri || `/api/v1/computers-inventory?${query_string_1.default.stringify(params)}`, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getMobileDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const bulkLength = limit || LIMIT;
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.JAMF));
        const params = {
            'page-size': bulkLength
        };
        return new JamfMobileDevicesCollection_1.JamfMobileDevicesCollection(this.client, nextUri || `/api/v2/mobile-devices?${query_string_1.default.stringify(params)}`, timeBasedAsyncLambdaInvoker, functionState);
    }
    async initWebhookToken() {
        await this.init();
        if (!this.webhookSecret) {
            const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(this.tenantUid);
            await awsSecretsService.init();
            const secrets = awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.JAMF, this.sourceId));
            this.webhookSecret = await this.initWebhookTokenImpl(secrets, CommonTypes_1.Source.JAMF);
        }
    }
    async registerWebhooks() {
        await this.init();
        await this.initWebhookToken();
        if (!process.env.GW_API_PRODUCER_NOTIFICATION_URL) {
            throw new Error('GW_API_PRODUCER_NOTIFICATION_URL is not set');
        }
        for (const ev of _.keys(JamfEndpointService_1.JamfWebhookEvent)) {
            await this.registerWebhook(ev);
        }
    }
    async registerWebhook(event) {
        await this.init();
        this.logger.info(`registering webhook ${event} for tenant ${this.tenantUid}`);
        const req = {
            webhook: {
                event,
                name: `${this.tenantUid}${Util_1.SOURCE_SEPARATOR}${this.sourceId}${Util_1.SOURCE_SEPARATOR}${event}`,
                url: process.env.GW_API_PRODUCER_NOTIFICATION_URL,
                enabled: true,
                content_type: 'application/json',
                authentication_type: 'BASIC',
                username: [this.tenantUid, CommonTypes_1.Source.JAMF, this.sourceId].join(Util_1.SOURCE_SEPARATOR),
                password: this.webhookSecret
            }
        };
        const res = await this.client.getClassicApiAxios().post('/JSSResource/webhooks/id/new', new fast_xml_parser_1.XMLBuilder({}).build(req), {
            headers: {
                Accept: 'application/xml',
                'Content-Type': 'application/xml'
            }
        });
        const webhookId = new fast_xml_parser_1.XMLParser().parse(res.data).webhook.id;
        await this.storeJamfWebhookId(webhookId);
        return webhookId;
    }
    async removeWebhooks() {
        await this.init();
        const registeredWebhooks = await this.getRegisteredWebhooks();
        for (const webhookId of registeredWebhooks) {
            await this.removeWebhook(webhookId);
        }
    }
    async getRegisteredWebhooks() {
        const tenantServices = new TenantServices_1.TenantServices();
        const existingJamfWebhooksConfig = await tenantServices.getTenantConfiguration(this.tenantUid, this.cfgKey);
        if (existingJamfWebhooksConfig) {
            return JSON.parse(existingJamfWebhooksConfig.value);
        }
        return [];
    }
    async removeWebhook(webhookSubscriptionId) {
        await this.init();
        await this.client.getClassicApiAxios().delete(`/JSSResource/webhooks/id/${webhookSubscriptionId}`);
        const tenantServices = new TenantServices_1.TenantServices();
        const existingJamfWebhooksConfig = await tenantServices.getTenantConfiguration(this.tenantUid, this.cfgKey);
        if (existingJamfWebhooksConfig) {
            const parsedJamfWebhooksConfig = JSON.parse(existingJamfWebhooksConfig.value);
            const tenantConfiguration = new TenantServices_1.TenantConfiguration(this.tenantUid, this.cfgKey, JSON.stringify(_.filter(parsedJamfWebhooksConfig, id => id !== webhookSubscriptionId)));
            await tenantServices.updateTenantConfigurationValue(tenantConfiguration);
        }
    }
    async removeFailingWebhooks(failingSourceId, whatIf = true) {
        await this.init();
        const tenantServices = new TenantServices_1.TenantServices();
        const webhookType = this.cfgKey.split(Util_1.SOURCE_SEPARATOR)[0];
        const failingWebhookKey = (0, Util_1.toSourceString)(webhookType, failingSourceId);
        const failingWebhook = await tenantServices.getTenantConfiguration(this.tenantUid, failingWebhookKey);
        if (!failingWebhook) {
            throw new Error(`No webhook found where tenantUid=${this.tenantUid}, source=${webhookType}, sourceId=${failingSourceId}`);
        }
        let failingWebhookIds = JSON.parse(failingWebhook.value) || [];
        if (failingWebhookIds.length === 0) {
            this.logger.error(`No webhook IDs found when removing JAMF webhook where tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.JAMF}, activeSourceId=${this.sourceId}, failingSourceId=${failingSourceId}`);
            throw new Error('No webhook IDs found');
        }
        const errors = [];
        for (const webhookId of failingWebhookIds) {
            try {
                if (!whatIf) {
                    await this.removeWebhook(webhookId);
                    this.logger.debug(`Deleted JAMF webhook ID ${webhookId} where tenantUid=${this.tenantUid}, sourceId=${failingSourceId}`);
                    failingWebhookIds = _.filter(failingWebhookIds, id => id !== webhookId);
                    const updatedTenantConfiguration = new TenantServices_1.TenantConfiguration(this.tenantUid, failingWebhookKey, JSON.stringify(failingWebhookIds));
                    await tenantServices.updateTenantConfigurationValue(updatedTenantConfiguration);
                }
                else {
                    this.logger.debug(`(whatif) will attempt to remove JAMF webhook where id=${webhookId}, tenantUid=${this.tenantUid}, source=${webhookType}, failingSourceId=${failingSourceId} using the credentials from activeSourceId=${this.sourceId}`);
                }
            }
            catch (ex) {
                this.logger.error(`Error occurred removing JAMF webhook where error=${ex.message}, tenantUid=${this.tenantUid}, source=${CommonTypes_1.Source.JAMF}, activeSourceId=${this.sourceId}, failingSourceId=${failingSourceId}, webhookId=${webhookId}`);
                errors.push(ex);
            }
        }
        if (errors.length > 0) {
            return Promise.reject(errors);
        }
        return Promise.resolve(true);
    }
    async storeJamfWebhookId(webhookId) {
        const tenantServices = new TenantServices_1.TenantServices();
        const existingJamfWebhooksConfig = await tenantServices.getTenantConfiguration(this.tenantUid, this.cfgKey);
        if (!existingJamfWebhooksConfig) {
            const tenantConfiguration = new TenantServices_1.TenantConfiguration(this.tenantUid, this.cfgKey, JSON.stringify([webhookId]));
            await tenantServices.addTenantConfiguration(tenantConfiguration);
        }
        else {
            const parsedJamfWebhooksConfig = JSON.parse(existingJamfWebhooksConfig.value);
            const tenantConfiguration = new TenantServices_1.TenantConfiguration(this.tenantUid, this.cfgKey, JSON.stringify([...parsedJamfWebhooksConfig, webhookId]));
            await tenantServices.updateTenantConfigurationValue(tenantConfiguration);
        }
    }
    async hasRegisteredWebhooks() {
        await this.init();
        const registeredWebhooks = await this.getRegisteredWebhooks();
        return !_.isEmpty(registeredWebhooks);
    }
    async removeWebhookSecrets(sourceString, secrets) {
        if (secrets === null || secrets === void 0 ? void 0 : secrets.webhookSecret) {
            await super.removeWebhookSecrets(sourceString, secrets);
        }
        this.webhookSecret = undefined;
    }
    async getWebhookStatus() {
        var _a, _b, _c, _d;
        await this.init();
        const registeredWebhooks = await this.getRegisteredWebhooks();
        if (_.isEmpty(registeredWebhooks)) {
            return this.errorStatus(this.webhookSource, 'No webhook registered', 'JAMF webhooks are not registered', false);
        }
        const disabledWebhooks = [];
        let expectedEventTypes = _.keys(JamfEndpointService_1.JamfWebhookEvent);
        for (const webhookId of registeredWebhooks) {
            let webhookDetails;
            try {
                webhookDetails = await this.client.getClassicApiAxios().get(`/JSSResource/webhooks/id/${webhookId}`);
            }
            catch (e) {
                return this.errorStatus(this.webhookSource, 'Error fetching webhook status', `get webhook ${webhookId} returned status ${e.response.status} ${e.response.statusText}`, true, `response error: ${(_b = (_a = e.response) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.error}, response error description: ${(_d = (_c = e.response) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.error_description}`);
            }
            if (!_.get(webhookDetails.data, 'webhook.enabled')) {
                disabledWebhooks.push(webhookId);
            }
            expectedEventTypes = _.without(expectedEventTypes, _.get(webhookDetails.data, 'webhook.event'));
        }
        if (!_.isEmpty(disabledWebhooks)) {
            return this.errorStatus(this.webhookSource, 'Not all webhooks are enabled', `disabled webhooks ${disabledWebhooks}`);
        }
        if (!_.isEmpty(expectedEventTypes)) {
            return this.errorStatus(this.webhookSource, 'Missing expected webhooks', `No webhooks registered for event types ${expectedEventTypes}`);
        }
        return new Services_1.WebhookStatus(this.webhookSource, 'success');
    }
}
exports.JamfCollectorServices = JamfCollectorServices;
