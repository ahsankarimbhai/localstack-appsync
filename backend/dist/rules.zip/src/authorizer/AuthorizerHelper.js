"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.shouldBlockTenantAndSource = exports.isDataSharingWebhooksApi = exports.isIncidentApi = exports.isSystemApi = exports.getHttpMethod = exports.getPolicyDocument = exports.EFFECT = void 0;
const lodash_1 = __importDefault(require("lodash"));
var EFFECT;
(function (EFFECT) {
    EFFECT["ALLOW"] = "Allow";
    EFFECT["DENY"] = "Deny";
})(EFFECT = exports.EFFECT || (exports.EFFECT = {}));
const getPolicyDocument = (effect, resource) => {
    const statementOne = {
        Action: 'execute-api:Invoke',
        Effect: effect,
        Resource: resource
    };
    return {
        Version: '2012-10-17',
        Statement: [statementOne]
    };
};
exports.getPolicyDocument = getPolicyDocument;
const getHttpMethod = (methodArn) => {
    const tmp = methodArn.split(':');
    const apiGatewayArnTmp = tmp[5].split('/');
    return apiGatewayArnTmp[2];
};
exports.getHttpMethod = getHttpMethod;
const isSystemApi = (methodArn) => {
    const tmp = methodArn.split(':');
    const apiGatewayArnTmp = tmp[5].split('/');
    return lodash_1.default.isEqual(apiGatewayArnTmp[3], 'system');
};
exports.isSystemApi = isSystemApi;
const isIncidentApi = (methodArn) => {
    const tmp = methodArn.split(':');
    const apiGatewayArnTmp = tmp[5].split('/');
    return lodash_1.default.isEqual(apiGatewayArnTmp[3], 'incidents');
};
exports.isIncidentApi = isIncidentApi;
const isDataSharingWebhooksApi = (methodArn) => {
    const tmp = methodArn.split(':');
    const apiGatewayArnTmp = tmp[5].split('/');
    return lodash_1.default.isEqual(apiGatewayArnTmp[3], 'webhooks');
};
exports.isDataSharingWebhooksApi = isDataSharingWebhooksApi;
const shouldBlockTenantAndSource = (tenantUid, sourceType, sourceId) => {
    const denylist = [
        { tenantUid: 'e518ee86-044f-42df-b557-13a3af7e29e0', sourceId: 'ed2f6e76-0d33-4831-b945-d47a90500cb5', sourceType: 'JAMF' }
    ];
    for (const item of denylist) {
        if (item.tenantUid === tenantUid && item.sourceId === sourceId && item.sourceType === sourceType) {
            return true;
        }
    }
    return false;
};
exports.shouldBlockTenantAndSource = shouldBlockTenantAndSource;
