"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RetrofitTenantConfigScheduleTask = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const TenantServices_1 = require("../../common/TenantServices");
const CommonTypes_1 = require("../../common/CommonTypes");
const Util_1 = require("../../common/Util");
const bluebird_1 = require("bluebird");
const lodash_1 = __importDefault(require("lodash"));
class RetrofitTenantConfigScheduleTask extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor() {
        super(...arguments);
        this.tenantServices = new TenantServices_1.TenantServices();
    }
    async execute() {
        const updates = await this.prepareTenantConfigWithSchedules();
        await this.retrofitTenantConfigs(updates);
        return bluebird_1.Promise.resolve();
    }
    async prepareTenantConfigWithSchedules() {
        const updates = [];
        const isGlobalReduceScheduleTurnedOn = await this.isGlobalReduceScheduleTurnedOn();
        const tenants = await this.tenantServices.getAllTenants();
        for (const tenant of tenants) {
            try {
                const tenantConfigs = await this.tenantServices.getTenantConfigurations(tenant.id);
                const isTenantReduceScheduleTurnedOn = this.isTenantReduceScheduleTurnedOn(tenantConfigs);
                const producerConfigs = this.tenantServices.mapToProducerConfigurations(tenantConfigs);
                for (const producer of producerConfigs) {
                    if (!producer.irohModuleInstanceId
                        || producer.producerType === CommonTypes_1.Source.ORBITAL
                        || producer.cronSchedule !== undefined) {
                        continue;
                    }
                    const configKey = (0, Util_1.toSourceString)(producer.producerType, producer.producerId);
                    const producerConfigValue = tenantConfigs.find(config => config.tenantKey === TenantServices_1.TenantServices.getTenantConfigKey(tenant.id, configKey)).value;
                    const shouldScheduleOnceAWeek = this.shouldScheduleOnceAWeek(isGlobalReduceScheduleTurnedOn, isTenantReduceScheduleTurnedOn, producer.producerType);
                    updates.push({
                        tenantUid: tenant.id,
                        configKey,
                        valueBefore: producerConfigValue,
                        valueAfter: JSON.stringify(lodash_1.default.merge(JSON.parse(producerConfigValue), { schedule: shouldScheduleOnceAWeek ? (0, Util_1.generateCronOnceAWeek)() : (0, Util_1.generateCronOnceADay)() }))
                    });
                }
            }
            catch (err) {
                this.logger.error(`Error when preparing update schedule data for tenant ${tenant.id}, err: ${err.message}`);
                throw err;
            }
        }
        return updates;
    }
    async retrofitTenantConfigs(updates) {
        this.logger.info(`start updating tenant configs with schedule data, total ${updates.length} items will be processed.`);
        let hasErr = false;
        await bluebird_1.Promise.map(updates, async (item) => {
            try {
                this.logger.info(`updating tenant config entry ${JSON.stringify(item)}`);
                await this.tenantServices.updateProducerConfiguration(item.tenantUid, item.configKey, undefined, undefined, item.valueAfter);
            }
            catch (err) {
                hasErr = true;
                this.logger.error(`Error when updating tenant config entry ${JSON.stringify(item)}, error: ${err}`);
            }
        }, { concurrency: 500 });
        if (hasErr) {
            throw new Error('Error occurred when retrofitting tenant config schedule data');
        }
    }
    async isGlobalReduceScheduleTurnedOn() {
        const featureFlags = await this.tenantServices.getGlobalFeatureFlags();
        return featureFlags.includes(TenantServices_1.FeatureFlag.REDUCE_SCHEDULING);
    }
    isTenantReduceScheduleTurnedOn(tenantConfigs) {
        const tenantFeatures = tenantConfigs.find(config => config.tenantKey === TenantServices_1.TenantServices.getTenantConfigKey(config.tenantUid, 'featureFlags'));
        const tenantFeatureFlags = tenantFeatures ? JSON.parse(tenantFeatures.value) : [];
        return tenantFeatureFlags.includes(TenantServices_1.FeatureFlag.REDUCE_SCHEDULING);
    }
    shouldScheduleOnceAWeek(isGlobalReduceScheduleTurnedOn, isTenantReduceScheduleTurnedOn, producerSource) {
        return (isGlobalReduceScheduleTurnedOn || isTenantReduceScheduleTurnedOn) && (0, CommonTypes_1.sourceWithLessSync)(producerSource);
    }
    getTaskName() {
        return RetrofitTenantConfigScheduleTask.TASK_NAME;
    }
}
exports.RetrofitTenantConfigScheduleTask = RetrofitTenantConfigScheduleTask;
RetrofitTenantConfigScheduleTask.TASK_NAME = 'retrofit-tenant-config-schedule-task';
