"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAttr = exports.UnifiedConnectorNotificationDataAttributeType = exports.UnifiedConnectorNotificationDataAttributeAction = void 0;
const _ = __importStar(require("lodash"));
var UnifiedConnectorNotificationDataAttributeAction;
(function (UnifiedConnectorNotificationDataAttributeAction) {
    UnifiedConnectorNotificationDataAttributeAction["changed"] = "changed";
    UnifiedConnectorNotificationDataAttributeAction["added"] = "added";
    UnifiedConnectorNotificationDataAttributeAction["deleted"] = "deleted";
})(UnifiedConnectorNotificationDataAttributeAction = exports.UnifiedConnectorNotificationDataAttributeAction || (exports.UnifiedConnectorNotificationDataAttributeAction = {}));
var UnifiedConnectorNotificationDataAttributeType;
(function (UnifiedConnectorNotificationDataAttributeType) {
    UnifiedConnectorNotificationDataAttributeType["unsupported"] = "unsupported";
    UnifiedConnectorNotificationDataAttributeType["disk"] = "disk";
    UnifiedConnectorNotificationDataAttributeType["nic"] = "nic";
    UnifiedConnectorNotificationDataAttributeType["ipv4"] = "ipv4";
    UnifiedConnectorNotificationDataAttributeType["ipv6"] = "ipv6";
    UnifiedConnectorNotificationDataAttributeType["hostname"] = "hostname";
    UnifiedConnectorNotificationDataAttributeType["software"] = "software";
    UnifiedConnectorNotificationDataAttributeType["serial"] = "serial";
    UnifiedConnectorNotificationDataAttributeType["domainname"] = "domainname";
    UnifiedConnectorNotificationDataAttributeType["name"] = "name";
    UnifiedConnectorNotificationDataAttributeType["partid"] = "partid";
    UnifiedConnectorNotificationDataAttributeType["hwid"] = "hwid";
    UnifiedConnectorNotificationDataAttributeType["mac"] = "mac";
    UnifiedConnectorNotificationDataAttributeType["major"] = "major";
    UnifiedConnectorNotificationDataAttributeType["minor"] = "minor";
    UnifiedConnectorNotificationDataAttributeType["patch"] = "patch";
    UnifiedConnectorNotificationDataAttributeType["build"] = "build";
    UnifiedConnectorNotificationDataAttributeType["arch"] = "arch";
    UnifiedConnectorNotificationDataAttributeType["kernel"] = "kernel";
    UnifiedConnectorNotificationDataAttributeType["product"] = "product";
    UnifiedConnectorNotificationDataAttributeType["suite"] = "suite";
    UnifiedConnectorNotificationDataAttributeType["deployment"] = "deployment";
})(UnifiedConnectorNotificationDataAttributeType = exports.UnifiedConnectorNotificationDataAttributeType || (exports.UnifiedConnectorNotificationDataAttributeType = {}));
const getAttr = (uc, attrType, attrName = 'value') => _.toString(_.get(_.find(uc.attributes, (attr) => attr.type === attrType && _.includes([
    UnifiedConnectorNotificationDataAttributeAction.added,
    UnifiedConnectorNotificationDataAttributeAction.changed
], attr.action)), attrName));
exports.getAttr = getAttr;
