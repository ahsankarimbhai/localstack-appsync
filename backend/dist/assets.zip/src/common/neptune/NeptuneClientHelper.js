"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNeptuneShardUrl = exports.getNeptuneShardById = exports.getNeptuneShardSettings = exports.isConnectionError = void 0;
const connErrorMessageList = [
    'websocket is not open',
    'connection has been closed'
];
function isConnectionError(err) {
    if (!err || !err.message) {
        return false;
    }
    return connErrorMessageList.some(errMsg => err.message.toLowerCase().includes(errMsg));
}
exports.isConnectionError = isConnectionError;
function getNeptuneShardSettings() {
    const clusterSettings = JSON.parse(process.env.NEPTUNE_CLUSTER_SETTINGS || '[]');
    if (clusterSettings.length === 0) {
        throw new Error('Environment variable NEPTUNE_CLUSTER_SETTINGS is not set correctly');
    }
    return clusterSettings;
}
exports.getNeptuneShardSettings = getNeptuneShardSettings;
function getNeptuneShardById(shardId) {
    const setting = getNeptuneShardSettings().find(item => item.shardId === shardId);
    if (!setting) {
        throw new Error(`Environment variable NEPTUNE_CLUSTER_SETTINGS is not set for shardId ${shardId}`);
    }
    return setting;
}
exports.getNeptuneShardById = getNeptuneShardById;
function getNeptuneShardUrl(shardId, readOnly) {
    const setting = getNeptuneShardById(shardId);
    return `ws://${process.env.LOCALSTACK_HOSTNAME}:4510/gremlin`;
}
exports.getNeptuneShardUrl = getNeptuneShardUrl;
