"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FunctionState = exports.FunctionStateServices = void 0;
const _ = __importStar(require("lodash"));
const DynamoDBServices_1 = require("./awsclient/dynamodb/DynamoDBServices");
const Util_1 = require("./Util");
const LambdaLogger_1 = require("./LambdaLogger");
const DynamodbServiceFactory_1 = require("./awsclient/dynamodb/DynamodbServiceFactory");
class FunctionStateServices {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    static getState(functionState) {
        return (0, Util_1.parseJSONString)(functionState.getState());
    }
    save(functionState) {
        functionState.lastUpdated = Date.now();
        return this.dynamoDBServices.save(FunctionState.TABLE_NAME, functionState);
    }
    async getByKey(tenantUid, functionName, producer) {
        const key = FunctionState.createFunctionStateKey(tenantUid, functionName, producer);
        const { lastSuccessfulSequence, lastUpdated, state } = await this.dynamoDBServices.getByKey(FunctionState.TABLE_NAME, FunctionState.FUNCTION_STATE_KEY, key) || {};
        return new FunctionState(key, lastSuccessfulSequence, lastUpdated, state);
    }
    async removeTenantFunctionStates(tenantUid) {
        this.logger.info(`Function states for the tenant ${tenantUid} will be deleted`);
        return this.deleteFunctionStates(await this.getTenantAllFunctionStates(tenantUid));
    }
    deleteFunctionStates(functionStatesToDelete) {
        return Promise.all(_.map(functionStatesToDelete, (functionState) => this.deleteByKey(functionState.functionStateKey)));
    }
    async deleteByKey(functionStateKey) {
        return this.dynamoDBServices.delete(FunctionState.TABLE_NAME, FunctionState.FUNCTION_STATE_KEY, functionStateKey);
    }
    async getTenantAllFunctionStates(tenantUid, lastEvaluatedKey) {
        let returnItems = [];
        const response = await this.dynamoDBServices.getFilteredTableEntries(FunctionState.TABLE_NAME, `contains(${FunctionState.FUNCTION_STATE_KEY}, :key)`, { ':key': tenantUid }, lastEvaluatedKey);
        if (response.lastEvaluatedKey) {
            returnItems = await this.getTenantAllFunctionStates(tenantUid, response.lastEvaluatedKey);
        }
        return _.concat(returnItems, response.items);
    }
}
exports.FunctionStateServices = FunctionStateServices;
class FunctionState {
    constructor(functionStateKey, lastSuccessfulSequence, lastUpdated, state) {
        this.functionStateKey = functionStateKey;
        this.lastSuccessfulSequence = lastSuccessfulSequence || 0;
        this.lastUpdated = lastUpdated || Date.now();
        this.state = state || JSON.stringify({});
    }
    static createFunctionStateKey(tenantUid, functionName, producer) {
        return [tenantUid, functionName, producer].join(DynamoDBServices_1.DynamoDBServices.KEY_SEPARATOR);
    }
    setState(state) {
        this.state = state;
    }
    getState() {
        return this.state;
    }
}
exports.FunctionState = FunctionState;
FunctionState.TABLE_NAME = 'function-state';
FunctionState.FUNCTION_STATE_KEY = 'functionStateKey';
FunctionState.URI_ON_FAILURE = 'uriOnFailure';
FunctionState.COLLECTION_ERROR = 'collectionError';
