"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UmbrellaProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const UmbrellaEndpointService_1 = require("../../collectors/services/UmbrellaEndpointService");
class UmbrellaProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(roamingComputer, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, roamingComputer.name, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new UmbrellaEndpointService_1.UmbrellaEndpointService(tenantUid, sourceId);
    }
}
exports.UmbrellaProcessorServices = UmbrellaProcessorServices;
