"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const lodash_1 = __importDefault(require("lodash"));
const LambdaLogger_1 = require("../common/LambdaLogger");
const TenantServices_1 = require("../common/TenantServices");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
process.env.AWS_REGION = 'us-east-1';
const logger = new LambdaLogger_1.LambdaLogger();
const secretsManager = new client_secrets_manager_1.SecretsManagerClient({ logger });
async function main() {
    const envPrefixes = [
        'opeer-dev',
        'jroschak-dev',
        'olfreyla-dev',
        'vdineva-dev',
        'ymanusov-dev',
        'yvaisman-dev',
        'ci',
        'staging'
    ];
    const tenantSecrets = [];
    for (const envPrefix of envPrefixes) {
        process.env.ENV_PREFIX = `${envPrefix}-posaas`;
        const tenantServices = new TenantServices_1.TenantServices();
        const secretNames = lodash_1.default.map(await tenantServices.getAllTenants(), tenant => `posture-${tenant.id}`);
        logger.info(`${envPrefix} ${secretNames.length}`);
        tenantSecrets.push(secretNames);
    }
    const existingSecrets = lodash_1.default.map(await getAllSecrets(), 'Name');
    const postureSecrets = lodash_1.default.filter(existingSecrets, secret => lodash_1.default.startsWith(secret, 'posture-')
        && !lodash_1.default.endsWith(secret, 'global')
        && !secret.includes('11111111-1111-1111-1111-111111111111'));
    const unusedSecrets = lodash_1.default.difference(postureSecrets, lodash_1.default.flatten(tenantSecrets));
    for (const unusedSecret of unusedSecrets) {
        logger.info(`deleting secret ${unusedSecret}`);
        await secretsManager.send(new client_secrets_manager_1.DeleteSecretCommand({
            SecretId: unusedSecret,
            RecoveryWindowInDays: 7
        }));
    }
}
async function getAllSecrets(token) {
    let returnItems = [];
    const secrets = await secretsManager.send(new client_secrets_manager_1.ListSecretsCommand({ MaxResults: 100, NextToken: token }));
    if (secrets.NextToken) {
        returnItems = await getAllSecrets(secrets.NextToken);
    }
    return lodash_1.default.concat(returnItems, secrets.SecretList);
}
logger.info('CleanupUnusedSecrets');
const start = Date.now();
main()
    .then(res => logger.info(res))
    .finally(() => {
    logger.info('CleanupUnusedSecrets runtime', Date.now() - start);
});
