"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InTuneCollection = void 0;
const Collection_1 = require("../../common/Collection");
function extractNextLink(res) {
    return res.data['@odata.nextLink'];
}
function extractData(res) {
    return res.data.value;
}
class InTuneCollection extends Collection_1.Collection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker) {
        super(client, uri, extractNextLink, extractData, timeBasedAsyncLambdaInvoker);
    }
}
exports.InTuneCollection = InTuneCollection;
