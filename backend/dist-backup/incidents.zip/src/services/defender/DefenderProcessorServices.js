"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefenderProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const DefenderEndpointService_1 = require("../../collectors/services/DefenderEndpointService");
class DefenderProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(device, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, device.computerDnsName, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        if (Array.isArray(device.ipAddresses)) {
            for (const address of device.ipAddresses) {
                if (address.macAddress) {
                    await this.verifyChange(currentTopology, address.macAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
                    break;
                }
            }
        }
        await this.verifyChange(currentTopology, device.lastExternalIpAddress, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new DefenderEndpointService_1.DefenderEndpointService(tenantUid, sourceId);
    }
}
exports.DefenderProcessorServices = DefenderProcessorServices;
