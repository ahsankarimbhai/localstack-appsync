"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureUserStateModelService = exports.AzureUserStateModel = exports.AzureUserModelService = exports.AzureUserModel = void 0;
const _ = __importStar(require("lodash"));
const BaseGraphElement_1 = require("./BaseGraphElement");
const CommonTypes_1 = require("../common/CommonTypes");
const BaseGraphService_1 = require("./BaseGraphService");
class AzureUserModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.AZURE_USER;
    }
    async initProperties(azureUser) {
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, azureUser.id);
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.AzureUserModel = AzureUserModel;
class AzureUserModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new AzureUserModel(this.partitionKey);
    }
}
exports.AzureUserModelService = AzureUserModelService;
class AzureUserStateModel extends BaseGraphElement_1.BaseGraphVertex {
    constructor() {
        super(...arguments);
        this.type = CommonTypes_1.VertexType.AZURE_USER_STATE;
    }
    async initProperties(azureUser) {
        let timestamp;
        this.setProperty(CommonTypes_1.VertexBasicProperty.EXT_ID, this.calculateHash(_.omit(azureUser, ['lastSyncDateTime'])));
        this.setProperty(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, Date.now());
        _.forEach(_.toPairs(azureUser), (pair) => {
            if (pair[0] === 'id') {
                return;
            }
            switch (pair[0]) {
                case AzureUserStateModel.DISPLAY_NAME:
                    this.setProperty(AzureUserStateModel.DISPLAY_NAME, pair[1]);
                    this.setProperty(CommonTypes_1.VertexBasicProperty.NAME, pair[1]);
                    break;
                case AzureUserStateModel.SIGNIN_ACTIVITY:
                    timestamp = Date.parse(pair[1].lastSignInDateTime);
                    if (!Number.isNaN(timestamp)) {
                        this.setProperty(AzureUserStateModel.LAST_SIGNIN_DATETIME, pair[1].lastSignInDateTime);
                    }
                    break;
                default:
                    this.setProperty(_.camelCase(pair[0]), pair[1]);
            }
        });
    }
    getKeyProperties() {
        return [CommonTypes_1.VertexBasicProperty.EXT_ID];
    }
}
exports.AzureUserStateModel = AzureUserStateModel;
AzureUserStateModel.EXTERNAL_PROPERTIES = [];
AzureUserStateModel.ACCOUNT_ENABLED = 'accountEnabled';
AzureUserStateModel.BLOCK_SIGNIN = 'blockSignin';
AzureUserStateModel.BUSINESS_PHONES = 'businessPhones';
AzureUserStateModel.COMPANY_NAME = 'companyName';
AzureUserStateModel.CREATED_DATETIME = 'createdDateTime';
AzureUserStateModel.DELETED_DATETIME = 'deletedDateTime';
AzureUserStateModel.DISPLAY_NAME = 'displayName';
AzureUserStateModel.DEPARTMENT = 'department';
AzureUserStateModel.EMPLOYEE_ID = 'employeeId';
AzureUserStateModel.EMPLOYEE_HIRE_DATETIME = 'employeeHireDate';
AzureUserStateModel.EMPLOYEE_LEAVE_DATETIME = 'employeeLeaveDateTime';
AzureUserStateModel.EMPLOYEE_TYPE = 'employeeType';
AzureUserStateModel.GIVEN_NAME = 'givenName';
AzureUserStateModel.ID = 'id';
AzureUserStateModel.IDENTITIES = 'identities';
AzureUserStateModel.JOB_TITLE = 'jobTitle';
AzureUserStateModel.LAST_PASSWORD_CHANGE_DATETIME = 'lastPasswordChangeDateTime';
AzureUserStateModel.LAST_SIGNIN_DATETIME = 'lastSignInDateTime';
AzureUserStateModel.MAIL = 'mail';
AzureUserStateModel.MANAGER = 'manager';
AzureUserStateModel.MAIL_NICKNAME = 'mailNickname';
AzureUserStateModel.MOBILE_PHONE = 'mobilePhone';
AzureUserStateModel.OFFICE_LOCATION = 'officeLocation';
AzureUserStateModel.ONPREM_DN = 'onPremisesDistinguishedName';
AzureUserStateModel.ONPREM_DOMAIN = 'onPremisesDomainName';
AzureUserStateModel.ONPREM_IMMUTABLE_ID = 'onPremisesImmutableId';
AzureUserStateModel.ONPREM_SAM = 'onPremisesSamAccountName';
AzureUserStateModel.ONPREM_SID = 'onPremisesSecurityIdentifier';
AzureUserStateModel.ONPREM_UPN = 'onPremisesUserPrincipalName';
AzureUserStateModel.OTHER_MAILS = 'otherMails';
AzureUserStateModel.OWNED_DEVICES = 'ownedDevices';
AzureUserStateModel.PASSWORD_POLICIES = 'passwordPolicies';
AzureUserStateModel.SECURITY_IDENTIFIER = 'securityIdentifier';
AzureUserStateModel.SURNAME = 'surname';
AzureUserStateModel.SIGNIN_ACTIVITY = 'signInActivity';
AzureUserStateModel.USAGE_LOCATION = 'usageLocation';
AzureUserStateModel.USER_PRINCIPAL_NAME = 'userPrincipalName';
AzureUserStateModel.USER_TYPE = 'userType';
AzureUserStateModel.GROUP_IDS = 'groupIds';
AzureUserStateModel.GROUP_NAMES = 'groupNames';
AzureUserStateModel.GROUP_DESCRIPTIONS = 'groupDescriptions';
class AzureUserStateModelService extends BaseGraphService_1.BaseVertexService {
    createInstance() {
        return new AzureUserStateModel(this.partitionKey);
    }
}
exports.AzureUserStateModelService = AzureUserStateModelService;
