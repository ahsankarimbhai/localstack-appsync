"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneMigrationStateTracker = void 0;
const BasicScheduledTaskProcessor_1 = require("../scheduled/BasicScheduledTaskProcessor");
const BatchTaskServices_1 = require("../common/BatchTaskServices");
const DateUtils_1 = require("../common/DateUtils");
const LambdaServices_1 = require("../common/LambdaServices");
const NeptuneShardMigrationLogRepo_1 = require("../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const ThrottleTenantForMigrationRunner_1 = require("./runners/ThrottleTenantForMigrationRunner");
const RefreshExportStatusRunner_1 = require("./runners/RefreshExportStatusRunner");
const RefreshLoadStatusRunner_1 = require("./runners/RefreshLoadStatusRunner");
const FailureRetryRunner_1 = require("./runners/FailureRetryRunner");
const bluebird_1 = require("bluebird");
class NeptuneMigrationStateTracker extends BasicScheduledTaskProcessor_1.BasicScheduledTaskProcessor {
    constructor() {
        super(BatchTaskServices_1.TaskScope.GLOBAL, undefined);
        this.neptuneShardMigrationLogRepo = new NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationLogRepo();
        this.lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
        this.throttleTenantForMigrationRunner = new ThrottleTenantForMigrationRunner_1.ThrottleTenantForMigrationRunner();
        this.refreshExportStatusRunner = new RefreshExportStatusRunner_1.RefreshExportStatusRunner();
        this.refreshLoadStatusRunner = new RefreshLoadStatusRunner_1.RefreshLoadStatusRunner();
        this.failureRetryRunner = new FailureRetryRunner_1.FailureRetryRunner();
        this.EXPORT_NEPTUNE_DATA_LAMBDA_NAME = `${process.env.ENV_PREFIX}-export-neptune-data`;
        this.BULK_LOAD_NEPTUNE_DATA_LAMBDA_NAME = `${process.env.ENV_PREFIX}-bulk-load-neptune-data`;
    }
    async execute() {
        const logsInProgress = await this.neptuneShardMigrationLogRepo.getLogsByStatus([
            NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.START,
            NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORTING,
            NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORT_FAILED,
            NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOADING,
            NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOAD_FAILED
        ]);
        if (logsInProgress.length === 0) {
            await this.throttleTenantForMigrationRunner.run();
            return bluebird_1.Promise.resolve();
        }
        const tenantsToExport = logsInProgress
            .filter(l => l.migrationStatus === NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.START && l.startAt && l.startAt < (Date.now() - DateUtils_1.MINUTE_IN_MILLIS * 15))
            .map(l => l.tenantUid);
        if (tenantsToExport.length > 0) {
            this.logger.info(`found tenants ready to be exported, trigger ${this.EXPORT_NEPTUNE_DATA_LAMBDA_NAME}`);
            await this.lambdaServices.asyncInvoke(this.EXPORT_NEPTUNE_DATA_LAMBDA_NAME, JSON.stringify({ tenants: tenantsToExport }));
        }
        const logsInExporting = logsInProgress.filter(l => l.migrationStatus === NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORTING);
        if (logsInExporting.length > 0) {
            const tenantsToLoad = await this.refreshExportStatusRunner.run(logsInExporting);
            if (tenantsToLoad.length > 0) {
                this.logger.info(`found tenants ready to be loaded, trigger ${this.BULK_LOAD_NEPTUNE_DATA_LAMBDA_NAME}`);
                await this.lambdaServices.asyncInvoke(this.BULK_LOAD_NEPTUNE_DATA_LAMBDA_NAME, JSON.stringify({ tenants: tenantsToLoad }));
            }
        }
        const logsInLoading = logsInProgress.filter(l => l.migrationStatus === NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOADING);
        if (logsInLoading.length > 0) {
            const tenantsToLoad = await this.refreshLoadStatusRunner.run(logsInLoading);
            if (tenantsToLoad.length > 0) {
                this.logger.info(`found tenants ready to be loaded, trigger ${this.BULK_LOAD_NEPTUNE_DATA_LAMBDA_NAME}`);
                await this.lambdaServices.asyncInvoke(this.BULK_LOAD_NEPTUNE_DATA_LAMBDA_NAME, JSON.stringify({ tenants: tenantsToLoad }));
            }
        }
        const logsInFailure = logsInProgress.filter(l => l.migrationStatus === NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.EXPORT_FAILED || l.migrationStatus === NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.LOAD_FAILED);
        if (logsInFailure.length > 0) {
            await this.failureRetryRunner.run(logsInFailure);
        }
        return bluebird_1.Promise.resolve();
    }
    getTaskName() {
        return NeptuneMigrationStateTracker.TASK_NAME;
    }
}
exports.NeptuneMigrationStateTracker = NeptuneMigrationStateTracker;
NeptuneMigrationStateTracker.TASK_NAME = 'neptune-migration-state-tracker';
