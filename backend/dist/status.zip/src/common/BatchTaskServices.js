"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchTaskServices = exports.BatchTaskMetadataServices = exports.BatchTask = exports.BatchTaskMetadata = exports.TaskScope = void 0;
const _ = __importStar(require("lodash"));
const DynamoDBServices_1 = require("./awsclient/dynamodb/DynamoDBServices");
const CommonTypes_1 = require("./CommonTypes");
const LambdaLogger_1 = require("./LambdaLogger");
const DynamodbServiceFactory_1 = require("./awsclient/dynamodb/DynamodbServiceFactory");
var TaskScope;
(function (TaskScope) {
    TaskScope["GLOBAL"] = "global";
    TaskScope["TENANT"] = "tenant";
    TaskScope["PRODUCER"] = "producer";
})(TaskScope = exports.TaskScope || (exports.TaskScope = {}));
class BatchTaskMetadata {
    constructor(name, scope, producerTypeList = (0, CommonTypes_1.allSources)(), taskParams, allowParallel) {
        this.name = name;
        this.scope = scope;
        this.producerTypeList = producerTypeList;
        this.taskParams = taskParams;
        this.allowParallel = allowParallel;
        this.created = Date.now();
    }
}
exports.BatchTaskMetadata = BatchTaskMetadata;
BatchTaskMetadata.TABLE_NAME_SUFFIX = 'task-metadata';
BatchTaskMetadata.SCOPE_INDEX_NAME = DynamoDBServices_1.DynamoDBServices.getTableName('task-scope');
BatchTaskMetadata.NAME = 'name';
BatchTaskMetadata.SCOPE = 'scope';
class BatchTask {
    constructor(name, tenantUid, producer, taskParams) {
        this.name = name;
        this.tenantUid = tenantUid;
        this.producer = producer;
        this.taskParams = taskParams;
        this.created = Date.now();
        this.taskKey = BatchTask.getKey(name, tenantUid, producer);
    }
    static getKey(name, tenantUid, producer) {
        return _.join(_.compact([name, tenantUid, producer]), DynamoDBServices_1.DynamoDBServices.KEY_SEPARATOR);
    }
}
exports.BatchTask = BatchTask;
BatchTask.TABLE_NAME_SUFFIX = 'task';
BatchTask.TASK_KEY = 'taskKey';
class BatchTaskMetadataServices {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    }
    save(batchTaskMetadata) {
        return this.dynamoDBServices.save(this.getTableName(), batchTaskMetadata);
    }
    getByName(name) {
        return this.dynamoDBServices.getByKey(this.getTableName(), BatchTaskMetadata.NAME, name);
    }
    async getByScope(scope) {
        const tasks = await this.dynamoDBServices.getItemsBySecondaryIndex(this.getTableName(), DynamoDBServices_1.DynamoDBServices.getTableName('task-scope'), BatchTaskMetadata.SCOPE, scope);
        if (scope === TaskScope.PRODUCER) {
            tasks.forEach((item) => {
                var _a;
                if (item.producerTypeList) {
                    if (Array.isArray((_a = item.producerTypeList) === null || _a === void 0 ? void 0 : _a.values)) {
                        item.producerTypeList = item.producerTypeList.values;
                    }
                    else {
                        item.producerTypeList = Array.from(item.producerTypeList);
                    }
                }
            });
        }
        return tasks;
    }
    async getAll() {
        const tasks = await this.dynamoDBServices.getAllTableEntries(this.getTableName());
        return tasks;
    }
}
exports.BatchTaskMetadataServices = BatchTaskMetadataServices;
class BatchTaskServices {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    save(batchTask) {
        return this.dynamoDBServices.save(this.getTableName(), batchTask);
    }
    getByKey(name, tenantUid, producer) {
        return this.dynamoDBServices.getByKey(this.getTableName(), BatchTask.TASK_KEY, BatchTask.getKey(name, tenantUid, producer));
    }
    getByTaskKey(taskKey) {
        return this.dynamoDBServices.getByKey(this.getTableName(), BatchTask.TASK_KEY, taskKey);
    }
    delete(name, tenantUid, producer) {
        const taskKey = BatchTask.getKey(name, tenantUid, producer);
        return this.deleteByKey(taskKey);
    }
    async removeTenantTasks(tenantUid) {
        this.logger.info(`All tasks for the tenant: ${tenantUid} will be deleted`);
        return this.deleteTasks(await this.getAllTenantTasks(tenantUid));
    }
    async removeProducerTasks(tenantUid, producer) {
        return this.deleteTasks(await this.getAllProducerTasks(tenantUid, producer));
    }
    async getAll() {
        const tasks = await this.dynamoDBServices.getAllTableEntries(this.getTableName());
        return tasks;
    }
    deleteTasks(tasksToDelete) {
        return Promise.all(_.map(tasksToDelete, (task) => this.deleteByKey(task.taskKey)));
    }
    deleteByKey(taskKey) {
        return this.dynamoDBServices.delete(this.getTableName(), BatchTask.TASK_KEY, taskKey);
    }
    getAllProducerTasks(tenantUid, producer) {
        return this.getAllTasksByKey(`${tenantUid}${DynamoDBServices_1.DynamoDBServices.KEY_SEPARATOR}${producer}`);
    }
    getAllTenantTasks(tenantUid) {
        return this.getAllTasksByKey(tenantUid);
    }
    getAllTasksByKey(taskKey) {
        return this.dynamoDBServices.getAllFilteredTableEntries(this.getTableName(), `contains(${BatchTask.TASK_KEY}, :key)`, { ':key': taskKey });
    }
}
exports.BatchTaskServices = BatchTaskServices;
