"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefenderCollection = void 0;
const Collection_1 = require("../../common/Collection");
function extractNextLink(res) {
    var _a;
    if (((_a = res.data.value) === null || _a === void 0 ? void 0 : _a.length) > 0) {
        const baseUrl = res.config.url || this.getNextUri() || `${res.config.baseURL.split('/api/')[1]}`;
        const uriSplit = baseUrl.split('?');
        const resParams = new URLSearchParams(uriSplit[1]);
        const top = parseInt(resParams.get('$top') || `${DefenderCollection.LIMIT}`, 10);
        let skip = parseInt(resParams.get('$skip') || '0', 10);
        skip += top;
        resParams.set('$skip', `${skip}`);
        return `${uriSplit[0]}?${decodeURIComponent(resParams.toString())}`;
    }
    return undefined;
}
function extractData(res) {
    return res.data.value;
}
class DefenderCollection extends Collection_1.Collection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        const uriSplit = uri.split('?');
        const uriParams = new URLSearchParams(uriSplit[1]);
        if (!uriParams.has('$top')) {
            uriParams.set('$top', `${DefenderCollection.LIMIT}`);
        }
        if (!uriParams.has('$skip')) {
            uriParams.set('$skip', '0');
        }
        uri = `${uriSplit[0]}?${decodeURIComponent(uriParams.toString())}`;
        super(client, uri, extractNextLink, extractData, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.DefenderCollection = DefenderCollection;
DefenderCollection.LIMIT = 100;
