"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuoUserService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
class DuoUserService extends Services_1.BasePersonService {
    getPvType() {
        return CommonTypes_1.VertexType.DUO_USER;
    }
    getPsType() {
        return CommonTypes_1.VertexType.DUO_USER_STATE;
    }
    processNotifications(events) {
        return Object.values(events);
    }
}
exports.DuoUserService = DuoUserService;
