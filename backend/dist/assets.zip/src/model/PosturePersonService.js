"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PosturePersonService = exports.PersonType = void 0;
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../common/CommonTypes");
const gremlin_1 = require("gremlin");
const PostureEntityService_1 = require("./PostureEntityService");
const PosturePersonModel_1 = require("./PosturePersonModel");
const Util_1 = require("../common/Util");
const NeptuneServicesFactory_1 = require("../common/neptune/NeptuneServicesFactory");
const ElasticsearchServices_1 = require("../common/ElasticsearchServices");
const AzureUserModel_1 = require("./AzureUserModel");
const DuoUserModel_1 = require("./DuoUserModel");
const ElasticsearchFactory_1 = require("../common/ElasticsearchFactory");
const LabelService_1 = require("../services/common/LabelService");
const NeptuneClientManager_1 = require("../common/neptune/NeptuneClientManager");
const PostureEndpointService_1 = require("./PostureEndpointService");
const __ = gremlin_1.process.statics;
const t = gremlin_1.process.t;
const P = gremlin_1.process.P;
const withOptions = gremlin_1.process.withOptions;
var PersonType;
(function (PersonType) {
    PersonType["MEMBER"] = "Member";
    PersonType["GUEST"] = "Guest";
})(PersonType = exports.PersonType || (exports.PersonType = {}));
class PosturePersonService extends PostureEntityService_1.PostureEntityService {
    constructor(tenantUid) {
        super(tenantUid);
        this.tenantUid = tenantUid;
    }
    getComplexType() {
        return this.getLabel();
    }
    getEdgeType() {
        return CommonTypes_1.EdgeType.POSTURE_PERSON;
    }
    getLabel() {
        return CommonTypes_1.VertexType.POSTURE_PERSON;
    }
    getPostureModelService(tenantUid) {
        return new PosturePersonModel_1.PosturePersonModelService(tenantUid);
    }
    getIdentifierVertexTypes() {
        return (0, CommonTypes_1.personIdentifierVertexTypes)();
    }
    getIdentifierEdgeTypes() {
        return (0, CommonTypes_1.personIdentifierEdgeTypes)();
    }
    async deleteEntityFromES(currentPE) {
        await this.esServices.deletePersonInformation(currentPE);
    }
    async countPosturePersons(filter, labelsMap) {
        const countPosturePersonsResult = await this.esServices.countPosturePersons(filter);
        countPosturePersonsResult.labels = _.filter(countPosturePersonsResult.labels, labelCount => labelsMap.has(labelCount.value));
        return countPosturePersonsResult;
    }
    async getPosturePersonsFilterChoices(filter, properties, limit = 100) {
        return this.esServices.getPersonPropertyAggregations(filter, properties, limit);
    }
    async listPosturePersons(filter, labelMap) {
        return this.esServices.listPosturePersons(filter, labelMap);
    }
    async exportPosturePersonsScroll(filter, labelMap, scrollId) {
        return this.esServices.personPagedSearchScroll(filter, labelMap, scrollId);
    }
    async getPosturePerson(uid) {
        const neptuneSvc = this.getNeptuneServices();
        const results = await Promise.all([
            neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, uid).as('pe')
                .out(CommonTypes_1.EdgeType.POSTURE_PERSON).as('pv')
                .outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).inV().as('ps')
                .select('pe', 'pv', 'ps')
                .by(t.id)
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
                .toList(), NeptuneClientManager_1.NeptuneClientType.Reader),
            neptuneSvc.executeTenantQuery((g) => neptuneSvc.getGraphTraversal(g, uid).as('pe')
                .out(CommonTypes_1.EdgeType.POSTURE_PERSON).as('pv')
                .outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).inV().as('ps')
                .out().dedup().as('cv')
                .select('pe', 'pv', 'cv')
                .by(t.id)
                .by(t.id)
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
                .toList(), NeptuneClientManager_1.NeptuneClientType.Reader)
        ]);
        return _.first(await this.mergeToPersons(results[0], results[1]));
    }
    async getUsedDevices(mergedPerson) {
        if (!mergedPerson) {
            return [];
        }
        const service = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        const devices = [];
        if (mergedPerson.emails) {
            for (const email of mergedPerson.emails) {
                try {
                    const emailDevices = await service.getUserEndpoints('email', email);
                    devices.push(...emailDevices);
                }
                catch (e) {
                    this.logger.error(`getUsedDevices got exception from getUserEndpoints, tenant=${this.tenantUid}, email=${email}: ${e.message}`);
                }
            }
        }
        if (mergedPerson.users) {
            for (const user of mergedPerson.users) {
                try {
                    const userDevices = await service.getUserEndpoints('user', user);
                    devices.push(...userDevices);
                }
                catch (e) {
                    this.logger.error(`getUsedDevices got exception from getUserEndpoints, tenant=${this.tenantUid}, user=${user}: ${e.message}`);
                }
            }
        }
        const usedDevices = [];
        for (const device of devices) {
            const usedDevice = {
                displayName: device.hostname,
                lastSignInDateTime: device.lastUpdated || 'unknown',
                manufacturer: 'unknown',
                model: device.systemModel || 'unknown',
                osType: (0, CommonTypes_1.getOsType)(device.osType),
                operatingSystem: device.osHumanReadableVersion,
                operatingSystemVersion: device.osVersion
            };
            usedDevices.push(usedDevice);
        }
        return usedDevices;
    }
    async mergeToPersons(pvResults, cvResults) {
        const mergedPersons = {};
        const pvResultSet = new gremlin_1.driver.ResultSet(pvResults);
        for (const result of pvResultSet.toArray()) {
            const peUid = result.get('pe');
            const pe = mergedPersons[peUid] || { uid: peUid, propertyTimestamp: {} };
            const pv = result.get('pv');
            const ps = result.get('ps');
            await this.addProducerProperties(pe, pv, ps);
            mergedPersons[peUid] = pe;
        }
        const cvResultSet = new gremlin_1.driver.ResultSet(cvResults);
        for (const result of cvResultSet.toArray()) {
            const peUid = result.get('pe');
            const pvUid = result.get('pv');
            const pe = mergedPersons[peUid] || { uid: peUid, propertyTimestamp: {} };
            const cv = result.get('cv');
            this.addConnectorProperties(pe, cv, pvUid);
            mergedPersons[peUid] = pe;
        }
        return _.map(_.values(mergedPersons), mergedPerson => {
            mergedPerson.personType = this.extractPersonType(mergedPerson);
            return mergedPerson;
        });
    }
    extractPersonType(mergedPerson) {
        return mergedPerson.personType;
    }
    async addProducerProperties(pe, pv, ps) {
        await this.initProducerConfiguration();
        const label = (0, Util_1.parseSimpleLabel)(pv.get(t.label));
        const { sourceId } = this.parseSourceTypeAndId(pv.get(t.label));
        const pvUid = pv.get(t.id);
        pe.producers = pe.producers || [];
        if (_.isEmpty(_.filter(this.producerConfigurations, { producerId: sourceId }))) {
            return;
        }
        const psProperties = this.toKeyValueList(ps);
        if (!_.find(pe.producers, { uid: pvUid, producerId: sourceId })) {
            pe.producers.push({
                uid: pvUid,
                producerId: sourceId,
                type: (0, CommonTypes_1.vertexTypeToSource)(label),
                properties: psProperties
            });
        }
        pe.lastUpdated = _.toString(_.max([_.toNumber(pe.lastUpdated), (0, CommonTypes_1.val)(ps.get(CommonTypes_1.VertexBasicProperty.LAST_UPDATED))]));
        switch (label) {
            case CommonTypes_1.VertexType.DUO_USER: {
                const unixCreated = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.CREATED_KEY));
                if (unixCreated) {
                    pe.createdDateTime = new Date(unixCreated * 1000).toISOString();
                }
                const unixLastLogin = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.LAST_LOGIN_KEY));
                if (unixLastLogin) {
                    pe.lastSignInDateTime = new Date(unixLastLogin * 1000).toISOString();
                }
                pe.employeeId = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.USER_ID_KEY));
                pe.emails = pe.emails || [];
                const email = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.EMAIL_KEY));
                if (_.indexOf(pe.emails, email) < 0) {
                    pe.emails.push(email);
                }
                pe.users = pe.users || [];
                const username = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.USERNAME_KEY));
                if (_.indexOf(pe.users, username) < 0) {
                    pe.users.push(username);
                }
                pe.givenName = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.FIRST_NAME_KEY));
                pe.surname = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.LAST_NAME_KEY));
                pe.displayName = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.REAL_NAME_KEY)) || username;
                pe.accountEnabled = 'false';
                const isEnrolled = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.IS_ENROLLED));
                if (isEnrolled) {
                    const status = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.STATUS_KEY));
                    pe.accountEnabled = status === 'disabled' ? 'false' : 'true';
                }
                try {
                    const duoPhones = JSON.parse((0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.PHONES_KEY)));
                    for (const duoPhone of duoPhones) {
                        if (duoPhone.type === 'Mobile') {
                            const ownedDevice = {
                                displayName: duoPhone.phone_id,
                                lastSignInDateTime: duoPhone.last_seen,
                                manufacturer: 'Unavailable',
                                model: duoPhone.model,
                                operatingSystem: duoPhone.platform,
                                operatingSystemVersion: 'Unavailable',
                                osType: (0, CommonTypes_1.getOsType)(duoPhone.platform)
                            };
                            if (ownedDevice.lastSignInDateTime === '' && pe.createdDateTime) {
                                ownedDevice.lastSignInDateTime = pe.createdDateTime;
                            }
                            if (pe.ownedDevices === undefined) {
                                pe.ownedDevices = [];
                            }
                            pe.ownedDevices.push(ownedDevice);
                            if (duoPhone.number) {
                                if (pe.mobilePhones === undefined) {
                                    pe.mobilePhones = [];
                                }
                                pe.mobilePhones.push(duoPhone.number);
                            }
                        }
                    }
                }
                catch {
                }
                pe.groupNames = pe.groupNames || [];
                try {
                    const duoGroups = JSON.parse((0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.GROUPS_KEY)));
                    duoGroups.forEach((duoGroup) => {
                        if (pe.groupNames === undefined) {
                            pe.groupNames = [];
                        }
                        pe.groupNames.push(duoGroup.name);
                    });
                }
                catch {
                }
                pe.employeeId = (0, CommonTypes_1.val)(ps.get(DuoUserModel_1.DuoUserStateModel.USER_ID_KEY));
                break;
            }
            case CommonTypes_1.VertexType.AZURE_USER: {
                try {
                    const azureOwnedDevices = JSON.parse((0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.OWNED_DEVICES)));
                    azureOwnedDevices.forEach((azureDevice) => {
                        const ownedDevice = {
                            displayName: azureDevice.displayName,
                            lastSignInDateTime: azureDevice.approximateLastSignInDateTime,
                            manufacturer: azureDevice.manufacturer,
                            model: azureDevice.model,
                            operatingSystem: azureDevice.operatingSystem,
                            operatingSystemVersion: azureDevice.operatingSystemVersion,
                            osType: (0, CommonTypes_1.getOsType)(azureDevice.operatingSystem)
                        };
                        if (pe.ownedDevices === undefined) {
                            pe.ownedDevices = [];
                        }
                        pe.ownedDevices.push(ownedDevice);
                    });
                }
                catch {
                }
                pe.accountEnabled = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.ACCOUNT_ENABLED));
                pe.blockSignin = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.BLOCK_SIGNIN));
                pe.businessPhones = pe.businessPhones || [];
                try {
                    pe.businessPhones.push(...JSON.parse((0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.BUSINESS_PHONES))));
                }
                catch {
                }
                pe.companyName = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.COMPANY_NAME));
                pe.createdDateTime = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.CREATED_DATETIME));
                pe.deletedDateTime = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.DELETED_DATETIME));
                pe.department = (0, CommonTypes_1.val)(ps.get('department'));
                pe.displayName = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.DISPLAY_NAME));
                pe.emails = pe.emails || [];
                const email = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.MAIL));
                if (email && email.length > 0 && _.indexOf(pe.emails, email) < 0) {
                    pe.emails.push(email);
                }
                try {
                    pe.emails.push(...JSON.parse((0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.OTHER_MAILS))));
                    pe.emails = _.uniq(pe.emails);
                }
                catch {
                }
                pe.employeeId = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.EMPLOYEE_ID));
                pe.employeeHireDateTime = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.EMPLOYEE_HIRE_DATETIME));
                pe.employeeLeaveDateTime = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.EMPLOYEE_LEAVE_DATETIME));
                pe.givenName = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.GIVEN_NAME));
                pe.groupNames = pe.groupNames || [];
                try {
                    pe.groupNames.push(...JSON.parse((0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.GROUP_NAMES))));
                }
                catch {
                }
                pe.groupDescriptions = pe.groupDescriptions || [];
                try {
                    pe.groupDescriptions.push(...JSON.parse((0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.GROUP_DESCRIPTIONS))));
                }
                catch {
                }
                pe.jobTitle = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.JOB_TITLE));
                pe.lastPasswordChangeDateTime = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.LAST_PASSWORD_CHANGE_DATETIME));
                pe.lastSignInDateTime = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.LAST_SIGNIN_DATETIME));
                pe.manager = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.MANAGER));
                pe.mailNickname = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.MAIL_NICKNAME));
                pe.mobilePhones = pe.mobilePhones || [];
                const mobile = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.MOBILE_PHONE));
                if (mobile && mobile.length > 0 && _.indexOf(pe.mobilePhones, mobile) < 0) {
                    pe.mobilePhones.push(mobile);
                }
                pe.officeLocation = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.OFFICE_LOCATION));
                pe.passwordPolicies = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.PASSWORD_POLICIES));
                pe.personType = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.USER_TYPE));
                pe.surname = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.SURNAME));
                pe.usageLocation = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.USAGE_LOCATION));
                pe.users = pe.users || [];
                const username = (0, CommonTypes_1.val)(ps.get(AzureUserModel_1.AzureUserStateModel.USER_PRINCIPAL_NAME));
                if (username && username.length > 0 && _.indexOf(pe.users, username) < 0) {
                    pe.users.push(username);
                }
                break;
            }
            default:
        }
    }
    addConnectorProperties(pe, cv, pvUid) {
        const label = (0, Util_1.parseSimpleLabel)(cv.get(t.label));
        switch (label) {
            case CommonTypes_1.VertexType.COMPUTER_SID: {
                pe.windowsSID = pe.windowsSID || [];
                const sid = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.windowsSID, sid) < 0) {
                    pe.windowsSID.push(sid);
                }
                this.addValueToProducerProperties('windowsSID', sid, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.USER: {
                pe.users = pe.users || [];
                const user = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.users, user) < 0) {
                    pe.users.push(user);
                }
                this.addValueToProducerProperties('users', user, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.EMAIL: {
                pe.emails = pe.emails || [];
                const email = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                if (_.indexOf(pe.emails, email) < 0) {
                    pe.emails.push(email);
                }
                this.addValueToProducerProperties('emails', email, pe, pvUid);
                break;
            }
            case CommonTypes_1.VertexType.EXTERNAL_REFERENCE: {
                if (pvUid) {
                    const producer = _.find(pe.producers, { uid: pvUid });
                    if (producer) {
                        const externalReference = (0, CommonTypes_1.val)(cv.get(CommonTypes_1.VertexBasicProperty.EXT_ID));
                        producer.properties.push({ key: 'externalReference', value: externalReference });
                    }
                }
                break;
            }
            default: {
                this.logger.error(`unhandled connector type ${label}`);
            }
        }
    }
    async updateSearchableVertex(peUid, recalculateUnreliableIvs = false) {
        const mergedPerson = await this.getPosturePerson(peUid);
        if (mergedPerson) {
            mergedPerson.usedDevices = await this.getUsedDevices(mergedPerson);
        }
        const updateResults = await Promise.allSettled([
            this.esServices.updateMergedPerson(mergedPerson, peUid),
            this.recalculateUnreliableIdentifierVerticesIfNeeded(peUid, recalculateUnreliableIvs)
        ]);
        const failedOperation = _.findLast(updateResults, res => res.status === 'rejected');
        if (failedOperation) {
            throw new Error(`failed to finish update updateSearchableVertex, reason: ${JSON.stringify(failedOperation)}`);
        }
    }
    async sendNotifications(epUid, isPEMerged) { }
    dashboardCounts() {
        return this.esServices.dashboardCounts();
    }
    async listPosturePersonsHistoricalState(filter) {
        const pageNumber = filter.pageNumber || 0;
        const pageSize = filter.pageSize || PosturePersonService.HISTORICAL_STATE_PAGE_SIZE;
        if (pageNumber < 0) {
            throw new Error(`pageNumber must not be negative: ${pageNumber}`);
        }
        if (pageSize <= 0) {
            throw new Error(`pageSize must be positive: ${pageSize}`);
        }
        if (pageSize > PosturePersonService.MAX_PAGE_SIZE) {
            throw new Error(`pageSize ${pageSize} must not exceed ${PosturePersonService.MAX_PAGE_SIZE}`);
        }
        if (filter.since === filter.until) {
            filter.until += 1000 * 60 * 10;
            this.logger.debug(`listPosturePersonsHistoricalState filter.since === filter.until so increase filter.until by 10 minutes (from ${filter.since} to ${filter.until})`);
        }
        if (filter.since > filter.until) {
            throw new Error(`invalid time range ${filter.since} to ${filter.until}`);
        }
        if (!filter.peUid && _.isEmpty(filter.producers) && _.isEmpty(filter.searchTypes)) {
            throw new Error('Expects to receive at least 1 search type or producer');
        }
        const offset = pageNumber * pageSize;
        const filterStatesConditions = () => [
            __.has(CommonTypes_1.EdgeBasicProperty.SINCE, P.gt(filter.since)).has(CommonTypes_1.EdgeBasicProperty.SINCE, P.lt(filter.until)),
            __.has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.gt(filter.since)).has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.lt(filter.until)),
            __.has(CommonTypes_1.EdgeBasicProperty.SINCE, P.lt(filter.since)).has(CommonTypes_1.EdgeBasicProperty.UNTIL, P.gt(filter.until)),
            __.has(CommonTypes_1.EdgeBasicProperty.SINCE, P.lt(filter.since)).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
        ];
        const psFilterQueries = [];
        const psSearchLabels = this.getPsSearchLabels(filter.searchTypes);
        if (psSearchLabels.length > 0) {
            psFilterQueries.push(__.has(t.label, gremlin_1.process.P.within(...psSearchLabels)));
        }
        const ivIds = _.map(filter.searchTypes, searchType => _.join([searchType.value, searchType.type, this.tenantUid], NeptuneServicesFactory_1.VERTEX_ID_SEPARATOR));
        if (ivIds.length > 0) {
            psFilterQueries.push(__.out().has(t.id, gremlin_1.process.P.within(...ivIds)));
        }
        const neptuneSvc = this.getNeptuneServices();
        const results = await neptuneSvc.executeTenantQuery(async (g) => {
            let query;
            if (filter.peUid) {
                query = neptuneSvc.getGraphTraversal(g, filter.peUid).as('pe');
            }
            else if (!_.isEmpty(filter.producers)) {
                if (psFilterQueries.length === 0) {
                    query = await this.getByExtIdQuery(g, filter.producers, filterStatesConditions(), offset, pageSize);
                }
                else {
                    query = await this.getByProducerQuery(g, filter.producers, filterStatesConditions(), psFilterQueries, offset, pageSize);
                }
            }
            else {
                const ivTypes = (0, CommonTypes_1.personIdentifierVertexTypes)();
                const byIvPriority = _.maxBy(filter.searchTypes, (searchType) => ivTypes.indexOf(searchType.type));
                query = this.getByIVsQuery(g, byIvPriority || filter.searchTypes[0], filterStatesConditions(), offset, pageSize);
            }
            return query.union(__.out(CommonTypes_1.EdgeType.POSTURE_PERSON)
                .outE(CommonTypes_1.EdgeType.HAS_STATE)
                .or(...filterStatesConditions())
                .inV().as('ps')
                .path().from_('pe').to('ps')
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all)), __.out(CommonTypes_1.EdgeType.POSTURE_PERSON)
                .outE(CommonTypes_1.EdgeType.HAS_STATE)
                .or(...filterStatesConditions())
                .inV().as('ps')
                .out().as('cv')
                .path().from_('ps').to('cv')
                .by(t.id)
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))).toList();
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
        const timeTicksPerEndpoint = this.getTimeTicksPerEntity(results, filter.since, filter.until);
        const out = await this.processHistoricalStateQueryResult(results, timeTicksPerEndpoint);
        if (out.length <= pageSize) {
            return {
                hasNextPage: false,
                states: out
            };
        }
        return {
            hasNextPage: true,
            states: _.slice(out, 0, pageSize)
        };
    }
    async processHistoricalStateQueryResult(results, timeTicksPerEndpoint) {
        const resultSet = new gremlin_1.driver.ResultSet(results);
        const mergedPersons = {};
        const psToPe = {};
        for (const result of resultSet.toArray()) {
            const path = result.objects;
            if (path.length === 4) {
                const pe = path[0];
                const peUid = pe.get(t.id);
                const pv = path[1];
                const stateEdge = path[2];
                const until = stateEdge.get(CommonTypes_1.EdgeBasicProperty.UNTIL);
                const since = stateEdge.get(CommonTypes_1.EdgeBasicProperty.SINCE);
                const ps = path[3];
                const psUid = ps.get(t.id);
                const personTimeTicks = timeTicksPerEndpoint[peUid];
                const mergedPerson = mergedPersons[peUid] || PostureEntityService_1.PostureEntityService.initMergedEntity(peUid, personTimeTicks);
                const updatedIndices = [];
                for (let i = 0; i < personTimeTicks.length - 1; i += 1) {
                    const timeTickSince = personTimeTicks[i];
                    const timeTickUntil = personTimeTicks[i + 1];
                    if (since <= timeTickSince && (!until || until >= timeTickUntil)) {
                        updatedIndices.push(i);
                        await this.addProducerProperties(mergedPerson[i], pv, ps);
                    }
                }
                mergedPersons[peUid] = mergedPerson;
                psToPe[psUid] = { peUid, updatedIndices };
            }
            else {
                const psUid = path[0];
                const cv = path[1];
                const { peUid, updatedIndices } = psToPe[psUid];
                const mergedPerson = mergedPersons[peUid];
                for (let i = 0; i < updatedIndices.length; i += 1) {
                    this.addConnectorProperties(mergedPerson[updatedIndices[i]], cv);
                }
                mergedPersons[peUid] = mergedPerson;
            }
        }
        return _.values(mergedPersons);
    }
    async linkDirectCandidateDetailed(vertexType, savedVertexId) {
        return undefined;
    }
    async addDataFromESToMergedPerson(posturePerson) {
        var _a;
        const esService = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
        const additionalEsData = await esService.getPersonSpecificFields([posturePerson.uid], ['labels', 'assetValue', 'rulesLabels', 'rulesAssetValue']);
        const currentData = additionalEsData.find(meta => meta._id === posturePerson.uid);
        if (currentData) {
            const psi = { ...currentData._source };
            const labels = currentData._source.labels;
            posturePerson.labels = _.isEmpty(labels) ? [] : await new LabelService_1.LabelService(this.tenantUid).getLabels(labels);
            posturePerson.assetValue = (_a = psi.assetValue) !== null && _a !== void 0 ? _a : ElasticsearchServices_1.ElasticsearchServices.DEFAULT_ASSET_VALUE;
        }
        else {
            this.logger.error(`Error when trying to add labels and value data for person ${posturePerson.uid} of tenant ${this.tenantUid}. Person was not found.`);
            throw new Error('Person not found');
        }
    }
}
exports.PosturePersonService = PosturePersonService;
