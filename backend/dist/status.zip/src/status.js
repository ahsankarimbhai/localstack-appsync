"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.systemStatus = void 0;
const KinesisServices_1 = require("./common/kinesis/KinesisServices");
const LambdaLogger_1 = require("./common/LambdaLogger");
const TenantServices_1 = require("./common/TenantServices");
const SNSServices_1 = require("./common/SNSServices");
const NeptuneClientHelper_1 = require("./common/neptune/NeptuneClientHelper");
const NeptuneClientManager_1 = require("./common/neptune/NeptuneClientManager");
const bluebird_1 = require("bluebird");
const KinesisHelper_1 = require("./common/kinesis/KinesisHelper");
const DynamodbServiceFactory_1 = require("./common/awsclient/dynamodb/DynamodbServiceFactory");
const neptuneClientManager = NeptuneClientManager_1.NeptuneClientManager.getInstance();
const systemStatus = async () => {
    const OK = 'OK';
    const FAIL = 'FAIL';
    let status;
    const logger = new LambdaLogger_1.LambdaLogger();
    const response = [];
    response.push({ key: 'appSync', value: OK });
    try {
        status = FAIL;
        const processingStream = new KinesisServices_1.KinesisServices(KinesisHelper_1.PRE_PROCESSING_STREAM, true);
        try {
            await processingStream.describeStream();
            status = OK;
        }
        catch (e) {
            logger.error(`Failed to describe Kinesis ${KinesisHelper_1.PRE_PROCESSING_STREAM} stream with error: ${e.message}`);
        }
        response.push({ key: 'kinesis', value: status });
        status = FAIL;
        try {
            const shardSettings = (0, NeptuneClientHelper_1.getNeptuneShardSettings)();
            await bluebird_1.Promise.map(shardSettings, async (shard) => {
                logger.debug(`executing neptune query g.V().limit(1).toList() on Neptune shard ${shard.fullName}`);
                await neptuneClientManager.executeQueryScope(shard.shardId, NeptuneClientManager_1.NeptuneClientType.Reader, (g) => g.V().limit(1).toList());
            });
            status = OK;
        }
        catch (e) {
            logger.error(`Failed to connect to Neptune with error: ${e.message}`);
        }
        response.push({ key: 'neptune', value: status });
        status = FAIL;
        try {
            const dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
            await dynamoDBServices.getByKey(TenantServices_1.Tenant.TABLE_NAME, 'id', '1111');
            status = OK;
        }
        catch (e) {
            logger.error(`Failed to fetch record from DynamoDB with error: ${e.message}`);
        }
        response.push({ key: 'dynamodb', value: status });
        status = FAIL;
        const snsServices = new SNSServices_1.SNSServices();
        const attributes = {
            target: { DataType: 'String', StringValue: 'garbage' }
        };
        try {
            const snsTopicArnName = 'TEST_SNS_TOPIC_ARN';
            const snsTopicArn = process.env[snsTopicArnName];
            if (!snsTopicArn) {
                throw new Error(`${snsTopicArnName} is not set`);
            }
            await snsServices.publish(snsTopicArn, JSON.stringify({}), attributes);
            status = OK;
        }
        catch (e) {
            logger.error(`Failed to put record into SNS with error: ${e.message}`);
        }
        response.push({ key: 'sns', value: status });
    }
    catch (e) {
        logger.error(`Status failed with error: ${e.message}`);
        response.push({ key: 'generalError', value: FAIL });
    }
    return bluebird_1.Promise.resolve(response);
};
exports.systemStatus = systemStatus;
