"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimestreamUtil = void 0;
const _ = __importStar(require("lodash"));
const uuid_1 = require("uuid");
const TimestreamWriteServices_1 = require("./TimestreamWriteServices");
const KinesisServices_1 = require("./kinesis/KinesisServices");
const LambdaLogger_1 = require("./LambdaLogger");
const KinesisHelper_1 = require("./kinesis/KinesisHelper");
class TimestreamUtil {
    constructor() {
        this.timestreamWriteServices = new TimestreamWriteServices_1.TimestreamWriteServices();
        this.kinesisServices = new KinesisServices_1.KinesisServices(KinesisHelper_1.TIMESTREAM_STREAM);
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    sendRequestsToStream(requests) {
        if (_.isEmpty(requests)) {
            return;
        }
        this.logger.debug('Sending metrics to timestream stream');
        const records = _.map(requests, request => ({
            Data: JSON.stringify(request),
            PartitionKey: (0, uuid_1.v4)().toString()
        }));
        return this.kinesisServices.putRecords(records);
    }
    async sendMetricsToDatabase(records) {
        for await (const record of records) {
            const data = Buffer.from(record.kinesis.data, 'base64').toString();
            const params = (JSON.parse(data));
            try {
                await this.timestreamWriteServices.sendRequest(params);
            }
            catch (err) {
                this.logger.error('Failed on sending request to Timestream', err, JSON.stringify(record));
            }
        }
    }
}
exports.TimestreamUtil = TimestreamUtil;
