"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AirWatchDevicesCollection = void 0;
const AirWatchDeviceCollection_1 = require("./AirWatchDeviceCollection");
class AirWatchDevicesCollection extends AirWatchDeviceCollection_1.AirWatchDeviceCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.AirWatchDevicesCollection = AirWatchDevicesCollection;
