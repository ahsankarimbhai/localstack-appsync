"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComputersCollection = void 0;
const JamfCollection_1 = require("./JamfCollection");
class ComputersCollection extends JamfCollection_1.JamfCollection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker, functionState) {
        super(client, uri, timeBasedAsyncLambdaInvoker);
        this.functionState = functionState;
    }
}
exports.ComputersCollection = ComputersCollection;
