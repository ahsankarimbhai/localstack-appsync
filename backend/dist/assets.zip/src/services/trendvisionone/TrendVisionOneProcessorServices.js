"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrendVisionOneProcessorServices = void 0;
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const TrendVisionOneEndpointService_1 = require("../../collectors/services/TrendVisionOneEndpointService");
class TrendVisionOneProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(trendVisionOneDevice, vertexState, currentTopology, changes, unchanged) {
        await this.verifyChange(currentTopology, trendVisionOneDevice.endpointName.value, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        await this.verifyChange(currentTopology, trendVisionOneDevice.agentGuid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        for (const macAddress of trendVisionOneDevice.macAddress.value) {
            await this.verifyChange(currentTopology, macAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        }
        for (const loginUser of trendVisionOneDevice.loginAccount.value) {
            await this.verifyChange(currentTopology, loginUser, CommonTypes_1.VertexType.USER, changes, unchanged);
        }
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new TrendVisionOneEndpointService_1.TrendVisionOneEndpointService(tenantUid, sourceId);
    }
}
exports.TrendVisionOneProcessorServices = TrendVisionOneProcessorServices;
