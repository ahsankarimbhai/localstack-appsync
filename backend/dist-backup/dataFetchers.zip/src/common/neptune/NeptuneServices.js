"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneServices = void 0;
const ts_retry_promise_1 = require("ts-retry-promise");
const gremlin_1 = require("gremlin");
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../CommonTypes");
const LambdaLogger_1 = require("../LambdaLogger");
const Util_1 = require("../Util");
const NeptuneClientManager_1 = require("./NeptuneClientManager");
const NeptuneClientHelper_1 = require("./NeptuneClientHelper");
const ShardingServices_1 = require("./ShardingServices");
const __ = gremlin_1.process.statics;
const { t: { id, label } } = gremlin_1.process;
const withOptions = gremlin_1.process.withOptions;
class NeptuneServices {
    constructor(tenantUid, strongConsistentReadDelay = 100) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.sourceVertex = 'sourceVertex';
        this.targetVertex = 'targetVertex';
        this.foundEdge = 'foundEdge';
        this.strongConsistentReadDelay = strongConsistentReadDelay;
        this.neptuneClientMgr = NeptuneClientManager_1.NeptuneClientManager.getInstance();
        this.neptuneShardingService = new ShardingServices_1.ShardingServices();
    }
    async executeTenantQuery(queryFunc, clientType = NeptuneClientManager_1.NeptuneClientType.Writer) {
        if (process.env.WRITER_ONLY_NEPTUNE_CONNECTION === 'true') {
            clientType = NeptuneClientManager_1.NeptuneClientType.Writer;
        }
        const shardId = await this.getNeptuneShardId(clientType);
        return this.neptuneClientMgr.executeQueryScope(shardId, clientType, queryFunc, this.strongConsistentReadDelay);
    }
    async getNeptuneShardId(clientType) {
        if (!this.neptuneShardId) {
            const tenantShard = await this.neptuneShardingService.getCachedNeptuneCluster(this.tenantUid);
            if (clientType === NeptuneClientManager_1.NeptuneClientType.Writer && tenantShard.isThrottled) {
                throw new Error('database is current in maintenance and will be recovered soon');
            }
            this.neptuneShardId = tenantShard.shardId;
        }
        return this.neptuneShardId;
    }
    addVertex(vertex, projectionProperties = []) {
        return this.executeTenantQuery((g) => {
            const addVertex = this.addVertexTraversalSteps(g, vertex);
            return this.getSingleResult(addVertex, projectionProperties);
        });
    }
    static createLabels(vertexLabel, tenantUid, secondaryLabels) {
        const baseLabel = `${vertexLabel}::${vertexLabel}${Util_1.SOURCE_SEPARATOR}${tenantUid}`;
        if (secondaryLabels && secondaryLabels.length > 0) {
            return `${baseLabel}::`.concat(secondaryLabels.map(p => `${p}${Util_1.SOURCE_SEPARATOR}${tenantUid}`).join('::'));
        }
        return baseLabel;
    }
    addVertexTraversalSteps(graphTraversal, vertex) {
        let addVertex = graphTraversal ? graphTraversal.addV(NeptuneServices.createLabels(vertex.label, this.tenantUid)) : __.addV(NeptuneServices.createLabels(vertex.label, this.tenantUid));
        addVertex = addVertex.property(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
        _.forEach(vertex.properties, (property) => {
            addVertex = addVertex.property(property.key, (0, CommonTypes_1.valueOrJsonString)(property.value));
        });
        return addVertex;
    }
    getVertices(vertexFilter, limit = 0, projectionProperties = []) {
        return this.executeTenantQuery((g) => {
            let query = g.V();
            if (vertexFilter.label) {
                query = query.hasLabel(vertexFilter.label);
            }
            query = query.has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
            query = this.hasProperties(vertexFilter.properties, query);
            query = limit > 0 ? query.limit(limit) : query;
            return this.listVertexResults(vertexFilter, query, projectionProperties);
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    upsertVertex(vertexFilter, vertexProperties, projectionProperties = [], secondaryLabels) {
        return this.executeTenantQuery((g) => {
            const upsertVertexQuery = this.addUpsertVertexTraversalStepsWithFold(g, vertexFilter, vertexProperties, secondaryLabels);
            return this.listVertexResults(vertexFilter, upsertVertexQuery, projectionProperties);
        });
    }
    addUpsertVertexTraversalStepsWithFold(graphTraversal, vertexFilter, vertexProperties, secondaryLabels) {
        let addV = __.addV(NeptuneServices.createLabels(vertexFilter.label, this.tenantUid, secondaryLabels));
        addV = addV.property(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
        addV = vertexFilter.id ? addV.property(id, vertexFilter.id) : addV;
        const updateV = __.unfold();
        let upsertVertexQuery = vertexFilter.id ? graphTraversal.V(vertexFilter.id) : graphTraversal.V();
        if (vertexFilter.label) {
            upsertVertexQuery = upsertVertexQuery.hasLabel(vertexFilter.label);
        }
        upsertVertexQuery = this.hasProperties(vertexFilter.properties, upsertVertexQuery);
        upsertVertexQuery = upsertVertexQuery.has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
        upsertVertexQuery = upsertVertexQuery.fold().coalesce(updateV, addV);
        upsertVertexQuery = this.updateProperties(vertexProperties, upsertVertexQuery);
        return vertexFilter.id ? upsertVertexQuery.as(NeptuneServices.normalizedAlias(vertexFilter.id)) : upsertVertexQuery;
    }
    addUpsertVertexTraversalSteps(graphTraversal, vertexFilter, vertexProperties, secondaryLabels) {
        let addV = __.addV(NeptuneServices.createLabels(vertexFilter.label, this.tenantUid, secondaryLabels));
        addV = addV.property(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
        addV = vertexFilter.id ? addV.property(id, vertexFilter.id) : addV;
        const updateV = __.V(vertexFilter.id);
        let upsertVertexQuery = graphTraversal.coalesce(updateV, addV);
        upsertVertexQuery = this.updateProperties(vertexProperties, upsertVertexQuery);
        return vertexFilter.id ? upsertVertexQuery.as(NeptuneServices.normalizedAlias(vertexFilter.id)) : upsertVertexQuery;
    }
    getEdgeBySourceAndTarget(sourceVertexFilter, targetVertexFilter, limit = 100) {
        return this.executeTenantQuery((g) => {
            let getEdgeBySourceAndTargetQuery = g.V();
            getEdgeBySourceAndTargetQuery = this.applyVertexFilter(sourceVertexFilter, getEdgeBySourceAndTargetQuery).as(this.sourceVertex);
            const targetVertexTraversalSteps = this.applyVertexFilter(targetVertexFilter, __.inV());
            getEdgeBySourceAndTargetQuery = getEdgeBySourceAndTargetQuery.outE().where(targetVertexTraversalSteps).as(this.foundEdge);
            getEdgeBySourceAndTargetQuery = getEdgeBySourceAndTargetQuery.inV().as(this.targetVertex).limit(limit);
            return this.listEdgeResults(sourceVertexFilter, getEdgeBySourceAndTargetQuery);
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    applyVertexFilter(vertexFilter, query) {
        let vertexTraversalSteps = query;
        if (vertexFilter.id) {
            vertexTraversalSteps = vertexTraversalSteps.hasId(vertexFilter.id);
        }
        if (vertexFilter.label) {
            vertexTraversalSteps = vertexTraversalSteps.hasLabel(vertexFilter.label);
        }
        vertexTraversalSteps = vertexTraversalSteps.has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
        vertexTraversalSteps = this.hasProperties(vertexFilter.properties, vertexTraversalSteps);
        return vertexTraversalSteps;
    }
    async getSingleVertex(vertexFilter) {
        if (!vertexFilter.label) {
            return Promise.reject(new Error('vertex label is mandatory'));
        }
        const result = await this.getVertices(vertexFilter, 1);
        return _.get(result, '[0]');
    }
    fetchVertexById(vertexId) {
        return this.executeTenantQuery((g) => this.listVertexResults({ id: vertexId }, g.V(vertexId).has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid)), NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    fetchVerticesById(vertices) {
        return this.executeTenantQuery((g) => this.listVertexResults({}, g.V(vertices).has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid)), NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    addEdge(edge) {
        return this.executeTenantQuery((g) => {
            const addEdge = this.addEdgeTraversalSteps(g, edge);
            return addEdge.from_(this.sourceVertex).to(this.targetVertex).as(this.foundEdge)
                .select(this.foundEdge, this.sourceVertex, this.targetVertex)
                .by(__.valueMap().with_(withOptions.tokens, withOptions.all))
                .toList()
                .then((results) => {
                const resultSet = new gremlin_1.driver.ResultSet(results);
                const neptuneResult = resultSet.first();
                return this.resultMapToEdge(neptuneResult);
            })
                .catch((err) => {
                throw err;
            });
        });
    }
    addEdgeWithPartitionKey(graphTraversal, edgeLabel) {
        return graphTraversal.addE(edgeLabel).property(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
    }
    addEdgeTraversalSteps(graphTraversal, edge) {
        let addEdge = graphTraversal.V(edge.from).property(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid).as(this.sourceVertex);
        addEdge = addEdge.V(edge.to).property(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid).as(this.targetVertex);
        addEdge = this.addEdgeWithPartitionKey(addEdge, edge.label);
        addEdge = this.addProperties(edge.properties, addEdge);
        return addEdge;
    }
    upsertEdge(edge) {
        return this.executeTenantQuery((g) => {
            const addE = __.addE(edge.label).to(this.targetVertex);
            const updateE = __.outE(edge.label).where(__.inV().hasId(edge.to));
            let upsertEdgeQuery = g.V(edge.to).as(this.targetVertex).V(edge.from).as(this.sourceVertex)
                .coalesce(updateE, addE);
            upsertEdgeQuery = this.addProperties(edge.properties, upsertEdgeQuery);
            upsertEdgeQuery = upsertEdgeQuery.property(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
            upsertEdgeQuery = upsertEdgeQuery.as(this.foundEdge);
            return this.listEdgeResults(edge, upsertEdgeQuery);
        });
    }
    addUpsertEdgeTraversalSteps(graphTraversal, edge) {
        const normalizerToAlias = NeptuneServices.normalizedAlias(edge.to);
        let addE = __.addE(edge.label);
        addE = addE.to(__.select(normalizerToAlias));
        addE = addE.property(CommonTypes_1.BasicProperty.PARTITION_KEY, this.tenantUid);
        addE = this.addProperties(edge.properties, addE);
        let updateE = __.outE(edge.label).where(__.inV().where(gremlin_1.process.P.eq(normalizerToAlias)));
        updateE = this.addProperties(edge.properties, updateE);
        return graphTraversal.select(NeptuneServices.normalizedAlias(edge.from)).coalesce(updateE, addE);
    }
    static normalizedAlias(name) {
        return name ? name.replace(/[^a-zA-Z0-9]/g, '') : name;
    }
    getCurrentPSWithOutgoingVertices(pvFilter) {
        return this.executeTenantQuery((g) => {
            const currentPS = 'currentPS';
            const iVs = 'IVs';
            let query = this.getGraphTraversal(g, pvFilter.id).outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL);
            query = query.inV().as(currentPS).out().as(iVs);
            return this.listVertexResults(pvFilter, query.union(__.select(currentPS), __.select(iVs)).dedup());
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    addCurrentStateTraversal(graphTraversal, edge) {
        const newStateDate = Date.now();
        let addNewState = __.outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).property(CommonTypes_1.EdgeBasicProperty.UNTIL, newStateDate);
        addNewState = addNewState.inV().outE().property(CommonTypes_1.EdgeBasicProperty.IS_CURRENT, false).fold();
        addNewState = addNewState.V(edge.to).as(this.targetVertex).V(edge.from).as(this.sourceVertex);
        addNewState = addNewState.addE(CommonTypes_1.EdgeType.HAS_STATE).to(this.targetVertex);
        addNewState = this.addProperties(edge.properties, addNewState);
        addNewState = addNewState.property(CommonTypes_1.EdgeBasicProperty.SINCE, newStateDate);
        return graphTraversal.V(edge.from)
            .coalesce(__.outE(CommonTypes_1.EdgeType.HAS_STATE).hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL).inV().hasId(edge.to), addNewState);
    }
    getGraphTraversal(g, vertexId) {
        const v = (vertexId) ? g.V(vertexId) : g.V();
        return v.has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.getTenantUid());
    }
    getSimpleGraphTraversal(g) {
        return g.V();
    }
    getEdgeTraversal(g, edgeId) {
        const e = (edgeId) ? g.E(edgeId) : g.E();
        return e.has(CommonTypes_1.BasicProperty.PARTITION_KEY, this.getTenantUid());
    }
    getGraphTraversalBasedOnLabel(g, prefix, suffix) {
        let vertexLabel = `${prefix}__${this.tenantUid}`;
        if (suffix) {
            vertexLabel += `__${suffix}`;
        }
        return g.V().hasLabel(vertexLabel);
    }
    getTenantUid() {
        return this.tenantUid;
    }
    listEdgeResults(filter, query) {
        return (0, ts_retry_promise_1.retry)(() => query.select(this.foundEdge, this.sourceVertex, this.targetVertex)
            .by(__.valueMap().with_(withOptions.tokens, withOptions.all)).toList(), { retries: 3 })
            .then((results) => {
            const resultSet = new gremlin_1.driver.ResultSet(results);
            const toArray = resultSet.toArray();
            return _.map(toArray, (neptuneResult) => this.resultMapToEdge(neptuneResult));
        })
            .catch((err) => {
            this.logger.warn('Failed to list edges', err, filter);
            throw err;
        });
    }
    listVertexResults(vertexFilter, query, projectionProperties = []) {
        return (0, ts_retry_promise_1.retry)(() => query.valueMap(true, ...projectionProperties).toList(), { retries: 3 })
            .then((results) => {
            const resultSet = new gremlin_1.driver.ResultSet(results);
            const toArray = resultSet.toArray();
            return _.map(toArray, (element) => this.resultMapToVertex(element));
        })
            .catch((err) => {
            throw err;
        });
    }
    getSingleResult(addVertex, projectionProperties = []) {
        return addVertex.valueMap(true, ...projectionProperties).toList()
            .then((results) => {
            const resultSet = new gremlin_1.driver.ResultSet(results);
            return this.resultMapToVertex(resultSet.first());
        })
            .catch((err) => {
            throw err;
        });
    }
    resultMapToEdge(neptuneResult) {
        const edgeInfoMap = neptuneResult.get(this.foundEdge);
        const edgeProperties = _.chain(Array.from(edgeInfoMap))
            .filter(element => element[0] !== id && element[0] !== label)
            .map((element) => ({
            key: element[0],
            value: element[1]
        })).value();
        return {
            id: edgeInfoMap.get(id),
            label: edgeInfoMap.get(label),
            properties: edgeProperties,
            from: neptuneResult.get(this.sourceVertex).get(id),
            to: neptuneResult.get(this.targetVertex).get(id)
        };
    }
    resultMapToVertex(neptuneResult) {
        const resultProperties = _.chain(Array.from(neptuneResult))
            .filter(element => element[0] !== id && element[0] !== label)
            .map((element) => ({
            key: element[0],
            value: element[1][0]
        })).value();
        return {
            id: neptuneResult.get(id),
            label: neptuneResult.get(label),
            properties: resultProperties
        };
    }
    updateProperties(properties, graphTraversal) {
        let query = graphTraversal;
        _.forEach(properties, (property) => {
            if (!_.isNil(property.value)) {
                query = query.property(gremlin_1.process.cardinality.single, property.key, (0, CommonTypes_1.valueOrJsonString)(property.value));
            }
            else {
                query = query.properties(property.key).drop();
            }
        });
        return query;
    }
    addProperties(properties, graphTraversal) {
        let query = graphTraversal;
        _.forEach(properties, (property) => {
            query = query.property(property.key, (0, CommonTypes_1.valueOrJsonString)(property.value));
        });
        return query;
    }
    hasProperties(properties, graphTraversal) {
        let query = graphTraversal;
        _.forEach(properties, (property) => {
            query = query.has(property.key, (0, CommonTypes_1.valueOrJsonString)(property.value));
        });
        return query;
    }
    getPostureEndpointsByPV(vertexId) {
        return this.getPostureEntitiesByPV(vertexId, CommonTypes_1.EdgeType.POSTURE_ENDPOINT);
    }
    getPosturePersonsByPV(vertexId) {
        return this.getPostureEntitiesByPV(vertexId, CommonTypes_1.EdgeType.POSTURE_PERSON);
    }
    getPostureEntitiesByPV(vertexId, edgeType) {
        return this.executeTenantQuery((g) => this.listVertexResults({}, this.getGraphTraversal(g, vertexId).inE(edgeType).outV()), NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    closeCurrentState(vertexId, now) {
        return (0, ts_retry_promise_1.retry)(() => this.executeTenantQuery((g) => this.getGraphTraversal(g, vertexId)
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
            .property(CommonTypes_1.EdgeBasicProperty.UNTIL, now || Date.now())
            .inV()
            .outE()
            .property(CommonTypes_1.EdgeBasicProperty.IS_CURRENT, false)
            .iterate()), { retryIf: (err) => !(0, NeptuneClientHelper_1.isConnectionError)(err) });
    }
    getCurrentState(vertexId) {
        return this.executeTenantQuery((g) => {
            const vertexQuery = this.getGraphTraversal(g, vertexId)
                .outE(CommonTypes_1.EdgeType.HAS_STATE)
                .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
                .inV();
            return this.getSingleResult(vertexQuery);
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    async getPostureEntity(pvUid, edgeType) {
        return this.executeTenantQuery(async (g) => {
            const results = await this.getGraphTraversal(g, pvUid).inE(edgeType).outV().id()
                .toList();
            const resultSet = new gremlin_1.driver.ResultSet(results);
            return resultSet.toArray().length > 0 ? resultSet.toArray()[0] : undefined;
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    async getPostureEndpointByPV(pvUid) {
        return this.getPostureEntity(pvUid, CommonTypes_1.EdgeType.POSTURE_ENDPOINT);
    }
    async getPosturePersonByPV(pvUid) {
        return this.getPostureEntity(pvUid, CommonTypes_1.EdgeType.POSTURE_PERSON);
    }
}
exports.NeptuneServices = NeptuneServices;
