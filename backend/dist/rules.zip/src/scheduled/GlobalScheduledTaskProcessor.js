"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalScheduledTaskProcessor = void 0;
const BasicScheduledTaskProcessor_1 = require("./BasicScheduledTaskProcessor");
const BatchTaskServices_1 = require("../common/BatchTaskServices");
class GlobalScheduledTaskProcessor extends BasicScheduledTaskProcessor_1.BasicScheduledTaskProcessor {
    constructor(taskParams) {
        super(BatchTaskServices_1.TaskScope.GLOBAL, undefined, taskParams);
        this.taskParams = taskParams;
    }
}
exports.GlobalScheduledTaskProcessor = GlobalScheduledTaskProcessor;
