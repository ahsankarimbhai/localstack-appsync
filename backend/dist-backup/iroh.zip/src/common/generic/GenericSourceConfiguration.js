"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StoredFieldMappedType = exports.ExtractNextLinkSource = exports.ModuleAttributeSource = void 0;
var ModuleAttributeSource;
(function (ModuleAttributeSource) {
    ModuleAttributeSource["INSTANCE"] = "instance";
    ModuleAttributeSource["TYPE"] = "type";
    ModuleAttributeSource["LITERAL"] = "literal";
})(ModuleAttributeSource = exports.ModuleAttributeSource || (exports.ModuleAttributeSource = {}));
var ExtractNextLinkSource;
(function (ExtractNextLinkSource) {
    ExtractNextLinkSource["QUERY"] = "query";
    ExtractNextLinkSource["RESPONSE"] = "response";
})(ExtractNextLinkSource = exports.ExtractNextLinkSource || (exports.ExtractNextLinkSource = {}));
var StoredFieldMappedType;
(function (StoredFieldMappedType) {
    StoredFieldMappedType["EXTERNAL_IP_ADDRESS"] = "externalIpAddress";
    StoredFieldMappedType["MAC_ADDRESS"] = "macAddress";
    StoredFieldMappedType["HARDWARE_ID"] = "hardwareId";
    StoredFieldMappedType["COMPUTER_SID"] = "computerSID";
    StoredFieldMappedType["SERIAL_NUMBER"] = "serialNumber";
    StoredFieldMappedType["COOKIE"] = "cookie";
    StoredFieldMappedType["USER"] = "user";
    StoredFieldMappedType["APP_USER"] = "appUser";
    StoredFieldMappedType["EMAIL"] = "email";
    StoredFieldMappedType["IMEI"] = "imei";
    StoredFieldMappedType["PHONE_NUMBER"] = "phoneNumber";
    StoredFieldMappedType["HOSTNAME"] = "hostname";
    StoredFieldMappedType["EXTERNAL_REFERENCE"] = "externalReference";
    StoredFieldMappedType["EXT_ID"] = "extId";
    StoredFieldMappedType["TIME_IN_MILLIS"] = "timeInMillis";
    StoredFieldMappedType["OS_TYPE"] = "osType";
    StoredFieldMappedType["OS_VERSION"] = "osVersion";
})(StoredFieldMappedType = exports.StoredFieldMappedType || (exports.StoredFieldMappedType = {}));
