"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShardingServices = void 0;
const LambdaLogger_1 = require("../LambdaLogger");
const DateUtils_1 = require("../DateUtils");
const CloudWatchService_1 = require("../awsclient/CloudWatchService");
const NeptuneShardRepo_1 = require("../dynamoDBRepo/NeptuneShardRepo");
const _ = __importStar(require("lodash"));
const bluebird_1 = require("bluebird");
const NeptuneClientHelper_1 = require("./NeptuneClientHelper");
const MemoryCache_1 = require("../cache/MemoryCache");
const NEPTUNE_SHARD_CACHE_KEY_PREFIX = 'NEPTUNE_SHARD';
class ShardingServices {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.cloudWatchService = new CloudWatchService_1.CloudWatchService();
        this.neptuneShardRepo = new NeptuneShardRepo_1.NeptuneShardRepo();
    }
    async getCachedNeptuneCluster(tenantUid) {
        const clusterSettings = (0, NeptuneClientHelper_1.getNeptuneShardSettings)();
        if (clusterSettings.length === 1) {
            return { tenantUid, shardId: clusterSettings[0].shardId };
        }
        const tenantShard = await this.neptuneShardRepo.getNeptuneShard(tenantUid);
        if (!tenantShard) {
            throw new Error(`Neptune cluster is not found for tenant ${tenantUid}`);
        }
        return tenantShard;
    }
    async allocateNeptuneCluster(tenantUid) {
        const existing = await this.neptuneShardRepo.getNeptuneShard(tenantUid);
        if (existing) {
            return existing.shardId;
        }
        let allocatedShardId;
        const clusterSettings = (0, NeptuneClientHelper_1.getNeptuneShardSettings)();
        if (clusterSettings.length === 1) {
            allocatedShardId = clusterSettings[0].shardId;
        }
        else if (process.env.PREDEFINED_NEPTUNE_SHARD_ID) {
            allocatedShardId = (0, NeptuneClientHelper_1.getNeptuneShardById)(process.env.PREDEFINED_NEPTUNE_SHARD_ID).shardId;
        }
        else {
            const metricPeriod = +(process.env.METRIC_PERIOD_IN_DAYS || DateUtils_1.WEEK_DAYS);
            const start = new Date();
            start.setDate(start.getDate() - metricPeriod);
            const shards = await bluebird_1.Promise.map(clusterSettings, async (cluster) => {
                try {
                    const cpuUtilization = await this.getNeptuneWriterCpuUtilization(cluster.fullName, start, new Date(), metricPeriod);
                    this.logger.debug(`Neptune cluster ${cluster.fullName}, CPUUtilization: ${cpuUtilization}`);
                    return {
                        ...cluster,
                        cpuUtilization
                    };
                }
                catch (err) {
                    this.logger.error(`Failed to fetch metric of CPUUtilization for Neptune cluster ${cluster.fullName}, err: ${err.message}`);
                    return undefined;
                }
            });
            const leastUsedShard = _.orderBy(shards.filter(shard => shard), shard => shard.cpuUtilization, 'asc')[0];
            if (!leastUsedShard) {
                throw new Error('Not a Neptune cluster is available');
            }
            allocatedShardId = leastUsedShard.shardId;
        }
        await this.neptuneShardRepo.upsertNeptuneShard({
            tenantUid,
            shardId: allocatedShardId
        });
        return allocatedShardId;
    }
    async getNeptuneWriterCpuUtilization(clusterName, start, end, metricPeriod) {
        const dataPoints = await this.cloudWatchService.getMetricStatistics({
            MetricName: 'CPUUtilization',
            Namespace: 'AWS/Neptune',
            Period: metricPeriod * DateUtils_1.DAY_SECONDS,
            StartTime: start,
            EndTime: end,
            Statistics: ['Average'],
            Dimensions: [
                {
                    Name: 'DBClusterIdentifier',
                    Value: clusterName
                },
                {
                    Name: 'Role',
                    Value: 'WRITER'
                }
            ]
        });
        if (!dataPoints || dataPoints.length === 0 || dataPoints[0].Average === undefined) {
            throw new Error('dataPoints is empty');
        }
        return dataPoints[0].Average;
    }
}
__decorate([
    (0, MemoryCache_1.memCacheDecorator)(NEPTUNE_SHARD_CACHE_KEY_PREFIX, 900)
], ShardingServices.prototype, "getCachedNeptuneCluster", null);
__decorate([
    (0, MemoryCache_1.memCacheDecorator)(NEPTUNE_SHARD_CACHE_KEY_PREFIX, 900)
], ShardingServices.prototype, "allocateNeptuneCluster", null);
exports.ShardingServices = ShardingServices;
