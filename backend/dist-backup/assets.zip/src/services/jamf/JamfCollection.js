"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JamfCollection = void 0;
const _ = __importStar(require("lodash"));
const query_string_1 = __importDefault(require("query-string"));
const url_1 = require("url");
const Collection_1 = require("../../common/Collection");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
function extractNextLink(res) {
    let reqUrl = new url_1.URL(_.get(res, 'config.url', ''), res.config.baseURL);
    if (res.config.baseURL && res.config.baseURL.indexOf(ProxyClientFactory_1.ProxyClientFactory.IROH_PREF) > 0) {
        const apiAddressIndex = res.config.baseURL.indexOf('/api/v');
        const baseUrl = res.config.baseURL.substring(0, apiAddressIndex);
        const apiUrl = res.config.baseURL.substring(apiAddressIndex);
        reqUrl = new url_1.URL(apiUrl, baseUrl);
    }
    const searchParams = reqUrl.searchParams;
    const pageSize = _.toNumber(searchParams.get('page-size'));
    const page = _.toNumber(searchParams.get('page'));
    const totalCount = res.data.totalCount;
    if (totalCount <= (page + 1) * pageSize) {
        return undefined;
    }
    const params = query_string_1.default.parse(reqUrl.search);
    params.page = page + 1;
    return `${reqUrl.pathname}?${query_string_1.default.stringify(params)}`;
}
function extractData(res) {
    return res.data.results;
}
class JamfCollection extends Collection_1.Collection {
    constructor(client, uri, timeBasedAsyncLambdaInvoker) {
        super(client, uri, extractNextLink, extractData, timeBasedAsyncLambdaInvoker, JamfCollection.RETRY_CONFIG);
    }
}
exports.JamfCollection = JamfCollection;
JamfCollection.RETRY_CONFIG = {
    retries: 3,
    delay: 5000,
    timeout: 600000,
    backoff: 'NEXT_RETRY_DELAY'
};
