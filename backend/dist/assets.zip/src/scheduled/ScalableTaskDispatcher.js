"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScalableTaskDispatcher = void 0;
const LambdaLogger_1 = require("../common/LambdaLogger");
const SQSService_1 = require("../common/awsclient/SQSService");
const ScheduleServices_1 = require("../common/ScheduleServices");
const EventBridgeService_1 = require("../common/awsclient/EventBridgeService");
const StepFunctionService_1 = require("../common/awsclient/StepFunctionService");
class ScalableTaskDispatcher {
    constructor(taskName, taskQueueUrl, taskStateMachineArn, eventBusArn) {
        this.taskName = taskName;
        this.taskQueueUrl = taskQueueUrl;
        this.taskStateMachineArn = taskStateMachineArn;
        this.eventBusArn = eventBusArn;
        this.sqsServices = new SQSService_1.SQSService();
        this.eventBridgeServices = new EventBridgeService_1.EventBridgeService();
        this.stepFunctionServices = new StepFunctionService_1.StepFunctionService();
        this.scheduledTaskMetadataServices = new ScheduleServices_1.ScheduledTaskMetadataServices();
        this.logger = new LambdaLogger_1.LambdaLogger();
        if (!taskName || !taskQueueUrl || !taskStateMachineArn || !eventBusArn) {
            throw new Error('must provide valid taskName, taskQueueUrl, taskStateMachineArn and eventBusArn');
        }
    }
    async dispatchTasks() {
        const taskMetadata = await this.scheduledTaskMetadataServices.getCachedByName(this.taskName);
        const runningTasks = await this.stepFunctionServices.listExecutions(this.taskStateMachineArn, 'RUNNING');
        let capacity = (taskMetadata.concurrency || 0) - runningTasks.length;
        this.logger.debug(`Found ${capacity} availabilities for task ${this.taskName}`);
        if (capacity <= 0) {
            return;
        }
        while (capacity > 0) {
            const taskMessages = await this.fetchTasks(capacity > 10 ? 10 : capacity);
            this.logger.debug(`fetched ${taskMessages.length} task messages from queue`);
            if (taskMessages.length === 0) {
                break;
            }
            const taskMessageBodies = taskMessages.filter(msg => msg.messageBody).map(msg => msg.messageBody);
            if (taskMessageBodies.length > 0) {
                this.logger.debug(`dispatching ${taskMessageBodies.length} tasks`);
                await this.triggerTasks(taskMessageBodies);
            }
            await this.deleteTasks(taskMessages);
            capacity -= taskMessageBodies.length;
        }
    }
    async fetchTasks(taskCount) {
        var _a;
        const tasks = [];
        try {
            const messages = await this.sqsServices.receive({
                QueueUrl: this.taskQueueUrl,
                AttributeNames: ['All'],
                MaxNumberOfMessages: taskCount
            });
            for (const msg of messages) {
                const messageBody = (((_a = msg.Attributes) === null || _a === void 0 ? void 0 : _a.MessageGroupId) === this.taskName ? msg.Body : '') || '';
                tasks.push({ messageBody, messageId: msg.MessageId || '', receiptHandle: msg.ReceiptHandle || '' });
            }
        }
        catch (err) {
            this.logger.error(`Failed to retrieve messages from ${this.taskQueueUrl}, err: ${err.message}`);
        }
        return tasks;
    }
    async triggerTasks(taskMessageBodies) {
        try {
            const evtReqs = taskMessageBodies.map(msg => ({
                EventBusName: this.eventBusArn,
                Source: `${process.env.ENV_PREFIX}-scheduled_task_runner`,
                DetailType: 'detail',
                Detail: msg
            }));
            this.logger.debug(`Trigger scalable tasks: ${JSON.stringify(taskMessageBodies)}`);
            await this.eventBridgeServices.publish(evtReqs);
        }
        catch (err) {
            this.logger.error(`Failed to trigger scalable tasks ${JSON.stringify(taskMessageBodies)}, err: ${err.message}`);
        }
    }
    async deleteTasks(taskMessages) {
        try {
            const req = {
                QueueUrl: this.taskQueueUrl,
                Entries: taskMessages.filter(msg => msg.receiptHandle).map(msg => ({
                    Id: msg.messageId,
                    ReceiptHandle: msg.receiptHandle
                }))
            };
            await this.sqsServices.deleteBatch(req);
        }
        catch (err) {
            this.logger.error(`Failed to delete tasks from queue, err: ${err.message}`);
        }
    }
}
exports.ScalableTaskDispatcher = ScalableTaskDispatcher;
