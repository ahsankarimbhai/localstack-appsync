"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.systemHandler = exports.handler = exports.validateToken = void 0;
const _ = __importStar(require("lodash"));
const jsonwebtoken_1 = require("jsonwebtoken");
const JwtHelper_1 = require("../common/tokenhelper/JwtHelper");
const IdpKeyClientFactory_1 = require("../common/tokenhelper/IdpKeyClientFactory");
const CommonTypes_1 = require("../common/CommonTypes");
const Util_1 = require("../common/Util");
const LambdaLogger_1 = require("../common/LambdaLogger");
const AuthorizerHelper_1 = require("./AuthorizerHelper");
const logger = new LambdaLogger_1.LambdaLogger();
const getContext = async (keyClient, decodedToken, token) => {
    const user = keyClient.getUserId(decodedToken);
    const tenant = await keyClient.getTenantDataFromToken(decodedToken);
    logger.info(`Tenant in getContext is: ${JSON.stringify(tenant)}`);
    return {
        tenantUid: tenant.uid,
        tenantExtId: tenant.tenantExtId,
        tenantName: (0, Util_1.encodeTenantName)(tenant.name),
        role: tenant.role,
        id: user.id,
        irohToken: token
    };
};
const generateAuthResponse = async (keyClient, resource, tokenPayload, token) => {
    const principalId = (0, JwtHelper_1.getUser)(tokenPayload);
    const policyDocument = (0, AuthorizerHelper_1.getPolicyDocument)(AuthorizerHelper_1.EFFECT.ALLOW, resource);
    const context = await getContext(keyClient, tokenPayload, token);
    return { principalId, policyDocument, context };
};
const authorize = (keyClient, tokenPayload, resource) => {
    try {
        keyClient.verifyAudience(tokenPayload, resource);
    }
    catch (err) {
        logger.error(`Failed to authorize token ${JSON.stringify(err.message)} for resource: ${resource}.`);
        throw Util_1.UNAUTHORIZED;
    }
};
const validateToken = async (keyClient, token, decodedToken) => {
    const signingKey = await keyClient.getSigningKey(decodedToken.header);
    if (!signingKey) {
        throw Util_1.UNAUTHORIZED;
    }
    const options = {
        algorithms: ['RS256']
    };
    try {
        await (0, jsonwebtoken_1.verify)(token, signingKey, options);
    }
    catch (err) {
        if (err.name !== 'TokenExpiredError') {
            logger.error('Failed to verify token.', err);
        }
        throw Util_1.UNAUTHORIZED;
    }
};
exports.validateToken = validateToken;
const handler = async (event) => basicHandler(event);
exports.handler = handler;
const systemHandler = (event) => basicHandler(event);
exports.systemHandler = systemHandler;
const basicHandler = async (event) => {
    logger.log(`Authorizer Event is, err: ${JSON.stringify(event)}`);
    if (!event.methodArn) {
        logger.error(`methodArn must be specified in event: ${event}`);
        return Promise.reject(Util_1.UNAUTHORIZED);
    }
    const token = (0, JwtHelper_1.extractTokenFromHeader)(_.get(event, 'headers.Authorization')) || '';
    if ((0, CommonTypes_1.empty)(token)) {
        logger.error(`Token must be specified in authorization header: ${event}`);
        return Promise.reject(Util_1.UNAUTHORIZED);
    }
    if ((0, JwtHelper_1.isJwt)(token)) {
        const decodedToken = (0, jsonwebtoken_1.decode)(token, { complete: true });
        const tokenPayload = _.get(decodedToken, 'payload', '');
        const keyClient = IdpKeyClientFactory_1.IdpKeyClientFactory.getKeyClient((0, JwtHelper_1.getIssuer)(tokenPayload));
        await (0, exports.validateToken)(keyClient, token, decodedToken);
        authorize(keyClient, tokenPayload, event.methodArn);
        return generateAuthResponse(keyClient, event.methodArn, tokenPayload, token);
    }
    return Promise.reject(Util_1.UNAUTHORIZED);
};
