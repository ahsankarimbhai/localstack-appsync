"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericSourceEndpointService = void 0;
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const Util_1 = require("../../common/Util");
class GenericSourceEndpointService extends Services_1.BaseEndpointService {
    constructor(tenantUid, source, sourceModel) {
        super(tenantUid, source);
        this.sourceModel = sourceModel;
    }
    getPvType() {
        return CommonTypes_1.VertexType.GENERIC_SOURCE_DEVICE;
    }
    getPsType() {
        return CommonTypes_1.VertexType.GENERIC_SOURCE_DEVICE_STATE;
    }
    getPvLabel() {
        const camelCaseSourceName = `${this.sourceModel.sourceName.substring(0, 1).toLowerCase()}${this.sourceModel.sourceName.substring(1)}`;
        return `${camelCaseSourceName}Device${Util_1.SOURCE_SEPARATOR}${this.sourceId}`;
    }
    getPsLabel() {
        const camelCaseSourceName = `${this.sourceModel.sourceName.substring(0, 1).toLowerCase()}${this.sourceModel.sourceName.substring(1)}`;
        return `${camelCaseSourceName}DeviceState${Util_1.SOURCE_SEPARATOR}${this.sourceId}`;
    }
    processNotifications(body) {
        throw new Error('Generic notification handling is not yet supported.');
    }
}
exports.GenericSourceEndpointService = GenericSourceEndpointService;
