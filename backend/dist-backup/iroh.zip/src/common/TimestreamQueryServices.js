"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimestreamReportServices = exports.WORKFLOW_EXECUTED_QUERY_TEMPLATE = exports.WORKFLOW_RELATIVE_METRIC_SUM_QUERY_TEMPLATE = exports.WORKFLOW_GROUP_OF_METRICS_SUM_QUERY_TEMPLATE = exports.WORKFLOW_TIMES_QUERY_TEMPLATE = exports.TimestreamQueryServices = void 0;
const _ = __importStar(require("lodash"));
const LambdaLogger_1 = require("./LambdaLogger");
const client_timestream_query_1 = require("@aws-sdk/client-timestream-query");
const CommonTypes_1 = require("./CommonTypes");
const util = __importStar(require("util"));
const TimestreamWriteServices_1 = require("./TimestreamWriteServices");
const TenantServices_1 = require("./TenantServices");
class TimestreamQueryServices {
    constructor() {
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.queryClient = new client_timestream_query_1.TimestreamQueryClient({ region: process.env.AWS_REGION === 'ap-southeast-2' ? 'eu-central-1' : process.env.AWS_REGION });
        if (!process.env.ENV_PREFIX) {
            throw new Error('ENV_PREFIX is not set');
        }
    }
    async getQueryResults(query, nextToken) {
        const params = {
            QueryString: query
        };
        if (nextToken) {
            params.NextToken = nextToken;
        }
        const response = await this.queryClient.send(new client_timestream_query_1.QueryCommand(params));
        const results = this.parseQueryResult(response);
        if (!response.NextToken) {
            return results;
        }
        return _.union(results, await this.getQueryResults(query, response.NextToken));
    }
    parseQueryResult(response) {
        const queryStatus = response.QueryStatus;
        this.logger.debug('Current query status', JSON.stringify(queryStatus));
        const columnInfo = response.ColumnInfo;
        const rows = response.Rows;
        return _.map(rows, (row) => this.parseRow(columnInfo, row));
    }
    parseRow(columnInfo, row) {
        const data = row.Data;
        return _.map(columnInfo, (info, i) => TimestreamQueryServices.parseDatum(info, data[i]));
    }
    static parseDatum(info, datum) {
        if (datum.NullValue != null && datum.NullValue) {
            return { key: info.name, value: CommonTypes_1.NA };
        }
        const columnType = info.Type;
        if (columnType.ArrayColumnInfo != null || columnType.RowColumnInfo != null || columnType.TimeSeriesMeasureValueColumnInfo != null) {
            throw new Error(`Unsupported column type ${JSON.stringify(columnType)}`);
        }
        return TimestreamQueryServices.parseScalarType(info, datum);
    }
    static parseScalarType(info, datum) {
        return { key: info.Name, value: datum.ScalarValue };
    }
}
exports.TimestreamQueryServices = TimestreamQueryServices;
exports.WORKFLOW_TIMES_QUERY_TEMPLATE = 'SELECT measure_name, date_trunc(\'second\', time) as time'
    + ' FROM "%s".%s'
    + ' WHERE time >= ago(%dd)'
    + ' AND tenant = \'%s\''
    + ' AND producer = \'%s\''
    + ' AND workflow = \'%s\''
    + ' AND measure_name IN (\'started\', \'completed\', \'failed\')'
    + ' ORDER BY time';
exports.WORKFLOW_GROUP_OF_METRICS_SUM_QUERY_TEMPLATE = 'SELECT '
    + 'SUM(if(measure_name = \'%s\', measure_value::bigint)) AS %s, '
    + 'SUM(if(measure_name = \'%s\', measure_value::bigint)) AS %s, '
    + 'SUM(if(measure_name = \'%s\', measure_value::bigint)) AS %s '
    + 'FROM "%s".%s '
    + 'WHERE time >= \'%s\' '
    + 'AND time <= (\'%s\' + 10s) '
    + 'AND tenant = \'%s\' '
    + 'AND producer = \'%s\' '
    + 'AND workflow = \'%s\' '
    + 'AND measure_name in (\'%s\', \'%s\', \'%s\')';
exports.WORKFLOW_RELATIVE_METRIC_SUM_QUERY_TEMPLATE = 'SELECT SUM(measure_value::bigint) AS measure_sum'
    + ' FROM "%s".%s'
    + ' WHERE time >= ago(%dd)'
    + ' AND tenant = \'%s\''
    + ' AND producer = \'%s\''
    + ' AND workflow = \'%s\''
    + ' AND measure_name = \'%s\'';
exports.WORKFLOW_EXECUTED_QUERY_TEMPLATE = 'SELECT measure_name, tenant, producer, date_trunc(\'second\', time) as time'
    + ' FROM "%s".%s'
    + ' WHERE time >= ago(%dh)'
    + ' AND workflow = \'%s\''
    + ' AND measure_name IN (\'started\', \'completed\', \'failed\')'
    + ' ORDER BY tenant, producer, time';
class TimestreamReportServices {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.timestreamQueryServices = new TimestreamQueryServices();
        this.tenantServices = new TenantServices_1.TenantServices();
    }
    static getResultParameterName(name) {
        switch (name) {
            case TimestreamWriteServices_1.MetricName.RECORDS_TOTAL: return TimestreamReportServices.TOTAL_SUM;
            case TimestreamWriteServices_1.MetricName.RECORDS_SKIPPED: return TimestreamReportServices.SKIPPED_SUM;
            case TimestreamWriteServices_1.MetricName.RECORDS_NOT_LINKABLE: return TimestreamReportServices.NOT_LINKABLE_SUM;
            default: {
                return '';
            }
        }
    }
    async getCollectionMetricsHistory(days = 7, selectedProducers = [], workflows = [CommonTypes_1.WorkFlow.COLLECTION, CommonTypes_1.WorkFlow.NOTIFICATION_PROCESSING]) {
        const producers = _.isEmpty(selectedProducers) ? await this.tenantServices.getTenantSources(this.tenantUid) : selectedProducers;
        let results = [];
        for (const workflow of workflows) {
            results = [...results, ..._.flatten(await Promise.all(_.map(producers, producer => this.getWorkflowMetricsForNDays(producer, workflow, days))))];
        }
        return results;
    }
    async getWorkflowMetricsForNDays(producer, workflow = CommonTypes_1.WorkFlow.COLLECTION, days = 7) {
        return workflow === CommonTypes_1.WorkFlow.COLLECTION
            ? this.getCollectionMetrics(days, producer, workflow) : this.getNotificationMetrics(days, producer, CommonTypes_1.WorkFlow.NOTIFICATION_PROCESSING);
    }
    async getNotificationMetrics(days, producer, workflow, metricName = TimestreamWriteServices_1.MetricName.RECORDS_TOTAL) {
        const currentDate = new Date();
        const dayBefore = currentDate.setDate(currentDate.getDate() - 1);
        const notificationsQuery = util.format(exports.WORKFLOW_RELATIVE_METRIC_SUM_QUERY_TEMPLATE, TimestreamWriteServices_1.TimestreamWriteServices.getDatabaseName(), TimestreamWriteServices_1.TimestreamWriteServices.TABLE_NAME, days, this.tenantUid, producer, workflow, metricName);
        const notificationResults = await this.timestreamQueryServices.getQueryResults(notificationsQuery, undefined);
        const metricValue = TimestreamReportServices.getMetricValue(notificationResults[0], 'measure_sum');
        if (metricValue) {
            const metric = { key: metricName, value: parseInt(metricValue, 10) };
            return [{
                    producer,
                    workflow,
                    started: dayBefore.toString(),
                    metrics: [metric]
                }];
        }
        return [];
    }
    async getCollectionMetrics(days, producer, workflow, metricNames = [TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, TimestreamWriteServices_1.MetricName.RECORDS_SKIPPED, TimestreamWriteServices_1.MetricName.RECORDS_NOT_LINKABLE]) {
        const query = util.format(exports.WORKFLOW_TIMES_QUERY_TEMPLATE, TimestreamWriteServices_1.TimestreamWriteServices.getDatabaseName(), TimestreamWriteServices_1.TimestreamWriteServices.TABLE_NAME, days, this.tenantUid, producer, workflow);
        const results = await this.timestreamQueryServices.getQueryResults(query, undefined);
        const started = [];
        const completed = [];
        function getQuery(st, index, tenantUid) {
            return util.format(exports.WORKFLOW_GROUP_OF_METRICS_SUM_QUERY_TEMPLATE, TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, TimestreamReportServices.getResultParameterName(TimestreamWriteServices_1.MetricName.RECORDS_TOTAL), TimestreamWriteServices_1.MetricName.RECORDS_SKIPPED, TimestreamReportServices.getResultParameterName(TimestreamWriteServices_1.MetricName.RECORDS_SKIPPED), TimestreamWriteServices_1.MetricName.RECORDS_NOT_LINKABLE, TimestreamReportServices.getResultParameterName(TimestreamWriteServices_1.MetricName.RECORDS_NOT_LINKABLE), TimestreamWriteServices_1.TimestreamWriteServices.getDatabaseName(), TimestreamWriteServices_1.TimestreamWriteServices.TABLE_NAME, st, completed[index], tenantUid, producer, workflow, TimestreamWriteServices_1.MetricName.RECORDS_TOTAL, TimestreamWriteServices_1.MetricName.RECORDS_SKIPPED, TimestreamWriteServices_1.MetricName.RECORDS_NOT_LINKABLE);
        }
        function getMetrics(results) {
            const metrics = [];
            metricNames.forEach(name => {
                const metricValue = TimestreamReportServices.getMetricValue(results[0], TimestreamReportServices.getResultParameterName(name)) || '0';
                metrics.push({ key: name, value: parseInt(metricValue, 10) });
            });
            return metrics;
        }
        for (const measure of results) {
            if (TimestreamReportServices.doesMetricExist(measure, TimestreamWriteServices_1.MetricName.WORKFLOW_STARTED)) {
                if (started.length > completed.length) {
                    started.pop();
                }
                started.push(TimestreamReportServices.getMetricTime(measure));
            }
            if (TimestreamReportServices.doesMetricExist(measure, TimestreamWriteServices_1.MetricName.WORKFLOW_COMPLETED) || TimestreamReportServices.doesMetricExist(measure, TimestreamWriteServices_1.MetricName.WORKFLOW_FAILED)) {
                if (started.length === completed.length + 1) {
                    completed.push(TimestreamReportServices.getMetricTime(measure));
                }
            }
        }
        return Promise.all(_.map(started, async (st, index) => {
            if (completed.length === index) {
                return {
                    producer,
                    workflow,
                    started: st,
                    metrics: []
                };
            }
            const query = getQuery(st, index, this.tenantUid);
            const results = await this.timestreamQueryServices.getQueryResults(query, undefined);
            return {
                producer,
                workflow,
                started: st,
                durationInSec: (Date.parse(completed[index]) - Date.parse(st)) / 1000,
                metrics: getMetrics(results)
            };
        }));
    }
    static doesMetricExist(measure, name) {
        return !_.isUndefined(_.find(measure, { key: 'measure_name', value: name }));
    }
    static getMetricTime(measure) {
        return TimestreamReportServices.getMetricValue(measure, 'time');
    }
    static getMetricValue(measure, name) {
        const metric = _.find(measure, { key: name });
        return _.get(metric, 'value');
    }
}
exports.TimestreamReportServices = TimestreamReportServices;
TimestreamReportServices.TOTAL_SUM = 'total_sum';
TimestreamReportServices.SKIPPED_SUM = 'skipped_sum';
TimestreamReportServices.NOT_LINKABLE_SUM = 'not_linkable_sum';
