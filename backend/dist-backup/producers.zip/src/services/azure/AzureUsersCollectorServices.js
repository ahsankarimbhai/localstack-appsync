"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureUserCollectorServices = exports.AzureUsersFetcher = void 0;
const AzureUsersCollection_1 = require("./AzureUsersCollection");
const AzureGroupsCollection_1 = require("./AzureGroupsCollection");
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const axios_1 = require("axios");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const query_string_1 = __importDefault(require("query-string"));
const LIMIT = 100;
const PREMIUM_PROPERTIES = 'accountEnabled,businessPhones,companyName,createdDateTime,deletedDateTime,department,displayName,employeeHireDate,employeeId,employeeLeaveDateTime,employeeType,givenName,id,identities,jobTitle,lastPasswordChangeDateTime,mail,mailNickname,mobilePhone,officeLocation,onPremisesDistinguishedName,onPremisesDomainName,onPremisesImmutableId,onPremisesSamAccountName,onPremisesSecurityIdentifier,onPremisesUserPrincipalName,otherMails,passwordPolicies,surname,securityIdentifier,signInActivity,usageLocation,userPrincipalName,userType';
const BASIC_PROPERTIES = 'accountEnabled,businessPhones,companyName,createdDateTime,deletedDateTime,department,displayName,employeeHireDate,employeeId,employeeLeaveDateTime,employeeType,givenName,id,identities,jobTitle,lastPasswordChangeDateTime,mail,mailNickname,mobilePhone,officeLocation,onPremisesDistinguishedName,onPremisesDomainName,onPremisesImmutableId,onPremisesSamAccountName,onPremisesSecurityIdentifier,onPremisesUserPrincipalName,otherMails,passwordPolicies,surname,securityIdentifier,usageLocation,userPrincipalName,userType';
var BatchId;
(function (BatchId) {
    BatchId["USERS"] = "1";
    BatchId["MANAGERS"] = "2";
    BatchId["OWNED_DEVICES"] = "3";
})(BatchId || (BatchId = {}));
class AzureUsersFetcher {
    constructor(client, limit) {
        this.client = client;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.limit = LIMIT;
        this.useBasicProperties = false;
        this.total = 0;
        this.uri = '';
        this.limit = limit || LIMIT;
    }
    async fetchNextPage(uri, retryUtil) {
        this.uri = uri;
        const batchResponses = await retryUtil.executeWithRetry(() => this.fetchPageOfUsers(uri), (err) => this.shouldAbortRetry(err), (err) => this.handleFailure(err));
        if (batchResponses && batchResponses.length === 3) {
            const usersBatchResponse = batchResponses.find(i => i.id === BatchId.USERS);
            const managerBatchResponse = batchResponses.find(i => i.id === BatchId.MANAGERS);
            const ownedDevicesBatchResponse = batchResponses.find(i => i.id === BatchId.OWNED_DEVICES);
            const users = usersBatchResponse === null || usersBatchResponse === void 0 ? void 0 : usersBatchResponse.body.value;
            const managers = managerBatchResponse === null || managerBatchResponse === void 0 ? void 0 : managerBatchResponse.body.value;
            const ownedDevices = ownedDevicesBatchResponse === null || ownedDevicesBatchResponse === void 0 ? void 0 : ownedDevicesBatchResponse.body.value;
            if (users === undefined || managers === undefined || ownedDevices === undefined) {
                return [];
            }
            this.total += users.length;
            this.logger.debug(`Received ${users.length} Azure users, total ${this.total}`);
            users.forEach((user) => {
                if (user.memberOf) {
                    user.groupIds = user.memberOf.map(group => (group.id));
                    user.groupNames = user.memberOf.map(group => group.displayName);
                    user.groupDescriptions = user.memberOf.map(group => group.description);
                }
            });
            const map = new Map();
            users.forEach(item => map.set(item.id, item));
            ownedDevices.forEach(item => map.set(item.id, { ...map.get(item.id), ...item }));
            managers.forEach((item) => {
                if (item.manager) {
                    map.set(item.id, { ...map.get(item.id), manager: item.manager.displayName });
                }
            });
            const mergedUsers = Array.from(map.values());
            return mergedUsers;
        }
        return [];
    }
    async fetchPageOfUsers(uri) {
        var _a, _b;
        let usersUri;
        let managersUri;
        let ownedDevicesUri;
        if (uri.includes('managersNextLink')) {
            const uriSplit = uri.split('?');
            const uriParams = new URLSearchParams(uriSplit[1]);
            const usersNextLink = uriParams.get('usersNextLink') || '';
            const managersNextLink = uriParams.get('managersNextLink') || '';
            const ownedDevicesNextLink = uriParams.get('ownedDevicesNextLink') || '';
            usersUri = usersNextLink.replace('https://graph.microsoft.com/v1.0/', '');
            managersUri = managersNextLink.replace('https://graph.microsoft.com/v1.0/', '');
            ownedDevicesUri = ownedDevicesNextLink.replace('https://graph.microsoft.com/v1.0/', '');
        }
        else {
            const properties = this.useBasicProperties ? BASIC_PROPERTIES : PREMIUM_PROPERTIES;
            usersUri = `users?$orderBy=displayName&$top=${this.limit}&$select=${properties}&$expand=memberOf($select=displayName,description,id)&$count=true`;
            managersUri = `users?$orderby=displayName&$top=${this.limit}&$expand=manager($select=displayName)&$count=true`;
            ownedDevicesUri = `users?$orderby=displayName&$top=${this.limit}&$expand=ownedDevices($select=accountEnabled,approximateLastSignInDateTime,deviceId,displayName,manufacturer,model,operatingSystem,operatingSystemVersion,trustType)&$count=true`;
        }
        const batchRequest = {
            requests: [
                {
                    url: usersUri,
                    method: 'GET',
                    id: BatchId.USERS
                },
                {
                    url: managersUri,
                    method: 'GET',
                    id: BatchId.MANAGERS
                },
                {
                    url: ownedDevicesUri,
                    method: 'GET',
                    id: BatchId.OWNED_DEVICES
                }
            ]
        };
        const res = await this.client.post('/v1.0/$batch', batchRequest);
        const batchResponses = (_a = res.data) === null || _a === void 0 ? void 0 : _a.responses;
        if (batchResponses === undefined) {
            this.logger.error('Azure Users response was missing batch responses');
            return [];
        }
        const usersBatchResponse = batchResponses.find(i => i.id === BatchId.USERS);
        const managerBatchResponse = batchResponses.find(i => i.id === BatchId.MANAGERS);
        const ownedDevicesBatchResponse = batchResponses.find(i => i.id === BatchId.OWNED_DEVICES);
        const usersNextLink = usersBatchResponse === null || usersBatchResponse === void 0 ? void 0 : usersBatchResponse.body['@odata.nextLink'];
        const managersNextLink = managerBatchResponse === null || managerBatchResponse === void 0 ? void 0 : managerBatchResponse.body['@odata.nextLink'];
        const ownedDevicesNextLink = ownedDevicesBatchResponse === null || ownedDevicesBatchResponse === void 0 ? void 0 : ownedDevicesBatchResponse.body['@odata.nextLink'];
        if (usersBatchResponse && usersBatchResponse.status === 403 && !this.useBasicProperties) {
            this.logger.error('Azure Users query received a 403, will retry with non-premium properties...');
            this.useBasicProperties = true;
            throw usersBatchResponse === null || usersBatchResponse === void 0 ? void 0 : usersBatchResponse.body.error;
        }
        if (usersBatchResponse === null || usersBatchResponse === void 0 ? void 0 : usersBatchResponse.body.error) {
            this.logger.error(`Azure Users received error: ${JSON.stringify(usersBatchResponse.body.error)}`);
            const err = new axios_1.AxiosError(`${usersBatchResponse.status}: ${usersBatchResponse.body.error.message} (${usersBatchResponse.body.error.code})`, usersBatchResponse.status.toString());
            throw err;
        }
        this.nextUri = undefined;
        if (usersNextLink) {
            const nextLinks = {
                usersNextLink,
                managersNextLink,
                ownedDevicesNextLink
            };
            const encoded = query_string_1.default.stringify(nextLinks);
            this.nextUri = `/v1.0/$batch?${encoded}`;
        }
        if ((_b = res.data) === null || _b === void 0 ? void 0 : _b.responses) {
            return res.data.responses;
        }
        return [];
    }
    shouldAbortRetry(err) {
        var _a, _b, _c;
        if (err.response && (err.response.status === 400 || err.response.status === 401 || err.response.status === 403 || err.response.status === 404)) {
            if (((_b = (_a = err.response.data) === null || _a === void 0 ? void 0 : _a.errors) === null || _b === void 0 ? void 0 : _b.length) > 0 && err.response.data.errors[0].message && err.response.data.errors[0].code) {
                err.message = `${err.response.data.errors[0].message} (${err.response.data.errors[0].code}). `;
            }
            else {
                err.message = `${err.response.statusText} (${err.response.status}). `;
            }
            err.message += 'Please verify the Azure Users module configuration';
            this.logger.error(`Azure Users query cannot be resolved (aborting retry) because status=${err.response.status}, statusText=${err.response.statusText}, url=${(_c = err.config) === null || _c === void 0 ? void 0 : _c.baseURL}, and data=${JSON.stringify(err.response.data)}`);
            return true;
        }
        return false;
    }
    handleFailure(err) {
        this.logger.error(`Azure Users query failed all retries where error message=${err.message}`);
        if (err.lastError && err.lastError.response) {
            this.logger.error(`lastError status=${err.lastError.response.status}, statusText=${err.lastError.response.statusText}, url=${err.lastError.config.baseURL}, and data=${JSON.stringify(err.lastError.response.data)}`);
        }
        throw err;
    }
    provideNextUri() {
        return this.nextUri;
    }
}
exports.AzureUsersFetcher = AzureUsersFetcher;
class AzureUserCollectorServices extends Services_1.BaseCollectorService {
    constructor(secrets, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.functionName = functionName;
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.AZURE_USERS, this.sourceId);
        }
    }
    async getGroups(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.AZURE_USERS));
        const bulkLength = limit || LIMIT;
        return new AzureGroupsCollection_1.AzureGroupsCollection(this.client, nextUri || `/v1.0/groups?$top=${bulkLength}`, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getUsers(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.AZURE_USERS));
        const bulkLength = limit || LIMIT;
        return new AzureUsersCollection_1.AzureUsersCollection(new AzureUsersFetcher(this.client, bulkLength), nextUri || '/v1.0/$batch', timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.AzureUserCollectorServices = AzureUserCollectorServices;
