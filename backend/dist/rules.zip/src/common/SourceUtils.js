"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SourceUtils = exports.diManagedProducers = exports.moduleTypeToProducerSource = exports.logger = void 0;
const IrohModuleInstanceClient_1 = require("./IrohModuleInstanceClient");
const CommonTypes_1 = require("./CommonTypes");
const _ = __importStar(require("lodash"));
const LambdaLogger_1 = require("./LambdaLogger");
const TenantServices_1 = require("./TenantServices");
const Util_1 = require("./Util");
exports.logger = new LambdaLogger_1.LambdaLogger();
const DUO_USERS_SUFFIX = ' (Users)';
exports.moduleTypeToProducerSource = {};
exports.moduleTypeToProducerSource.amp = CommonTypes_1.Source.AMP;
exports.moduleTypeToProducerSource.duo = CommonTypes_1.Source.DUO;
exports.moduleTypeToProducerSource.duo_users = CommonTypes_1.Source.DUO_USERS;
exports.moduleTypeToProducerSource.duo_new_auth = CommonTypes_1.Source.DUO;
exports.moduleTypeToProducerSource.intune = CommonTypes_1.Source.INTUNE;
exports.moduleTypeToProducerSource.meraki = CommonTypes_1.Source.MERAKI;
exports.moduleTypeToProducerSource.jamf = CommonTypes_1.Source.JAMF;
exports.moduleTypeToProducerSource.umbrella = CommonTypes_1.Source.UMBRELLA;
exports.moduleTypeToProducerSource.mobileiron = CommonTypes_1.Source.MOBILEIRON;
exports.moduleTypeToProducerSource.secure_client = CommonTypes_1.Source.UNIFIED_CONNECTOR;
exports.moduleTypeToProducerSource.airwatch = CommonTypes_1.Source.AIRWATCH;
exports.moduleTypeToProducerSource.orbital = CommonTypes_1.Source.ORBITAL;
exports.moduleTypeToProducerSource.servicenow = CommonTypes_1.Source.SERVICENOW;
exports.moduleTypeToProducerSource.sentinelone = CommonTypes_1.Source.SENTINEL_ONE;
exports.moduleTypeToProducerSource.cybervision = CommonTypes_1.Source.CYBERVISION;
exports.moduleTypeToProducerSource.crowdstrike = CommonTypes_1.Source.CROWDSTRIKE;
exports.moduleTypeToProducerSource.defender = CommonTypes_1.Source.DEFENDER;
exports.moduleTypeToProducerSource.azuread_users = CommonTypes_1.Source.AZURE_USERS;
exports.moduleTypeToProducerSource.trendmicro = CommonTypes_1.Source.TREND_VISION_ONE;
exports.diManagedProducers = [CommonTypes_1.Source.CUSTOM];
class SourceUtils {
    static getSourceByModuleType(moduleType) {
        const secureXClass = _.find(moduleType.external_references, { class: IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS });
        if (secureXClass && secureXClass.external_id) {
            const secureXType = secureXClass.external_id.split(':').pop();
            return secureXType ? exports.moduleTypeToProducerSource[secureXType] : undefined;
        }
        exports.logger.debug(`${IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS} is missing on moduleType ${JSON.stringify(moduleType)}`);
        return undefined;
    }
    static async getModuleTypeIdBySource(tenantUid, source) {
        if (source === CommonTypes_1.Source.DUO_USERS) {
            source = CommonTypes_1.Source.DUO;
        }
        const irohModuleInstanceClient = new IrohModuleInstanceClient_1.IrohModuleInstanceClient(tenantUid);
        const diModuleTypes = await irohModuleInstanceClient.getDIModuleTypes();
        const result = _.find(diModuleTypes, (moduleType) => {
            const secureXClass = _.find(moduleType.external_references, { class: IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS });
            if (secureXClass && secureXClass.external_id) {
                const secureXType = secureXClass.external_id.split(':').pop();
                if (secureXType === undefined) {
                    return false;
                }
                const producer = exports.moduleTypeToProducerSource[secureXType];
                if (producer === undefined) {
                    return false;
                }
                return (secureXType && producer === source);
            }
            return false;
        });
        return result && result.id ? result.id : undefined;
    }
    static injectDuoUserModules(diModuleTypes, diModuleInstances) {
        const duoModuleTypes = _.filter(diModuleTypes, diModuleType => _.find(diModuleType.external_references, { external_id: 'securex:di:duo' }));
        const duoInstances = _.filter(diModuleInstances, moduleInstance => _.find(duoModuleTypes, { id: moduleInstance.module_type_id }));
        if (duoModuleTypes && duoModuleTypes.length > 0) {
            for (const duoType of duoModuleTypes) {
                const duoUsersType = JSON.parse(JSON.stringify(duoType));
                duoUsersType.title = `${duoUsersType.title} ${DUO_USERS_SUFFIX}`;
                duoUsersType.id = `${duoUsersType.id}${Util_1.SOURCE_TAG_DYNAMIC}`;
                const index = _.findIndex(duoUsersType.external_references, { external_id: 'securex:di:duo' });
                duoUsersType.external_references.splice(index, 1, { external_id: 'securex:di:duo_users', class: 'securex:di:asset_source' });
                diModuleTypes.push(duoUsersType);
            }
            exports.logger.debug(`Added DUO_USER module type, diModuleTypes = ${JSON.stringify(diModuleTypes)}`);
        }
        if (diModuleInstances && duoInstances && duoInstances.length > 0) {
            for (const duoInstance of duoInstances) {
                const duoUsersInstance = JSON.parse(JSON.stringify(duoInstance));
                duoUsersInstance.name = `${duoUsersInstance.name} ${DUO_USERS_SUFFIX}`;
                duoUsersInstance.id = `${duoUsersInstance.id}${Util_1.SOURCE_TAG_DYNAMIC}`;
                duoUsersInstance.module_type_id = `${duoUsersInstance.module_type_id}${Util_1.SOURCE_TAG_DYNAMIC}`;
                diModuleInstances.push(duoUsersInstance);
            }
            exports.logger.debug(`Added DUO_USERS module instance, diModuleInstances = ${JSON.stringify(diModuleInstances)}`);
        }
    }
    static async extractIrohModuleTypesInformation(tenantUid) {
        const irohModuleInstanceClient = new IrohModuleInstanceClient_1.IrohModuleInstanceClient(tenantUid);
        const moduleInstances = await irohModuleInstanceClient.getModuleInstances();
        const diModuleTypes = await irohModuleInstanceClient.getDIModuleTypes();
        const diModuleInstances = _.filter(moduleInstances, moduleInstance => _.find(diModuleTypes, { id: moduleInstance.module_type_id }));
        if (diModuleInstances) {
            SourceUtils.injectDuoUserModules(diModuleTypes, diModuleInstances);
        }
        return { diModuleTypes, diModuleInstances };
    }
    static matchModuleInstancesToModuleTypes(diModuleInstances, diModuleTypes) {
        return _.map(diModuleInstances, moduleInstance => {
            const moduleType = _.find(diModuleTypes, { id: moduleInstance.module_type_id });
            if (!moduleType) {
                throw new Error(`Failed to find module type for ${JSON.stringify(moduleInstance)}`);
            }
            return { moduleInstance, moduleType };
        });
    }
    static shouldModuleInstanceBeUsed(moduleInstance, moduleType, featureFlags) {
        var _a;
        switch (SourceUtils.getSourceByModuleType(moduleType)) {
            case CommonTypes_1.Source.ORBITAL:
                return (_a = _.get(moduleInstance.settings, 'custom_enable_device_insight')) !== null && _a !== void 0 ? _a : true;
            case CommonTypes_1.Source.SERVICENOW:
                return _.includes(featureFlags, TenantServices_1.FeatureFlag.SERVICE_NOW);
            case CommonTypes_1.Source.CYBERVISION:
                return _.includes(featureFlags, TenantServices_1.FeatureFlag.CYBER_VISION_ENABLED);
            case CommonTypes_1.Source.DUO_USERS:
                return _.includes(featureFlags, TenantServices_1.FeatureFlag.DUO_USERS);
            case CommonTypes_1.Source.TREND_VISION_ONE:
                return _.includes(featureFlags, TenantServices_1.FeatureFlag.TREND_VISION_ONE);
            default:
                return true;
        }
    }
    static async fetchIrohModulesInstancesAndTypesToUseInDi(tenantUid, featureFlags) {
        const { diModuleTypes, diModuleInstances } = await SourceUtils.extractIrohModuleTypesInformation(tenantUid);
        if (!diModuleTypes || _.isEmpty(diModuleTypes)) {
            exports.logger.info(`There are no Iroh module types with ${IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS} class for tenant ${tenantUid}`);
            return [];
        }
        if (!diModuleInstances || _.isEmpty(diModuleInstances)) {
            exports.logger.info(`There are no Iroh module type instances defined for tenant ${tenantUid}`);
            return [];
        }
        const matchedModuleInstancesToValues = SourceUtils.matchModuleInstancesToModuleTypes(diModuleInstances, diModuleTypes);
        return _.filter(matchedModuleInstancesToValues, ({ moduleInstance, moduleType }) => SourceUtils.shouldModuleInstanceBeUsed(moduleInstance, moduleType, featureFlags));
    }
    static extractModuleInstanceBaseUrl(producerType, moduleInstance, moduleType) {
        var _a, _b, _c, _d, _e, _f;
        switch (producerType) {
            case CommonTypes_1.Source.AMP:
                const urlFromModuleInstance = _.get(moduleInstance.settings, 'url');
                const urlFromModuleType = (_b = _.first((_a = _.find(moduleType === null || moduleType === void 0 ? void 0 : moduleType.configuration_spec, s => s.key === 'url')) === null || _a === void 0 ? void 0 : _a.options)) === null || _b === void 0 ? void 0 : _b.value;
                return _.isEmpty(urlFromModuleInstance) ? urlFromModuleType : urlFromModuleInstance;
            case CommonTypes_1.Source.CROWDSTRIKE:
                return moduleInstance.settings.custom_host;
            case CommonTypes_1.Source.DEFENDER:
                if (((_c = moduleType.properties['proxy-endpoint-metadata']) === null || _c === void 0 ? void 0 : _c.length) > 0) {
                    return moduleType.properties['proxy-endpoint-metadata'][0].target_url;
                }
                return moduleType.properties.url;
            case CommonTypes_1.Source.SENTINEL_ONE:
                return moduleInstance.settings.custom_host;
            case CommonTypes_1.Source.DUO:
                const shouldFetchDataFromModuleType = ((_d = (_.find(moduleType === null || moduleType === void 0 ? void 0 : moduleType.external_references, { class: IrohModuleInstanceClient_1.IrohModuleInstanceClient.IROH_MODULE_TYPE_CLASS }))) === null || _d === void 0 ? void 0 : _d.external_id) === 'securex:di:duo_new_auth';
                if (shouldFetchDataFromModuleType) {
                    let duoUrlFromModuleType = (_e = (_.find(moduleType === null || moduleType === void 0 ? void 0 : moduleType.external_references, { class: 'securex:duo:posture_endpoint' }))) === null || _e === void 0 ? void 0 : _e.link;
                    if (_.startsWith(duoUrlFromModuleType, 'https://')) {
                        duoUrlFromModuleType = _.trimStart(duoUrlFromModuleType, 'https://');
                    }
                    return duoUrlFromModuleType;
                }
                return _.get(moduleInstance.settings, 'duo-admin-url');
            case CommonTypes_1.Source.DUO_USERS:
                return _.get(moduleInstance.settings, 'duo-admin-url');
            case CommonTypes_1.Source.ORBITAL:
                return process.env.ORBITAL_BASE_URL;
            case CommonTypes_1.Source.TREND_VISION_ONE:
                return `https://${moduleInstance.settings.custom_host}`;
            case CommonTypes_1.Source.UNIFIED_CONNECTOR:
                return (_f = _.find(moduleType.external_references, { class: IrohModuleInstanceClient_1.IrohModuleInstanceClient.CSC_SUBSCRIPTION_URL_CLASS })) === null || _f === void 0 ? void 0 : _f.link;
            default:
                return _.get(moduleInstance.settings, 'url');
        }
    }
    static getMatchingModuleInstances(producer, diModuleInstances, diModuleTypes) {
        const moduleType = _.find(diModuleTypes, (diModuleType) => producer.producerType === SourceUtils.getSourceByModuleType(diModuleType));
        if (!moduleType) {
            return undefined;
        }
        const moduleInstances = _.filter(diModuleInstances, { module_type_id: moduleType.id });
        if (!moduleInstances || _.isEmpty(moduleInstances)) {
            return undefined;
        }
        return _.size(moduleInstances) === 1 ? moduleInstances[0] : SourceUtils.getMatchingModuleInstance(producer, moduleInstances);
    }
    static getMatchingModuleInstance(producer, moduleInstances) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        let matchingMethod = () => false;
        let username = (_a = _.find(producer.properties, { key: 'clientId' })) === null || _a === void 0 ? void 0 : _a.value;
        let url = (_b = _.find(producer.properties, { key: 'baseURL' })) === null || _b === void 0 ? void 0 : _b.value;
        switch (producer.producerType) {
            case CommonTypes_1.Source.AMP:
                username = (_c = _.find(producer.properties, { key: 'clientId' })) === null || _c === void 0 ? void 0 : _c.value;
                url = (_d = _.find(producer.properties, { key: 'baseURL' })) === null || _d === void 0 ? void 0 : _d.value;
                matchingMethod = (moduleInstance) => _.get(moduleInstance.settings, 'user') === username && _.get(moduleInstance.settings, 'url') === url;
                break;
            case CommonTypes_1.Source.AIRWATCH:
                username = (_e = _.find(producer.properties, { key: 'airWatchUsername' })) === null || _e === void 0 ? void 0 : _e.value;
                url = (_f = _.find(producer.properties, { key: 'baseUrl' })) === null || _f === void 0 ? void 0 : _f.value;
                matchingMethod = (moduleInstance) => _.get(moduleInstance.settings, 'basic-auth-user') === username && _.get(moduleInstance.settings, 'url') === url;
                break;
            case CommonTypes_1.Source.JAMF:
                username = (_g = _.find(producer.properties, { key: 'username' })) === null || _g === void 0 ? void 0 : _g.value;
                url = (_h = _.find(producer.properties, { key: 'jamfUrl' })) === null || _h === void 0 ? void 0 : _h.value;
                matchingMethod = (moduleInstance) => _.get(moduleInstance.settings, 'basic-auth-user') === username && _.get(moduleInstance.settings, 'url') === url;
                break;
            case CommonTypes_1.Source.MOBILEIRON:
                url = (_j = _.find(producer.properties, { key: 'baseUrl' })) === null || _j === void 0 ? void 0 : _j.value;
                matchingMethod = (moduleInstance) => _.get(moduleInstance.settings, 'url') === url;
                break;
            default:
        }
        const matchingModuleInstances = _.filter(moduleInstances, moduleInstance => matchingMethod(moduleInstance));
        if (!matchingModuleInstances || _.isEmpty(matchingModuleInstances)) {
            exports.logger.warn(`Unable to find single matching module instance for ${JSON.stringify(producer)}`);
            return undefined;
        }
        if (_.size(matchingModuleInstances) !== 1) {
            exports.logger.warn(`Multiple ${producer.producerType} instances defined with same details ${JSON.stringify(producer)}`);
            return undefined;
        }
        return matchingModuleInstances[0];
    }
}
exports.SourceUtils = SourceUtils;
