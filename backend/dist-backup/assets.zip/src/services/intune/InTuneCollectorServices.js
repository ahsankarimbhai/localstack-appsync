"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InTuneCollectorServices = void 0;
const InTuneDevicesCollection_1 = require("./InTuneDevicesCollection");
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const LIMIT = 100;
class InTuneCollectorServices extends Services_1.BaseCollectorService {
    constructor(secrets, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.secrets = secrets;
        this.functionName = functionName;
    }
    async init() {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, CommonTypes_1.Source.INTUNE, this.sourceId);
        }
    }
    async getDevices(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init();
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.INTUNE));
        const bulkLength = limit || LIMIT;
        return new InTuneDevicesCollection_1.InTuneDevicesCollection(this.client, nextUri || `/v1.0/deviceManagement/managedDevices?$top=${bulkLength}`, timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.InTuneCollectorServices = InTuneCollectorServices;
