"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JamfProcessorServices = void 0;
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const JamfEndpointService_1 = require("../../collectors/services/JamfEndpointService");
class JamfProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(input, vertexState, currentTopology, changes, unchanged) {
        if (input.general) {
            const jamfComputer = input;
            await this.verifyChange(currentTopology, jamfComputer.general.name, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.udid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.general.lastIpAddress, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.general.lastReportedIp, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.userAndLocation.username, CommonTypes_1.VertexType.USER, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.userAndLocation.email, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.userAndLocation.phone, CommonTypes_1.VertexType.PHONE_NUMBER, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.hardware.serialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.hardware.macAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        }
        else if (input.type) {
            const jamfMobileDevice = input;
            await this.verifyChange(currentTopology, jamfMobileDevice.name, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
            await this.verifyChange(currentTopology, jamfMobileDevice.serialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
            await this.verifyChange(currentTopology, jamfMobileDevice.wifiMacAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
            await this.verifyChange(currentTopology, jamfMobileDevice.phoneNumber, CommonTypes_1.VertexType.PHONE_NUMBER, changes, unchanged);
            await this.verifyChange(currentTopology, jamfMobileDevice.username, CommonTypes_1.VertexType.USER, changes, unchanged);
        }
        else {
            const jamfComputer = input;
            await this.verifyChange(currentTopology, jamfComputer.macAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.alternateMacAddress, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.serialNumber, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.udid, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.ipAddress, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.emailAddress, CommonTypes_1.VertexType.EMAIL, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.imei, CommonTypes_1.VertexType.IMEI, changes, unchanged);
            await this.verifyChange(currentTopology, jamfComputer.username, CommonTypes_1.VertexType.USER, changes, unchanged);
            await this.verifyChange(currentTopology, _.get(jamfComputer, 'location.username'), CommonTypes_1.VertexType.USER, changes, unchanged, jamfComputer.location);
            await this.verifyChange(currentTopology, jamfComputer.name, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
        }
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new JamfEndpointService_1.JamfEndpointService(tenantUid, sourceId);
    }
}
exports.JamfProcessorServices = JamfProcessorServices;
