"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DataMigrationStatusHandler = void 0;
const BasicScheduledTaskProcessor_1 = require("../scheduled/BasicScheduledTaskProcessor");
const DataMigrationServices_1 = require("../common/DataMigrationServices");
class DataMigrationStatusHandler extends BasicScheduledTaskProcessor_1.BasicStatusHandler {
    constructor(taskName, tenantUid, producer) {
        super();
        this.taskName = taskName;
        this.tenantUid = tenantUid;
        this.producer = producer;
        this.dataMigrationTaskServices = new DataMigrationServices_1.DataMigrationTaskServices();
    }
    async handleSuccess() {
        await super.handleSuccess();
        return this.dataMigrationTaskServices.updateTaskEndTime(this.taskName, this.tenantUid, this.producer);
    }
    async handleFailure(error) {
        await super.handleFailure(error);
        return this.dataMigrationTaskServices.updateTaskEndTime(this.taskName, this.tenantUid, this.producer, [`${error.message}, ${JSON.stringify(error)}`]);
    }
}
exports.DataMigrationStatusHandler = DataMigrationStatusHandler;
