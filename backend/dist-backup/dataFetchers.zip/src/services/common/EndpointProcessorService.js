"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EndpointProcessorService = void 0;
const PostureEndpointService_1 = require("../../model/PostureEndpointService");
const CommonTypes_1 = require("../../common/CommonTypes");
const NeptuneServicesFactory_1 = require("../../common/neptune/NeptuneServicesFactory");
const _ = __importStar(require("lodash"));
const gremlin_1 = require("gremlin");
const BaseGraphService_1 = require("../../model/BaseGraphService");
const BaseProcessorService_1 = require("./BaseProcessorService");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
class EndpointProcessorService extends BaseProcessorService_1.BaseProcessorService {
    constructor(tenantUid, sourceId) {
        super(tenantUid, sourceId);
        this.tenantUid = tenantUid;
        this.sourceId = sourceId;
        this.initProcessorService(tenantUid, sourceId);
    }
    async applyChanges(changes) {
        if (changes.length === 0) {
            return { savedVertex: undefined, durationMetrics: [] };
        }
        const lastUpdatedChanged = _.find(changes, { type: CommonTypes_1.ChangeType.LAST_UPDATED_UPDATE });
        if (changes.length === 1 && lastUpdatedChanged) {
            const lastUpdatedVertex = this.toVertex(lastUpdatedChanged);
            const neptuneService = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
            const existPSCount = await neptuneService.executeTenantQuery((g) => neptuneService.getGraphTraversal(g, lastUpdatedVertex.getId())
                .has(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, gremlin_1.process.P.gt(lastUpdatedVertex.getPropertyValue(CommonTypes_1.VertexBasicProperty.LAST_UPDATED))).count().next(), NeptuneClientManager_1.NeptuneClientType.Reader);
            if (existPSCount.value > 0) {
                this.logger.info('no ingestion is needed, PS is already stored with a newer "lastUpdated"');
                return { savedVertex: undefined, durationMetrics: [] };
            }
            await neptuneService.executeTenantQuery((g) => this.executeTraversal(this.addUpsertTraversal(g, lastUpdatedVertex, true)));
            const peToUpdate = await this.getPostureEntityForPs(lastUpdatedChanged.newVertex, CommonTypes_1.EdgeType.POSTURE_ENDPOINT);
            if (peToUpdate) {
                await this.getPostureService().updateSearchableVertex(peToUpdate);
                await this.getPostureService().sendNotifications(peToUpdate);
            }
            else {
                this.logger.error(`Should have been updating PE for a LAST_UPDATED_UPDATE of ${_.get(lastUpdatedChanged.newVertex, 'id')}, but was unable to find a connected PE.`);
            }
            return { savedVertex: lastUpdatedChanged.newVertex, durationMetrics: [] };
        }
        const pv = _.find(changes, c => ([CommonTypes_1.ChangeType.NEW, CommonTypes_1.ChangeType.DELETE, CommonTypes_1.ChangeType.UPDATE].includes(c.type)));
        if (!pv) {
            throw new Error(`Root vertex does not exist, tenant=${this.tenantUid}, producer=${this.sourceId}, ${JSON.stringify(changes)}`);
        }
        const changedPv = this.toVertex(pv);
        if (pv.type === CommonTypes_1.ChangeType.DELETE) {
            await this.closeCurrentState(changedPv, CommonTypes_1.EdgeType.POSTURE_ENDPOINT);
            return { savedVertex: undefined, durationMetrics: [] };
        }
        const pvs = _.find(changes, { type: CommonTypes_1.ChangeType.STATE_UPDATE });
        if (!pvs) {
            throw new Error('State vertex does not exist');
        }
        const newPvs = this.toVertex(pvs);
        const neptuneService = (0, NeptuneServicesFactory_1.getNeptuneServices)(this.tenantUid);
        const existPSCount = await neptuneService.executeTenantQuery((g) => neptuneService.getGraphTraversal(g, changedPv.getId())
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL)
            .inV()
            .has(CommonTypes_1.VertexBasicProperty.LAST_UPDATED, gremlin_1.process.P.gt(newPvs.getPropertyValue(CommonTypes_1.VertexBasicProperty.LAST_UPDATED)))
            .count()
            .next(), NeptuneClientManager_1.NeptuneClientType.Reader);
        if (existPSCount.value > 0) {
            this.logger.info('no ingestion is needed, PS is already stored with a newer "lastUpdated"');
            return { savedVertex: undefined, durationMetrics: [] };
        }
        await neptuneService.executeTenantQuery((g) => {
            let withFold = true;
            let graphTraversal = g;
            if (pv.type === CommonTypes_1.ChangeType.NEW) {
                graphTraversal = this.addUpsertTraversal(graphTraversal, changedPv, withFold);
                withFold = false;
            }
            graphTraversal = this.addUpsertTraversal(graphTraversal, newPvs, withFold);
            for (const change of changes) {
                let edgeType;
                switch (change.type) {
                    case CommonTypes_1.ChangeType.NEW:
                    case CommonTypes_1.ChangeType.UPDATE:
                    case CommonTypes_1.ChangeType.STATE_UPDATE:
                        break;
                    case CommonTypes_1.ChangeType.COMPUTER_SID_UPDATE:
                    case CommonTypes_1.ChangeType.HARDWARE_ID_UPDATE:
                    case CommonTypes_1.ChangeType.SERIAL_NUMBER_UPDATE:
                    case CommonTypes_1.ChangeType.IMEI_UPDATE:
                        edgeType = CommonTypes_1.EdgeType.HAS;
                        break;
                    case CommonTypes_1.ChangeType.MAC_ADDR_UPDATE:
                    case CommonTypes_1.ChangeType.PHONE_NUMBER_UPDATE:
                    case CommonTypes_1.ChangeType.EXTERNAL_IP_ADDR_UPDATE:
                    case CommonTypes_1.ChangeType.HOSTNAME_UPDATE:
                        edgeType = CommonTypes_1.EdgeType.USES;
                        break;
                    case CommonTypes_1.ChangeType.BROWSER_UPDATE:
                    case CommonTypes_1.ChangeType.EXTERNAL_REFERENCE_UPDATE:
                    case CommonTypes_1.ChangeType.USER_UPDATE:
                    case CommonTypes_1.ChangeType.EMAIL_UPDATE:
                    case CommonTypes_1.ChangeType.APP_USER_UPDATE:
                        edgeType = CommonTypes_1.EdgeType.USED_BY;
                        break;
                    default:
                        throw new Error(`Unsupported change type ${change.type}`);
                }
                if (edgeType) {
                    const newVertex = this.toVertex(change);
                    graphTraversal = this.addVertexTraversal(graphTraversal, newPvs, newVertex, edgeType);
                }
            }
            graphTraversal = (0, BaseGraphService_1.addCurrentStateTraversal)(graphTraversal, changedPv, newPvs);
            return this.executeTraversal(graphTraversal);
        });
        return this.postProcessing(changedPv);
    }
    getPostureService() {
        if (!this.postureService) {
            this.postureService = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
            this.postureService.sourceConfiguration = this.getSourceConfiguration();
        }
        return this.postureService;
    }
}
exports.EndpointProcessorService = EndpointProcessorService;
