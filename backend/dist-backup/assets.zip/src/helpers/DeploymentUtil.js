"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDeploymentsMap = void 0;
const UnifiedConnectorDeploymentServices_1 = require("../services/unifiedconnector/UnifiedConnectorDeploymentServices");
const UnifiedConnectorCollectorServices_1 = require("../services/unifiedconnector/UnifiedConnectorCollectorServices");
const getDeploymentsMap = (tenantUid) => {
    const deploymentServices = new UnifiedConnectorDeploymentServices_1.UnifiedConnectorDeploymentServices(tenantUid);
    return deploymentServices.getSourceDetails()
        .then(details => Promise.all(details.map(detail => new UnifiedConnectorCollectorServices_1.UnifiedConnectorCollectorServices(detail.secrets, detail.baseURL, detail.adminBaseUrl, tenantUid, detail.producerId).getDeploymentsBulk())))
        .then(summary => deploymentServices.getFlatMapOfDeployments(summary.flat()));
};
exports.getDeploymentsMap = getDeploymentsMap;
