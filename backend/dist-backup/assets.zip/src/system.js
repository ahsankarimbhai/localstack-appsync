"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.modulesUpdated = exports.deactivateTenant = void 0;
const TenantServices_1 = require("./common/TenantServices");
const LambdaLogger_1 = require("./common/LambdaLogger");
const Util_1 = require("./common/Util");
const tenant_management_1 = require("./tenant-management");
const ScheduleServices_1 = require("./common/ScheduleServices");
const LambdaServices_1 = require("./common/LambdaServices");
const IrohWebhookClient_1 = require("./common/IrohWebhookClient");
const logger = new LambdaLogger_1.LambdaLogger();
const deactivateTenant = async (event, context) => {
    const { tenantUid, role, id } = event.requestContext.authorizer;
    (0, Util_1.verifyAuthorization)(role, id, tenantUid);
    const tenantServices = new TenantServices_1.TenantServices();
    const existingTenant = await tenantServices.getTenantById(tenantUid, true);
    if (!existingTenant) {
        logger.info(`Tenant with id ${tenantUid} does not exist`);
        return false;
    }
    logger.info(`Deactivating tenant: ${existingTenant.toString()} by user ${id}`);
    await tenantServices.deleteTenant(tenantUid, true);
    const producers = await tenantServices.getTenantConfigurations(tenantUid);
    for (const producer of producers) {
        logger.info(`Deactivating producer: ${producer.key} by user ${id}`);
        await (0, tenant_management_1.removeProducerConfigurationHelper)(tenantUid, producer, context);
    }
    await new IrohWebhookClient_1.IrohWebhookClient(tenantUid).removeDIWebhooks();
    await new ScheduleServices_1.ScheduledTaskServices().removeTenantTasks(tenantUid);
    return (0, Util_1.lambdaProxyResponse)('DELETE');
};
exports.deactivateTenant = deactivateTenant;
const modulesUpdated = async (event) => {
    if (!process.env.ENV_PREFIX) {
        throw new Error('ENV_PREFIX is not set');
    }
    const { tenantUid } = event.requestContext.authorizer;
    if (!tenantUid) {
        logger.warn('request to update modules - required parameter tenantUid is missing in context');
        return (0, Util_1.lambdaProxyResponse)('PUT', 'required parameter tenantUid is missing in context', 401);
    }
    const tenantServices = new TenantServices_1.TenantServices();
    const existingTenant = await tenantServices.getTenantById(tenantUid);
    if (!existingTenant) {
        logger.warn(`request to update modules - Tenant with id ${tenantUid} does not exist`);
        return (0, Util_1.lambdaProxyResponse)('PUT', 'required parameter tenantUid is wrong', 400);
    }
    logger.debug(`Modules for tenant: ${existingTenant.id} got updated, will be syncing them to DI modules.`);
    const lambdaServices = new LambdaServices_1.LambdaServices(process.env.AWS_REGION);
    const functionName = `${process.env.ENV_PREFIX}-iroh-sync-producers`;
    const invokeParams = { tenantUid };
    await lambdaServices.asyncInvoke(functionName, JSON.stringify(invokeParams));
    logger.debug(`Modules sync for tenant: ${existingTenant.toString()} has been triggered.`);
    return (0, Util_1.lambdaProxyResponse)('POST');
};
exports.modulesUpdated = modulesUpdated;
