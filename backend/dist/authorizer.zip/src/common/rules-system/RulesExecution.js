"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RulesExecution = exports.RuleEntityWithAdheringDevices = void 0;
const ElasticsearchServices_1 = require("../ElasticsearchServices");
const Util_1 = require("../Util");
const LambdaLogger_1 = require("../LambdaLogger");
const OsVersionsServices_1 = require("../OsVersionsServices");
const elastic_builder_1 = __importDefault(require("elastic-builder"));
const RuleService_1 = require("../../services/common/RuleService");
const bluebird_1 = require("bluebird");
const Common_1 = require("./Common");
const TimestreamWriteServices_1 = require("../TimestreamWriteServices");
const CommonTypes_1 = require("../CommonTypes");
const IncidentTenantAgnosticService_1 = require("../../services/common/IncidentTenantAgnosticService");
const WebhookHelper_1 = require("../../services/common/data-sharing/WebhookHelper");
const WebhookNotificationService_1 = require("../../services/common/data-sharing/WebhookNotificationService");
const OUTPUT_FIELDS = ['labels', 'assetValue'];
class RuleEntityWithAdheringDevices extends RuleService_1.RuleEntity {
    constructor() {
        super(...arguments);
        this.adheringDevices = [];
    }
}
exports.RuleEntityWithAdheringDevices = RuleEntityWithAdheringDevices;
class RulesExecution {
    constructor(promisesConcurrency) {
        this.promisesConcurrency = promisesConcurrency;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.rulesMetrics = new Common_1.RulesMetrics();
        this.tenantAgnosticRuleService = new RuleService_1.GlobalRuleService();
        this.tenantAgnosticElasticSearchService = new ElasticsearchServices_1.ElasticsearchGlobalServices();
        this.webhookNotificationService = new WebhookNotificationService_1.WebhookNotificationService();
    }
    buildRecordsMetrics(records) {
        const countsByTenant = {};
        for (const ucRecord of records) {
            const modificationAction = ucRecord[1];
            const timeStamp = ucRecord[2];
            const tenantUid = ucRecord[3];
            if (!countsByTenant[tenantUid]) {
                countsByTenant[tenantUid] = {};
            }
            const countsOfTenant = countsByTenant[tenantUid];
            countsOfTenant[modificationAction] = (countsOfTenant[modificationAction] || 0) + 1;
            countsOfTenant.latest = (countsOfTenant.latest || 0) > timeStamp ? (countsOfTenant.latest || 0) : timeStamp;
        }
        const entries = Object.entries(countsByTenant);
        for (const [key, val] of entries) {
            const metrics = [];
            if (val.updated) {
                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_UPDATED_RECEIVED, val.updated));
            }
            if (val.created) {
                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_CREATED_RECEIVED, val.created));
            }
            if (val.apply) {
                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_IDENTIFIED_APPLY_RECEIVED, val.apply));
            }
            if (metrics.length) {
                metrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_RECEIVED_DURATION, Date.now() - val.latest));
                this.rulesMetrics.addRecordMetrics(metrics, key);
            }
        }
        this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_DEVICES_TENANTS_IN_BATCH, entries.length)], 'global');
    }
    async handleRecordsBatch(records) {
        this.logger.debug('handleRecordsBatch: ', JSON.stringify(records));
        const applyRecords = [];
        const updateCreateRecords = [];
        for (const record of records) {
            const extractedData = JSON.parse(Buffer.from(record.kinesis.data, 'base64').toString());
            const modificationAction = extractedData[1];
            switch (modificationAction) {
                case 'updated':
                    updateCreateRecords.push(extractedData);
                    break;
                case 'created':
                    updateCreateRecords.push(extractedData);
                    break;
                case 'apply':
                    applyRecords.push(extractedData);
                    break;
                default:
                    this.logger.error('unsupported device modification action: ', modificationAction);
                    break;
            }
        }
        this.buildRecordsMetrics(updateCreateRecords.concat(applyRecords));
        await bluebird_1.Promise.allSettled([updateCreateRecords.length ? this.handleUpdateCreate(updateCreateRecords) : null, applyRecords.length ? this.handleApply(applyRecords) : null].filter(item => item));
        await this.rulesMetrics.reportCurrentMetrics();
    }
    async handleApply(records) {
        var _a;
        this.logger.debug('handleApply: ', JSON.stringify(records));
        const globalMetrics = [];
        const deviceIdsSet = new Set();
        const ruleIdsByTenantIdFromRecords = {};
        for (const record of records) {
            const ruleId = record[4];
            if (ruleId !== Common_1.NO_RULE_ID) {
                const tenantId = record[3];
                deviceIdsSet.add(record[0]);
                ruleIdsByTenantIdFromRecords[tenantId] = ruleIdsByTenantIdFromRecords[tenantId] ? ruleIdsByTenantIdFromRecords[tenantId].add(ruleId) : new Set([ruleId]);
            }
            else {
                this.logger.error('ruleId not set');
            }
        }
        const deviceIds = [...deviceIdsSet];
        this.logger.debug('ruleIdsByTenantIdFromRecords: ', ruleIdsByTenantIdFromRecords);
        for (const tenantRulesTuple of Object.entries(ruleIdsByTenantIdFromRecords)) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_APPLY_RULES_FROM_RECORDS, tenantRulesTuple[1].size)], tenantRulesTuple[0]);
        }
        this.logger.debug('deviceIds: ', deviceIds);
        const uniqueTenantIds = Object.keys(ruleIdsByTenantIdFromRecords);
        this.logger.debug('uniqueTenantIds: ', uniqueTenantIds);
        const allRulesByTenantsFromDB = await this.tenantAgnosticRuleService.getRulesByTenants(uniqueTenantIds);
        this.logger.debug('allRulesByTenantsFromDB: ', JSON.stringify(allRulesByTenantsFromDB));
        for (const tenantRulesTuple of Object.entries(allRulesByTenantsFromDB)) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_APPLY_RULES_FROM_DB, tenantRulesTuple[1].length)], tenantRulesTuple[0]);
        }
        const mergedRulesByTenants = {};
        const rulesToApplyFromRecords = {};
        for (const [tenantId, rulesFromDB] of Object.entries(allRulesByTenantsFromDB)) {
            mergedRulesByTenants[tenantId] = rulesFromDB.filter((rule) => {
                const ruleIsFromRecords = ruleIdsByTenantIdFromRecords[tenantId].has(rule.ruleId);
                if (ruleIsFromRecords) {
                    rulesToApplyFromRecords[rule.ruleId] = rule;
                }
                return OUTPUT_FIELDS.some((outputField) => rule.matchingCondition[outputField]) || ruleIsFromRecords;
            });
        }
        this.logger.debug('mergedRulesByTenants: ', JSON.stringify(mergedRulesByTenants));
        if (Object.values(mergedRulesByTenants).every((mergedRulesList) => !mergedRulesList.length)) {
            return;
        }
        for (const tenantRulesTuple of Object.entries(mergedRulesByTenants)) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_APPLY_MERGED_RULES, tenantRulesTuple[1].length)], tenantRulesTuple[0]);
        }
        let now = Date.now();
        globalMetrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_QUERIES_DURATION, Date.now() - now));
        await this.queryEsForAdheringDevicesRemovingLabelsAndValuesFromMatchingCondition(mergedRulesByTenants, deviceIds);
        for (const rule of Object.values(mergedRulesByTenants).flat()) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_APPLY_RULES_TO_APPLY),
                new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_APPLY_DEVICES_MATCHING_RULES, (_a = rule.adheringDevices) === null || _a === void 0 ? void 0 : _a.length)], rule.tenantId);
        }
        const devicesToUpdateInEs = await this.tenantAgnosticElasticSearchService.bulkReadWholeDevicesByDeviceIds(deviceIds);
        this.logger.debug('devicesToUpdateInEs Before rule apply: ', JSON.stringify(devicesToUpdateInEs));
        this.applyRulesThatDoNotHaveOutputFieldsInMatchingCondition(devicesToUpdateInEs, mergedRulesByTenants);
        this.logger.debug('devicesToUpdateInEs after no output fields: ', JSON.stringify(devicesToUpdateInEs));
        this.applyRulesThatHaveOutputFieldsInMatchingCondition(devicesToUpdateInEs, mergedRulesByTenants);
        this.logger.debug('devicesToUpdateInEs after have output fields: ', JSON.stringify(devicesToUpdateInEs));
        const devicesToUpdateInEsList = Object.values(devicesToUpdateInEs).filter((device) => device.labelsUpdated || device.assetValueUpdated).map(device => ({ ...device, modifiedByRules: Array.from((new Set(device.modifiedByRules || []).values())) }));
        this.logger.debug('devicesToUpdateInEsList updated only: ', JSON.stringify(devicesToUpdateInEsList));
        for (const device of devicesToUpdateInEsList) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_APPLY_DEVICES_TO_UPDATE_IN_ES)], device.tenantUid);
        }
        now = Date.now();
        await bluebird_1.Promise.all([
            this.tenantAgnosticElasticSearchService.bulkUpdateRulesLabelsAndAssetValue(devicesToUpdateInEsList),
            new IncidentTenantAgnosticService_1.IncidentTenantAgnosticService().publishMultiTenantMessage(devicesToUpdateInEsList),
            this.sendNotifications(devicesToUpdateInEsList)
        ]);
        globalMetrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_APPLY_DEVICES_TO_UPDATE_IN_ES_DURATION, Date.now() - now));
        this.rulesMetrics.addRecordMetrics(globalMetrics, 'global');
    }
    async handleUpdateCreate(records) {
        var _a;
        this.logger.debug('handleUpdateCreate: ', JSON.stringify(records));
        const globalMetrics = [];
        const { latestTimeForQuery, allDeviceIdsInBatch, updateDeviceIdsInBatch, allUniqueTenantIdsInBatch } = this.classifyRecordsAndExtract(records);
        this.logger.debug('latestTimeForQuery in ms: ', latestTimeForQuery);
        this.logger.debug('allDeviceIdsInBatch: ', allDeviceIdsInBatch);
        this.logger.debug('updateDeviceIdsInBatch: ', updateDeviceIdsInBatch);
        this.logger.debug('allUniqueTenantIdsInBatch: ', allUniqueTenantIdsInBatch);
        const delayTimeMillis = latestTimeForQuery - Date.now();
        if (delayTimeMillis > 0) {
            this.logger.debug('applying delay of: ', delayTimeMillis);
            await (0, Util_1.delay)(delayTimeMillis);
            this.logger.debug('delay over');
            globalMetrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_UC_APPLIED_DELAY, delayTimeMillis));
        }
        const [devicesToUpdateInEs, rulesByTenants] = await bluebird_1.Promise.all([await this.tenantAgnosticElasticSearchService.bulkReadWholeDevicesByDeviceIds(allDeviceIdsInBatch),
            await this.tenantAgnosticRuleService.getRulesByTenants(allUniqueTenantIdsInBatch)]);
        this.logger.debug('devicesToUpdateInEs: ', JSON.stringify(devicesToUpdateInEs));
        this.logger.debug('rulesByTenants: ', JSON.stringify(rulesByTenants));
        for (const tenantRulesTuple of Object.entries(rulesByTenants)) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_UC_RULES_FROM_DB, tenantRulesTuple[1].length)], tenantRulesTuple[0]);
        }
        this.setUpdateDevicesForRevert(devicesToUpdateInEs, updateDeviceIdsInBatch);
        await this.queryEsForAdheringDevicesRemovingLabelsAndValuesFromMatchingCondition(rulesByTenants, allDeviceIdsInBatch);
        this.logger.debug('devicesToUpdateInEs Before rule apply: ', JSON.stringify(devicesToUpdateInEs));
        for (const rule of Object.values(rulesByTenants).flat()) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_UC_RULES_TO_APPLY),
                new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_UC_DEVICES_MATCHING_RULES, (_a = rule.adheringDevices) === null || _a === void 0 ? void 0 : _a.length)], rule.tenantId);
        }
        this.applyRulesThatDoNotHaveOutputFieldsInMatchingCondition(devicesToUpdateInEs, rulesByTenants);
        this.logger.debug('devicesToUpdateInEs after no output fields: ', JSON.stringify(devicesToUpdateInEs));
        this.applyRulesThatHaveOutputFieldsInMatchingCondition(devicesToUpdateInEs, rulesByTenants);
        this.logger.debug('devicesToUpdateInEs after have output fields: ', JSON.stringify(devicesToUpdateInEs));
        const devicesToUpdateInEsList = Object.values(devicesToUpdateInEs).map(device => ({ ...device, modifiedByRules: Array.from((new Set(device.modifiedByRules || []).values())) }));
        this.logger.debug('devicesToUpdateInEsList updated only: ', JSON.stringify(devicesToUpdateInEsList));
        for (const device of devicesToUpdateInEsList) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_UC_DEVICES_TO_UPDATE_IN_ES)], device.tenantUid);
        }
        const now = Date.now();
        await bluebird_1.Promise.all([
            this.tenantAgnosticElasticSearchService.bulkUpdateRulesLabelsAndAssetValue(devicesToUpdateInEsList),
            new IncidentTenantAgnosticService_1.IncidentTenantAgnosticService().publishMultiTenantMessage(devicesToUpdateInEsList),
            this.sendNotifications(devicesToUpdateInEsList)
        ]);
        globalMetrics.push(new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_UC_DEVICES_TO_UPDATE_IN_ES_DURATION, Date.now() - now));
        this.rulesMetrics.addRecordMetrics(globalMetrics, 'global');
    }
    async sendNotifications(devicesToUpdateInEsList) {
        var _a;
        try {
            const tenantDeviceIdsMap = new Map();
            for (const device of devicesToUpdateInEsList) {
                const tenantUid = device.tenantUid;
                const tenantDevices = (_a = tenantDeviceIdsMap.get(tenantUid)) !== null && _a !== void 0 ? _a : [];
                tenantDevices.push(device.postureEndpointId);
                tenantDeviceIdsMap.set(tenantUid, tenantDevices);
            }
            await bluebird_1.Promise.map(tenantDeviceIdsMap, async (tenantDeviceIdsPair) => this.webhookNotificationService.sendDeviceEvent(tenantDeviceIdsPair[0], WebhookHelper_1.WebhookEventType.DEVICE_UPDATE, tenantDeviceIdsPair[1]));
        }
        catch (err) {
            this.logger.error(`failed to send webhook notification ${WebhookHelper_1.WebhookEventType.DEVICE_UPDATE} event for devices: ${JSON.stringify(devicesToUpdateInEsList)}, err: ${err.message}`);
        }
    }
    classifyRecordsAndExtract(records) {
        let latestTimeForQuery = 0;
        const allDeviceIdsInBatch = [];
        const allTenantIdsInBatch = [];
        const updateDeviceIdsInBatch = [];
        for (const record of records) {
            const deviceId = record[0];
            const modificationAction = record[1];
            if (!['created', 'updated'].includes(modificationAction)) {
                this.logger.error('unexpected event type or modification action: ', modificationAction);
                continue;
            }
            const timeForModificationToBeQueryable = record[5] || 0;
            const tenantId = record[3];
            if (modificationAction === 'updated') {
                updateDeviceIdsInBatch.push(deviceId);
            }
            allDeviceIdsInBatch.push(deviceId);
            allTenantIdsInBatch.push(tenantId);
            latestTimeForQuery = (timeForModificationToBeQueryable > latestTimeForQuery) ? timeForModificationToBeQueryable : latestTimeForQuery;
        }
        const allUniqueTenantIdsInBatch = Array.from((new Set(allTenantIdsInBatch).values()));
        return { latestTimeForQuery, allDeviceIdsInBatch: Array.from((new Set(allDeviceIdsInBatch).values())), updateDeviceIdsInBatch: Array.from((new Set(updateDeviceIdsInBatch).values())), allUniqueTenantIdsInBatch };
    }
    setUpdateDevicesForRevert(devicesToUpdateInEs, updateDeviceIdsInBatch) {
        for (const deviceId of updateDeviceIdsInBatch) {
            const deviceObj = devicesToUpdateInEs[deviceId];
            if (deviceObj) {
                deviceObj.rulesAssetValue = null;
                deviceObj.rulesLabels = [];
                deviceObj.modifiedByRules = [];
                deviceObj.rulesLatestProcessed = Date.now();
                deviceObj.matchedByRules = [];
            }
            else {
                this.logger.error(`device id: ${deviceId} appears in batch records but not in data retrieved from elastic search`);
            }
        }
    }
    async queryEsForAdheringDevicesRemovingLabelsAndValuesFromMatchingCondition(rulesByTenants, allDeviceIdsInBatch) {
        const queries = [];
        for (const [tenantId, rules] of Object.entries(rulesByTenants)) {
            for (const rule of rules) {
                const ruleFilterWithLabelsAndValuesRemovedFromMatchingCondition = { ...rule.matchingCondition };
                OUTPUT_FIELDS.forEach(outfield => delete ruleFilterWithLabelsAndValuesRemovedFromMatchingCondition[outfield]);
                const ruleQueryWithLabelsAndValuesRemovedFromMatchingCondition = await ElasticsearchServices_1.ElasticsearchGlobalServices.buildSearchQuery(ruleFilterWithLabelsAndValuesRemovedFromMatchingCondition, () => new OsVersionsServices_1.OsVersionsServices().getOsVersions(), undefined, [elastic_builder_1.default.matchQuery('tenantUid.keyword', tenantId), elastic_builder_1.default.idsQuery(undefined, allDeviceIdsInBatch)]);
                queries.push(ruleQueryWithLabelsAndValuesRemovedFromMatchingCondition);
            }
        }
        const queryResultsInTheOrderOfQueries = await this.tenantAgnosticElasticSearchService.multiQuery(queries, false);
        let i = 0;
        for (const rules of Object.values(rulesByTenants)) {
            for (const rule of rules) {
                const queryResult = queryResultsInTheOrderOfQueries[i];
                if (queryResult.status === 200) {
                    rule.adheringDevices = queryResult.hits.hits.map((hit) => hit._id);
                }
                i += 1;
            }
        }
    }
    applyRulesInMemoryOnAllDevicesAdhering(devicesToUpdateInEs, rulesToApply, checkOutputFieldsMatching) {
        for (const ruleToApply of rulesToApply) {
            let manuallyAdheringCount = 0;
            for (const deviceId of ruleToApply.adheringDevices || []) {
                if ((!checkOutputFieldsMatching) || RulesExecution.doOutputFieldsAdhere(ruleToApply, devicesToUpdateInEs[deviceId])) {
                    RuleService_1.GlobalRuleService.applyRuleActionOnObject(devicesToUpdateInEs[deviceId], ruleToApply);
                    manuallyAdheringCount += checkOutputFieldsMatching ? 1 : 0;
                }
            }
            if (manuallyAdheringCount) {
                this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_DEVICES_MANUALLY_ADHERING_TO_OUTPUT_FIELDS, manuallyAdheringCount)], ruleToApply.tenantId);
            }
        }
    }
    static doOutputFieldsAdhere(rule, device) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
        if (!(rule && device)) {
            return false;
        }
        let deviceApplicableAssetValue;
        let deviceApplicableAssetValueOrigin;
        if ((device.assetValue || 0) >= (device.rulesAssetValue || 0)) {
            deviceApplicableAssetValue = device.assetValue;
            deviceApplicableAssetValueOrigin = CommonTypes_1.ModificationOrigin.MANUAL;
        }
        else {
            deviceApplicableAssetValue = device.rulesAssetValue;
            deviceApplicableAssetValueOrigin = CommonTypes_1.ModificationOrigin.RULES_BASED;
        }
        if (!deviceApplicableAssetValue) {
            deviceApplicableAssetValue = ElasticsearchServices_1.ElasticsearchServices.DEFAULT_ASSET_VALUE;
            deviceApplicableAssetValueOrigin = CommonTypes_1.ModificationOrigin.DEFAULT;
        }
        const deviceApplicableLabels = new Set((device.labels || []).concat(device.rulesLabels || []));
        const matchingConditionOriginExists = !!((_b = (_a = rule.matchingCondition) === null || _a === void 0 ? void 0 : _a.assetValue) === null || _b === void 0 ? void 0 : _b.origin);
        const originMatches = ((_d = (_c = rule.matchingCondition) === null || _c === void 0 ? void 0 : _c.assetValue) === null || _d === void 0 ? void 0 : _d.origin) === deviceApplicableAssetValueOrigin;
        const matchingConditionAssetValuesExist = !!((_g = (_f = (_e = rule.matchingCondition) === null || _e === void 0 ? void 0 : _e.assetValue) === null || _f === void 0 ? void 0 : _f.values) === null || _g === void 0 ? void 0 : _g.length);
        const assetValueValueMatches = (_k = (_j = (_h = rule.matchingCondition) === null || _h === void 0 ? void 0 : _h.assetValue) === null || _j === void 0 ? void 0 : _j.values) === null || _k === void 0 ? void 0 : _k.includes(deviceApplicableAssetValue);
        const assetValueExists = matchingConditionOriginExists || matchingConditionAssetValuesExist;
        const assetValueMatches = assetValueExists && (originMatches || !matchingConditionOriginExists) && (assetValueValueMatches || !matchingConditionAssetValuesExist);
        const matchingConditionLabelsExist = !!((_m = (_l = rule.matchingCondition) === null || _l === void 0 ? void 0 : _l.labels) === null || _m === void 0 ? void 0 : _m.length);
        const labelsMatch = !!((_p = (_o = rule.matchingCondition) === null || _o === void 0 ? void 0 : _o.labels) === null || _p === void 0 ? void 0 : _p.every(ruleConditionLabelInfoItem => ((!ruleConditionLabelInfoItem.exclude && (deviceApplicableLabels === null || deviceApplicableLabels === void 0 ? void 0 : deviceApplicableLabels.has(ruleConditionLabelInfoItem.labelId)))
            || (ruleConditionLabelInfoItem.exclude && !(deviceApplicableLabels === null || deviceApplicableLabels === void 0 ? void 0 : deviceApplicableLabels.has(ruleConditionLabelInfoItem.labelId))))));
        return (matchingConditionLabelsExist || assetValueExists) && (!matchingConditionLabelsExist || labelsMatch) && (!assetValueExists || assetValueMatches);
    }
    applyRulesThatHaveOutputFieldsInMatchingCondition(devicesToUpdateInEs, rulesByTenants) {
        const rulesWithOutputFieldsInFilter = Object.values(rulesByTenants).flat().filter((ruleToApply) => OUTPUT_FIELDS.some((outputField) => ruleToApply.matchingCondition[outputField]));
        for (const rule of rulesWithOutputFieldsInFilter) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_RULES_WITH_OUTPUT_FIELDS_IN_MATCHING_CRITERIA)], rule.tenantId);
        }
        for (let i = 0; i < rulesWithOutputFieldsInFilter.length; i += 1) {
            this.applyRulesInMemoryOnAllDevicesAdhering(devicesToUpdateInEs, rulesWithOutputFieldsInFilter, true);
        }
    }
    applyRulesThatDoNotHaveOutputFieldsInMatchingCondition(devicesToUpdateInEs, rulesByTenants) {
        const rulesWithNoOutputFieldsInFilter = Object.values(rulesByTenants).flat().filter((ruleToApply) => OUTPUT_FIELDS.every((outputField) => !ruleToApply.matchingCondition[outputField]));
        for (const rule of rulesWithNoOutputFieldsInFilter) {
            this.rulesMetrics.addRecordMetrics([new TimestreamWriteServices_1.Metric(TimestreamWriteServices_1.MetricName.RULES_EXEC_RULES_WITHOUT_OUTPUT_FIELDS_IN_MATCHING_CRITERIA)], rule.tenantId);
        }
        this.applyRulesInMemoryOnAllDevicesAdhering(devicesToUpdateInEs, rulesWithNoOutputFieldsInFilter, false);
    }
}
exports.RulesExecution = RulesExecution;
