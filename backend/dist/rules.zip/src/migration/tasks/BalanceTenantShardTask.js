"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BalanceTenantShardTask = void 0;
const DataMigrationTaskProcessor_1 = require("../DataMigrationTaskProcessor");
const TimestreamWriteServices_1 = require("../../common/TimestreamWriteServices");
const TimestreamQueryServices_1 = require("../../common/TimestreamQueryServices");
const NeptuneShardMigrationLogRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogRepo");
const NeptuneShardMigrationLogDetailRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardMigrationLogDetailRepo");
const NeptuneShardRepo_1 = require("../../common/dynamoDBRepo/NeptuneShardRepo");
const util_1 = __importDefault(require("util"));
const bluebird_1 = require("bluebird");
var BalanceSolution;
(function (BalanceSolution) {
    BalanceSolution["MIGRATION_SERVICE"] = "migrationService";
    BalanceSolution["CLONE_CLUSTER"] = "cloneCluster";
})(BalanceSolution || (BalanceSolution = {}));
var CloneClusterSteps;
(function (CloneClusterSteps) {
    CloneClusterSteps["START"] = "start";
    CloneClusterSteps["COMPLETE"] = "complete";
})(CloneClusterSteps || (CloneClusterSteps = {}));
class BalanceTenantShardTask extends DataMigrationTaskProcessor_1.GlobalDataMigrationTaskProcessor {
    constructor() {
        super(...arguments);
        this.neptuneShardMigrationLogRepo = new NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationLogRepo();
        this.neptuneShardMigrationLogDetailRepo = new NeptuneShardMigrationLogDetailRepo_1.NeptuneShardMigrationLogDetailRepo();
        this.neptuneShardRepo = new NeptuneShardRepo_1.NeptuneShardRepo();
        this.timeStreamQueryServices = new TimestreamQueryServices_1.TimestreamQueryServices();
    }
    getTaskName() {
        return BalanceTenantShardTask.TASK_NAME;
    }
    async execute() {
        const taskParam = this.getTaskParamsObj();
        if (!taskParam || !taskParam.balanceSolution
            || (taskParam.balanceSolution === BalanceSolution.CLONE_CLUSTER && !taskParam.cloneClusterSteps)) {
            throw new Error('must provide balanceSolution, cloneClusterSteps must be provided when balanceSolution is cloneCluster');
        }
        const anyTenantsInMigration = await this.neptuneShardMigrationLogRepo.anyTenantStartMigration();
        if (anyTenantsInMigration) {
            throw new Error('end task, found tenants in migration status');
        }
        if (taskParam.balanceSolution === BalanceSolution.MIGRATION_SERVICE
            || (taskParam.balanceSolution === BalanceSolution.CLONE_CLUSTER && taskParam.cloneClusterSteps === CloneClusterSteps.START)) {
            await this.cleanOldMigrationLogs();
            if (taskParam.tenantAllocations && taskParam.tenantAllocations.length > 0) {
                await this.createMigrationLogs(taskParam.tenantAllocations.map(tenantAllocation => ({
                    tenantUid: tenantAllocation.tenantUid,
                    shardId: tenantAllocation.sourceShardId,
                    migrateToShardId: tenantAllocation.targetShardId
                })), taskParam.balanceSolution, true);
            }
            else {
                await this.allocateNeptuneShard(taskParam.balanceSolution, taskParam.sourceShardIds || [], taskParam.targetShardIds || []);
            }
        }
        else if (taskParam.balanceSolution === BalanceSolution.CLONE_CLUSTER && taskParam.cloneClusterSteps === CloneClusterSteps.COMPLETE) {
            await this.unthrottleTenants();
        }
    }
    getTaskParamsObj() {
        try {
            return JSON.parse(this.taskParams);
        }
        catch {
            return undefined;
        }
    }
    async cleanOldMigrationLogs() {
        this.logger.info('start cleanOldMigrationLogs...');
        const migrationLogs = await this.neptuneShardMigrationLogRepo.getAllMigrationLogs();
        await bluebird_1.Promise.map(migrationLogs, async (migrationLog) => {
            await this.neptuneShardMigrationLogRepo.deleteTenantMigrationLog(migrationLog.tenantUid);
        }, { concurrency: 500 });
        const migrationLogDetails = await this.neptuneShardMigrationLogDetailRepo.getAllMigrationLogDetails();
        await bluebird_1.Promise.map(migrationLogDetails, async (migrationLogDetail) => {
            await this.neptuneShardMigrationLogDetailRepo.delete(migrationLogDetail.exportId);
        }, { concurrency: 500 });
        this.logger.info('end cleanOldMigrationLogs...');
    }
    async unthrottleTenants() {
        this.logger.info('start unthrottleTenants...');
        const migrationLogs = await this.neptuneShardMigrationLogRepo.getLogsByStatus([NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.CREATE]);
        await bluebird_1.Promise.map(migrationLogs, async (migrationLog) => {
            await this.neptuneShardRepo.upsertNeptuneShard({
                tenantUid: migrationLog.tenantUid,
                shardId: migrationLog.migrateToShardId
            });
            await this.neptuneShardMigrationLogRepo.deleteTenantMigrationLog(migrationLog.tenantUid);
        }, { concurrency: 500 });
        this.logger.info('end unthrottleTenants...');
    }
    async allocateNeptuneShard(balanceSolution, sourceShardIds, targetShardIds) {
        this.logger.info('start allocateNeptuneShard...');
        const tenantShardList = await this.neptuneShardRepo.getAll();
        const tenantShardMap = new Map();
        for (const tenantShard of tenantShardList) {
            tenantShardMap.set(tenantShard.tenantUid, tenantShard);
        }
        const measures = await this.getTenantMeasures();
        const migrations = [];
        let shardIndex = 0;
        for (const measure of measures) {
            this.logger.debug(`tenant: ${measure.tenant}, measure_sum: ${measure.measure_sum}`);
            const tenantShard = tenantShardMap.get(measure.tenant);
            if (!tenantShard) {
                continue;
            }
            const migrateFrom = tenantShard.shardId;
            const migrateTo = targetShardIds[shardIndex];
            if (migrateFrom !== migrateTo && sourceShardIds.includes(migrateFrom) && targetShardIds.includes(migrateTo)) {
                migrations.push({
                    ...tenantShard,
                    migrateToShardId: migrateTo
                });
                this.logger.info(`tenant ${tenantShard.tenantUid} would be migrated from shard ${migrateFrom} to ${migrateTo}`);
            }
            shardIndex = (shardIndex + 1) % targetShardIds.length;
        }
        await this.createMigrationLogs(migrations, balanceSolution);
        this.logger.info('end allocateNeptuneShard');
    }
    async createMigrationLogs(migrations, balanceSolution, shouldManualKickOff) {
        let hasErr = false;
        await bluebird_1.Promise.map(migrations, async (migrate) => {
            try {
                await this.neptuneShardMigrationLogRepo.upsertTenantMigrationLog({
                    tenantUid: migrate.tenantUid,
                    migrateFromShardId: migrate.shardId,
                    migrateToShardId: migrate.migrateToShardId,
                    migrationStatus: NeptuneShardMigrationLogRepo_1.NeptuneShardMigrationStatus.CREATE,
                    manualKickOff: shouldManualKickOff
                });
                if (balanceSolution === BalanceSolution.CLONE_CLUSTER) {
                    await this.neptuneShardRepo.updateNeptuneShard(migrate.tenantUid, undefined, true);
                }
            }
            catch (err) {
                hasErr = true;
                this.logger.error(`failed to add migration log for tenant ${migrate.tenantUid}, error: ${err.message}`);
            }
        }, { concurrency: 500 });
        if (hasErr) {
            throw new Error('Error occurred when allocateNeptuneShard');
        }
    }
    async getTenantMeasures() {
        const pastDays = +(process.env.PAST_DAYS_TO_CALCULATE_MEASURE_SUM || 60);
        const query = util_1.default.format('SELECT SUM(measure_value::bigint) AS measure_sum, tenant'
            + ' FROM "%s".%s'
            + ' WHERE time >= ago(%dd)'
            + ' AND workflow = \'%s\''
            + ' AND measure_name = \'%s\''
            + ' group by workflow, measure_name, tenant'
            + ' order by measure_sum desc', TimestreamWriteServices_1.TimestreamWriteServices.getDatabaseName(), TimestreamWriteServices_1.TimestreamWriteServices.TABLE_NAME, pastDays, 'processing', 'recordsTotal');
        const res = await this.timeStreamQueryServices.getQueryResults(query, undefined);
        return res.map(itemArr => {
            const measure = {};
            for (const element of itemArr) {
                measure[element.key] = element.value;
            }
            return measure;
        });
    }
}
exports.BalanceTenantShardTask = BalanceTenantShardTask;
BalanceTenantShardTask.TASK_NAME = 'balance-tenant-shard-task';
