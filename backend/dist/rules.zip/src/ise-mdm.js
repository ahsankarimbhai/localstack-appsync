"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deviceAttributes = exports.serverInfo = void 0;
const fast_xml_parser_1 = require("fast-xml-parser");
const LambdaLogger_1 = require("./common/LambdaLogger");
const serverInfo = async (event) => {
    new LambdaLogger_1.LambdaLogger().debug(event);
    const jsonResponse = {
        ise_api: {
            name: 'mdminfo',
            api_version: event.queryStringParameters.ise_api_version,
            api_path: '/ciscoise/mdmapi',
            redirect_url: 'https://sign-on.security.cisco.com/',
            query_max_size: 1000,
            messaging_support: false,
            vendor: 'SecureX',
            product_name: 'Cisco SecureX Posture',
            product_version: '1.0.0'
        }
    };
    return {
        statusCode: 200,
        body: new fast_xml_parser_1.XMLBuilder({}).build(jsonResponse)
    };
};
exports.serverInfo = serverInfo;
const deviceAttributes = async (event) => {
    new LambdaLogger_1.LambdaLogger().debug(event);
    return {
        statusCode: 200,
        body: []
    };
};
exports.deviceAttributes = deviceAttributes;
