"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedConnectorDeploymentServices = void 0;
const LambdaLogger_1 = require("../../common/LambdaLogger");
const CommonTypes_1 = require("../../common/CommonTypes");
const TenantServices_1 = require("../../common/TenantServices");
const _ = __importStar(require("lodash"));
const AwsSecretsService_1 = require("../../common/AwsSecretsService");
const Util_1 = require("../../common/Util");
class UnifiedConnectorDeploymentServices {
    constructor(tenantUid) {
        this.tenantUid = tenantUid;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async getSourceDetails(producerIds) {
        const sourceDetails = [];
        const producerType = CommonTypes_1.Source.UNIFIED_CONNECTOR;
        const ts = new TenantServices_1.TenantServices();
        try {
            if (!producerIds || _.isEmpty(producerIds)) {
                const producerConfig = await ts.getProducerConfigurations(this.tenantUid);
                producerIds = _.filter(producerConfig, x => x.producerType === CommonTypes_1.Source.UNIFIED_CONNECTOR).map(x => x.producerId);
            }
            this.logger.info(`getTenantUCDeployments for tenant ${this.tenantUid}, producer IDs: ${_.join(producerIds, ',')}`);
            const awsSecretsService = new AwsSecretsService_1.AwsSecretsService(this.tenantUid);
            await awsSecretsService.init();
            for (const producerId of producerIds) {
                try {
                    const tenantConfiguration = await ts.getTenantConfigurationOrFail(this.tenantUid, producerType, producerId);
                    if (tenantConfiguration && tenantConfiguration.value) {
                        const tenantConfigurationValue = JSON.parse(tenantConfiguration.value);
                        if (tenantConfigurationValue.baseURL && tenantConfigurationValue.adminBaseUrl) {
                            const baseURL = tenantConfigurationValue.baseURL;
                            const adminBaseUrl = tenantConfigurationValue.adminBaseUrl;
                            const secrets = awsSecretsService.getSecret((0, Util_1.toSourceString)(CommonTypes_1.Source.UNIFIED_CONNECTOR, producerId));
                            sourceDetails.push({ producerId, secrets, baseURL, adminBaseUrl });
                        }
                        else {
                            this.logger.error(`tenant configuration value for ${this.tenantUid} does not contain baseURL or adminBaseUrl`);
                        }
                    }
                    else {
                        this.logger.error(`tenant configuration for ${this.tenantUid} does not contain a value`);
                    }
                }
                catch (e) {
                    this.logger.error(`failed to get tenant configuration for ${this.tenantUid} and producer ${producerId}`, e);
                }
            }
        }
        catch (e) {
            this.logger.error(`failed to get source details for ${this.tenantUid}`, e);
        }
        return sourceDetails;
    }
    async getFlatMapOfDeployments(deployments) {
        return new Map(deployments.map(x => {
            let cloudMgmtVersion;
            const cloudMgmtVersionPackageName = 'cm-enterprise';
            if (Array.isArray(x.packages)) {
                for (const pac of x.packages) {
                    const index = pac.name.indexOf(cloudMgmtVersionPackageName);
                    const versionIndex = index + cloudMgmtVersionPackageName.length + 1;
                    if (index > -1 && pac.name.length > versionIndex) {
                        cloudMgmtVersion = pac.name.substring(versionIndex);
                        break;
                    }
                }
            }
            return [x.id, { name: x.name, cloudMgmtVersion }];
        }));
    }
}
exports.UnifiedConnectorDeploymentServices = UnifiedConnectorDeploymentServices;
