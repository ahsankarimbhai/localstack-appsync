"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AmpProcessorServices = void 0;
const _ = __importStar(require("lodash"));
const CommonTypes_1 = require("../../common/CommonTypes");
const EndpointProcessorService_1 = require("../common/EndpointProcessorService");
const AmpEndpointService_1 = require("../../collectors/services/AmpEndpointService");
class AmpProcessorServices extends EndpointProcessorService_1.EndpointProcessorService {
    async obtainIdentifierChanges(ampComputer, vertexState, currentTopology, changes, unchanged) {
        const hardwareId = ampComputer.mac_hardware_id || ampComputer.windows_machine_guid || ampComputer.windows_processor_id;
        await this.verifyChange(currentTopology, hardwareId, CommonTypes_1.VertexType.HARDWARE_ID, changes, unchanged);
        await this.verifyChange(currentTopology, ampComputer.external_ip, CommonTypes_1.VertexType.EXTERNAL_IP_ADDRESS, changes, unchanged);
        await this.verifyChange(currentTopology, ampComputer.serial_number, CommonTypes_1.VertexType.SERIAL_NUMBER, changes, unchanged);
        for (const mac of _.map(_.get(ampComputer, 'network_addresses', []), na => na.mac)) {
            await this.verifyChange(currentTopology, mac, CommonTypes_1.VertexType.MAC_ADDRESS, changes, unchanged);
        }
        await this.verifyChange(currentTopology, ampComputer.hostname, CommonTypes_1.VertexType.HOSTNAME, changes, unchanged);
    }
    initProcessorService(tenantUid, sourceId) {
        this.entityService = new AmpEndpointService_1.AmpEndpointService(tenantUid, sourceId);
    }
    hasPropertiesToMergeBy(ampComputer) {
        var _a;
        return (_a = !ampComputer.demo) !== null && _a !== void 0 ? _a : true;
    }
}
exports.AmpProcessorServices = AmpProcessorServices;
