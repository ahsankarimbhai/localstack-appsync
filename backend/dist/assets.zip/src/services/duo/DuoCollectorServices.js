"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuoCollectorServices = exports.DuoEndpointsFetcher = exports.DuoAuthLogsFetcher = void 0;
const _ = __importStar(require("lodash"));
const query_string_1 = __importDefault(require("query-string"));
const Services_1 = require("../../common/Services");
const CommonTypes_1 = require("../../common/CommonTypes");
const DuoEndpointsCollection_1 = require("./DuoEndpointsCollection");
const LambdaLogger_1 = require("../../common/LambdaLogger");
const DuoAuthLogsCollection_1 = require("./DuoAuthLogsCollection");
const DuoUsersCollection_1 = require("./DuoUsersCollection");
const ProxyClientFactory_1 = require("../../common/ProxyClientFactory");
const LIMIT = 500;
function isUpdatedDashboardApi(baseUrl) {
    return ['ciscodashboard-first.flavors.5c10.org/posture', 'ciscodashboard.duosecurity.com/posture'].includes(baseUrl);
}
function getApiUrlPrefix(duoClient, versionForAdminApi) {
    return isUpdatedDashboardApi(duoClient.baseUrl) ? '/v1' : `/admin/${versionForAdminApi}`;
}
function logErrorForJsonApiCall(logger, className, error) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
    logger.error(`Error occurred in ${className} where message=${error.message || ((_a = error.reason) === null || _a === void 0 ? void 0 : _a.message)}, code=${(_b = error.reason) === null || _b === void 0 ? void 0 : _b.code}, status=${(_d = (_c = error.reason) === null || _c === void 0 ? void 0 : _c.status) === null || _d === void 0 ? void 0 : _d.toString()},
    baseURL=${(_f = (_e = error.reason) === null || _e === void 0 ? void 0 : _e.config) === null || _f === void 0 ? void 0 : _f.baseURL}, target-url=${(_h = (_g = error.reason) === null || _g === void 0 ? void 0 : _g.config) === null || _h === void 0 ? void 0 : _h.headers['target-url']}, module-instance-id=${(_k = (_j = error.reason) === null || _j === void 0 ? void 0 : _j.config) === null || _k === void 0 ? void 0 : _k.headers['module-instance-id']}`);
}
class DuoAuthLogsFetcher {
    constructor(client) {
        this.client = client;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    async fetchNextPage(uri) {
        return new Promise((resolve, reject) => {
            const queryIndex = uri.indexOf('?');
            if (queryIndex < 0) {
                throw new Error(`auth logs uri must contain required params ${uri}`);
            }
            const path = uri.substring(0, queryIndex);
            const query = query_string_1.default.parse(uri.substring(queryIndex + 1));
            const mintime = _.toNumber(query.mintime);
            const maxtime = _.toNumber(query.maxtime);
            const next_offset = query.next_offset;
            const limit = _.toNumber(query.limit) || LIMIT;
            const event_types = 'authentication';
            const results = 'success';
            const params = {
                mintime,
                maxtime,
                event_types,
                results,
                limit
            };
            if (next_offset) {
                params.next_offset = next_offset;
            }
            this.logger.debug(`fetching ${path} from Duo AuthLogs for params ${JSON.stringify(params)}`);
            this.client.jsonApiCall('GET', path, params, (response) => {
                if (response.stat !== 'OK') {
                    logErrorForJsonApiCall(this.logger, 'DuoAuthLogsFetcher', response);
                    reject(new Error(response.message || response.reason.message));
                }
                else {
                    const authlogs = _.get(response, 'response.authlogs');
                    const nextOffset = _.get(response, 'response.metadata.next_offset');
                    if (!nextOffset) {
                        this.nextUri = undefined;
                    }
                    else {
                        params.next_offset = _.join(nextOffset, ',');
                        this.nextUri = `${path}?${query_string_1.default.stringify(params)}`;
                    }
                    resolve(authlogs);
                }
            });
        });
    }
    provideNextUri() {
        return this.nextUri;
    }
}
exports.DuoAuthLogsFetcher = DuoAuthLogsFetcher;
class DuoEndpointsFetcher {
    constructor(client) {
        this.client = client;
        this.logger = new LambdaLogger_1.LambdaLogger();
    }
    fetchNextPage(uri) {
        return new Promise((resolve, reject) => {
            const queryIndex = uri.indexOf('?');
            let path = uri;
            let limit = LIMIT;
            let offset = 0;
            let updatedAfter = 0;
            if (queryIndex > 0) {
                path = uri.substring(0, queryIndex);
                const query = query_string_1.default.parse(uri.substring(queryIndex + 1));
                limit = _.toNumber(query.limit) || LIMIT;
                offset = _.toNumber(query.offset) || 0;
                updatedAfter = _.toNumber(query.updated_after) || 0;
            }
            this.nextUri = `${path}?limit=${limit}&offset=${offset + limit}&updated_after=${updatedAfter}`;
            const params = {
                limit,
                offset,
                updated_after: updatedAfter
            };
            this.logger.debug(`fetching ${path} from Duo entities for params ${JSON.stringify(params)}`);
            this.client.jsonApiCall('GET', path, params, (response) => {
                if (response.stat !== 'OK') {
                    logErrorForJsonApiCall(this.logger, 'DuoEndpointsFetcher', response);
                    reject(new Error(response.message || response.reason.message));
                }
                else {
                    const endpoints = _.get(response, 'response');
                    if (_.get(response, 'metadata.next_offset') === undefined) {
                        this.nextUri = undefined;
                    }
                    resolve(endpoints);
                }
            });
        });
    }
    provideNextUri() {
        return this.nextUri;
    }
}
exports.DuoEndpointsFetcher = DuoEndpointsFetcher;
class DuoCollectorServices extends Services_1.BaseCollectorService {
    constructor(secrets, tenantUid, functionName, sourceId) {
        super(tenantUid, sourceId);
        this.functionName = functionName;
    }
    async init(source) {
        if (!this.client) {
            this.client = await ProxyClientFactory_1.ProxyClientFactory.getProxyClient(this.tenantUid, source, this.sourceId);
        }
    }
    async getEndpoints(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init(CommonTypes_1.Source.DUO);
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.DUO));
        const bulkLength = limit || LIMIT;
        const apiUrlPrefix = getApiUrlPrefix(this.client, 'v1');
        const url = nextUri || `${apiUrlPrefix}/endpoints?updated_after=${_.round(functionState.lastSuccessfulSequence / 1000)}&limit=${bulkLength}`;
        return new DuoEndpointsCollection_1.DuoEndpointsCollection(new DuoEndpointsFetcher(this.client), url, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getUsers(timeBasedAsyncLambdaInvoker, nextUri, limit) {
        await this.init(CommonTypes_1.Source.DUO_USERS);
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.DUO_USERS));
        const bulkLength = limit || LIMIT;
        const url = nextUri || `/admin/v1/users?updated_after=${_.round(functionState.lastSuccessfulSequence / 1000)}&limit=${bulkLength}`;
        return new DuoUsersCollection_1.DuoUsersCollection(new DuoEndpointsFetcher(this.client), url, timeBasedAsyncLambdaInvoker, functionState);
    }
    async getAuthLogs(timeBasedAsyncLambdaInvoker, nextUri, mintime, maxtime, limit) {
        await this.init(CommonTypes_1.Source.DUO);
        const functionState = await this.getInitialState(this.functionName, this.getProducer(CommonTypes_1.Source.DUO));
        const event_types = 'authentication';
        const results = 'success';
        const params = {
            mintime,
            maxtime,
            event_types,
            results,
            limit: limit || LIMIT
        };
        const apiUrlPrefix = getApiUrlPrefix(this.client, 'v2');
        const url = nextUri || `${apiUrlPrefix}/logs/authentication?${query_string_1.default.stringify(params)}`;
        return new DuoAuthLogsCollection_1.DuoAuthLogsCollection(new DuoAuthLogsFetcher(this.client), url, timeBasedAsyncLambdaInvoker, functionState);
    }
}
exports.DuoCollectorServices = DuoCollectorServices;
