"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NeptuneToEsDiffSyncTask = void 0;
const _ = __importStar(require("lodash"));
const gremlin_1 = require("gremlin");
const CommonTypes_1 = require("../../common/CommonTypes");
const NeptuneDBScheduledTaskProcessor_1 = require("../NeptuneDBScheduledTaskProcessor");
const PostureEndpointService_1 = require("../../model/PostureEndpointService");
const ElasticsearchServices_1 = require("../../common/ElasticsearchServices");
const ElasticsearchFactory_1 = require("../../common/ElasticsearchFactory");
const NeptuneClientManager_1 = require("../../common/neptune/NeptuneClientManager");
const __ = gremlin_1.process.statics;
class NeptuneToEsDiffSyncTask extends NeptuneDBScheduledTaskProcessor_1.NeptuneDBScheduledTaskProcessor {
    constructor(tenantUid) {
        super(tenantUid, 50);
        this.esServices = new ElasticsearchServices_1.ElasticsearchServices(this.tenantUid, (0, ElasticsearchFactory_1.getElasticSearchClient)());
    }
    getTaskName() {
        return NeptuneToEsDiffSyncTask.TASK_NAME;
    }
    async processRange(startRange) {
        const peUidsTraverser = await this.neptuneServices.executeTenantQuery((g) => this.getRangeQuery(g, startRange).toList(), NeptuneClientManager_1.NeptuneClientType.Reader);
        const peUids = _.map(new gremlin_1.driver.ResultSet(peUidsTraverser).toArray(), peuid => peuid.id);
        const existingUids = await this.esServices.getUidsIfExist(_.map(peUids, peuid => peuid));
        const identifiedDiffs = _.difference(peUids, existingUids);
        if (identifiedDiffs.length > 0) {
            this.logger.debug(`identified diffs. There are ${identifiedDiffs.length} in Neptune that aren't in ES. Neptune had ${peUids.length}, ES had ${existingUids.length}`);
        }
        const svc = new PostureEndpointService_1.PostureEndpointService(this.tenantUid);
        for (const peUid of identifiedDiffs) {
            this.logger.debug(`Identified PE ${peUid} of tenant ${this.tenantUid} as not having a matching record in ES. Running updateSearchableVertex for it.`);
            await svc.updateSearchableVertex(peUid);
            this.logger.debug(`Finished updating ${peUid} of tenant ${this.tenantUid} after it was missing in ES.`);
        }
    }
    async nextRangeCount(startRange) {
        return this.neptuneServices.executeTenantQuery(async (g) => {
            const nextRangeCount = this.getRangeQuery(g, startRange).count();
            const rangeCountValue = await nextRangeCount.next();
            return rangeCountValue.value;
        }, NeptuneClientManager_1.NeptuneClientType.Reader);
    }
    getRootTraversal(g) {
        return this.neptuneServices.getGraphTraversalBasedOnLabel(g, CommonTypes_1.VertexType.POSTURE_ENDPOINT);
    }
    getRangeQuery(g, startRange) {
        return this.getRootTraversal(g)
            .range(startRange, startRange + this.batchSize)
            .hasNot(CommonTypes_1.EdgeBasicProperty.DELETED)
            .where(__.out(CommonTypes_1.EdgeType.POSTURE_ENDPOINT)
            .outE(CommonTypes_1.EdgeType.HAS_STATE)
            .hasNot(CommonTypes_1.EdgeBasicProperty.UNTIL));
    }
}
exports.NeptuneToEsDiffSyncTask = NeptuneToEsDiffSyncTask;
NeptuneToEsDiffSyncTask.TASK_NAME = 'neptune-to-es-diff-sync-task';
