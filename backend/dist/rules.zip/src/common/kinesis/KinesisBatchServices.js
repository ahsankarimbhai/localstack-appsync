"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KinesisBatchServices = void 0;
const _ = __importStar(require("lodash"));
const Util_1 = require("../Util");
const KinesisServices_1 = require("./KinesisServices");
const KinesisHelper_1 = require("./KinesisHelper");
const RetryUtil_1 = require("../RetryUtil");
class KinesisBatchServices extends KinesisServices_1.KinesisServices {
    constructor(streamName, batchSize = KinesisHelper_1.DEFAULT_BATCH_SIZE, withRetry) {
        super(streamName);
        this.streamName = streamName;
        this.batchSize = batchSize;
        this.withRetry = withRetry;
        this.records = [];
        const envDelayInMillis = _.parseInt(process.env.DELAY_IN_MILLIS || '');
        this.delayInMillis = Number.isInteger(envDelayInMillis) ? envDelayInMillis : KinesisBatchServices.DEFAULT_DELAY_IN_MILLIS;
    }
    async addRecord(putRecordEntry) {
        this.records.push(_.clone(putRecordEntry));
        if (KinesisBatchServices.isAutoCommit() && this.records.length === this.batchSize) {
            const records = _.clone(this.records);
            this.reset();
            if (this.withRetry)
                await this.putBatchWithRetry(records);
            else
                await this.putBatch(records);
        }
    }
    async commit() {
        const chunks = _.chunk(this.records, this.batchSize);
        let sentRecords = 0;
        for await (const chunk of chunks) {
            sentRecords += this.withRetry ? await this.putBatchWithRetry(chunk) : await this.putBatch(chunk);
            if (_.size(chunk) === this.batchSize) {
                await (0, Util_1.delay)(this.delayInMillis);
            }
        }
        this.reset();
        return sentRecords;
    }
    async putBatch(records) {
        try {
            this.logger.debug(`Sending ${records.length} records to the ${this.streamName} stream`);
            await this.putRecords(records);
        }
        catch (err) {
            this.logger.error('Failed to send a chunk into the stream:', this.streamName, err);
            return 0;
        }
        return records.length;
    }
    async putBatchWithRetry(records) {
        this.logger.debug(`Sending ${records.length} records to the ${this.streamName} stream`);
        const retryUtil = new RetryUtil_1.RetryUtil(undefined, this.getRetryConfig());
        try {
            await retryUtil.executeWithRetry(async () => this.putRecordsWithFailedRecordCountCheck(records));
        }
        catch (e) {
            this.logger.error('Failed to send a chunk into the stream:', this.streamName, e);
            return 0;
        }
        return records.length;
    }
    getRetryConfig() {
        return {
            retries: 4,
            backoff: 'FIXED',
            delay: 300,
            retryIf: (err) => { var _a; return (_a = err.message) === null || _a === void 0 ? void 0 : _a.toLowerCase().includes('failed to put'); }
        };
    }
    reset() {
        this.records = [];
    }
    static isAutoCommit() {
        return _.isEqual(process.env.AUTO_COMMIT, 'true');
    }
}
exports.KinesisBatchServices = KinesisBatchServices;
KinesisBatchServices.DEFAULT_DELAY_IN_MILLIS = 1000;
