"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecretsService = void 0;
class SecretsService {
    init(scope) {
    }
    getSecret(key) {
        return this.getSecretByKey(key);
    }
    setSecretValue(key, value) {
    }
}
exports.SecretsService = SecretsService;
