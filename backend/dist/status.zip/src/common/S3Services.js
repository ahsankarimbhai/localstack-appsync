"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3Services = void 0;
const fs = __importStar(require("fs"));
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const LambdaLogger_1 = require("./LambdaLogger");
class S3Services {
    constructor(bucketName) {
        this.bucketName = bucketName;
        this.logger = new LambdaLogger_1.LambdaLogger();
        this.s3 = new client_s3_1.S3Client({ logger: this.logger });
    }
    getObject(key) {
        return this.s3.send(new client_s3_1.GetObjectCommand({
            Bucket: this.bucketName,
            Key: key
        }));
    }
    listObjects(prefix, maxKeys, continuationToken) {
        return this.s3.send(new client_s3_1.ListObjectsV2Command({
            Bucket: this.bucketName,
            MaxKeys: maxKeys,
            Prefix: prefix,
            ContinuationToken: continuationToken
        }));
    }
    listAllObjects(prefix) {
        const allObjects = [];
        const params = {
            Bucket: this.bucketName,
            Prefix: prefix
        };
        return this.listAllObjectsHelper(params, allObjects);
    }
    deleteObject(key) {
        return this.s3.send(new client_s3_1.DeleteObjectCommand({
            Bucket: this.bucketName,
            Key: key
        }));
    }
    async moveObject(sourceKey, destinationKey) {
        await this.s3.send(new client_s3_1.CopyObjectCommand({
            Bucket: this.bucketName,
            CopySource: `${this.bucketName}/${sourceKey}`,
            Key: `${destinationKey}`
        }));
        return this.deleteObject(sourceKey);
    }
    async listAllObjectsHelper(params, allObjects) {
        const response = await this.s3.send(new client_s3_1.ListObjectsV2Command(params));
        if (!response.Contents || response.Contents.length === 0) {
            return Promise.resolve(allObjects);
        }
        response.Contents.forEach(obj => allObjects.push(obj));
        if (response.NextContinuationToken) {
            params.ContinuationToken = response.NextContinuationToken;
            await this.listAllObjectsHelper(params, allObjects);
        }
        return Promise.resolve(allObjects);
    }
    uploadFile(objectName, filePath) {
        if (fs.existsSync(filePath)) {
            const stats = fs.statSync(filePath);
            if (stats.size === 0) {
                this.logger.debug(`skip uploading an empty file ${filePath}`);
            }
            else {
                this.logger.debug(`uploading object ${objectName} to bucket ${this.bucketName}`);
                return this.s3.send(new client_s3_1.PutObjectCommand({
                    Bucket: this.bucketName,
                    Key: objectName,
                    Body: fs.createReadStream(filePath)
                })).then((res) => {
                    this.logger.debug(res);
                    fs.unlinkSync(filePath);
                    this.logger.debug(`File ${filePath} deleted successfully`);
                });
            }
        }
        else {
            this.logger.error(`missing file to upload ${filePath}`);
            return Promise.reject(new Error(`missing file to upload ${filePath}`));
        }
        return Promise.resolve();
    }
    getSignedUrlForPutObject(destinationKey, expiration = S3Services.DEFAULT_SIGNED_URL_EXPIRATION_IN_SECONDS) {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: this.bucketName,
            Key: destinationKey
        });
        return (0, s3_request_presigner_1.getSignedUrl)(this.s3, command, { expiresIn: expiration });
    }
}
exports.S3Services = S3Services;
S3Services.DEFAULT_SIGNED_URL_EXPIRATION_IN_SECONDS = 60 * 15;
