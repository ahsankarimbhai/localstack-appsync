"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomSystemRuleService = void 0;
const RuleService_1 = require("../common/RuleService");
const CommonTypes_1 = require("../../common/CommonTypes");
const uuid_1 = require("uuid");
const ProducerSystemRuleService_1 = require("../common/ProducerSystemRuleService");
class CustomSystemRuleService extends ProducerSystemRuleService_1.ProducerSystemRuleService {
    constructor() {
        super(...arguments);
        this.sourceType = CommonTypes_1.Source.CUSTOM;
    }
    getSystemRules(sourceId) {
        const newRules = [];
        newRules.push({ ruleId: (0, uuid_1.v4)(), name: 'Custom Labels', description: 'Add labels from device', actionToTake: { addLabelsFromDevice: true }, matchingCondition: { producers: [{ type: this.sourceType, producerId: sourceId }] }, origin: RuleService_1.RuleOrigin.SYSTEM, enabled: true, hidden: true });
        newRules.push({ ruleId: (0, uuid_1.v4)(), name: 'Custom Value', description: 'Set asset value from device', actionToTake: { setAssetValueFromDevice: true }, matchingCondition: { producers: [{ type: this.sourceType, producerId: sourceId }] }, origin: RuleService_1.RuleOrigin.SYSTEM, enabled: true, hidden: true });
        return newRules;
    }
}
exports.CustomSystemRuleService = CustomSystemRuleService;
