"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelMetadataRepo = exports.LabelMetadataEntity = void 0;
const DynamodbServiceFactory_1 = require("../awsclient/dynamodb/DynamodbServiceFactory");
class LabelMetadataEntity {
    constructor(labelId, tenantId, color, name) {
        this.labelId = labelId;
        this.tenantId = tenantId;
        this.color = color;
        this.name = name;
    }
}
exports.LabelMetadataEntity = LabelMetadataEntity;
class LabelMetadataRepo {
    constructor() {
        this.dynamoDBServices = (0, DynamodbServiceFactory_1.getDynamoDBService)();
    }
    async isLabelWithAttrExist(tenantUid, attrName, attrValue) {
        const count = await this.dynamoDBServices.getCountByPartitionKeyAndAttribute(LabelMetadataRepo.TABLE_NAME, LabelMetadataRepo.HASH_KEY, tenantUid, attrName, attrValue);
        return count.Count > 0;
    }
    async getLabel(tenantUid, labelId) {
        return this.dynamoDBServices.getByCompositeKey(LabelMetadataRepo.TABLE_NAME, this.getCompositeKey(tenantUid, labelId));
    }
    getTenantLabels(tenantUid) {
        return this.dynamoDBServices.getByPartitionKey(LabelMetadataRepo.TABLE_NAME, LabelMetadataRepo.HASH_KEY, tenantUid);
    }
    async getAll() {
        return this.dynamoDBServices.getAllTableEntries(LabelMetadataRepo.TABLE_NAME);
    }
    async createLabel(label) {
        return this.dynamoDBServices.save(LabelMetadataRepo.TABLE_NAME, label);
    }
    async updateLabelMetadata(labelMetadata) {
        await this.dynamoDBServices.update(LabelMetadataRepo.TABLE_NAME, this.getCompositeKey(labelMetadata.tenantId, labelMetadata.labelId), { color: labelMetadata.color, name: labelMetadata.name });
    }
    async deleteLabel(tenantUid, labelId) {
        return this.dynamoDBServices.deleteByCompositeKey(LabelMetadataRepo.TABLE_NAME, this.getCompositeKey(tenantUid, labelId));
    }
    getCompositeKey(tenantIdValue, labelIdValue) {
        return { tenantId: tenantIdValue, labelId: labelIdValue };
    }
}
exports.LabelMetadataRepo = LabelMetadataRepo;
LabelMetadataRepo.TABLE_NAME = 'label-metadata';
LabelMetadataRepo.HASH_KEY = 'tenantId';
LabelMetadataRepo.ATTR_NAME = 'name';
